	/**
	 *  커스텀 파일 컴포넌트 초기화(원본파일 업로드용. 업로드후 이미지서버 url리턴)
	 * @param data
	 */
	_File.prototype.initCustom = function( data ) {

		var _self = this;
		var _ele = _self.ele;
		var _cfg = _self.cfg;
		
		// element 초기화
		var $fileListContainer = _ele.fileListContainer.clone();
		$fileListContainer.find('.fileAddBtn').attr('id', _self.cfg.browse_button);
		_ele.container.empty();
		_ele.container.append( $fileListContainer );

		// plupload 초기화
		_self.uploader = new plupload.Uploader({
			 runtimes 			: _cfg.runtimes
			,container			: _cfg.id
			,browse_button 		: _cfg.browse_button
			,max_file_size 		: '10mb'
			,url 				: '/sc/file/upload_custom'
			,multi_selection 	: false
			,filters 			: [{title : "Image files", extensions : "jpg,jpeg,gif,png"}]
		});
		
		$fileListContainer.find('.fileDelBtn').click( function() {
			
			if ($fileListContainer.find('.thumbnail').size() == 0) return false;
			
			if (!confirm('삭제하시겠습니까?')) return false;
			
			$fileListContainer.find('.thumbnailContainer').empty();
			$fileListContainer.attr('IMG_URL','');
			return false;
		});
		
		// plupload 초기화
		_self.uploader.init();
		
		// 데이터가 있을 경우 이미지 SRC 에 채워준다
		if( undefined != data && null != data ) {
			var idKey = _ele.container.attr('image-key');
			var nmKey = _ele.container.attr('image-name');
			$fileListContainer.find('.thumbnail').attr('src', '//img.fishapp.co.kr/'+data[idKey]);		
			$fileListContainer.attr('IMG_URL', data[idKey]);
		}

		// 파일 추가 이벤트
		_self.uploader.bind('FilesAdded', function(up, files) {

			// 초기화
			_self.uploader.files = files;
			$fileListContainer.find('.thumbnailContainer').empty();
			$fileListContainer.find('.thumbnailContainer').append( $('<img class="jdg-data-image thumbnail"/>') );
			$fileListContainer.attr('IMG_URL','');
			// 파일 업로드
			_self.uploader.start();
		});
		
		// 파일 업로드 성공 이벤트 (한 파일당 1회 발생)
		_self.uploader.bind('FileUploaded', function(up, file, response) {
			var data = JSON.parse(response.response);

			// 썸네일 추가
			$fileListContainer.find('.jdg-data-image').attr('src', '//img.fishapp.co.kr/'+data.IMG_URL);
			$fileListContainer.attr('IMG_URL',data.IMG_URL);
			// file 추가
			_self.file = data.IMG_URL;
		});
	};
	

	/**
	 *  커스텀 파일 리스트 컴포넌트 초기화(원본파일 업로드용. 업로드후 이미지서버 url리턴)
	 * @param data
	 */
	_FileList.prototype.initCustom = function( list ) {
		
		var _self = this;
		var _ele = _self.ele;
		var _cfg = _self.cfg;
		
		// element 초기화
		var $fileListContainer = _ele.fileListContainer.clone();
		var $fileList = $fileListContainer.find('.fileList');
		$fileListContainer.find('.fileAddBtn').attr('id', _self.cfg.browse_button);
		_ele.container.empty();
		_ele.container.append( $fileListContainer );
		
		// plupload 초기화
		_self.uploader = new plupload.Uploader({
			 runtimes 			: _cfg.runtimes
			,container			: _cfg.id
			,browse_button 		: _cfg.browse_button
			,max_file_size 		: '10mb'
			,url 				: '/sc/file/upload_custom'
			,filters 			: [{title : "Image files", extensions : "jpg,gif,png,jpeg"}]
		});

		// plupload 초기화
		_self.uploader.init();
		
		// 데이터가 있을 경우 수정Row에 채워준다
		if( undefined != list && null != list ) {
			var idKey = _ele.container.attr('image-key');
			var nmKey = _ele.container.attr('image-name');
			var fileList = jdg.util.toArray( list );
			for( var i=0, nMax=fileList.length ; i < nMax ; i++ ) {
				var imgUrl = fileList[i].IMG_ID;
				var $mRow = _ele.fileListRow.clone();

				$mRow.find('.thumbnail').attr('src','//img.fishapp.co.kr/' + imgUrl);		
				$mRow.attr('IMG_URL', imgUrl);
				$mRow.addClass('beforeRow');

				$mRow.find('.fileDelBtn').click( function() {					
					if (!confirm('삭제하시겠습니까?')) { return false;}				
					$fileList.find('li[IMG_URL="'+imgUrl+'"]').remove();
					return false;
				});

				$fileList.append( $mRow );
			}
		}

		// 파일 추가 이벤트
		_self.uploader.bind('FilesAdded', function(up, files) {
			if(!_cfg.multi_selection){
				var max_file = 5;
				if($fileList.find(".fileListRow").length >= max_file){
					alert("이미지는 "+max_file+"개만 업로드 가능합니다.");
					_self.uploader.splice();
					return false;
				}else{
					_self.uploader.start();
				}
			}else{
				_self.uploader.start();
			}
		});
		
		_self.uploader.bind('QueueChanged', function(up){
			console.log(up);
		});
			
		// 파일 업로드 성공 이벤트 (한 파일당 1회 발생)
		_self.uploader.bind('FileUploaded', function(up, file, response) {
		
			var data = JSON.parse(response.response);
			var $mRow = _ele.fileListRow.clone();

			// 썸네일 추가
			$mRow.find('.thumbnail').attr('src', '//img.fishapp.co.kr/'+data.IMG_URL);	
			$mRow.attr('IMG_URL',data.IMG_URL);

			console.log(_self.fileArray);
			// fileArray 추가
			_self.fileArray.push(data.FILE_ID);
			// 파일 삭제 이벤트
			$mRow.find('.fileDelBtn').on("click", function() {
				if (!confirm('삭제하시겠습니까?')) return false;
				// fileArray 삭제
				$fileList.find('[IMG_URL="'+data.IMG_URL+'"]').remove();
				return false;
			});
			$fileList.append( $mRow );
		});
		
	}
	
	
	