/*************************************************************************
  File Name  : common.js
  Description : 피쉬앱 공통 스크립트
 ***************************************************************************/
var jdg = {};

/**
 * 공통 Util
 */
jdg.util = {};

/**
 * validator
 * @param $container : 상위 element
 * @return
 **/
jdg.util.validator = function( $container, _trim ) {
	// 리턴값
	var _rFlag = true;
	// vType 속성 정의된 element만 validation check
	var $valList = $container.find('[vType]');
	
	$.each( $valList, function( idx, data ){
		var $this = $( this );
		var tagName = $this.prop('tagName');
		
		// 정의 속성
		var vType = $this.attr('vType');	// 타입	
		var vRequired = $this.attr('vRequired');	// 필수값 여부
		var vMaxLangth = $this.attr('vMaxlangth');	// 최대값
		var vMinLangth = $this.attr('vMinLangth');	// 최소값
		var vMessage = $this.attr('vMessage');	// 경고창용 메세지

		// element 별 value 추출
		var val = '';
		if( 'INPUT' === tagName || 'TEXTAREA' == tagName ) {
			val = $.trim( $this.val() );
		} else if( 'SELECT' === tagName ) {
			val = $.trim( $this.find('option:selected').val() );
		}
		
		// 필수값 체크
		if( 'true' === vRequired && '' === val ) {
			alert( vMessage + ' 을 입력해주세요' );
			_rFlag = false;
			return false;
		}
		// 타입 체크
		switch( vType ) {
			// 숫자
			case 'email' :
				if( '' !== val && ! /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(val) ) {
					alert( vMessage + ' 값은 형식이 유효하지 않습니다');
					_rFlag = false;
					return false;
				}
				break;
			case 'code' :
				if( '' !== val && !(/^[a-zA-Z0-9_]+$/.test(val)) ) {
					alert( vMessage + ' 값은 숫자, 영문, 언더바(_)로만 입력 가능합니다');
					_rFlag = false;
					return false;
				}
				break;
			case 'digits' :
				if( '' !== val && !(/^\d+$/.test(val)) ) {
					alert( vMessage + ' 값은 숫자로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'date' :
				if( '' !== val && ! /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(val) ){
					alert( vMessage + '  값은 날짜형식으로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'number' :
				if( ! /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(val) ) {
					alert( vMessage + ' 값은 숫자로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'bizRegNo' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{3}-?[0-9]{2}-?[0-9]{5}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo1' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{3}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo2' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{2}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo3' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{5}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;

			case 'tel' :
				if( $.trim( val ).length > 0 ){
					if( ! /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/.test(val) ){
						alert( vMessage + ' 번호가 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
				
			default :
				break;
		}
		
		// 최대값 체크
		if( '' !== val && val.length > vMaxLangth ) {
			alert( vMessage + ' 값은 '+vMaxLangth +'자리 이상 입력하실수 없습니다.' );
			_rFlag = false;
			return false;
		}
		
		// 최소값 체크
		if( '' !== val & val.length < vMinLangth ) {
			alert( vMessage + ' 값은 '+vMinLangth +'자리 이상 입력하셔야 합니다.' );
			_rFlag = false;
			return false;
		}
		
	});
	
	// 모든 validation 성공 수행 후, container trim
	if( _trim && _rFlag ) {
		$.each( $valList, function(){
			var $this = $( this );
			var tagName = $this.prop('tagName');
			if( 'INPUT' === tagName || 'TEXTAREA' == tagName ) {
				$this.val( $.trim( $this.val()) );
			}
		});
	}
	return _rFlag;
};


/**
 * detailDataSetting : JSON 형태의 상세데이터를 상세폼에 셋팅
 * @param $container : 상위 element
 */
jdg.util.detailDataSetting = function( $container, data ) {
	
	$.each( $container.find('[data-key]') , function() {
		var $this = $(this);
		var tagName = $this.prop('tagName');
		var dataStr = data[$this.attr('data-key')];
		var dataType = $this.attr('data-type');
		
		if( undefined == dataStr ) {
			dataStr = '';
		} else {
			if( '' !== dataStr ) {
				var commaFlag = $this.attr('addComma');
				var dataPrepend = $this.attr('data-prepend');
				var dataAppend = $this.attr('data-append');
				if( 'true'==commaFlag ) dataStr = jdg.util.addComma(dataStr);
				if( dataPrepend ) dataStr = dataPrepend + dataStr;
				if( dataAppend ) dataStr = dataStr + dataAppend;
			}
		}
		switch( tagName ) {
			case 'INPUT':
				$this.val( dataStr );
				break;
			case 'TEXTAREA' :
				if( dataStr != null && dataStr != undefined && dataStr != '' )
					dataStr = dataStr.replace(/<br>/g, '\n');
				$this.val( dataStr );
				break;
			case 'SELECT' :
				if( '' == dataStr ) $this.find('option:eq(0)').attr('selected', true);
				else $this.val( dataStr );
				break;
			case 'IMG' :
				if( '' !== dataStr ) {
					$this.attr('src' ,  dataStr );
					$this.show();
				} else {
					$this.attr('src' , '' );
					$this.hide();
				}
				break;
			default :
				$this.html( dataStr );
		}
	});
};




/**
 * Array로 형 변환
 * @param data
 * @returns list
 */
jdg.util.toArray = function( data ) {
	var list;
	if( data instanceof Array ) {
		list = data;
	} else {
		list = [];
		list.push( data );
	}
	return list;
};

/**
 * Client 날짜 더하기
 * @returns [YYYY-MM-DD]
 */
jdg.util.todayAdd = function(value) {
	var today = new Date();
	today.setDate(today.getDate() + value);	
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ;
};


/**
 * Client 오늘 날짜
 * @returns [YYYY-MM-DD]
 */
jdg.util.today = function() {
	var today = new Date();
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ;
};

/**
 * 받은 년수만큼 더하거나 뺀 날짜
 */
jdg.util.addYear = function(year){
	var today = new Date();
	today.setYear(today.getFullYear() + year);
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ; 
}

/**
 * 기준일의 다음 날짜
 * @param [YYYY-MM-DD]
 * @return [YYYY-MM-DD]
 */
jdg.util.tommorow = function( today ) {
	
	
	var tommorow = today;
	var date = new Date();
	var todayYear = today.substr(0,4);
	var todayMonth = parseInt(today.substr(5,7))-1;
	var todayDate = today.substr(8,10);
	
	date.setFullYear(todayYear, todayMonth, todayDate);
	date.setDate( Number(todayDate)+1 );
	var tommorowYear = date.getFullYear();
	var tommorowMonth = date.getMonth()+1;
	var tommorowDate = date.getDate();
	return tommorowYear + '-' 
		+ ((tommorowMonth < 10) ? ('0' + tommorowMonth) : tommorowMonth) + '-'
		+ ((tommorowDate < 10) ? ('0' + tommorowDate) : tommorowDate);
};


/**
 * 날짜 포맷 변경
 * @param date: string 형태의 날짜 DATE
 * @return 변환된 포맷형식의 string DATE
 */
jdg.util.replaceDate = function( date, type, str ) {
	var returnDate = date;
	if( undefined != date ) {
		var str = str ? str : '-';
		var size = date.length;
		var year = date.substring(0,4);
		var month = date.substring(4,6);
		var day = date.substring(6,8);
		if(  size == 8 ) {
			returnDate = year + str + month + str + day;
		} else if( size >= 12 ) {
			var hour = date.substring(8,10);
			var minute = date.substring(10,12);
			returnDate = year + str + month + str + day + " " + hour + ":" + minute;
		}
		
		if (type != undefined) {
			switch (type) {
			case 'yymmdd':
				returnDate = year + str + month + str + day;
				break;

			default:
				returnDate = year + str + month + str + day + " " + hour + ":" + minute;
				break;
			}
		}
	}
	return returnDate;
};


/**
 * 숫자 천단위 콤마 넣기
 * @param num: 변환할 숫자
 */
jdg.util.addComma = function( num ) {
	var reg = /(^[+-]?\d+)(\d{3})/;
	num = $.trim(num);
	while (reg.test(num)) {
		num = num.replace(reg, '$1' + ',' + '$2');
	}
	return num;
};


/**
 * 사업자 등록번호 변환
 * @param num: 변환할 숫자
 */
jdg.util.replaceRegNo = function( num ) {
	var reg = /([0-9]{3})([0-9]{2})([0-9]{5})/;
	num = $.trim(num);
	num = num.replace(reg, "$1-$2-$3");
	return num;
};

/**
 * 사업자 등록번호 변환
 * @param num: 변환할 숫자
 */
jdg.util.setRegNo = function( reg1Obj, reg2Obj, reg3Obj, regNo ) {
	var strArrayRegNo;
	
	var replaceRegNo = jdg.util.replaceRegNo( regNo );
	
	if( regNo.indexOf('-') < 0 ){					
		strArrayRegNo = replaceRegNo.split('-');
	} else {
		strArrayRegNo = regNo.split('-');
	}
	
	
	reg1Obj.val(strArrayRegNo[0]);
	reg2Obj.val(strArrayRegNo[1]);
	reg3Obj.val(strArrayRegNo[2]);
};

/**
 * 테이블 colroup width 일괄 지정
 * @param
 * @returns 
 * 1. class="jdg-cmpt-list" 테이블에 대해서만 적용됩니다.
 * 2. col에 사이즈가 지정된 속성 name 을 추가해주세요
 */
jdg.util.resizeColgroupWidth = function() {
	var $colGroup = $('.jdg-cmpt-list').find('col');
	$.each( $colGroup, function() {
		var $this = $( this );
		var name = $this.attr('name');
		switch( name ) {
			case 'ID' :
				$this.attr('width', 90);
				break;
			case 'CREATED':
				$this.attr('width', 180);
				break;
		}
	});
};

/**
 * 레이어 가져오기
 */
jdg.util.getLayer = function( layerId ) {
	var $layer = $('#' + layerId);
	var _state = $('#state').val();
	if("/sc" != _state){
		_state = _state + $('#shipId').val();
	}
	
	if($layer.size() == 0 || $layer == null){ //해당레이어가 없을땐 가져와서 body에 append
		$.post(_state + '/layerPopup' , function(data) {
			if(data != null || data != ""){
				$layer = $(data).filter('#' + layerId).hide();
				//close 이벤트 등록
				$layer.find('.jdg-btn-close').click(function(){
					$layer.hide();
				});
				$('body').append($layer);
			}
		});
	}else{
		return false;
	}
};

/**
 * 전화번호 포맷 변환
 * @param (ex:01011111111)
 * @return "010-1111-1111"
 */
jdg.util.setPhonNumber = function( pNum ) {
	return pNum.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,"$1-$2-$3");
};

/**
 * 전화번호 set value
 */
jdg.util.setTelNum = function(tel1Obj, tel2Obj, tel3Obj,telNum) {
	
	if (telNum == null)
	{
		//tel1Obj.val('').attr("selected", "selected");	

		tel2Obj.val('');	

		tel3Obj.val('');			
	}
	else if( telNum.indexOf('-') > 0 ){					
		var strArrayTelNo = telNum.split('-');
		
		tel1Obj.val(strArrayTelNo[0]).attr("selected", "selected");	

		tel2Obj.val(strArrayTelNo[1]);	

		tel3Obj.val(strArrayTelNo[2]);	
	}
};

/**
 * 말줄임
 * @param str : 변환할 string
 * @param int : 해당 자릿수보다 길 경우 말줄임한 string을 리턴한다
 */
jdg.util.setStringOverview =function( str, int ) {
	var result = str + '';
	if( result.length > int ) {
		result = result.substring(0, int) + '...';
	}
	return result;
};

/**
 * 자릿수채우기
 * @param str : 변환할 string
 * @param int : 해당 자릿수만큼 0을 채워준다
 */
jdg.util.setStringFillZero = function( str, int ) {
	var result = str + '';
	if( result.length < int ) {
		for( var i=0 ; i < int-1 ; i++ ) {
			result = '0' + result;
		}
	}
	return result;
};

/**
 * placeholder와 같은 기능(placeholder가 ie저버전에서 안먹히는 버그 때문에 만듬)
 * @param $obj : placeholder 적용할 객체(input type이 text와 password만 가능)
 * @param message : 사용할 글귀
 */
jdg.util.setPlaceHolder = function( $obj, message ) {
	if( $obj.attr('type') == "text" ){
		$obj.val(message);
		
		$obj.bind("focus blur",function(e){
			var textVal = $obj.val();
			
			if(e.type == "focus") {
				if( textVal == message ){
					$obj.val("");
				}
			}
			else {
				if( textVal == "" ){
					$obj.val(message);
				}
			}
		});
	}else if( $obj.attr('type') == "password" ){//password는 기본적으로 placeholder가 적용 안되기때문에 text로 보여지고 포커스시 password로 치환한다
		$obj.replaceWith($obj.clone(true).attr('type','text').addClass('placeholderPw').val(message));
		$obj = $('.placeholderPw');
		
		$obj.bind("focus blur",function(e){
			var pwTxtVal = $obj.val();

			if(e.type == "focus") {
				if( pwTxtVal == message ){
					$obj.replaceWith($obj.clone(true).val("").attr('type','password'));
					$obj = $('.placeholderPw');
					$obj.focus();
				}
			}
		});
	}else{
		return "placeholder를 사용할수 없는 객체입니다.";
	}
};


/**
 * 한 페이지에 보여질 목록수 쿠기 저장
 * @param cnt 		: URL 페이지 목록 수 
 * @param term 		: 쿠기에 저장될 날짜(일) 수
 */
jdg.util.setItemCnt = function() {
	if( $.cookie('itemCnt') == null )
		$.cookie('itemCnt', 5);
	
	if( $('#itemCnt').val() != undefined && $('#itemCnt').val() != null && $('#itemCnt').val() != '' ){
		$.cookie('itemCnt', $('#itemCnt').val());
	}

	result = $.cookie( 'itemCnt' );
	return result;
};

/**
 * @Item의 내용을 파라미터 길이 대로 자르고 '...'을 붙여 리턴하는 함수,
 * @param item		: 타겟 컨텐츠
 * @param sIndex	: 자르기 위한 시작위치
 * @param sLen		: 자르기 위한 길이
 * @param addStr	: 자르고 나서 붙일 문자열
 */
jdg.util.subStr = function(item, sIndex, sLen, addStr){
	if( item == null )
		return item;
	if( item == undefined )
		return item;
	if( item == '' )
		return item;
	if( item.length < sLen )
		return item;
	return item.substr(sIndex, sLen - 1) + addStr;
};

/**
 * @이미지 상위에 있는 컨테이너 사이즈에 들어가도록 이미지태그를 비율 유지하며 리사이즈
 * @param $container		: 이미지 상위 div
 * @param width	: 원본 이미지 가로
 * @param height	: 원본 이미지 세로
 */
jdg.util.setImgRatio = function($container, width, height){
//    $(window).resize(function(){
    	var maxWidth = $container.width();   
        var maxHeight = $container.height();   
        
        width = (typeof width == "string")? Number(width) : width;
        height = (typeof height == "string")? Number(height) : height;
        
        // 가로나 세로의 길이가 최대 사이즈보다 크면 실행
        if(width > maxWidth || height > maxHeight){
           if(width > height){ // 가로가 세로보다 크면 가로는 최대사이즈로, 세로는 비율 맞춰 리사이즈
              resizeWidth = maxWidth;
              resizeHeight = Math.round((height * resizeWidth) / width);
              
              if(resizeHeight > maxHeight){ 
            	  resizeHeight = maxHeight;
                  resizeWidth = Math.round((width * resizeHeight) / height);
              }
           }else{// 세로가 가로보다 크면 세로는 최대사이즈로, 가로는 비율 맞춰 리사이즈
              resizeHeight = maxHeight;
              resizeWidth = Math.round((width * resizeHeight) / height);
              
              if(resizeWidth > maxWidth){
            	  resizeWidth = maxWidth;
                  resizeHeight = Math.round((height * resizeWidth) / width);
              }
           }
        }else{// 최대사이즈보다 작으면 원본 그대로
           resizeWidth = width;
           resizeHeight = height;
        }
        
        $container.find('img').attr({width:resizeWidth, height:resizeHeight});  
//   }).resize();
};



/**
 * 일괄치환
 * @replaceAll
 */
String.prototype.replaceAll = function( str1, str2 ) {
	var temp_str = '';
	if( this.trim() != '' && str1 != str2 ) {
		temp_str = this.trim();
		while( temp_str.indexOf(str1) > -1 ) {
			temp_str = temp_str.replace(str1, str2);
		}
	}
	return temp_str;
};

/**
 * 시작일이 월요일때의 getWeek()
 * @returns
 */
Date.prototype.getMondayWeek = function() {
    var determinedate = new Date();
    determinedate.setFullYear(this.getFullYear(), this.getMonth(), this.getDate());
    var D = determinedate.getDay();
    // 시작일이 월요일때의 처리
    if(D == 0) {
    	D = 7;
    }
    determinedate.setDate( determinedate.getDate() + (4 - D) );
    var YN = determinedate.getFullYear();
    var ZBDoCY = Math.floor((determinedate.getTime() - new Date(YN, 0, 1, -6)) / 86400000);
    var WN = 1 + Math.floor(ZBDoCY / 7);
    ( 10 > WN ) && ( WN = '0' + WN ); 
    return Number( YN + '' + WN );
};

/**
 * 시작일이 일요일때의 getWeek()
 * @returns
 */
Date.prototype.getSundayWeek = function() {
	var dayOfMonth = this.getDate();	
	var first = new Date( this.getFullYear(), this.getMonth(), 1 );
	var monthFirstDateDay = first.getDay();	
	return Math.ceil( (dayOfMonth + monthFirstDateDay) / 7 );
};


function recvImage( ImageID ) {
	
	    var file = {name: ImageID + '.jpg', id:ImageID};
	
		var rsp = {};
		rsp.response = '{"FILE_ID": "' + ImageID + '"}';
	
		Bplat.viewPkg.BplatBody.fileList.uploader.trigger('FileUploaded',file, rsp);	
}



function autoDataGetter(comp)
{
 var key;
 var childComp;
 var value;
 
 var retObject = {};
 
 var childs = comp.find("em,input,checkbox,select,textarea"); 
 var size = childs.length;
 
 for (var idx = 0; idx < size; idx++)
 {
	  childComp = $(childs[idx]);
	  
	  key = childComp.data('key');  
	  fmt = childComp.data('format');
	  
	  if (key == null)
	  {
		  continue;
	  }
	 	
	  if (childComp.is("em"))
	  {
		  value = childComp.text();
	  }
	  else if (childComp.is(":checkbox"))
	  {
		  value = childComp.attr('checked') ? "Y" : "N";
	  }
	  else
	  {
		  value = childComp.val();
	  }	  
	  
	  if (childComp.css('display') == 'none' && value == "")
	  {
		  continue;
	  }	  
	  
	  if (value != null)
	  {
		  retObject[key] = value.trim();
	  }  
	  
	  if (childComp.is("select"))
	  {
		  retObject[key + "_TEXT"] = childComp.find('option:selected').text();
	  }
 }
 
 return retObject;

}

function autoDataSetter(comp, data)
{
 var key;
 var childComp;
 var value;
 
 var fmt;
 
 var childs = comp.find("[data-key]"); 
 var size = childs.length;
 
 for (var idx = 0; idx < size; idx++)
 {
	  childComp = $(childs[idx]);
	  
	  key = childComp.data('key'); 
	  fmt = childComp.data('format'); 
	  
	 
	  value = data[key];
	  
	  if (value == null)
	  {
		  value = "";
	  }
	  
	  if (fmt != null && value.length >= 8)
	  {
		  value = strToDateString(value);
	  }
	  
	  if (childComp.is(":checkbox"))
	  {
		  var chk = (value != null && value == "Y");
		  childComp.attr('checked', chk);		  
	  }	  
	  else if (childComp.is("select") || childComp.is("textarea") || childComp.is("input"))
	  {
		  childComp.val(value);
	  }
	  else
	  {
		  childComp.html(value);
	  }

 }

}




function checkData(cond, err_msg)
{
	if (cond)
	{
		throw err_msg;
	}
}

function setupEtcInput(form, data)
{
	 var selectObjs = $("select[data-handle]");
	
	 var size = selectObjs.length;
	 var selObj;
	 var inpObj;
	 var value;
	 var inpFieldName;
	 
	 for (var idx = 0; idx < size; idx++)
	 {
		 selObj = $(selectObjs[idx]);
		 inpFieldName = selObj.data('handle');
		 inpObj = form.find('input[data-key=' + inpFieldName + ']');
		 value = data[selObj.data('key')];
		 
		if (value == undefined)
		{
			value = "";
		} 
		
		if (value == 'etc')
		{
			inpObj.val(data[inpFieldName]);
		}
		else if (selObj.val() == "" && value != "")
		{
			selObj.val('etc');
			inpObj.val(value);
		}
		else
		{
			inpObj.val('');
			inpObj.hide();
		}	 
		 
	 }
}


function dateToString(dt)
{
	return dt.getFullYear() + '-' + jdg.util.setStringFillZero(dt.getMonth() + 1,2) + '-' + jdg.util.setStringFillZero(dt.getDate(),2);
}

function strToDateString(str)
{
	return str.substr(0,4) + '-' + str.substr(4,2) + '-' + str.substr(6,2) ;
}


function getCurrDateString()
{
	var dt = new Date();	
	return dt.getFullYear() + jdg.util.setStringFillZero(dt.getMonth() + 1,2) + jdg.util.setStringFillZero(dt.getDate(),2);
}


function addMovieUrl(container)
{
	
	var youtubeUrl = prompt("유튜브 공유주소를 입력하세요.\n예: https://youtu.be/SZKFdDDMk4Q","");
	var imgUrl = "";

	if (youtubeUrl == "" || youtubeUrl == null)
	{
		return false;
	}
	
	youtubeUrl = youtubeUrl.replaceAll("https", "http");	
	
	var vid = youtubeUrl.match('youtu.be') ? youtubeUrl.substring(16, 30):youtubeUrl.substring(31, 45);		
	imgUrl = "https://img.youtube.com/vi/" + vid + "/0.jpg";		
	
	var fileList = container.fileList.getFileList() ;
	
	for (var idx in fileList) 
	{
		if (fileList[idx].IMG_ID == vid)
			{
				alert('이미 추가되어 있는 동영상입니다.');
				return false;
			}
	}

	var img = $("<img />").attr('src', imgUrl)
    .load(function() {
        if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth < 130) {
        	alert("유튜브 공유주소가 잘못었습니다..");
            return false;
        }
        else
        {
			var mrow = container.$movieListRow.clone();
			
			mrow.find('#vfrm').attr('src', "//www.youtube.com/embed/" + vid);
			mrow.attr('IMG_ID',vid);					
			
			mrow.find('.fileName').val( youtubeUrl );
			
			mrow.find('.fileDelBtn').click( function() {
				// fileArray 삭제
				event.preventDefault();
				
				if (this.parentElement.className == "movieListRow")
				 {
					this.parentElement.remove();
				 }
				else if (this.parentElement.parentElement.className == "movieListRow")
				{
					this.parentElement.parentElement.remove();
				}
				
				
			});
			
			$('.fileListContainer').find('.fileList').append(mrow);
			
			return false;
        	
        }
    });

	return false;
}


function changeResizeMovieFrame()
{
	var bWidth = $(document.body).width();
	
	var iWidth = bWidth - 40;
	
	if (iWidth > 500)
	{
		iWidth = 500;
	}
	
	var iHeight = iWidth * 0.63;
	

	$(".movIframe").width(iWidth);
	$(".movIframe").height(iHeight);

}


function resizeMovieFrame()
{
	if ($(".movIframe") != null)
	{
		changeResizeMovieFrame();
		
		$(window).resize(function(){					
			changeResizeMovieFrame();
		});		
		
	}
}

// 다수의 엘리먼트중 선택된 엘리먼트를 이동
// 한칸 위로 갈때는 -1, 한칸 아래로 갈때는 +1
function changeElementIndex(btnObj, c)
{
	if (c == null || isNaN(c)) return;
	
	var me = $(btnObj).parent();
	var brothers = me.parent().children();
	var cnt = brothers.length;
	var idx = me.index();
	
	if (c == -1)
		{
			if (cnt == 1 || idx == 0) return;		
			brothers.eq(idx - 1).before(me);
		}
	else if (c == +1)
		{
			if (idx == cnt - 1) return;	
			brothers.eq(idx + 1).after(me);		
		}

}

function stopEvent(evnt) {
	   if(evnt.stopPropagation) {
	      evnt.stopPropagation(); // FF
	   } else {
	      evnt.cancleBubble=true; // IE
	   }
	}

function popupScrollOpenWidth(url, title, width, height){
	popupOpen(url,title,width, height,', scrollbars=yes,resizable=yes,fullscreen=no');
}


function popupScrollOpen(url){
	popupOpen(url,'선박관리자',screen.width, screen.height,', scrollbars=yes,resizable=yes,fullscreen=no');
}


function popupFullScreen(url)
{
    popupOpen(url,'선박관리자',screen.width, screen.height,',fullscreen=yes,scrollbars=yes');
}

function popupOpen(url,titleTxt,wdt,hgt, attr)
{
	if (attr == null)
	{
		attr = "";
	}
	
    var win = window.open(url,titleTxt, 'height=' + hgt + ',width=' + wdt+ attr);    
    
    if (win == null)
    {
    	alert('팝업이 차단되어 있습니다. 팝업차단을 해제해주십시오.');
    }
    else
    {
    	win.focus();
    }
}


function rgb2hex(rgb) {
    rgb = Array.apply(null, arguments).join().match(/\d+/g);
    rgb = ((rgb[0] << 16) + (rgb[1] << 8) + (+rgb[2])).toString(16);

    return rgb;
};


function preventEvent(e)
{
	if (e.preventDefault) {
	    e.preventDefault();
	} else {
	    e.returnValue = false;
	}	

}

function isHoliday(dateval)
{
	var holistr = null;
	var dateYear = dateval.substr(0,4);
	
	if (dateYear == '2019')
	{
		holistr = "0101,0204,0205,0206,0301,0506,0606,0815,0912,0913,1003,1009,1225";	
	}
	else if (dateYear == '2020')
	{
		holistr = "0101.0124,0127,0430,0505,0930,1001,1002,1009,1225";
	}
	else if (dateYear == '2021')
	{
		holistr = "0101.0211,0212,0301,0505,0519,0920,0921,0922";
	}
	else if (dateYear == '2022')
	{
		holistr = "0101.0131,0201,0202,0301,0505,0606,0815,0909,0912,1003";
	}

	if (holistr)
	{
		var dateMd = dateval.substr(4,4);
		
		return holistr.indexOf(dateMd, 0) >= 0;
	}
	
	return false;
}