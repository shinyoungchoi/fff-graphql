/*************************************************************************
  File Name  : component.js
  Description : 피쉬앱 공통 컴포넌트
 ***************************************************************************/

/**
 * Component 정의
 */
var component = {
	 'List' : _List
	,'FileList' : _FileList
	,'File' : _File
};


/**
 * 리스트 속성 정의
 * @param p_properties
 */
function _List( p_properties ) {
	 
	// validation
	 if( null == p_properties.container || null == p_properties.template ) {
		 throw new Error( '리스트 속성이 정의 되어 있지 않습니다.' );
		 return false;
	 }
	 
	 // p_properties에 대한 디폴트 값 정의
	 var defaultProperties = {
		  'container'	: null
		 ,'template'	: null
		 ,'nodata'		: null
	 };
	 
	 // Element 목록 정의
	 this.ele = $.extend( defaultProperties, p_properties );
	 
	 // listData 정의
	 this.listData = [];
};

/**
 * 리스트 생성 함수
 * @param list
 * @param rowKey
 * @param _func
 */
_List.prototype.createList = function( list, rowKey, _func , _afterFunc) {
	
	var _ele = this.ele;
	var _context = $('#context').val();
	var _state = $('#state').val();
	if(_state && "/sc" != _state && "/cc" != _state.substr(0,3)){
		_state = _state + $('#shipId').val();
	}
	
	// Array 형변환
	var listArray = jdg.util.toArray( list );

	
	// 저장
	this.listData = listArray;
	
	// 컨테이너 초기화
	var $container = _ele.container;
	$container.empty();
	var dataSize = listArray.length;
	 
	// nodata 추가
	if( dataSize <= 0 && null != _ele.nodata ) {
		$container.append( _ele.nodata.clone() );
	} 
	
	// 리스트 생성
	else {	
		for( var i=0 ; i < dataSize ; i++ ) {
			 var data = listArray[i];
			 var $row = _ele.template.clone();
			 $.each( $row.find('[data-key]'), function() {
				var $this = $(this);
				var dataStr = data[$this.attr('data-key')];
				if( undefined != dataStr && null != dataStr && '' != dataStr ) {
					var commaFlag = $this.attr('addComma');
					var dataPrepend = $this.attr('data-prepend');
					var dataAppend = $this.attr('data-append');
					if( 'true'==commaFlag ) dataStr = jdg.util.addComma(dataStr);
					if( dataPrepend ) dataStr = dataPrepend + dataStr;
					if( dataAppend ) dataStr = dataStr + dataAppend;
				}
				$this.html( dataStr );
			 });
			 var width = _ele.template.find('[image-key]').width();
			 $.each( $row.find('[image-key]'), function() {
					var $this = $(this);
					var dataStr = data[$this.attr('image-key')];
					if( undefined == dataStr ) 
						$row.find('img').attr('src', _context + '/resources/bc/img/img_blank.png');
					else 
						$this.attr('src', '/cm/file/image/' + dataStr + '/' + width);
			 });
			 //  call back function
			 if( $.isFunction(_func) ) {
				 _func( data, $row );
			 }
			 // ROW KEY 지정
			 if( rowKey || null != rowKey )  $row.attr('rowKey', data[rowKey]);
			 $container.append( $row );
			 
			 if( $.isFunction(_afterFunc) ) {
				 _afterFunc( data, $row );
			 }
		}
	}
};


/**
 * 리스트 추가 함수
 * @param list
 * @param rowKey
 * @param _func
 */
_List.prototype.appendList = function( list, rowKey, _func ) {
	
	var _ele = this.ele;
	var _context = $('#context').val();
	var _state = $('#state').val();
	if("/sc" != _state){
		_state = _state + $('#shipId').val();
	}
	
	// Array 형변환
	var listArray = jdg.util.toArray( list );
	
	// 저장
	//this.listData = listArray;
	
	// 컨테이너 초기화
	var $container = _ele.container;
	var dataSize = listArray.length;
	 
	// nodata 추가
	if( dataSize <= 0 && null != _ele.nodata ) {

	} 
	
	// 리스트 생성
	else {	
		for( var i=0 ; i < dataSize ; i++ ) {
			 var data = listArray[i];
			 var $row = _ele.template.clone();
			 $.each( $row.find('[data-key]'), function() {
				var $this = $(this);
				var dataStr = data[$this.attr('data-key')];
				if( undefined != dataStr && null != dataStr && '' != dataStr ) {
					var commaFlag = $this.attr('addComma');
					var dataPrepend = $this.attr('data-prepend');
					var dataAppend = $this.attr('data-append');
					if( 'true'==commaFlag ) dataStr = jdg.util.addComma(dataStr);
					if( dataPrepend ) dataStr = dataPrepend + dataStr;
					if( dataAppend ) dataStr = dataStr + dataAppend;
				}
				$this.html( dataStr );
			 });
			 var width = _ele.template.find('[image-key]').width();
			 $.each( $row.find('[image-key]'), function() {
					var $this = $(this);
					var dataStr = data[$this.attr('image-key')];
					if( undefined == dataStr ) 
						$row.find('img').attr('src', _context + '/resources/bc/img/img_blank.png');
					else 
						$this.attr('src', _context + _state + '/file/image/' + dataStr + '/' + width);
			 });
			 //  call back function
			 if( $.isFunction(_func) ) {
				 _func( data, $row );
			 }
			 // ROW KEY 지정
			 if( rowKey || null != rowKey )  $row.attr('rowKey', data[rowKey]);
			 $container.append( $row );
		}
	}
};


/**
 * 목록에서 데이터를 조회 (Key 1개)
 * @param key
 * @param code
 */
_List.prototype.getListRowData = function( key, code ) {
	var listArray = this.listData;	
	for( var i=0, iSize=listArray.length; i < iSize ; i++ ) {
		if(key == listArray[i][code]) {
			console.log(listArray[i]);
			return listArray[i];
		}
	}
};

/**
 * 목록에서 데이터를 조회 (Key 2개)
 * @param key1
 * @param code1
 * @param key2
 * @param code2
 */
_List.prototype.getListRowDataFromDouble = function( key1, code1, key2, code2 ) {
	var listArray = this.listData;
	for( var i=0, iSize=listArray.length; i < iSize ; i++ ) {
		if( (key1 == listArray[i][code1]) && (key2 == listArray[i][code2]) ) {
			return listArray[i];
		}
	}
};





/**
 * 파일리스트 속성 정의
 * @param p_properties
 */
function _FileList( p_properties ) {
	
	// validation!
	if( null == p_properties.id || null == p_properties.container ) {
		throw new Error( '파일 리스트 속성이 정의 되어 있지 않습니다.' );
		return false;
	}
	
	// Uploader 정의
	this.uploader = null;
	
	// FILE_ID 저장
	this.fileArray = [];
	
	// Element 목록 정의
	this.ele = {
		  'container' 		 : p_properties.container
		 ,'fileListContainer' : $('#commonTemplate').find('.fileListContainer')
		 ,'fileListRow' : $('#commonTemplate').find('.fileListRow')
		 ,'movieListRow' : $('#commonTemplate').find('.movieListRow')
	};
	
	// 기본 설정값 정의
	this.cfg = {
		 'runtimes'			 : 'gears,html5,flash,silverlight,browserplus'
		,'id' 				 : p_properties.id
		,'browse_button' 	 : p_properties.id + 'Btn'
		,'uploadURL' 		 : $('#imgUploadURL').val()
		,'deleteURL'		 : $('#imgDeleteURL').val()
		,'flashURL' 		 : $('#pluploadFlashScfURL').val()
		,'silverURL' 		 : $('#pluploadSilverlightXapURL').val()
		,'multi_selection'   : true
		,'max_file' 		 : 100
	};
	
	if(p_properties.selection == 'N'){
		this.cfg.multi_selection = false;
		this.cfg.max_file = p_properties.max_file;
	}
	// plupload IE10 버그 해결을 위한 runtime 강제 지정
	if(navigator.userAgent.toLowerCase().indexOf("msie") > -1) { // if IE
		this.cfg.runtimes = 'flash';
	}
	
	// context 정의
	this.context = $('#context').val();
	var state = $('#state').val();
	if("/sc" != state){
		state = state + $('#shipId').val();
	}
	this.state = state;
	
};

/**
 * 파일 리스트 초기화
 * @param list
 */
_FileList.prototype.init = function( list ) {
	
	var _self = this;
	var _ele = _self.ele;
	var _cfg = _self.cfg;
	
	// element 초기화
	var $fileListContainer = _ele.fileListContainer.clone();
	var $fileList = $fileListContainer.find('.fileList');
	$fileListContainer.find('.fileAddBtn').attr('id', _self.cfg.browse_button);
	_ele.container.empty();
	_ele.container.append( $fileListContainer );
	
	// plupload 초기화
	_self.uploader = new plupload.Uploader({
		 runtimes 			: _cfg.runtimes
		,container			: _cfg.id
		,browse_button 		: _cfg.browse_button
		,max_file_size 		: '20mb'
		,url 				: _cfg.uploadURL
		,multi_selection 	: _cfg.multi_selection
		,flash_scf_url 		: _cfg.flashURL
		,silverlight_xap_url: _cfg.silverURL
		,filters 			: [{title : "Image files", extensions : "jpg,gif,png,jpeg"}]
	});
	
	// plupload 초기화
	_self.uploader.init();
	
	// 데이터가 있을 경우 수정Row에 채워준다
	if( undefined != list && null != list ) {
		var idKey = _ele.container.attr('image-key');
		var nmKey = _ele.container.attr('image-name');
		var fileList = jdg.util.toArray( list );
		for( var i=0, nMax=fileList.length ; i < nMax ; i++ ) {
			var data = fileList[i];
			var $mRow = _ele.fileListRow.clone();
			
			
			var imgId = data[idKey];
			if (imgId == null) imgId = data.IMG_ID;
		
			if (data.MOVIE_YN != undefined && data.MOVIE_YN == "Y")
			{
			    var ifrmUrl = 'https://www.youtube.com/embed/' + data.IMG_ID;
				var ifrmCon = _ele.movieListRow.find('iframe').parent().clone();
				ifrmCon.find('iframe').attr('src',ifrmUrl);
				
				$mRow.find('.thumbnail').replaceWith(ifrmCon);
				$mRow.attr('data-type','mov');
				$mRow.find('.fileName').val( ifrmUrl );
			}
			else
			{
				var imgUrl;
				
				if (data.HOSTING_URL)
				{
					imgUrl = data.HOSTING_URL.replace('/a.', '/w260/a.');
				}
				else if(imgId.substr(0,5) == "https"){
					imgUrl = imgId;
				}
				else
				{
					imgUrl = (imgId.substr(0,6) == "HOMEBG")? '//img.fishapp.co.kr/legacy/bg/'+ imgId +'.jpg' : '/cm/file/image/'+ imgId +'/thumbnail';
				}
				
				
				$mRow.find('.thumbnail').attr('src', imgUrl);		

				if( data.FILE_NAME != undefined )
					$mRow.find('.fileName').val( data.FILE_NAME );
				else if( data.IMG_NAME != undefined )
					$mRow.find('.fileName').val( data.IMG_NAME );
				
				$mRow.attr('HOSTING_URL', data.HOSTING_URL);
			}
			
			$mRow.attr('IMG_ID', imgId);
			$mRow.addClass('beforeRow');
			
			$mRow.find('.fileDelBtn').attr('IMG_ID', imgId);
			$mRow.find('.fileDelBtn').click( function() {
				
				if (!confirm('삭제하시겠습니까?')) { return;}				
				
				$fileList.find('[IMG_ID="'+$(this).attr('IMG_ID')+'"]').remove();
				return false;
			});
			$mRow.find('textarea').val( data.CONTENT );
			if( 'Y' === data.MAIN_YN ) {
				$mRow.find('[name=mainImage]').attr('checked',true);
				var $mainImgFlag = $mRow.find('[data-type=mainImage]'); 
				if( $mainImgFlag.length > 0 ){
					$mainImgFlag.removeClass('jdg-disabled-flag').addClass('jdg-select-flag');
				}
			}
			$fileList.append( $mRow );
		}
	}

	// 파일 추가 이벤트
	_self.uploader.bind('FilesAdded', function(up, files) {
		if(!_cfg.multi_selection){
			var max_file = _cfg.max_file;
			if($fileList.find(".fileListRow").length >= max_file){
				alert("이미지는 "+max_file+"개만 업로드 가능합니다.");
				_self.uploader.splice();
				return false;
			}else{
				_self.uploader.start();
			}
		}else{
			console.log("must");
			_self.uploader.start();
		}
	});
	
	_self.uploader.bind('QueueChanged', function(up){
		console.log(up);
	});
		
	// 파일 업로드 성공 이벤트 (한 파일당 1회 발생)
	_self.uploader.bind('FileUploaded', function(up, file, response) {
	
		var data = JSON.parse(response.response);
		var $mRow = _ele.fileListRow.clone();
		var _state = $('#state').val();
		if("/sc" != _state){
			_state = _state + $('#shipId').val();
			// 파일명
			$mRow.find('.fileName').val( file.name );
		}
		// 썸네일 추가
		$mRow.find('.thumbnail').attr('src', '/cm/file/image/'+data.FILE_ID+'/thumbnail');		
		$mRow.attr('IMG_ID',data.FILE_ID);
		console.log(_self.fileArray);
		// fileArray 추가
		_self.fileArray.push(data.FILE_ID);
		// 파일 삭제 이벤트
		$mRow.find('.fileDelBtn').on("click", function() {
			
			// fileArray 삭제
			$fileList.find('[IMG_ID='+data.FILE_ID+']').remove();
			$.ajax({
				 url : _self.cfg.deleteURL
				,type : 'POST'
				,data : {'FILE_ID' : data.FILE_ID}
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	if( data.hasOwnProperty('result') ) {
						_self.uploader.removeFile( file );
						$mRow.remove();
			    	}
			    }
			});
			return false;
		});
		$fileList.append( $mRow );
	});
	
	// radio 클릭 이벤트
	_self.ele.container.delegate('[name=mainImage]','click',function(e){
		var $checks = _self.ele.container.find('[name=mainImage]').attr('mainYn','N');
		$( this ).attr('mainYn','Y');
	});
	
	// BC 전용 라디오 대체 이미지 클릭 이벤트
	_self.ele.container.delegate('[data-type=mainImage]','click',function(e){
		var $this = $(this);
		_self.ele.container.find('.jdg-select-flag').removeClass('jdg-select-flag').addClass('jdg-disabled-flag');
		$this.removeClass('jdg-disabled-flag').addClass('jdg-select-flag');
		$this.siblings('[name=mainImage]').click();
	});
	
	// WF 전용 라디오 대체 이미지 클릭 이벤트
	_self.ele.container.delegate('[data-type=cfMainImage]','click',function(e){
		var $this = $(this);
		_self.ele.container.find('[data-type=cfMainImage]').removeClass('jdg-selected');
		$this.addClass('jdg-selected');
		$this.siblings('[name=mainImage]').click();
	});
};


/**
 * 파일 리스트 초기화
 * @param list
 */
_FileList.prototype.initWithoutTextArea = function( list ) {
	
	var _self = this;
	var _ele = _self.ele;
	var _cfg = _self.cfg;
	
	// element 초기화
	var $fileListContainer = _ele.fileListContainer.clone();
	var $fileList = $fileListContainer.find('.fileList');
	$fileListContainer.find('.fileAddBtn').attr('id', _self.cfg.browse_button);
	_ele.container.empty();
	_ele.container.append( $fileListContainer );
	
	// plupload 초기화
	_self.uploader = new plupload.Uploader({
		 runtimes 			: _cfg.runtimes
		,container			: _cfg.id
		,browse_button 		: _cfg.browse_button
		,max_file_size 		: '20mb'
		,url 				: _cfg.uploadURL
		,multi_selection 	: true
		,flash_scf_url 		: _cfg.flashURL
		,silverlight_xap_url: _cfg.silverURL
		,filters 			: [{title : "Image files", extensions : "jpg,gif,png,jpeg"}]
	});
	
	// plupload 초기화
	_self.uploader.init();
	
	// 데이터가 있을 경우 수정Row에 채워준다
	if( undefined != list && null != list ) {
		var idKey = _ele.container.attr('image-key');
		var nmKey = _ele.container.attr('image-name');
		var fileList = jdg.util.toArray( list );
		for( var i=0, nMax=fileList.length ; i < nMax ; i++ ) {
			var data = fileList[i];
			var $mRow = _ele.fileListRow.clone();
			
			
			var imgId = data[idKey];
			if (imgId == null) imgId = data.IMG_ID;
			
			if (data.MOVIE_YN != undefined && data.MOVIE_YN == "Y")
			{
			    var ifrmUrl = 'https://www.youtube.com/embed/' + data.IMG_ID;
				var ifrmCon = _ele.movieListRow.find('iframe').parent().clone();
				ifrmCon.find('iframe').attr('src',ifrmUrl);
				
				$mRow.find('.thumbnail').replaceWith(ifrmCon);
				$mRow.attr('data-type','mov');
				$mRow.find('.fileName').val( ifrmUrl );
			}
			else
			{
				var imgUrl;
				
				if (data.HOSTING_URL)
				{
					imgUrl = data.HOSTING_URL.replace('/a.', '/w260/a.');
				}
				else if(imgId.substr(0,5) == "https"){
					imgUrl = imgId;
				}
				else
				{
					imgUrl = (imgId.substr(0,6) == "HOMEBG")? '//img.fishapp.co.kr/legacy/bg/'+ imgId +'.jpg' : '/cm/file/image/'+ imgId +'/thumbnail';
				}
				
				
				$mRow.find('.thumbnail').attr('src', imgUrl);	

				if( data.FILE_NAME != undefined )
					$mRow.find('.fileName').val( data.FILE_NAME );
				else if( data.IMG_NAME != undefined )
					$mRow.find('.fileName').val( data.IMG_NAME );
				
				$mRow.attr('HOSTING_URL', data.HOSTING_URL);
			}
			
			$mRow.attr('IMG_ID', imgId);
			$mRow.addClass('beforeRow');
		
			$mRow.find("textarea").attr("style", "display:none;");
			$mRow.find(".jdg-checkbox").attr("style", "display:none;");
			
			$mRow.find('.fileDelBtn').attr('IMG_ID', imgId);
			$mRow.find('.fileDelBtn').click( function() {
				
				if (!confirm('삭제하시겠습니까?')) { return;}				
				
				$fileList.find('[IMG_ID='+$(this).attr('IMG_ID')+']').remove();
				return false;
			});
			$mRow.find('textarea').val( data.CONTENT );
			if( 'Y' === data.MAIN_YN ) {
				$mRow.find('[name=mainImage]').attr('checked',true);
				var $mainImgFlag = $mRow.find('[data-type=mainImage]'); 
				if( $mainImgFlag.length > 0 ){
					$mainImgFlag.removeClass('jdg-disabled-flag').addClass('jdg-select-flag');
				}
			}
			$fileList.append( $mRow );
		}
	}

	// 파일 추가 이벤트
	_self.uploader.bind('FilesAdded', function(up, files) {
		_self.uploader.start();
	});
	
	// 파일 업로드 성공 이벤트 (한 파일당 1회 발생)
	_self.uploader.bind('FileUploaded', function(up, file, response) {
		var data = JSON.parse(response.response);
		var $mRow = _ele.fileListRow.clone();
		var _state = $('#state').val();
		if("/sc" != _state){
			_state = _state + $('#shipId').val();
			// 파일명
			$mRow.find('.fileName').val( file.name );
		}
		// 썸네일 추가
		$mRow.find('.thumbnail').attr('src', '/cm/file/image/'+data.FILE_ID+'/thumbnail');		
		$mRow.attr('IMG_ID',data.FILE_ID);

		$mRow.find("textarea").attr("style", "display:none;");
		$mRow.find(".jdg-checkbox").attr("style", "display:none;");
		
		// fileArray 추가
		_self.fileArray.push(data.FILE_ID);
		// 파일 삭제 이벤트
		$mRow.find('.fileDelBtn').click( function() {
			// fileArray 삭제
			_self.fileArray.remove(data.FILE_ID);
			$.ajax({
				 url : _self.cfg.deleteURL
				,type : 'POST'
				,data : {'FILE_ID' : data.FILE_ID}
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	if( data.hasOwnProperty('result') ) {
						_self.uploader.removeFile( file );
						$mRow.remove();
			    	}
			    }
			});
			return false;
		});
		$fileList.append( $mRow );
	});
	
	// radio 클릭 이벤트
	_self.ele.container.delegate('[name=mainImage]','click',function(e){
		var $checks = _self.ele.container.find('[name=mainImage]').attr('mainYn','N');
		$( this ).attr('mainYn','Y');
	});
	
	// BC 전용 라디오 대체 이미지 클릭 이벤트
	_self.ele.container.delegate('[data-type=mainImage]','click',function(e){
		var $this = $(this);
		_self.ele.container.find('.jdg-select-flag').removeClass('jdg-select-flag').addClass('jdg-disabled-flag');
		$this.removeClass('jdg-disabled-flag').addClass('jdg-select-flag');
		$this.siblings('[name=mainImage]').click();
	});
	
	// WF 전용 라디오 대체 이미지 클릭 이벤트
	_self.ele.container.delegate('[data-type=cfMainImage]','click',function(e){
		var $this = $(this);
		_self.ele.container.find('[data-type=cfMainImage]').removeClass('jdg-selected');
		$this.addClass('jdg-selected');
		$this.siblings('[name=mainImage]').click();
	});
};

/**
 * 파일 업로드용 Json List 조회
 * @param
 */
_FileList.prototype.getFileList = function() {
	var _self = this;
	var files = [];
	var $fileList = _self.ele.container.find('li,div.file_con');
	$.each( $fileList, function() {
		var $this = $(this);
		var mainYn = $this.find('[name=mainImage]').is(':checked');
		var movieYn = $this.data('type') == "mov"? "Y" : "N";
		files.push({
			 'IMG_ID' : $this.attr('IMG_ID')
			,'MAIN_YN' : mainYn == true ? 'Y' : 'N'
			,'CONTENT' : $this.find('textarea').val()
			,'MOVIE_YN' : movieYn
			, HOSTING_URL : $this.attr('HOSTING_URL')
		});
	});
	return files;
};

/**
 * 파일id String 조회(여러개의 파일명을 ','로 연결된 string으로 리턴)
 * @param
 */
_FileList.prototype.getFileIdString = function() {
	
	var _self = this;
	var fileStr = null;
	var $fileList = _self.ele.container.find('li');
	
	$.each( $fileList, function() {
		
		if (fileStr == null)
		{
			fileStr = $(this).attr('IMG_ID');
		}
		else
		{
			fileStr += "," + $(this).attr('IMG_ID');
		}	
	});
	return fileStr;
};


/**
 * 업로드중이던 파일 전체 삭제
 * @param
 */
_FileList.prototype.removeFileList = function() {
	var _self = this;
	var files = _self.fileArray;
	for( var i=0, nMax=files.length; i < nMax; i++ ) {
		$.ajax({
			 url : _self.cfg.deleteURL
			,type : 'POST'
			,data : {'FILE_ID' : files[i]}
		    ,dataType : 'json'
		    ,success : function( data ) {
		    	// ??
		    }
		});
	}
};





/**
 * 파일 컴포넌트 속성 정의
 * @param p_properties
 */
function _File( p_properties ) {
	
	// validation!
	if( null == p_properties.id || null == p_properties.container ) {
		throw new Error( '파일 리스트 속성이 정의 되어 있지 않습니다.' );
		return false;
	}
	
	/**
	 * Uploader 정의
	 */
	this.uploader = null;
	
	/**
	 * FILE_ID 저장
	 */
	this.file = null;
	
	/**
	 * Element 목록 정의
	 */
	this.ele = {
		  'container' 		 : p_properties.container
		 ,'fileListContainer' : $('#commonTemplate').find('.fileContainer')
	};
	
	/**
	 * 기본 설정값 정의
	 */
	this.cfg = {
		 'runtimes'			 : 'gears,html5,flash,silverlight,browserplus'
		,'id' 				 : p_properties.id
		,'browse_button' 	 : p_properties.id + 'Btn'
		,'uploadURL' 		 : $('#imgUploadURL').val()
		,'deleteURL'		 : $('#imgDeleteURL').val()
		,'flashURL' 		 : $('#pluploadFlashScfURL').val()
		,'silverURL' 		 : $('#pluploadSilverlightXapURL').val()
	};
	// plupload IE10 버그 해결을 위한 runtime 강제 지정
	if (navigator.userAgent.toLowerCase().indexOf("msie") > -1) { // if IE
		this.cfg.runtimes = 'flash';
	}
	// context
	this.context = $('#context').val();
	var state = $('#state').val();
	if("/sc" != state){
		state = state + $('#shipId').val();
	}
	this.state = state;
};

/**
 * 파일 컴포넌트 초기화
 * @param data
 */
_File.prototype.init = function( data ) {

	var _self = this;
	var _ele = _self.ele;
	var _cfg = _self.cfg;
	
	// element 초기화
	var $fileListContainer = _ele.fileListContainer.clone();
	console.log($fileListContainer.html());
	$fileListContainer.find('.fileAddBtn').attr('id', _self.cfg.browse_button);
	_ele.container.empty();
	_ele.container.append( $fileListContainer );
	
	// plupload 초기화
	_self.uploader = new plupload.Uploader({
		 runtimes 			: _cfg.runtimes
		,container			: _cfg.id
		,browse_button 		: _cfg.browse_button
		,max_file_size 		: '20mb'
		,url 				: _cfg.uploadURL
		,multi_selection 	: false
		,flash_scf_url 		: _cfg.flashURL
		,silverlight_xap_url: _cfg.silverURL
		,filters 			: [{title : "Image files", extensions : "jpg,jpeg,gif,png"}]
	});
	
	// plupload 초기화
	_self.uploader.init();
	
	// 데이터가 있을 경우 이미지 SRC 에 채워준다
	if( undefined != data && null != data ) {
		var idKey = _ele.container.attr('image-key');
		if(idKey == undefined){
			idKey = "IMG_ID";
		}
		var nmKey = _ele.container.attr('image-name');
		$fileListContainer.find('.thumbnail').attr('src', '/cm/file/image/'+data[idKey]+'/thumbnail');		
		$fileListContainer.attr('IMG_ID', data[idKey]);
		$fileListContainer.find('.fileDelBtn').click( function() {
			$fileListContainer.find('.thumbnailContainer').empty();
			$fileListContainer.find('.thumbnailContainer').append( $('<img class="jdg-data-image thumbnail"/>') );
			$fileListContainer.attr('IMG_ID','');
			return false;
		});
	}

	// 파일 추가 이벤트
	_self.uploader.bind('FilesAdded', function(up, files) {
		
		var fsize = files[0].size ;
		
		if (fsize> 10485760)
		{
			fsize = Math.round (fsize * 100 / 1048576 ) / 100;
			
			alert('사진 첨부는 10MB이하로 제한되어 있습니다. \n선택하신 파일의 크기는 ' +  fsize + 'MB 입니다.');
			return;
		}
		
		// 기존파일삭제
		if( null != _self.file ) {
			$.ajax({
				 url : _self.cfg.deleteURL
				,type : 'POST'
				,data : {'FILE_ID' : _self.file}
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	// ??
			    }
			});	
		}
		// 초기화
		_self.uploader.files = files;
		$fileListContainer.find('.thumbnailContainer').empty();
		$fileListContainer.find('.thumbnailContainer').append( $('<img class="jdg-data-image thumbnail"/>') );
		$fileListContainer.attr('IMG_ID','');
		// 파일 업로드
		_self.uploader.start();
	});
	
	// 파일 업로드 성공 이벤트 (한 파일당 1회 발생)
	_self.uploader.bind('FileUploaded', function(up, file, response) {
		var data = JSON.parse(response.response);
		var _state = $('#state').val();
		if("/sc" != _state){
			_state = _state + $('#shipId').val();
		}
		// 썸네일 추가
		$fileListContainer.find('.jdg-data-image').attr('src', '/cm/file/image/'+data.FILE_ID+'/thumbnail');
		$fileListContainer.attr('IMG_ID',data.FILE_ID);
		// file 추가
		_self.file = data.FILE_ID;
		// 파일 삭제 이벤트
		$fileListContainer.find('.fileDelBtn').click( function() {
			// fileArray 삭제
			_self.file = null;
			$.ajax({
				 url : _self.cfg.deleteURL
				,type : 'POST'
				,data : {'FILE_ID' : data.FILE_ID}
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	if( data.hasOwnProperty('result') ) {
						_self.uploader.removeFile( file );
						$fileListContainer.find('.thumbnailContainer').empty();
						$fileListContainer.find('.thumbnailContainer').append( $('<img class="jdg-data-image"/>') );
						$fileListContainer.attr('IMG_ID','');
			    	}
			    }
			});
			return false;
		});
	});
};

/**
 * 현재 업로드된 파일 조회
 * @param
 */
_File.prototype.getFile = function() {
	return this.ele.container.find('.fileContainer').attr('IMG_ID');
};

/**
 * 업로드중이던 파일 삭제
 * @param
 */
_File.prototype.removeFile = function() {
	var _self = this;
	$.ajax({
		 url : _self.cfg.deleteURL
		,type : 'POST'
		,data : {'FILE_ID' : _self.file}
	    ,dataType : 'json'
	    ,success : function( data ) {
	    	// ??
	    }
	});
};


/** option display 처리 */
jQuery.fn.toggleOption = function( show ) {
    jQuery( this ).toggle( show );
    if( show ) {
        if( jQuery( this ).parent( 'span.toggleOption' ).length )
            jQuery( this ).unwrap( );
    } else {
        jQuery( this ).wrap( '<span class="toggleOption" style="display: none;" />' );
    }
};
