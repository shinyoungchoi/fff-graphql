   $(document).ready(function(){	
	   
	   var _toTop = $('#toTop');
	   var _toTopVis = false;
	   
		$(document).on("scroll",function(){			
			var vis = ($(document).scrollTop() > 200);			
			if (vis != _toTopVis)
			{
				_toTopVis = vis;
				if (vis)
				{
					_toTop.show();
				}
				else
				{
					_toTop.hide();
				}
			}
		});
   });   
   