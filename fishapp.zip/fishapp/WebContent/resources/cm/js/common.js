/*************************************************************************
  File Name  : common.js
  Description : 피쉬앱 공통 스크립트
 ***************************************************************************/
var jdg = {};

/**
 * 공통 Util
 */
jdg.util = {};

/**
 * validator
 * @param $container : 상위 element
 * @return
 **/
jdg.util.validator = function( $container, _trim ) {
	// 리턴값
	var _rFlag = true;
	// vType 속성 정의된 element만 validation check
	var $valList = $container.find('[vType]');
	
	$.each( $valList, function( idx, data ){
		var $this = $( this );
		var tagName = $this.prop('tagName');
		
		// 정의 속성
		var vType = $this.attr('vType');	// 타입	
		var vRequired = $this.attr('vRequired');	// 필수값 여부
		var vMaxLangth = $this.attr('vMaxlangth');	// 최대값
		var vMinLangth = $this.attr('vMinLangth');	// 최소값
		var vMessage = $this.attr('vMessage');	// 경고창용 메세지

		// element 별 value 추출
		var val = '';
		if( 'INPUT' === tagName || 'TEXTAREA' == tagName ) {
			val = $.trim( $this.val() );
		} else if( 'SELECT' === tagName ) {
			val = $.trim( $this.find('option:selected').val() );
		}
		
		// 필수값 체크
		if( 'true' === vRequired && '' === val ) {
			alert( vMessage + ' 을 입력해주세요' );
			_rFlag = false;
			return false;
		}
		// 타입 체크
		switch( vType ) {
			// 숫자
			case 'email' :
				if( '' !== val && ! /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(val) ) {
					alert( vMessage + ' 값은 형식이 유효하지 않습니다');
					_rFlag = false;
					return false;
				}
				break;
			case 'code' :
				if( '' !== val && !(/^[a-zA-Z0-9_]+$/.test(val)) ) {
					alert( vMessage + ' 값은 숫자, 영문, 언더바(_)로만 입력 가능합니다');
					_rFlag = false;
					return false;
				}
				break;
			case 'digits' :
				if( '' !== val && !(/^\d+$/.test(val)) ) {
					alert( vMessage + ' 값은 숫자로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'date' :
				if( '' !== val && ! /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(val) ){
					alert( vMessage + '  값은 날짜형식으로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'number' :
				if( ! /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(val) ) {
					alert( vMessage + ' 값은 숫자로만 입력 가능합니다.');
					_rFlag = false;
					return false;
				}
				break;
			case 'bizRegNo' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{3}-?[0-9]{2}-?[0-9]{5}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo1' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{3}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo2' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{2}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
			case 'bizRegNo3' :
				if( $.trim( val ).length > 0 ){
					if( ! /^[0-9]{5}$/.test(val) ){
						alert( vMessage + '값이 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;

			case 'tel' :
				if( $.trim( val ).length > 0 ){
					if( ! /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/.test(val) ){
						alert( vMessage + ' 번호가 유효하지 않습니다.' );
						_rFlag = false;
						return false;
					}
				}
				break;
				
			default :
				break;
		}
		
		// 최대값 체크
		if( '' !== val && val.length > vMaxLangth ) {
			alert( vMessage + ' 값은 '+vMaxLangth +'자리 이상 입력하실수 없습니다.' );
			_rFlag = false;
			return false;
		}
		
		// 최소값 체크
		if( '' !== val & val.length < vMinLangth ) {
			alert( vMessage + ' 값은 '+vMinLangth +'자리 이상 입력하셔야 합니다.' );
			_rFlag = false;
			return false;
		}
		
	});
	
	// 모든 validation 성공 수행 후, container trim
	if( _trim && _rFlag ) {
		$.each( $valList, function(){
			var $this = $( this );
			var tagName = $this.prop('tagName');
			if( 'INPUT' === tagName || 'TEXTAREA' == tagName ) {
				$this.val( $.trim( $this.val()) );
			}
		});
	}
	return _rFlag;
};


/**
 * detailDataSetting : JSON 형태의 상세데이터를 상세폼에 셋팅
 * @param $container : 상위 element
 */
jdg.util.detailDataSetting = function( $container, data ) {
	
	$.each( $container.find('[data-key]') , function() {
		var $this = $(this);
		var tagName = $this.prop('tagName');
		var dataStr = data[$this.attr('data-key')];
		var dataType = $this.attr('data-type');
		
		if( undefined == dataStr ) {
			dataStr = '';
		} else {
			if( '' !== dataStr ) {
				var commaFlag = $this.attr('addComma');
				var dataPrepend = $this.attr('data-prepend');
				var dataAppend = $this.attr('data-append');
				if( 'true'==commaFlag ) dataStr = jdg.util.addComma(dataStr);
				if( dataPrepend ) dataStr = dataPrepend + dataStr;
				if( dataAppend ) dataStr = dataStr + dataAppend;
			}
		}
		switch( tagName ) {
			case 'INPUT':
				$this.val( dataStr );
				break;
			case 'TEXTAREA' :
				if( dataStr != null && dataStr != undefined && dataStr != '' )
					dataStr = dataStr.replace(/<br>/g, '\n');
				$this.val( dataStr );
				break;
			case 'SELECT' :
				if( '' == dataStr ) $this.find('option:eq(0)').attr('selected', true);
				else $this.val( dataStr );
				break;
			case 'IMG' :
				if( '' !== dataStr ) {
					$this.attr('src' ,  dataStr );
					$this.show();
				} else {
					$this.attr('src' , '' );
					$this.hide();
				}
				break;
			default :
				$this.html( dataStr );
		}
	});
};


/**
 * 이미지 리스트
 */
jdg.util.createImgList = function( imgList, $container ) {
	var _state = $('#state').val();
	var localStatus = _state.split('/')[1];
	var $imgListTemp = $('.imgListTemp');
	
	// 메인의 컨테이너 초기화
	$container.empty();
	
	switch (localStatus) {
	case 'bc': case 'cf': case 'cc':
		
		if (localStatus != 'cc')
		{
			_state = _state + $('#shipId').val();
		}
		
		var $component = $imgListTemp.find('dl').clone();
		var imgWidth = $imgListTemp.find('dl dt img').width();
		var $imgDt = $component.find('dt');
		var $imgDd = $component.find('dd');
		$component.empty();
		$.each(imgList, function(key, item){
			var $tempDt = $imgDt.clone();
			var $tempDd = $imgDd.clone();
			var width = '/' + imgWidth;
			var imgSrc = _state + '/file/image/' + item.IMG_ID;
			$tempDt.find('img').click(function(){
				jdg.util.openImgPopup( imgSrc, item.IMG_WIDTH, item.IMG_HEIGHT );
			});
			if( item.IMG_WIDTH != null && item.IMG_WIDTH != '0' && item.IMG_WIDTH != '' ){
				if ( item.IMG_WIDTH < 700 ) {
					$tempDt.find('img').width( item.IMG_WIDTH );
					width = '';
				} 
			}
			$tempDt.find('img').attr('src', imgSrc + width);
			$tempDd.html(item.CONTENT);
			$component.append( $tempDt );
			$component.append( $tempDd );
		});
		break;
	case 'sc': default:
		// 컴포넌트를 감싸는 div 를 만든다.
		var $component = $imgListTemp.find('.jdg-ui-photo-wrap').clone();
		var $imgUl = $component.find('ul');
		var $imgLi = $component.find('li');
		
		// 기존의 이미지 리스트 UL을 초기화
		$imgUl.empty();
		
		// 이미지의 수만큼 루프를 돌며 컴포넌트에 추가한다.
		var i = 0;
		var imgListLen = imgList.length;
		
		var imgId;
		var imgUrl;
		while( i < imgListLen ){
			var $tempLi = $imgLi.clone();
			
			var $fleft = $tempLi.find('.jdg-fleft');
			
			imgId = imgList[i].IMG_ID;			
			
			if (imgList[i].MOVIE_YN != undefined && imgList[i].MOVIE_YN == "Y")
			{
				var ifrm = $('<iframe frameborder="0" allowfullscreen src="//www.youtube.com/embed/' + imgId + '"></iframe>');				
				$fleft.find('img').replaceWith(ifrm);
			}
			else
			{
				if (imgId.substr(0,6) == "HOMEBG")
				{
					imgUrl = "//img.fishapp.co.kr/legacy/bg/" + imgId + ".jpg";
				}
				else if (imgId.substr(0,6) == "custom") 
				{
					imgUrl = "//img.fishapp.co.kr/" + imgId;
				}
				else if (imgId.substr(0,5) == "https") 
				{
					imgUrl =  imgId;
				}
				else
				{
					imgUrl = _state + '/file/image/'+ imgId + "/thumbnail";
				}
				
				var leftImgWidth = imgList[i].IMG_WIDTH;
				var leftImgHeight = imgList[i].IMG_HEIGHT;
				$fleft.find('img').attr( 'src', imgUrl );
				$fleft.find('img').attr( 'title', imgId);
				$fleft.find('img').click(function(){
					jdg.util.openImgPopup( imgUrl, leftImgWidth, leftImgHeight );
				});
			}

			$fleft.find('.jdg-data-description').html(imgList[i].CONTENT);
			$tempLi.append( $fleft );
			i++;
		
			if( imgList[i] != undefined ){
				var $fright = $tempLi.find('.jdg-fright');
				
				imgId = imgList[i].IMG_ID;			
				
				if (imgList[i].MOVIE_YN != undefined && imgList[i].MOVIE_YN == "Y")
				{
					var ifrm = $('<iframe frameborder="0" allowfullscreen src="//www.youtube.com/embed/' + imgList[i].IMG_ID + '"></iframe>');				
					$fright.find('img').replaceWith(ifrm);
				}
				else
				{
			
					if (imgId.substr(0,6) == "HOMEBG")
					{
						imgUrl = "//img.fishapp.co.kr/legacy/bg/" + imgId + ".jpg";
					}
					else if (imgId.substr(0,6) == "custom") 
					{
						imgUrl = "//img.fishapp.co.kr/" + imgId;
					}
					else if (imgId.substr(0,5) == "https") 
					{
						imgUrl =  imgId;
					}
					else
					{
						imgUrl = _state + '/file/image/'+ imgId + "/thumbnail";
					}
					
					
					var rightImgWidth = imgList[i].IMG_WIDTH;
					var rightImgHeight = imgList[i].IMG_HEIGHT;
					$fright.find('img').attr( 'src', imgUrl);
					$fright.find('img').attr( 'title', imgId);
					$fright.find('img').click(function(){
						jdg.util.openImgPopup( imgUrl, rightImgWidth, rightImgHeight );
					});
				}

				$fright.find('.jdg-data-description').html(imgList[i].CONTENT);
				$tempLi.append( $fright );
				i++; 
			} else {
				$tempLi.find('.jdg-fright').remove();
			}
			$imgUl.append( $tempLi );
		}
		break;
	}
	
	
	// 컨테이너에 컴포넌트 추가
	$container.append( $component );
	$container.show();
};

/**
 * 이미지 팝업
 * @param data
 * @returns open popup
 */
jdg.util.openImgPopup = function( src, width, height ){
	// 브라우저의 크기 측정
	var windowWidth = $(window).width();
	var windowHeight = $(window).height();
	
	// 팝업 최대값 측정
	var popupMaxWidth = windowWidth * 3/4;
	var popupMaxHeight = windowHeight * 4/5;
	
	// 서버에 저장된 width 와 height 가 없을 경우 팝업은 default 사이즈로 열림
	if( width == 0 ){
		width = 500;
		height = 500;
	}
	
	// 가로 스크롤 생성
	var overflowX = "overflow-x:hidden;";
	
	// 세로 스크롤 생성
	var overflowY = "overflow-y:hidden;";
	
	// 이미지 가로 사이즈가 브라우저 해상도에 비례한 최대 가로 사이즈 보다 클경우 가로 해상도로 셋팅
	if( width > popupMaxWidth || width == undefined ){
		width = popupMaxWidth;
		overflowX = "";
	}
	
	// 이미지 세로 사이즈가 브라우저 해상도에 비례한 최대 세로 사이즈 보다 클경우 가로 해상도로 셋팅
	if( height > popupMaxHeight || height == undefined ){
		height = popupMaxHeight;
		overflowY = "";
	}
	
	// 팝업이 띄워질 위치를 구함
	var top = windowHeight / 2 - height / 2;
	var left = windowWidth / 2 - width / 2;
	
	popwin=open("","",'width='+width+',height='+height+',scrollbars=yes,top='+top+',left='+left+'');
	popwin.document.write('<html>');
	popwin.document.write('<title>Image Window</title>');
	popwin.document.write('<body topmargin=0 leftmargin=0 style="'+overflowX+overflowY+'">');
	popwin.document.write('<img src="'+src +'">');
	popwin.document.write('</body>');
	popwin.document.write('<html>');
};


/**
 * Array로 형 변환
 * @param data
 * @returns list
 */
jdg.util.toArray = function( data ) {
	var list;
	if( data instanceof Array ) {
		list = data;
	} else {
		list = [];
		list.push( data );
	}
	return list;
};


/**
 * Client 오늘 날짜
 * @returns [YYYY-MM-DD]
 */
jdg.util.today = function() {
	var today = new Date();
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ;
};

/**
 * 받은 년수만큼 더하거나 뺀 날짜
 */
jdg.util.addYear = function(year){
	var today = new Date();
	today.setYear(today.getFullYear() + year);
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ; 
}


jdg.util.addDay = function( fromDay, days ) {	
	
	var date = new Date();
	var y1 = fromDay.substr(0,4);
	var m1 = parseInt(fromDay.substr(5,7))-1;
	var d1 = fromDay.substr(8,10);	
	date.setFullYear(y1, m1, d1);
	date.setDate( Number(d1)+ days );
	var y2 = date.getFullYear();
	var m2 = date.getMonth()+1;
	var d2 = date.getDate();
	return y2 + '-' + ((m2 < 10) ? ('0' + m2) : m2) + '-' + ((d2 < 10) ? ('0' + d2) : d2);
};


/**
 * Client 날짜 더하기
 * @returns [YYYY-MM-DD]
 */
jdg.util.todayAdd = function(value) {
	var today = new Date();
	today.setDate(today.getDate() + value);	
	return today.getFullYear() + '-' + (this.setStringFillZero(today.getMonth()+1,2))  + '-' + this.setStringFillZero(today.getDate(),2) ;
};


/**
 * 기준일의 다음 날짜
 * @param [YYYY-MM-DD]
 * @return [YYYY-MM-DD]
 */
jdg.util.tommorow = function( today ) {
	return jdg.util.addDay(today, 1);
};


/**
 * 날짜 포맷 변경
 * @param date: string 형태의 날짜 DATE
 * @return 변환된 포맷형식의 string DATE
 */
jdg.util.replaceDate = function( date, type, str ) {
	var returnDate = date;
	if( undefined != date ) {
		var str = str ? str : '-';
		var size = date.length;
		var year = date.substring(0,4);
		var month = date.substring(4,6);
		var day = date.substring(6,8);
		if(  size == 8 ) {
			returnDate = year + str + month + str + day;
		} else if( size >= 12 ) {
			var hour = date.substring(8,10);
			var minute = date.substring(10,12);
			returnDate = year + str + month + str + day + " " + hour + ":" + minute;
		}
		
		if (type != undefined) {
			switch (type) {
			case 'yymmdd':
				returnDate = year + str + month + str + day;
				break;

			default:
				returnDate = year + str + month + str + day + " " + hour + ":" + minute;
				break;
			}
		}
	}
	return returnDate;
};


/**
 * 숫자 천단위 콤마 넣기
 * @param num: 변환할 숫자
 */
jdg.util.addComma = function( num ) {
	var reg = /(^[+-]?\d+)(\d{3})/;
	num = $.trim(num);
	while (reg.test(num)) {
		num = num.replace(reg, '$1' + ',' + '$2');
	}
	return num;
};


/**
 * 사업자 등록번호 변환
 * @param num: 변환할 숫자
 */
jdg.util.replaceRegNo = function( num ) {
	var reg = /([0-9]{3})([0-9]{2})([0-9]{5})/;
	num = $.trim(num);
	num = num.replace(reg, "$1-$2-$3");
	return num;
};

/**
 * 사업자 등록번호 변환
 * @param num: 변환할 숫자
 */
jdg.util.setRegNo = function( reg1Obj, reg2Obj, reg3Obj, regNo ) {
	var strArrayRegNo;
	
	var replaceRegNo = jdg.util.replaceRegNo( regNo );
	
	if(regNo != null){
		if( regNo.indexOf('-') < 0 ){					
			strArrayRegNo = replaceRegNo.split('-');
		} else {
			strArrayRegNo = regNo.split('-');
		}	
		
		reg1Obj.val(strArrayRegNo[0]);
		reg2Obj.val(strArrayRegNo[1]);
		reg3Obj.val(strArrayRegNo[2]);
	}
};

/**
 * 테이블 colroup width 일괄 지정
 * @param
 * @returns 
 * 1. class="jdg-cmpt-list" 테이블에 대해서만 적용됩니다.
 * 2. col에 사이즈가 지정된 속성 name 을 추가해주세요
 */
jdg.util.resizeColgroupWidth = function() {
	var $colGroup = $('.jdg-cmpt-list').find('col');
	$.each( $colGroup, function() {
		var $this = $( this );
		var name = $this.attr('name');
		switch( name ) {
			case 'ID' :
				$this.attr('width', 90);
				break;
			case 'CREATED':
				$this.attr('width', 180);
				break;
		}
	});
};


/**
 * URL 기준 메뉴 활성화
 * @param
 * @returns
 */
jdg.util.setVisibleCtegory = function(){
	var localPath = (window.location.pathname).split('/');
	var mode = localPath[1];
	
	var state = $('#jdbMenuItem').val() != '' || $('#jdbMenuItem').val().length > 0 ? $('#jdbMenuItem').val() : localPath[localPath.length - 1];

	if( mode == "bc" ){//bc일때 
		state = $('#jdbMenuItem').val() != '' || $('#jdbMenuItem').val().length > 0 ? $('#jdbMenuItem').val() : localPath[5];
		jdg.util.setBrowserTitle(state);//브라우저 타이틀 셋팅
		
		var $menulist = $('.jdg-list-lnb').children();
		
		$.each($menulist, function(){
			if($(this).children('.jdg-ui-lnb-sub').length > 0){//서브 메뉴가 있을때
				var $subCategory = $(this).find('a');
				$.each($subCategory, function(){
					var getParameter = location.search;
					
					if( getParameter == "" ){//파라미터가 없을 때
						if(state == $(this).attr('menu')){
							$(this).attr('class','jdg-selected');
							$(this).parents('li').attr('class','jdg-selected');
							return false;
						}
					}else{//파라미터가 있을 때 
						var menu = "";
						var params = getParameter.replace("?","").split("&");
						for(i = 0; i < params.length; i ++){
							var temp = params[i].split("=");
							if( temp[0] == "menuType" ){
								menu = temp[1];
							}
						}
						
						if(menu == ""){//파라미터중 menuType가 없을 때 
							if(state == $(this).attr('menu')){
								$(this).attr('class','jdg-selected').parent().show();
								$(this).parents('li').attr('class','jdg-selected');
								return false;
							}
						}else{//파라미터중 menuType가 있을 때
							if(menu == $(this).attr('menu')){
								$(this).attr('class','jdg-selected').parent().show();
								$(this).parents('li').attr('class','jdg-selected');
								return false;
							}
						}
					}
				});
			} else {//서브메뉴가 없을때
				if( state == $(this).attr('menu') ){
					$(this).attr('class', 'jdg-selected');
					return false;
				}
			}
		});
		
		// LNB 서브메뉴 이벤트 셋팅
		$(".jdg-list-lnb li > a").bind("mouseover mouseout focus blur", function(e){
			
			if(e.type == "mouseover" || e.type == "focus"){
				$(".jdg-ui-sub-inner a:first-child").addClass("jdg-first");
				$(".jdg-ui-sub-inner a:last-child").addClass("jdg-last");
				
				$(this).addClass("jdg-on");
				$(this).next().css({left : $(this).find("span").offset().left, top : $(this).find("span").offset().top});
				$(this).next().show();
				
				$(this).next().bind("mouseover mouseout", function(e){
					if(e.type == "mouseover" || e.type == "focus"){ 
						$(this).prev().addClass("jdg-on");
						$(this).show();
					} else { 
						$(this).hide();
						$(this).prev().removeClass("jdg-on");
					}
				});
				
				$(this).next().find("a").bind("focus blur", function(e){
					if(e.type == "focus"){
						$(this).parent().parent().show();
					} else {
						$(this).parent().parent().hide();
					}
				});
				
			} else if(e.type == "mouseout") {
				$(this).next().hide();
				$(this).removeClass("jdg-on");
			} else {
				$(this).removeClass("jdg-on");
			}
		});
		
	}else if( mode == "sc" ){//sc일때
		var $menulist = $('#jdgMenuList').children();
		
		$.each($menulist, function(){
			if($(this).children('ul').length > 0){
				var $subCategory = $(this).children('ul').children('li');
				$.each($subCategory, function(){
					if(state == $(this).attr('menu')){
						console.log($(this));
						$(this).attr('class','jdg-selected').parent().show();
						$(this).parent().parent().attr('class','jdg-selected');
						return false;
					}
				});
			} else {
				if( state == $(this).attr('menu') ){
					$(this).attr('class', 'jdg-selected');
					return false;
				}
			}
		});
	}else if( mode == "cf" || mode == "pw"){ //cf 또는 pw일때
		
		state = $('#jdbMenuItem').val() != '' || $('#jdbMenuItem').val().length > 0 ? $('#jdbMenuItem').val() : localPath[5];
		var $menulist = $('.jdg-list-gnb').children();
		
		$.each($menulist, function(){
			if( state == $(this).attr('menu') ){
				jdg.util.setBrowserTitle(state);
				$(this).attr('class', 'jdg-selected');
				return false;
			}
		});
	}else if(mode == "pt"){ //pt일때

		state = $('#jdbMenuItem').val() != '' || $('#jdbMenuItem').val().length > 0 ? $('#jdbMenuItem').val() : localPath[3];
		var $menulist = $('.jdg-list-gnb').children();
		
		$.each($menulist, function(){
			if( state == $(this).attr('menu') ){
				//jdg.util.setBrowserTitle(state);
				$(this).attr('class', 'jdg-selected');
				return false;
			}
		});
	}
	
};
/*
 * 브라우져 타이틀 셋팅
 */
jdg.util.setBrowserTitle = function( lnb ) {
	var tempStr = "";
	
	switch (lnb){
		case "home":
			tempStr = "홈";
			break;
		case "schedule":
			tempStr = "출조";
			break;
		case "fish":
			tempStr = "조행기";
			break;
		case "post":
			tempStr = "공지";
			break;
		case "ship":
			tempStr = "선박";
			break;
		case "member":
			tempStr = "회원";
			break;
		case "biz":
			tempStr = "업체";
			break;
		case "stat":
			tempStr = "통계";
			break;
		default:
			tempStr = "";
	}
	
	if( tempStr != "" ){
		$('title').text(tempStr + " | " + $('#bizShipTitle').val());
	}

};



/**
 * 공통데이터 select box 초기화
 */
jdg.util.initSelectBox = function() {
	// 월
	var $months = $('.monthSelectBox');
	$.each( $months, function() {
		var $sel = $( this );
		$sel.empty();
		for( var i=1; i < 13 ; i++ ) {
			var $option = $('<option value='+i+'>'+i+'월</option>');
			$sel.append($option);
		}
	});
	// 시
	var $hours = $('.hourSelectBox');
	$.each( $hours, function() {
		var $sel = $( this );
		$sel.empty();
		for( var i=0; i < 24 ; i++ ) {
			var hour = (i<10) ? '0'+i : i;
			var $option = $('<option value='+hour+'>'+hour+'</option>');
			$sel.append($option);
		}
	});
	// 분
	var $minutes = $('.minuteSelectBox');
	$.each( $minutes, function() {
		var $sel = $( this );
		$sel.empty();
		for( var i=0; i <= 59 ; i++) {
			var minute = (i<10) ? '0'+i : i;
			var $option = $('<option value='+minute+'>'+minute+'</option>');
			$sel.append($option);
		}
	});
};

/**
 * 레이어 가져오기
 */
jdg.util.getLayer = function( layerId ) {
	var $layer = $('#' + layerId);
	var _state = $('#state').val();
	if("/sc" != _state){
		_state = _state + $('#shipId').val();
	}
	
	if($layer.size() == 0 || $layer == null){ //해당레이어가 없을땐 가져와서 body에 append
		$.post(_state + '/layerPopup' , function(data) {
			if(data != null || data != ""){
				$layer = $(data).filter('#' + layerId).hide();
				//close 이벤트 등록
				$layer.find('.jdg-btn-close').click(function(){
					$layer.hide();
				});
				$('body').append($layer);
			}
		});
	}else{
		return false;
	}
};

/**
 * 전화번호 포맷 변환
 * @param (ex:01011111111)
 * @return "010-1111-1111"
 */
jdg.util.setPhonNumber = function( pNum ) {
	return pNum.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/,"$1-$2-$3");
};

/**
 * 전화번호 set value
 */
jdg.util.setTelNum = function(tel1Obj, tel2Obj, tel3Obj,telNum) {
	
	if (telNum == null)
	{
		//tel1Obj.val('').attr("selected", "selected");	

		tel2Obj.val('');	

		tel3Obj.val('');			
	}
	else if( telNum.indexOf('-') > 0 ){					
		var strArrayTelNo = telNum.split('-');
		
		tel1Obj.val(strArrayTelNo[0]).attr("selected", "selected");	

		tel2Obj.val(strArrayTelNo[1]);	

		tel3Obj.val(strArrayTelNo[2]);	
	}
};

/**
 * 말줄임
 * @param str : 변환할 string
 * @param int : 해당 자릿수보다 길 경우 말줄임한 string을 리턴한다
 */
jdg.util.setStringOverview =function( str, int ) {
	var result = str + '';
	if( result.length > int ) {
		result = result.substring(0, int) + '...';
	}
	return result;
};

/**
 * 자릿수채우기
 * @param str : 변환할 string
 * @param int : 해당 자릿수만큼 0을 채워준다
 */
jdg.util.setStringFillZero = function( str, int ) {
	var result = str + '';
	if( result.length < int ) {
		for( var i=0 ; i < int-1 ; i++ ) {
			result = '0' + result;
		}
	}
	return result;
};

/**
 * placeholder와 같은 기능(placeholder가 ie저버전에서 안먹히는 버그 때문에 만듬)
 * @param $obj : placeholder 적용할 객체(input type이 text와 password만 가능)
 * @param message : 사용할 글귀
 */
jdg.util.setPlaceHolder = function( $obj, message ) {
	if( $obj.attr('type') == "text" ){
		$obj.val(message);
		
		$obj.bind("focus blur",function(e){
			var textVal = $obj.val();
			
			if(e.type == "focus") {
				if( textVal == message ){
					$obj.val("");
				}
			}
			else {
				if( textVal == "" ){
					$obj.val(message);
				}
			}
		});
	}else if( $obj.attr('type') == "password" ){//password는 기본적으로 placeholder가 적용 안되기때문에 text로 보여지고 포커스시 password로 치환한다
		$obj.replaceWith($obj.clone(true).attr('type','text').addClass('placeholderPw').val(message));
		$obj = $('.placeholderPw');
		
		$obj.bind("focus blur",function(e){
			var pwTxtVal = $obj.val();

			if(e.type == "focus") {
				if( pwTxtVal == message ){
					$obj.replaceWith($obj.clone(true).val("").attr('type','password'));
					$obj = $('.placeholderPw');
					$obj.focus();
				}
			}else{
// 이부분때문에 iframe안에서는 작동이 안되서 막음
//				if( pwTxtVal == "" ){
//					$obj.val(message);
//					$obj.replaceWith($obj.clone(true).attr('type','text').val(message));
//					$obj = $('.placeholderPw');
//				}
			}
		});
	}else{
		return "placeholder를 사용할수 없는 객체입니다.";
	}
};


/**
 * 한 페이지에 보여질 목록수 쿠기 저장
 * @param cnt 		: URL 페이지 목록 수 
 * @param term 		: 쿠기에 저장될 날짜(일) 수
 */
jdg.util.setItemCnt = function() {
	if( $.cookie('itemCnt') == null )
		$.cookie('itemCnt', 5);
	
	if( $('#itemCnt').val() != undefined && $('#itemCnt').val() != null && $('#itemCnt').val() != '' ){
		$.cookie('itemCnt', $('#itemCnt').val());
	}
	/* 
	if ( undefined != cnt ) {
		if ( undefined == term ) {
			$.cookie( 'ItemCnt', cnt );
		}else{
			$.cookie( 'ItemCnt', cnt, { expires: term } );
		}
	}
	*/
	result = $.cookie( 'itemCnt' );
	return result;
};

/**
 * @Item의 내용을 파라미터 길이 대로 자르고 '...'을 붙여 리턴하는 함수,
 * @param item		: 타겟 컨텐츠
 * @param sIndex	: 자르기 위한 시작위치
 * @param sLen		: 자르기 위한 길이
 * @param addStr	: 자르고 나서 붙일 문자열
 */
jdg.util.subStr = function(item, sIndex, sLen, addStr){
	if( item == null )
		return item;
	if( item == undefined )
		return item;
	if( item == '' )
		return item;
	if( item.length < sLen )
		return item;
	return item.substr(sIndex, sLen - 1) + addStr;
};

/**
 * @이미지 상위에 있는 컨테이너 사이즈에 들어가도록 이미지태그를 비율 유지하며 리사이즈
 * @param $container		: 이미지 상위 div
 * @param width	: 원본 이미지 가로
 * @param height	: 원본 이미지 세로
 */
jdg.util.setImgRatio = function($container, width, height){
//    $(window).resize(function(){
    	var maxWidth = $container.width();   
        var maxHeight = $container.height();   
        
        width = (typeof width == "string")? Number(width) : width;
        height = (typeof height == "string")? Number(height) : height;
        
        // 가로나 세로의 길이가 최대 사이즈보다 크면 실행
        if(width > maxWidth || height > maxHeight){
           if(width > height){ // 가로가 세로보다 크면 가로는 최대사이즈로, 세로는 비율 맞춰 리사이즈
              resizeWidth = maxWidth;
              resizeHeight = Math.round((height * resizeWidth) / width);
              
              if(resizeHeight > maxHeight){ 
            	  resizeHeight = maxHeight;
                  resizeWidth = Math.round((width * resizeHeight) / height);
              }
           }else{// 세로가 가로보다 크면 세로는 최대사이즈로, 가로는 비율 맞춰 리사이즈
              resizeHeight = maxHeight;
              resizeWidth = Math.round((width * resizeHeight) / height);
              
              if(resizeWidth > maxWidth){
            	  resizeWidth = maxWidth;
                  resizeHeight = Math.round((height * resizeWidth) / width);
              }
           }
        }else{// 최대사이즈보다 작으면 원본 그대로
           resizeWidth = width;
           resizeHeight = height;
        }
        
        $container.find('img').attr({width:resizeWidth, height:resizeHeight});  
//   }).resize();
};


/**
 * 로더 생성
 */
jdg.util.showLoader = function() {
	
	if (jdg.loader.intId != null)
	{
		return;
	}
	
	// Becomes this.options
	var options = {
		bgColor 		: '#fff',
		opacity			: 0.8,
		classOveride 	: false
	};
	var container 	= $(document.body);	
	
	// Create the overlay 
	var overlay = $('<div id="spiner"></div>').css({
		 'background-color': options.bgColor
		,'opacity':options.opacity
		,'width':$(window).width()
		,'height': $(window).height()
		,'position':'fixed'
		,'top':'0px'
		,'left':'0px'
		,'z-index':999
	}).addClass('ajax_overlay');
	//overlay.addClass('ajax_loader1');
	
	// insert overlay and loader into DOM 
	container.append(
		overlay.append(
			$('<div></div>')
		)
	);
	
	jdg.loader.seq = 1;
	jdg.loader.intId = setInterval(jdg.util.changeImage, 30);

};

jdg.loader =  {};

jdg.util.changeImage = function()
{
	jdg.loader.seq ++;
	
	if (jdg.loader.seq == 15)
	{
		jdg.loader.seq = 1;
	}
	
	$("#spiner").attr('class', 'ajax_loader' + jdg.loader.seq);

};


/**
 * 로더 삭제
 */
jdg.util.removeLoader = function() {
	
	clearInterval(jdg.loader.intId);
	
	jdg.loader.intId = null;

	var overlay = $("#spiner");
	overlay.remove();

};

/**
 * loading bar
 */
jdg.util.spinnerObj = function($target){
	
	var target = $target.get(0);
	var opts = {
			  lines: 11, // The number of lines to draw
			  length: 8, // The length of each line
			  width: 3, // The line thickness
			  radius: 8, // The radius of the inner circle
			  corners: 1, // Corner roundness (0..1)
			  rotate: 0, // The rotation offset
			  direction: 1, // 1: clockwise, -1: counterclockwise
			  color: '#000', // #rgb or #rrggbb or array of colors
			  speed: 1, // Rounds per second
			  trail: 15, // Afterglow percentage
			  shadow: true, // Whether to render a shadow
			  hwaccel: true, // Whether to use hardware acceleration
			  className: 'spinner', // The CSS class to assign to the spinner
			  zIndex: 2e9, // The z-index (defaults to 2000000000)
			  top: 'auto', // Top position relative to parent in px
			  left: 'auto' // Left position relative to parent in px
			};
	var spinner = new Spinner(opts);
	
	var loader ={'start' : function(){
								$('body').append('<div id="spin_modal_overlay" style="background-color: rgba(0, 0, 0, 0.6); width:100%; height:100%; position:fixed; top:0px; left:0px; z-index:'+(opts.zIndex-1)+'"/>');
								$target.keydown(function(event){
									 event.preventDefault();
								});
								return spinner.spin(target);
								}
			   , 'stop' : function(){$('#spin_modal_overlay').remove();return spinner.stop();}};
	
	return loader;
	
};

/*****************************************************************************************
 *   util 은 이 위로 선언해주세요
 *****************************************************************************************/

/**
 * userAgent 체크
 */
jdg.Device = {
		TYPE_DESKTOP : 'desktop'
	   ,TYPE_PHONE : 'phone'
	   ,TYPE_TABLET : 'tablet'
	   ,agent : {
		   mobile : (/Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/i.test(window.navigator.userAgent))
		  ,tablet : (/iPad|tablet/i.test(window.navigator.userAgent))
	   }
	   ,detect : function() {
		   
		   if( this.type ) {
			   return;
		   }
		   
		   if( this.agent.mobile ) {
			   var userAgent = navigator.userAgent.toLowerCase();
			   if( userAgent.search('android') > -1 ) {
				   if( userAgent.search('mobile') == -1 ) {
					   this.type = this.TYPE_TABLET;
				   }
			   }
			   
			   if( !this.type ) {
				   this.type = this.TYPE_PHONE;
			   }
		   }
		   
		   if( this.agent.tablet ) {
			   this.type = this.TYPE_TABLET;
		   }
		   
		   if( !this.type ) {
			   this.type = this.TYPE_DESKTOP;
		   }
		   
	   }
};


/**
 * 일괄치환
 * @replaceAll
 */
String.prototype.replaceAll = function( str1, str2 ) {
	var temp_str = '';
	if( this.trim() != '' && str1 != str2 ) {
		temp_str = this.trim();
		while( temp_str.indexOf(str1) > -1 ) {
			temp_str = temp_str.replace(str1, str2);
		}
	}
	return temp_str;
};

/**
 * 시작일이 월요일때의 getWeek()
 * @returns
 */
Date.prototype.getMondayWeek = function() {
    var determinedate = new Date();
    determinedate.setFullYear(this.getFullYear(), this.getMonth(), this.getDate());
    var D = determinedate.getDay();
    // 시작일이 월요일때의 처리
    if(D == 0) {
    	D = 7;
    }
    determinedate.setDate( determinedate.getDate() + (4 - D) );
    var YN = determinedate.getFullYear();
    var ZBDoCY = Math.floor((determinedate.getTime() - new Date(YN, 0, 1, -6)) / 86400000);
    var WN = 1 + Math.floor(ZBDoCY / 7);
    ( 10 > WN ) && ( WN = '0' + WN ); 
    return Number( YN + '' + WN );
};

/**
 * 시작일이 일요일때의 getWeek()
 * @returns
 */
Date.prototype.getSundayWeek = function() {
	var dayOfMonth = this.getDate();	
	var first = new Date( this.getFullYear(), this.getMonth(), 1 );
	var monthFirstDateDay = first.getDay();	
	return Math.ceil( (dayOfMonth + monthFirstDateDay) / 7 );
};

/**
 * Document ready Event!
 */
$( document ).ready( function() {
	//url 기준으로 메뉴 활성화
	jdg.util.setVisibleCtegory();
	// 테이블 colroup width 일괄 지정
	jdg.util.resizeColgroupWidth();
	// 공통데이터 select box 초기화
	jdg.util.initSelectBox();

});

/**
 * Hash EVENT!
 */
$(function() {
	$(window).hashchange( function() {
		var hash = location.hash;
		var localPath = (window.location.pathname).split('/');
		var state = localPath[localPath.length - 1];
		//  BC 출조 처리
		if( 'schedule' === state && '' !== hash ) {
			if( $.isFunction( Bplat.viewPkg.BplatBody.createCalendar ) ) {
				var hashDay = hash.replace('#','');
				var year = hashDay.substring(0,4);
				var month = hashDay.substring(4,6);
				Bplat.viewPkg.BplatBody.createCalendar(year,month-1);
			}
		}
		// WF 조행기 페이징 처리
		if( ('member' === state || 'cptn' == state) && 'fish' === localPath[localPath.length - 2] && '' !== hash ) {
			if( $.isFunction( Bplat.viewPkg.BplatBody.getFishList ) ) {
				Bplat.viewPkg.BplatBody.getFishList( hash.replace('#','') );
			}
		}
	});
	$(window).hashchange();
});

/*!
 * jQuery hashchange event - v1.3 - 7/21/2010
 * http://benalman.com/projects/jquery-hashchange-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function($,window,undefined){
  '$:nomunge'; // Used by YUI compressor.
  
  // Reused string.
  var str_hashchange = 'hashchange',
    
    // Method / object references.
    doc = document,
    fake_onhashchange,
    special = $.event.special,
    
    // Does the browser support window.onhashchange? Note that IE8 running in
    // IE7 compatibility mode reports true for 'onhashchange' in window, even
    // though the event isn't supported, so also test document.documentMode.
    doc_mode = doc.documentMode,
    supports_onhashchange = 'on' + str_hashchange in window && ( doc_mode === undefined || doc_mode > 7 );
  
  // Get location.hash (or what you'd expect location.hash to be) sans any
  // leading #. Thanks for making this necessary, Firefox!
  function get_fragment( url ) {
    url = url || location.href;
    return '#' + url.replace( /^[^#]*#?(.*)$/, '$1' );
  };
  
  // Method: jQuery.fn.hashchange
  // 
  // Bind a handler to the window.onhashchange event or trigger all bound
  // window.onhashchange event handlers. This behavior is consistent with
  // jQuery's built-in event handlers.
  // 
  // Usage:
  // 
  // > jQuery(window).hashchange( [ handler ] );
  // 
  // Arguments:
  // 
  //  handler - (Function) Optional handler to be bound to the hashchange
  //    event. This is a "shortcut" for the more verbose form:
  //    jQuery(window).bind( 'hashchange', handler ). If handler is omitted,
  //    all bound window.onhashchange event handlers will be triggered. This
  //    is a shortcut for the more verbose
  //    jQuery(window).trigger( 'hashchange' ). These forms are described in
  //    the <hashchange event> section.
  // 
  // Returns:
  // 
  //  (jQuery) The initial jQuery collection of elements.
  
  // Allow the "shortcut" format $(elem).hashchange( fn ) for binding and
  // $(elem).hashchange() for triggering, like jQuery does for built-in events.
  $.fn[ str_hashchange ] = function( fn ) {
    return fn ? this.bind( str_hashchange, fn ) : this.trigger( str_hashchange );
  };
  
  // Property: jQuery.fn.hashchange.delay
  // 
  // The numeric interval (in milliseconds) at which the <hashchange event>
  // polling loop executes. Defaults to 50.
  
  // Property: jQuery.fn.hashchange.domain
  // 
  // If you're setting document.domain in your JavaScript, and you want hash
  // history to work in IE6/7, not only must this property be set, but you must
  // also set document.domain BEFORE jQuery is loaded into the page. This
  // property is only applicable if you are supporting IE6/7 (or IE8 operating
  // in "IE7 compatibility" mode).
  // 
  // In addition, the <jQuery.fn.hashchange.src> property must be set to the
  // path of the included "document-domain.html" file, which can be renamed or
  // modified if necessary (note that the document.domain specified must be the
  // same in both your main JavaScript as well as in this file).
  // 
  // Usage:
  // 
  // jQuery.fn.hashchange.domain = document.domain;
  
  // Property: jQuery.fn.hashchange.src
  // 
  // If, for some reason, you need to specify an Iframe src file (for example,
  // when setting document.domain as in <jQuery.fn.hashchange.domain>), you can
  // do so using this property. Note that when using this property, history
  // won't be recorded in IE6/7 until the Iframe src file loads. This property
  // is only applicable if you are supporting IE6/7 (or IE8 operating in "IE7
  // compatibility" mode).
  // 
  // Usage:
  // 
  // jQuery.fn.hashchange.src = 'path/to/file.html';
  
  $.fn[ str_hashchange ].delay = 50;
  /*
  $.fn[ str_hashchange ].domain = null;
  $.fn[ str_hashchange ].src = null;
  */
  
  // Event: hashchange event
  // 
  // Fired when location.hash changes. In browsers that support it, the native
  // HTML5 window.onhashchange event is used, otherwise a polling loop is
  // initialized, running every <jQuery.fn.hashchange.delay> milliseconds to
  // see if the hash has changed. In IE6/7 (and IE8 operating in "IE7
  // compatibility" mode), a hidden Iframe is created to allow the back button
  // and hash-based history to work.
  // 
  // Usage as described in <jQuery.fn.hashchange>:
  // 
  // > // Bind an event handler.
  // > jQuery(window).hashchange( function(e) {
  // >   var hash = location.hash;
  // >   ...
  // > });
  // > 
  // > // Manually trigger the event handler.
  // > jQuery(window).hashchange();
  // 
  // A more verbose usage that allows for event namespacing:
  // 
  // > // Bind an event handler.
  // > jQuery(window).bind( 'hashchange', function(e) {
  // >   var hash = location.hash;
  // >   ...
  // > });
  // > 
  // > // Manually trigger the event handler.
  // > jQuery(window).trigger( 'hashchange' );
  // 
  // Additional Notes:
  // 
  // * The polling loop and Iframe are not created until at least one handler
  //   is actually bound to the 'hashchange' event.
  // * If you need the bound handler(s) to execute immediately, in cases where
  //   a location.hash exists on page load, via bookmark or page refresh for
  //   example, use jQuery(window).hashchange() or the more verbose 
  //   jQuery(window).trigger( 'hashchange' ).
  // * The event can be bound before DOM ready, but since it won't be usable
  //   before then in IE6/7 (due to the necessary Iframe), recommended usage is
  //   to bind it inside a DOM ready handler.
  
  // Override existing $.event.special.hashchange methods (allowing this plugin
  // to be defined after jQuery BBQ in BBQ's source code).
  special[ str_hashchange ] = $.extend( special[ str_hashchange ], {
    
    // Called only when the first 'hashchange' event is bound to window.
    setup: function() {
      // If window.onhashchange is supported natively, there's nothing to do..
      if ( supports_onhashchange ) { return false; }
      
      // Otherwise, we need to create our own. And we don't want to call this
      // until the user binds to the event, just in case they never do, since it
      // will create a polling loop and possibly even a hidden Iframe.
      $( fake_onhashchange.start );
    },
    
    // Called only when the last 'hashchange' event is unbound from window.
    teardown: function() {
      // If window.onhashchange is supported natively, there's nothing to do..
      if ( supports_onhashchange ) { return false; }
      
      // Otherwise, we need to stop ours (if possible).
      $( fake_onhashchange.stop );
    }
    
  });
  
  // fake_onhashchange does all the work of triggering the window.onhashchange
  // event for browsers that don't natively support it, including creating a
  // polling loop to watch for hash changes and in IE 6/7 creating a hidden
  // Iframe to enable back and forward.
  fake_onhashchange = (function(){
    var self = {},
      timeout_id,
      
      // Remember the initial hash so it doesn't get triggered immediately.
      last_hash = get_fragment(),
      
      fn_retval = function(val){ return val; },
      history_set = fn_retval,
      history_get = fn_retval;
    
    // Start the polling loop.
    self.start = function() {
      timeout_id || poll();
    };
    
    // Stop the polling loop.
    self.stop = function() {
      timeout_id && clearTimeout( timeout_id );
      timeout_id = undefined;
    };
    
    // This polling loop checks every $.fn.hashchange.delay milliseconds to see
    // if location.hash has changed, and triggers the 'hashchange' event on
    // window when necessary.
    function poll() {
      var hash = get_fragment(),
        history_hash = history_get( last_hash );
      
      if ( hash !== last_hash ) {
        history_set( last_hash = hash, history_hash );
        
        $(window).trigger( str_hashchange );
        
      } else if ( history_hash !== last_hash ) {
        location.href = location.href.replace( /#.*/, '' ) + history_hash;
      }
      
      timeout_id = setTimeout( poll, $.fn[ str_hashchange ].delay );
    };
    

    $.browser.msie && !supports_onhashchange && (function(){
      
      var iframe,
        iframe_src;
      
      self.start = function(){
        if ( !iframe ) {
          iframe_src = $.fn[ str_hashchange ].src;
          iframe_src = iframe_src && iframe_src + get_fragment();
          
          // Create hidden Iframe. Attempt to make Iframe as hidden as possible
          // by using techniques from http://www.paciellogroup.com/blog/?p=604.
          iframe = $('<iframe tabindex="-1" title="empty"/>').hide()
            
            // When Iframe has completely loaded, initialize the history and
            // start polling.
            .one( 'load', function(){
              iframe_src || history_set( get_fragment() );
              poll();
            })
            
            // Load Iframe src if specified, otherwise nothing.
            .attr( 'src', iframe_src || 'javascript:0' )
            
            // Append Iframe after the end of the body to prevent unnecessary
            // initial page scrolling (yes, this works).
            .insertAfter( 'body' )[0].contentWindow;
          
          // Whenever `document.title` changes, update the Iframe's title to
          // prettify the back/next history menu entries. Since IE sometimes
          // errors with "Unspecified error" the very first time this is set
          // (yes, very useful) wrap this with a try/catch block.
          doc.onpropertychange = function(){
            try {
              if ( event.propertyName === 'title' ) {
                iframe.document.title = doc.title;
              }
            } catch(e) {}
          };
          
        }
      };
      
      // Override the "stop" method since an IE6/7 Iframe was created. Even
      // if there are no longer any bound event handlers, the polling loop
      // is still necessary for back/next to work at all!
      self.stop = fn_retval;
      
      // Get history by looking at the hidden Iframe's location.hash.
      history_get = function() {
        return get_fragment( iframe.location.href );
      };
      
      // Set a new history item by opening and then closing the Iframe
      // document, *then* setting its location.hash. If document.domain has
      // been set, update that as well.
      history_set = function( hash, history_hash ) {
        var iframe_doc = iframe.document,
          domain = $.fn[ str_hashchange ].domain;
        
        if ( hash !== history_hash ) {
          // Update Iframe with any initial `document.title` that might be set.
          iframe_doc.title = doc.title;
          
          // Opening the Iframe's document after it has been closed is what
          // actually adds a history entry.
          iframe_doc.open();
          
          // Set document.domain for the Iframe document as well, if necessary.
          domain && iframe_doc.write( '<script>document.domain="' + domain + '"</script>' );
          
          iframe_doc.close();
          
          // Update the Iframe's hash, for great justice.
          iframe.location.hash = hash;
        }
      };      
    })();
  
    return self;
  })();
  
})(jQuery,this);


$.download = function (url, data, method) {
    if (url && data) {
        //convert the data object into input HTML fields
        var inputs = '';
        var convertToInput = function (key, keyStr, obj) {
            if (typeof obj === 'undefined') {
                return;
            } else if (typeof obj === "object") {
                for (var innerKey in obj) {
                    if (obj.hasOwnProperty(innerKey)) {
                        var innerKeyStr = '';
                        if (keyStr === '') {
                            innerKeyStr = innerKey.toString();
                        } else {
                            innerKeyStr = keyStr + "[" + innerKey.toString() + "]";
                        }
                        convertToInput(innerKey, innerKeyStr, obj[innerKey]);
                    }
                }
                return;
            } else if ($.isArray(obj)) {
                obj.forEach(function (item) {
                    convertToInput(key, keyStr + "[]", item);
                });
                return;
            }

            inputs += "<input type='hidden' name='" + keyStr + "' value='" + obj + "' />";
        };
        convertToInput(null, '', data);

        //send request
        jQuery('<form action="' + url + '" method="' + (method || 'post') + '">' + inputs + '</form>').appendTo('body').submit().remove();
    };
};


function recvImage( ImageID ) {	
	    var file = {name: ImageID + '.jpg', id:ImageID};	
		var rsp = {};
		rsp.response = '{"FILE_ID": "' + ImageID + '"}';	
		Bplat.viewPkg.BplatBody.fileList.uploader.trigger('FileUploaded',file, rsp);	
}

function autoDataGetter(comp)
{
 var key;
 var childComp;
 var value;
 
 var retObject = {};
 
 var childs = comp.find("em,input,checkbox,select,textarea"); 
 var size = childs.length;
 
 for (var idx = 0; idx < size; idx++)
 {
	  childComp = $(childs[idx]);
	  
	  key = childComp.data('key');  
	  fmt = childComp.data('format');
	  
	  if (key == null)
	  {
		  continue;
	  }
	 	
	  if (childComp.is("em"))
	  {
		  value = childComp.text();
	  }
	  else if (childComp.is(":checkbox"))
	  {
		  value = childComp.attr('checked') ? "Y" : "N";
	  }
	  else
	  {
		  value = childComp.val();
	  }	  
	  
	  if (childComp.css('display') == 'none' && value == "")
	  {
		  continue;
	  }	  
	  
	  if (value != null)
	  {
		  retObject[key] = value.trim();
	  }  
	  
	  if (childComp.is("select"))
	  {
		  retObject[key + "_TEXT"] = childComp.find('option:selected').text();
	  }
 }
 
 return retObject;
}

function autoDataSetter(comp, data)
{
 var key;
 var childComp;
 var value;
 
 var fmt;
 
 var childs = comp.find("[data-key]"); 
 var size = childs.length;
 
 for (var idx = 0; idx < size; idx++)
 {
	  childComp = $(childs[idx]);
	  
	  key = childComp.data('key'); 
	  fmt = childComp.data('format'); 
	 
	  value = data[key];
	  
	  if (value == null)
	  {
		  value = "";
	  }
	  
	  if (fmt != null && value.length >= 8)
	  {
		  value = strToDateString(value);
	  }
	  
	  if (childComp.is(":checkbox"))
	  {
		  var chk = (value != null && value == "Y");
		  childComp.attr('checked', chk);		  
	  }	  
	  else if (childComp.is("select") || childComp.is("textarea") || childComp.is("input"))
	  {
		  childComp.val(value);
	  }
	  else
	  {
		  childComp.html(value);
	  }
 }
}

function checkData(cond, err_msg)
{
	if (cond)
	{
		throw err_msg;
	}
}

function setupEtcInput(form, data)
{
	 var selectObjs = $("select[data-handle]");
	
	 var size = selectObjs.length;
	 var selObj;
	 var inpObj;
	 var value;
	 var inpFieldName;
	 
	 for (var idx = 0; idx < size; idx++)
	 {
		 selObj = $(selectObjs[idx]);
		 inpFieldName = selObj.data('handle');
		 inpObj = form.find('input[data-key=' + inpFieldName + ']');
		 value = data[selObj.data('key')];
		 
		if (value == undefined)
		{
			value = "";
		} 
		
		if (value == 'etc')
		{
			inpObj.val(data[inpFieldName]);
		}
		else if (selObj.val() == "" && value != "")
		{
			selObj.val('etc');
			inpObj.val(value);
		}
		else
		{
			inpObj.val('');
			inpObj.hide();
		}	 
	 }
}

function dateToString(dt)
{
	return dt.getFullYear() + '-' + jdg.util.setStringFillZero(dt.getMonth() + 1,2) + '-' + jdg.util.setStringFillZero(dt.getDate(),2);
}

function dateToStr(dt)
{
	return dt.getFullYear() + jdg.util.setStringFillZero(dt.getMonth() + 1,2) + jdg.util.setStringFillZero(dt.getDate(),2);
}

function strToDateString(str)
{
	return str.substr(0,4) + '-' + str.substr(4,2) + '-' + str.substr(6,2) ;
}

function getCurrDateString()
{
	var dt = new Date();	
	return dt.getFullYear() + jdg.util.setStringFillZero(dt.getMonth() + 1,2) + jdg.util.setStringFillZero(dt.getDate(),2);
}

function format00(value)
{
	if (value < 10)
		return "0" + value;
	return value;	
}

function addMovieUrl(container)
{
	var youtubeUrl = prompt("유튜브 공유주소를 입력하세요.\n예: https://youtu.be/SZKFdDDMk4Q","");
	var imgUrl = "";

	if (youtubeUrl == "" || youtubeUrl == null)
	{
		return false;
	}
	
	youtubeUrl = youtubeUrl.replaceAll("https", "http");	
	
	var vid = youtubeUrl.match('youtu.be') ? youtubeUrl.substring(16, 30):youtubeUrl.substring(31, 45);		
	imgUrl = "https://img.youtube.com/vi/" + vid + "/0.jpg";		
	
	var fileList = container.fileList.getFileList() ;
	
	for (var idx in fileList) 
	{
		if (fileList[idx].IMG_ID == vid)
			{
				alert('이미 추가되어 있는 동영상입니다.');
				return false;
			}
	}

	var img = $("<img />").attr('src', imgUrl)
    .load(function() {
        if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth < 130) {
        	alert("유튜브 공유주소가 잘못었습니다..");
            return false;
        }
        else
        {
			var mrow = container.$movieListRow.clone();
			
			mrow.find('#vfrm').attr('src', "//www.youtube.com/embed/" + vid);
			mrow.attr('IMG_ID',vid);					
			
			mrow.find('.fileName').val( youtubeUrl );
			
			mrow.find('.fileDelBtn').click( function() {
				// fileArray 삭제
				event.preventDefault();
				
				if (this.parentElement.className == "movieListRow")
				 {
					this.parentElement.remove();
				 }
				else if (this.parentElement.parentElement.className == "movieListRow")
				{
					this.parentElement.parentElement.remove();
				}
				
			});
			
			$('.fileListContainer').find('.fileList').append(mrow);
			
			return false;
        	
        }
    });

	return false;
}


function changeResizeMovieFrame()
{
	var bWidth = $(document.body).width();
	
	var iWidth = bWidth - 40;
	
	if (iWidth > 500)
	{
		iWidth = 500;
	}
	
	var iHeight = iWidth * 0.63;

	$(".movIframe").width(iWidth);
	$(".movIframe").height(iHeight);
}


function resizeMovieFrame()
{
	if ($(".movIframe") != null)
	{
		changeResizeMovieFrame();
		
		$(window).resize(function(){					
			changeResizeMovieFrame();
		});	
	}
}

// 다수의 엘리먼트중 선택된 엘리먼트를 이동
// 한칸 위로 갈때는 -1, 한칸 아래로 갈때는 +1
function changeElementIndex(btnObj, c)
{
	if (c == null || isNaN(c)) return;
	
	var me = $(btnObj).parent();
	var brothers = me.parent().children();
	var cnt = brothers.length;
	var idx = me.index();
	
	if (c == -1)
		{
			if (cnt == 1 || idx == 0) return;		
			brothers.eq(idx - 1).before(me);
		}
	else if (c == +1)
		{
			if (idx == cnt - 1) return;	
			brothers.eq(idx + 1).after(me);		
		}
}

function stopEvent(evnt) {
	   if(evnt.stopPropagation) {
	      evnt.stopPropagation(); // FF
	   } else {
	      evnt.cancleBubble=true; // IE
	   }
	}

function popupScrollOpen(url){
	popupOpen(url,'선박관리자',screen.width, screen.height,', scrollbars=yes,resizable=yes,fullscreen=no');
}

function popupFullScreen(url)
{
    popupOpen(url,'선박관리자',screen.width, screen.height,',fullscreen=yes,scrollbars=yes');
}

function popupOpen(url,titleTxt,wdt,hgt, attr)
{
	if (attr == null)
	{
		attr = "";
	}
	
    var win = window.open(url,titleTxt, 'height=' + hgt + ',width=' + wdt+ attr);    
    
    if (win == null)
    {
    	alert('팝업이 차단되어 있습니다. 팝업차단을 해제해주십시오.');
    }
    else
    {
    	win.focus();
    }
}


function rgb2hex(rgb) {
    rgb = Array.apply(null, arguments).join().match(/\d+/g);
    rgb = ((rgb[0] << 16) + (rgb[1] << 8) + (+rgb[2])).toString(16);
    return rgb;
};


function preventEvent(e)
{
	if (e.preventDefault) {
	    e.preventDefault();
	} else {
	    e.returnValue = false;
	}	
}

function scrollBottom()
{
	//$("html, body").animate({ scrollTop: $(document).height() }, 200);
}


function isHoliday(dateval)
{
	var holistr = null;
	var dateYear = dateval.substr(0,4);
	
	if (dateYear == '2019')
	{
		holistr = "0101,0204,0205,0206,0301,0506,0606,0815,0912,0913,1003,1009,1225";	
	}
	else if (dateYear == '2020')
	{
		holistr = "0101.0124,0127,0430,0505,0930,1001,1002,1009,1225";
	}
	else if (dateYear == '2021')
	{
		holistr = "0101.0211,0212,0301,0505,0519,0920,0921,0922";
	}
	else if (dateYear == '2022')
	{
		holistr = "0101.0131,0201,0202,0301,0505,0606,0815,0909,0912,1003";
	}
	
	if (holistr)
	{
		var dateMd = dateval.substr(4,4);		
		return holistr.indexOf(dateMd, 0) >= 0;
	}
	
	return false;
}
