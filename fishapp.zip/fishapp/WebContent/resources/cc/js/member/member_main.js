defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberMainURL = $('#memberMainURL').val();
				this._memberListURL = $('#memberListURL').val();
				this._memberDetailtURL = $('#memberDetailtURL').val();
				this._bizDetailURL = $('#bizDetailURL').val();
				this._memberEmailPopupURL = $('#memberEmailPopupURL').val();
				
				this._pageURL = $('#pageURL').val();
				this._shipURL = $('#shipURL').val();
				
				//SHIP_ID
				this.$shipId = $('#shipId').val();
				
				// element
				this.$listContainer = $('#memberListContainer');
				this.$listTemplate = $('#memberListTemplate');
				this.$searchBtn = $('#searchBtn');
				this.$searchTxt = $('#searchTxt');
				this.$selectPage = $('#selectPage');
				this.$selectShip = $('#selectShip');
				this.$detailFormSendMail = $('#sendMail');
				this.$detailFormSendSms = $('#sendSms');
				this.$searchType = $(':radio[name="searchRdo"]');
				this.$bizDetail = $('#bizDetail');
				
				// form
				this.$srchForm = $('#memberSearchForm');
				this.$detailForm = $('#memberDetailForm');
				
				
				// static variable
				this.selectMemberId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				//DEFAULT SELECTED PERPAGE 
				this.$selectPage.val(jdg.util.setItemCnt());
				
				this.defaultParam = {
					 'PAGE' : '1'
					,'PERPAGE' : '5'
				};
				
				//DEFAULT SELECTED SHIP
				this.$selectShip.val(this.$shipId);
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$srchForm.submit(function() {
					// 회원목록조회
					var param = {'PAGE': '1'};
					_self.getMemberList(param);
					return false;
				});
				
				// 검색버튼클릭
				_self.$searchBtn.click( function() {
					//validation check
					
					
					
					var serchTxtVal = $('#searchTxt').val();
					var page = '1';
					var itemCnt = _self.getPageAnditemCnt("itemCnt");
					var searchType= $(':radio[name="searchRdo"]:checked').attr('data-value');
					Bplat.view.loadPage(_self._pageURL
										+ '?page=' + page 
										+ '&itemCnt=' + itemCnt
										+ '&searchType='+ searchType
										+ '&word='+serchTxtVal  );
				});
				
				//검색어에서 엔터시 처리
				_self.$searchTxt.keydown( function(e) {
					
					if(window.event){
						keyValue = window.event.keyCode;
				    }else{
					    keyValue = e.keyCode;
				    }
					
					if(keyValue == 13){
						var serchTxtVal = $('#searchTxt').val();
						var page = '1';
						var itemCnt = _self.getPageAnditemCnt("itemCnt");
						var searchType= $(':radio[name="searchRdo"]:checked').attr('data-value');
						Bplat.view.loadPage(_self._pageURL
											+ '?page=' + page 
											+ '&itemCnt=' + itemCnt
											+ '&searchType='+ searchType
											+ '&word='+serchTxtVal  );
					}
				});
				
				// 페이징 셀렉트박스 변경시
				_self.$selectPage.change( function() {
					var itemCnt =  _self.$selectPage.find(":selected").val();
					var page = '1';
					
					//검색 결과 유지
					var searchType = _self.getURLParameter("searchType");
					var serchTxtVal = _self.getURLParameter("word");
					if(searchType == 'null' || serchTxtVal == 'null'){
						Bplat.view.loadPage(_self._pageURL
								+ '?page=' + page 
								+ '&itemCnt=' + itemCnt);
					}else{
						Bplat.view.loadPage(_self._pageURL
								+ '?page=' + page 
								+ '&itemCnt=' + itemCnt
								+ '&searchType='+ searchType
								+ '&word='+serchTxtVal
						);
					}
					
					
					
					
				});
				
				// 선박 셀렉트박스 변경시
				_self.$selectShip.change( function() {
					var shipId =  _self.$selectShip.find(":selected").val();
					Bplat.view.loadPage(_self._shipURL+ shipId + '/member');
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );

				});
				
				// 상세폼 메일보내기
				_self.$detailFormSendMail.click( function() {
					_self.sendMail();
				});
				
				// 상세폼 문자보내기
				_self.$detailFormSendSms.click( function() {
					_self.sendSms();
				});
				
				jdg.util.setPlaceHolder(_self.$searchTxt, "검색어");
			},
			
			
			//상세 페이지 열기
			'openDetailForm' : function( $tr ){
				var _self = this;
				var memId = _self.selectMemberId = $tr.attr('rowKey');
				$.cookie("selectMemberId", memId);
				var param = {'MEM_ID':memId};
				
				$.ajax({
					 url : _self._memberDetailtURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('memberDetail') ) {
				    		_self.selectFormShow('detail', data.memberDetail);    		
				    	}
				    }
				});
				
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'detail' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
					
					//상세폼이 보여질때 상세폼으로 포커스이동
					$detailForm.attr('tabindex',-1).focus().removeAttr('tabindex');
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$detailForm.hide();
				}
			},
			
			// 회원 목록 조회
			'getMemberList' : function( param ) {
				var _self = this;
				
				//url  -> server
				param.PAGE = param.page;
				var itemCnt = jdg.util.setItemCnt();
				switch (itemCnt) {
					case '10':
						itemCnt = 10;
						break;
					case '20':
						itemCnt = 20;
						break;
					case '30':
						itemCnt = 30;
						break;
					default:
						itemCnt = 5;
						break;
				}
				param.PERPAGE = itemCnt;
				
				//검색 후 HOLD
				var word = _self.getURLParameter("word");
				var searchType = _self.getURLParameter("searchType");
				if(param.searchType == 'name'){
					$(':radio[name="searchRdo"]:radio[value="MEM_NAME"]').attr('checked', 'true');
					_self.$searchTxt.val(word);
					param.MEM_NAME = word;
				}else if(param.searchType == 'email'){
					$(':radio[name="searchRdo"]:radio[value="EMAIL"]').attr('checked', 'true');
					_self.$searchTxt.val(word);
					param.EMAIL = word;
				}else if(param.searchType == 'tel'){
					$(':radio[name="searchRdo"]:radio[value="TEL"]').attr('checked', 'true');
					_self.$searchTxt.val(word);
					param.TEL = word;
				}else{
					$(':radio[name="searchRdo"]:radio[value="MEM_NAME"]').attr('checked', 'true');
					_self.$searchTxt.val("검색어");
				}
				//--검색 후 HOLD
				
				$.extend( _self.defaultParam , param);	
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : _self.defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('memberList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.memberList, 'MEM_ID' , function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    		});
				    		// 페이징 초기화
				    		var searchType = _self.getURLParameter("searchType");
							var serchTxtVal = _self.getURLParameter("word");
				    		$('#memberListPaging').paging({
								 current: _self.defaultParam.PAGE
								,max: (Math.ceil(data.total / itemCnt))
								,onclick:function(e,page){
									if(searchType == 'null' || serchTxtVal == 'null'){
										Bplat.view.loadPage(_self._pageURL
												+ '?page=' + page 
												+ '&itemCnt=' + itemCnt);
									}else{
										Bplat.view.loadPage(_self._pageURL
												+ '?page=' + page 
												+ '&itemCnt=' + itemCnt
												+ '&searchType='+ searchType
												+ '&word='+serchTxtVal
										);
									}
								}
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.memberList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			
			//PAGE & PERPAGE 초기화 및 현재 URL 설정 RETURN 
			'getPageAnditemCnt' : function(name){
				var _self = this;
				if(name =='page'){
					var page = _self.getURLParameter(name);
					if(page == 'null') page = 1;
					return page;
				}else if(name == 'itemCnt'){
					var itemCnt = _self.getURLParameter(name);
					if(itemCnt == 'null') itemCnt = 5;
					return itemCnt;
				}
			},
			
			'getDetailBiz' : function(){
				var _self = this;
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	_self.$bizDetail.data("bizDetail", data.bizDetail);
				    }
				});
			},
			
			'getURLParameter' : function(name){
				return decodeURI(
				        (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search)||[,null])[1]
				);
			},
			
			
			'sendMail' : function( mode, data ) {
				var _self = this;
				var bizDetail = _self.$bizDetail.data("bizDetail");
				if(!bizDetail.SMTP_HOST){
					alert( '업체정보 > SMTP정보 를 입력하셔야 메일을 발송할 수 있습니다' );
					return;
				}
				if(!bizDetail.SMTP_PORT){
					alert( '업체정보 > SMTP정보 를 입력하셔야 메일을 발송할 수 있습니다' );
					return;
				}
				if(!bizDetail.SMTP_USER){
					alert( '업체정보 > SMTP정보 를 입력하셔야 메일을 발송할 수 있습니다' );
					return;
				}
				Bplat.view.openPopup({
					'url' : _self._memberEmailPopupURL
					,'width' : 600
					,'height' : 500
				}, 'member_email_popup');
				
			},
			'sendSms' : function( mode, data ) {
				alert("sms보내기 버튼!!!");
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				
				// 초기화
				this.setElement();
				this.setEvent();
				// 회원목록조회
				this.getMemberList(p_param);
				this.getDetailBiz();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});

