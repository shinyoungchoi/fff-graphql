defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleMainURL = $('#scheduleMainURL').val();
				// element
				this.$srhShipSel = $('#srchShipSel');
				this.$srhYearSel = $('#scheduleYearSel');
				this.$srhMonthSel = $('#scheduleMonthSel');
				this.$prevMonth = $('#schedulePrevMonth');
				this.$nextMonth = $('#scheduleNextMonth');
				this.$regBtn = $('#scheduleRegBtn');
				this.$layerContainer = $('#layerContainer');
				this.$quickDetail = $('#scheduleListTemplate').find('.scheduleQuickDetail');
				// Calendar
				this.$calendarContainer = $('#calendarContainer');
				this.$calendarRow = $('#calendarTemplate').find('.calendarRow');
				this.$scheduleRow = $('#scheduleListTemplate').find('.scheduleRow');
				// static variable
				this.currentScheduleList = null;
				this.selectShipId = null;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {
					var year = Number(_self.$srhYearSel.val());
					var month = Number(_self.$srhMonthSel.val());
					if( month == 1 ) {
						if( _self.$srhYearSel.find('option:eq(0)').val() == year ) {
							alert('더이상 조회하실수 없습니다.');
							return;
						}
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					var year = Number(_self.$srhYearSel.val());
					var month = Number(_self.$srhMonthSel.val());
					if( month == 12 ) {
						if( _self.$srhYearSel.find('option:last').val() == year ) {
							alert('더이상 조회하실수 없습니다.');
							return;
						}
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				// Calendar 지정년월로 이동
				$('.changeSchedule').change( function() {
					var year = _self.$srhYearSel.val();
					var month = _self.$srhMonthSel.val();
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				// 마우스 오버시 상세 레이어
				_self.$calendarContainer.delegate('.scheduleRow','click', function( e ){
					// 초기화
					var scheId = $(this).attr('scheId');
					if( _self.$layerContainer.find('.scheduleQuickDetail [schdId='+scheId+']').length > 0 ) return;
					_self.$layerContainer.empty();
					// 레이어팝업생성
					var $this = $(this);
					var offSet = $this.offset();
					var $layer = _self.$quickDetail.clone();
					$layer.find('.jdg-btn-close').click( function() {
						$layer.remove();
					});
					$layer.attr('scheId', scheId);
					// 좌표추출
					var pageWidth = $('body').width()/2;
					$layer.css( 'top', offSet.top+$this.height() );
					if( pageWidth < offSet.left ) $layer.css( 'left', (offSet.left-$layer.width()+$this.width()) );
					else $layer.css( 'left', offSet.left );
					// 데이터셋팅
					$.each(_self.currentScheduleList, function(idx,data) {
						if( scheId === data.SCHD_ID ) {
							jdg.util.detailDataSetting( $layer, data );
							// 출조일 셋팅
							var schdDate = data.SCHD_DATE+data.SCHD_TIME;
							if( schdDate ) $layer.find('[data-type=SCHD_DATE]').text(jdg.util.replaceDate(schdDate));
							// 출조상세페이지로 이동
							$layer.find('.loadScheduleDetailPage').click( function() {
				   				// 출조상세로 이동
								Bplat.view.loadPage( 'schedule/detail_form?SCHD_ID=' + data.SCHD_ID + "&SHIP_ID=" + data.SHIP_ID);
							});
							return;
						}
					});
					_self.$layerContainer.append( $layer );
				});
				
				/* 출조등록
				_self.$regBtn.click(function() {
    				// 출조등록으로 이동
					Bplat.view.loadPage( 'schedule/insert_form?SHIP_ID=' + _self.$srhShipSel.val());
				}); */
				
			},
			// 스케줄 상단 년,월 초기화
			'initDatePicker' : function( year ) {
				var _self = this;
				for( var i=2010 ; i<=(year+5) ; i++ ) {
					var $option = $('<option>').val(i).text(i+'년');
					_self.$srhYearSel.append($option);
				}
			},
			// 달력생성
			'createCalendar' : function( year, month ) {
				var _self = this;
				_self.$calendarContainer.empty();
				var tmpDay = new Date();
				tmpDay.setFullYear(year, month, 1);
				var dayOfMonth = tmpDay.getRangeDaysOfMonth(); //이번달
				var startDay = Number( dayOfMonth[0].split('-')[2] );
				var endDay = Number( dayOfMonth[1].split('-')[2] );
				var srhMonth = (month+1 < 10) ? '0'+(month+1) : (month+1);
				for( var i = startDay; i <= endDay ; i++ ) {
					tmpDay.setDate(i);
					var day = tmpDay.getDay();
					var date = tmpDay.getDate();
					var srhDate = (date<10) ? '0'+date : date;
					if( i == 1 || day == 1 ) {
						var $week = _self.$calendarRow.clone();
						_self.$calendarContainer.append( $week );
					}
					var $td = $week.find('[day='+day+']');
					$td.find('[data-type=day]').text(i);
					$td.attr('schdDate', year + '' + srhMonth + '' + srhDate);
				}
				_self.$srhYearSel.val(year);
				_self.$srhMonthSel.val(month+1);
				// 해당 Calendar의 물때 조회
				_self.getSeaTimeList( year + '' + srhMonth );
				// 해당 Calendar의 출조 스케쥴 조회
				_self.getScheduleList({'SCHD_MONTH' : year + '' + srhMonth });
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var defaultParam = {'SHIP_ID' : _self.selectShipId};
				$.extend( defaultParam, param );
				$.ajax({
					 url : 'schedule/list.json'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var scheduleList = data.scheduleList;
				    	
				    	var schdTime;
				    	var rsv_cnt;
			    		_self.currentScheduleList = scheduleList;
			    		$.each( scheduleList, function( idx, data ) {
			    			
			    			schdTime = data.SCHD_TIME.substr(0,2) + ":" + data.SCHD_TIME.substr(2,2);
			    			
			    			var $td = _self.$calendarContainer.find('[schdDate='+data.SCHD_DATE+']');
			    			var $scheduleRow = _self.$scheduleRow.clone();
			    			
			    			$scheduleRow.find('.fishTime').text(schdTime+ " " + data.SHIP_NAME);
			    			$scheduleRow.find('.sub_title').text( data.SUB_TITLE );
			    			
			    			rsv_cnt = data.RESERVE_CONFIRM_CNT * 1 + data.RESERVE_WAIT_CNT * 1;
			    			
			    			if (rsv_cnt == 0)
			    			{
			    				$scheduleRow.find('.jdg-data-cf,.jdg-data-nd').hide();
			    			}
			    			else
			    			{
			    				$scheduleRow.find('.jdg-data-cf,.jdg-data-nd').show();
				    			$scheduleRow.find('.confirmCnt').text( data.RESERVE_CONFIRM_CNT );
				    			$scheduleRow.find('.waitCnt').text( data.RESERVE_WAIT_CNT );
			    			}
			    			

			    			$scheduleRow.attr('scheId', data.SCHD_ID);

			    			if (data.STATUS_CD == '113_180')
			    			{
			    				data.STATUS_NAME = '마감';
			    				$scheduleRow.find('.status_name').html("<font color=#9f9f9f>마감</font>" );
			    			}
			    			else if (data.STATUS_CD == '113_210')
			    			{
			    				$scheduleRow.find('.status_name').html("<font color=red>출조취소</font>" );
			    			}
			    			else
			    			{
			    				$scheduleRow.find('.status_name').html("<font color=blue>" + data.STATUS_NAME + "</font>");
			    			}
			    			
			    			$td.find('.scheduleContainer').append( $scheduleRow );
			    		});
				    }
				});
			},
			// 물때 초기화
			'getSeaTimeList' : function( schdDate ) {
				var _self = this;
				$.ajax({
					 url : 'schedule/seatime.json'
					,type : 'POST'
					,data : {
						'SCHD_MONTH' : schdDate
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var seatimeList = data.seatimeList;
						for( var i=0, iSize=seatimeList.length ; i < iSize ; i++ ) {
							var data = seatimeList[i];
							_self.$calendarContainer.find('[schddate='+data.SOLAR_DATE +']').find('.seaTime').text( data.MOOL );
						}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				// 초기 SHIP ID 셋팅
				var tagName = _self.$srhShipSel.prop('tagName');
				if( 'SELECT' === tagName ) _self.$srhShipSel.val( _self.shipId );
				_self.selectShipId = _self.shipId;
				
				// 캘린더 초기화
				var hash = location.hash;
				if( '' == hash ) {
					var today = new Date();
					var year = today.getFullYear();
					var month = today.getMonth();
					_self.initDatePicker( year );
					// set hash
					location.hash = year + '' + jdg.util.setStringFillZero(month+1,2);
				} else {
					var hashDay = hash.replace('#','');
					var year = Number(hashDay.substring(0,4));
					var month = Number(hashDay.substring(4,6))-1;
					_self.initDatePicker( year );
					_self.createCalendar( year, month );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
