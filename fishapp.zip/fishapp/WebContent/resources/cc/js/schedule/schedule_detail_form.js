defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleMainURL = $('#scheduleMainURL').val();
				this._scheduleDetailURL = $('#scheduleDetailURL').val();
				this._scheduleUpdateURL = $('#scheduleUpdateURL').val();
				this._reserveUpdateURL = $('#reserveUpdateURL').val();
				this._reserveUpdateStatusURL = $('#reserveUpdateStatusURL').val();
				this._reserveManURL = $('#reserveManURL').val();
				this._cancelScheduleURL = $('#cancelScheduleURL').val();
				this._removeScheduleURL = $('#removeScheduleURL').val();

				// element
				this.$shipTitle = $('#scheduleTitle');
				this.$detailForm = $('#scheduleDetailForm');
				this.$reserveContainer = $('#reserveContainer');
				this.$reserveContainer2 = $('#reserveContainer2');
				this.$reserveContainer3 = $('#reserveContainer3');
				
				this.$reserveRow = $('#reserveTemplate').find('.searchRow');
				this.$nodataRow = $('#reserveTemplate').find('.nodataRow');
				this.$scheduleUpdateFormBtn = $('#scheduleUpdateFormBtn');
				
				this.$scheduleCancelBtn = $('#scheduleCancelBtn');//출조취소버튼

				this.$updateForm = $('#scheduleUpdateForm');
				this.$cancelBtn = $('#scheduleUpdateCancelBtn');
				this.$removeScheduleBtn = $('#scheduleRemoveBtn');
				this.$updateStatusBtn = $('#scheduleUpdateStatusBtn');
				this.$srhFishKindBtn = $('#srhFishKindBtn');
				this.$srhPrepareBtn = $('#srhPrepareBtn');
				this.$srhLocDescBtn = $('#srhLocDescBtn');
				this.$scheduleListBtn = $('#scheduleListBtn');
				this.list = new component.List({
					 'container' : this.$reserveContainer
					,'template' : this.$reserveRow
					,'nodata' : this.$nodataRow
				});
				
				this.list2 = new component.List({
					 'container' : this.$reserveContainer2
					,'template' : this.$reserveRow
					,'nodata' : this.$nodataRow
				});				

				this.list3 = new component.List({
					 'container' : this.$reserveContainer3
					,'template' : this.$reserveRow
					,'nodata' : this.$nodataRow
				});		
				
				
				// static variable
				this.scheId = $('#scheId').val();
				this.detailData = null;
				this.reserveList = null;
			},
			'setEvent'		: function() {
				var _self = this;
				// 수정화면으로 변경
				_self.$scheduleUpdateFormBtn.click( function() {
					
					_self.$scheduleCancelBtn.hide();
					
					_self.$shipTitle.text('출조 수정');
					_self.$detailForm.hide();
					if( _self.reserveList.length > 0 ) {
						_self.$updateForm.find('.modifyRow').hide();
						_self.$updateForm.find('.notModifyRow').show();
					} else {
						_self.$updateForm.find('.modifyRow').show();
						_self.$updateForm.find('.notModifyRow').hide();
					}
					// 예약상태에 따른 버튼 label 변경
					if(  _self.detailData.STATUS_CD == '113_110' ) {
						_self.$updateForm.find('#scheduleUpdateStatusBtn').attr('STATUS_CD','113_170');
						_self.$updateForm.find('#scheduleUpdateStatusBtn span').text('예약마감');
					} else {
						_self.$updateForm.find('#scheduleUpdateStatusBtn').attr('STATUS_CD','113_110');
						_self.$updateForm.find('#scheduleUpdateStatusBtn span').text('예약마감 취소');
					}
					
					
					_self.createOptionSelect( _self.$updateForm.find('[data-key=PSGR_CNT]'), _self.detailData.SHIP_PSGR_CNT );	
		
					
					_self.initDatailSetting('update', _self.detailData);
					_self.$updateForm.show();
				});
				
				// 어종 선택
				_self.$srhFishKindBtn.click( function(e) {
					_self.openLayerPopup('fishKindLayer',$(this));
					return false;
				});
				
				// 채비 선택
				_self.$srhPrepareBtn.click( function() {
					_self.openLayerPopup('prepareLayer',$(this));
					return false;
				});
				
				
				
				// 출조지 선택
				_self.$srhLocDescBtn.click( function() {
					_self.openLayerPopup('locDescLayer',$(this));
					return false;
				});

				
				// 출조취소 선택
				_self.$scheduleCancelBtn.click( function() {
					_self.openLayerPopup('cancelLayer',$(this), -100, true);
					return false;
				});
				
			
				
				
				
				// 출조수정
				_self.$updateForm.submit(function() {
					_self.updateSchedule();
					return false;
				});
				
				// 출조수정취소
				_self.$cancelBtn.click(function() {
					_self.$shipTitle.text('출조 상세');
					_self.$detailForm.show();
					_self.$updateForm.hide();
					
					if(  _self.detailData.STATUS_CD != '113_210' ) {
						_self.$scheduleCancelBtn.show();
						_self.$removeScheduleBtn.show();
					}
					
					return false;
				});
				
				// 예약마감
				_self.$updateStatusBtn.click(function() {
					var $this = $(this);
					if( confirm( $this.find('span').text() + ' 하시겠습니까?') ) {
						_self.updateSchedule({'STATUS_CD' : $this.attr('STATUS_CD')});
					}
					return false;
				});
				
				// 목록으로 되돌아가기
				_self.$scheduleListBtn.click(function() {
					history.back();
				});
			},
			// 출조수정
			'updateSchedule' : function( param ) {
				var _self = this;
				var $updateForm = _self.$updateForm;
				var updateParam = {
					'SCHD_ID' : _self.scheId
				};
				if( param ) {
					// 예약마감
					$.extend( updateParam, param );
				} else {
					// validation
					if( !jdg.util.validator( $updateForm, true ) ) return false;
					
					var feeMan = $updateForm.find('[data-key=FEE]').val();
					
					if (feeMan < 10000)
					{
						alert('1인 선비는 만원이하로 입력할수 없습니다.');
						return;
					}
					
					var modifyParam = {
						  'SCHD_TIME' : $updateForm.find('.hour option:selected').val() + $updateForm.find('.minute option:selected').val()
						, 'SUB_TITLE' : $updateForm.find('[data-key=SUB_TITLE]').val()
						, 'DESCR' : $updateForm.find('[data-key=DESCR]').val()
						, 'FEE' : $updateForm.find('[data-key=FEE]').val()
						, 'FEE_WHOLE' : $updateForm.find('[data-key=FEE_WHOLE]').val()
						, 'LOC_DESC' : $updateForm.find('[data-key=LOC_DESC]').val()
						, 'FISH_KIND' : $updateForm.find('[data-key=FISH_KIND]').val()
						, 'PREPARE' : $updateForm.find('[data-key=PREPARE]').val()
						, 'PSGR_CNT' : $updateForm.find('[data-key=PSGR_CNT]').val()
					};
					$.extend( updateParam, modifyParam );
				}
				$.ajax({
					 url : _self._scheduleUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
						location.reload();
				    }
				});
			},
			// 예약수정
			'updateReserve' : function( param ) {
				var _self = this;
				$.ajax({
					 url : _self._reserveUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
						location.reload();
				    }
				});
			},
			// 예약상태수정
			'updateReserveStatus' : function( param ) {
				var _self = this;
				$.ajax({
					 url : _self._reserveUpdateStatusURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
						location.reload();
				    }
				});
			},
			
			
			// 출조취소
			'updateCancelSchedule' : function(cancelDesc) {
				var _self = this;
				
				var param = _self.detailData;
				param.DESC = cancelDesc;
				
				// 로더 생성
				jdg.util.showLoader();
				
				$.ajax({
					 url : _self._cancelScheduleURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	jdg.util.removeLoader();
				    	alert('출조취소가 완료되었습니다.');
						location.reload();
				    }
				});
			},
						
		
			// 출조상세 및 예약현황 조회
			'getDetailSchedule' : function() {
				var _self = this;
				$.ajax({
					 url : _self._scheduleDetailURL
					,type : 'POST'
					,data : {
						'SCHD_ID' : _self.scheId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var detail = data.detail;
				    	_self.detailData = detail;
				    	_self.reserveList = data.reserveList;
						_self.initDatailSetting('detail', detail);
						_self.initReserveList(data.reserveList);
				    }
				});
			},
			'initDatailSetting' : function( mode, detail ) {
				var _self = this;
				if( 'detail' === mode ) {
					
					$("#shipName").text("(" + _self.detailData.SHIP_NAME + ")");
						
					if (detail.STATUS_CD == "113_180")
					{
						detail.STATUS_NAME = "마감";
					}					
					
					// 출조상세
					var $detailForm = _self.$detailForm;
					jdg.util.detailDataSetting( $detailForm, detail );
					// 출조일 셋팅
					var schdDate = detail.SCHD_DATE+detail.SCHD_TIME;
					if( schdDate ) $detailForm.find('[data-key=SCHD_DATE]').text(jdg.util.replaceDate(schdDate));
					
					if (_self.detailData.STATUS_CD == '113_210' )
					{
						$detailForm.find('[data-key=STATUS_NAME]').css('color','red');
						$detailForm.find('[data-key=DESCR]').css('color','red');
					}
						
					if(  _self.detailData.STATUS_CD != '113_210' ) {
						_self.$scheduleCancelBtn.show();
					}
					
					//if(  _self.detailData.STATUS_CD == '113_110' ) {
					_self.$scheduleUpdateFormBtn.show();
					//}	
					
					//취소자를 제외한 전체 예약 인원
					this.reservers = detail.RESERVE_CONFIRM_CNT + detail.RESERVE_WAIT_CNT + detail.WAIT_CNT;
	
					_self.$removeScheduleBtn.show();
					_self.$removeScheduleBtn.click(_self.removeSchedule);					
					
				} else if('update' === mode ) {
					// 출조수정
					var $updateForm = _self.$updateForm;
					var detail = _self.detailData;
					jdg.util.detailDataSetting( $updateForm, _self.detailData );
					$updateForm.find('[data-type=SCHD_DATE]').text( jdg.util.replaceDate(detail.SCHD_DATE) );
					$updateForm.find('.hour').val( detail.SCHD_TIME.substr(0,2) );
					$updateForm.find('.minute').val( detail.SCHD_TIME.substr(2,4) );
					
					$updateForm.find('[data-key=PSGR_CNT]').val(detail.PSGR_CNT );
				}
			},
			// 예약현황 리스트 셋팅
			'initReserveList' : function( reserveList ) {
				var _self = this;
				// 예약현황
				
				var arr = $.grep(reserveList, function(item, index) {
					  return item.SITE_CD == 'L';
					});
				
				var arr2 = $.grep(reserveList, function(item, index) {
					  return item.SITE_CD == 'S';
					});

				var arr3 = $.grep(reserveList, function(item, index) {
					  return item.SITE_CD == 'P';
					});				
	
				_self.list.createList(arr, "RSV_ID", function(data, $row){					
					_self.makeList2(data, $row);
				});
				
				
				_self.list2.createList(arr2, "RSV_ID", function(data, $row){					
					_self.makeList(data, $row);
				});

				_self.list3.createList(arr3, "RSV_ID", function(data, $row){					
					_self.makeList2(data, $row);
				});
			
			},
				

			// 출조삭제
			"removeSchedule" : function()
			{
				var _self = Bplat.viewPkg.BplatBody;
				
				if (_self.reservers != 0)
				{
					alert('예약자가 있는 스케쥴은 삭제가 불가능합니다.');
					return false;
				}
				
				var chk = confirm("출조스케쥴을 삭제하시겠습니까?");
				
				if (chk == false)
				{
					return false;
				}
				
				var param = {
						'SCHD_ID' : _self.scheId
					};
				
				// 로더 생성
				jdg.util.showLoader();
				
				$.ajax({
					 url : _self._removeScheduleURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	jdg.util.removeLoader();
				    	alert('출조삭제가 완료되었습니다.');
				    	//목록으로 이동
				    	Bplat.view.loadPage(  '../' + _self._scheduleMainURL + '#' +  _self.detailData.SCHD_DATE.substring(0,6) );
				    }
				});
				
				
			},

			"makeList" : function(data, $row)
			{
				var _self = this;
				
				// 독선여부
				if( 'Y' === data.WHOLE_YN ) $row.find('[data-type=WHOLE_YN]').text('(독선)');
				// 예약상태별 버튼 노출 및 예약상태수정
				if( data.STATUS_CD == '104_310' ) { // 미입금
					$row.find('[data-key=STATUS_NAME]').css('color','#fd8002');
					$row.find('.rsvConfirm').show();
					$row.find('.rsvCancel').attr('STATUS_CD','104_410');
					$row.find('.rsvCancel').show();
				} else if( data.STATUS_CD == '104_340' ) { // 예약대기
					$row.find('.rsvCancel').attr('STATUS_CD','104_410');
					$row.find('.rsvCancel').show();
				} else if( data.STATUS_CD == '104_300' ) { // 예약확정/입금완료
					$row.find('[data-key=STATUS_NAME]').css('color','#6759ba');
					$row.find('.rsvCancel').attr('STATUS_CD','104_420');
					$row.find('.rsvCancel').show();
				} else if( data.STATUS_CD == '104_420' || data.STATUS_CD == '104_520') { // 예약취소/환불예정 또는 출조취소/환불예정
					$row.find('.rsvRefunds').show();
				}
				
				$row.find('.rsvManViewBtn').click( function() {
					// 승선명부 팝업
					Bplat.view.openPopup({
						 'url' : _self._reserveManURL + '?RSV_ID=' + data.RSV_ID + '&MAN_CNT=' + data.MAN_CNT 
						,'width' : 450
						,'height' : 500
					}, 'reserve_man_popup');
					return false;
				});
				
				// 예약확정
				$row.find('.rsvConfirm').click( function(){
					if( confirm('예약 확정 하시겠습니까?') ) {
						_self.updateReserveStatus({
							 'RSV_ID' : data.RSV_ID
							,'STATUS_CD' : '104_300'
						});
					}
					return false;
				});
				// 예약취소
				$row.find('.rsvCancel').click( function(){
					if( confirm('예약 취소 하시겠습니까?') ) {
						var statusCd = $( this ).attr('STATUS_CD');
						_self.updateReserveStatus({
							 'RSV_ID' : data.RSV_ID
							,'STATUS_CD' : statusCd
						});
					}
					return false;
				});
				// 환불완료 (예약취소인 경우 104_430, 출조취소인 경우 104_530)
				$row.find('.rsvRefunds').click( function(){
					if( confirm('환불 완료 하시겠습니까?') ) {
						_self.updateReserveStatus({
							 'RSV_ID' : data.RSV_ID
							,'STATUS_CD' : '104_430'
						});	
					}
					return false;
				});
				// 예약금수정
				$row.find('.totCostModify').click( function() {
					var $totCost = $row.find('[data-type=TOT_COST]');
					if( 'true' ===$totCost.attr('modify') ) {
						$totCost.attr('modify','false');
						// 수정
						_self.updateReserve({
							 'RSV_ID' : data.RSV_ID
							,'TOT_COST' : $totCost.find('input').val()
						});
					} else {
						var $modifyRow = _self.$reserveContainer2.find('[modify=true]');
						$.each( $modifyRow, function() {
							var $this = $(this);
							$this.attr('modify','false');
							$this.find('em').show();
							$this.find('input').hide();
						});
						$totCost.attr('modify','true');
						$totCost.find('em').hide();
						$totCost.find('input').show();
						$totCost.find('input').val( data.TOT_COST );
						return false;
					}
				});
				// 메모수정
				$row.find('.memoModify').click( function() {
					var $memo = $row.find('[data-type=MEMO]');
					if( 'true' ===$memo.attr('modify') ) {
						// 수정
						_self.updateReserve({
							 'RSV_ID' : data.RSV_ID
							,'MEMO' : $memo.find('input').val()
						});
					} else {
						var $modifyRow = _self.$reserveContainer2.find('[modify=true]');
						$.each( $modifyRow, function() {
							var $this = $(this);
							$this.attr('modify','false');
							$this.find('em').show();
							$this.find('input').hide();
						});
						$memo.attr('modify','true');
						$memo.find('em').hide();
						$memo.find('input').show();
						$memo.find('input').val( data.MEMO );
						return false;
					}
				});
				$row.find('.rsvManViewBtn').click( function() {
					// 승선명부 팝업
					Bplat.view.openPopup({
						 'url' : _self._reserveManURL + '?RSV_ID=' + data.RSV_ID + '&MAN_CNT=' + data.MAN_CNT 
						,'width' : 450
						,'height' : 500
					}, 'reserve_man_popup');
					return false;
				});
				
			},
			
			"makeList2" : function(data, $row)
			{
				var _self = this;
				
				// 독선여부
				if( 'Y' === data.WHOLE_YN ) $row.find('[data-type=WHOLE_YN]').text('(독선)');
				// 예약상태별 버튼 노출 및 예약상태수정
				if( data.STATUS_CD == '104_310' ) { // 미입금
					$row.find('[data-key=STATUS_NAME]').css('color','#fd8002');
					$row.find('.rsvCancel').attr('STATUS_CD','104_410');
				} else if( data.STATUS_CD == '104_340' ) { // 예약대기
					$row.find('.rsvCancel').attr('STATUS_CD','104_410');
				} else if( data.STATUS_CD == '104_300' ) { // 예약확정/입금완료
					$row.find('[data-key=STATUS_NAME]').css('color','#6759ba');
					$row.find('.rsvCancel').attr('STATUS_CD','104_420');
				} else if( data.STATUS_CD == '104_420' || data.STATUS_CD == '104_520') { // 예약취소/환불예정 또는 출조취소/환불예정
					
				}
				
				$row.find('.totCostModify').hide();
				$row.find('.memoModify').hide();				
				
				$row.find('.rsvManViewBtn').click( function() {
					// 승선명부 팝업
					Bplat.view.openPopup({
						 'url' : _self._reserveManURL + '?RSV_ID=' + data.RSV_ID + '&MAN_CNT=' + data.MAN_CNT 
						,'width' : 450
						,'height' : 500
					}, 'reserve_man_popup');
					return false;
				});
			},
						
			
			
			
			// 레이어팝업
			'openLayerPopup' : function( id, $btn, ypos, xcenter) {
				
				if (ypos == null) ypos == 0;
				
				
				var _self = this;
				var $layerContainer = $('#layerContainer');
				// 초기화
				if( $layerContainer.find('.'+id).length > 0 ) return;
				$layerContainer.empty();
				// 레이어팝업생성
				var offSet = $btn.offset();
				var $layer = $('#layerTemplate').find('.'+id).clone();
				$layer.find('.jdg-btn-close').click( function() {
					$layer.remove();
				});
				$layer.find('.item').click( function() {
					var $this = $(this);
					var $input = $btn.prev();
					var beforeVal =  $input.val();
					var val = ' ' + $this.find('strong').text() + ' ';
					if( beforeVal.search(val) == -1 ) {
						if( '' === beforeVal ) {
							$input.val( val );
						} else { 
							$input.val( beforeVal + ',' + val );
						}
					}
				});
				
				
				var scSelect = $layer.find('#sc_select')
				var scText = $layer.find('#sc_text');
				
				scText.val(scSelect.val() + " 출조를 취소합니다.");

				scSelect.change( function() {
					var scVal = this.value;

					if (scVal == "")
						{
							scText.prop('disabled', false);
							scText.val("");							
						}
					else
						{
							scText.prop('disabled', true);							
							scText.val(scVal + " 출조를 취소합니다.");
						}

					return false;
				});	

				// 출조취소팝업 닫기 클릭
				$layer.find('#scheduleCancelCloseBtn').click( function() {
					$layer.remove();
					return false;
				});				

				
				// 출조취소확정 클릭
				$layer.find('#scheduleCancelConfirmBtn').click( function() {
										
					if( confirm('출조 취소를 확정 하시겠습니까? (모든 예약은 취소됩니다.)') ) {
						
						var scText = $layer.find('#sc_text');
						
						_self.updateCancelSchedule(scText.val());
					}
					return false;
				});					
				
				
				$layer.css( 'top', (offSet.top+$btn.height() + ypos) );
				var pageWidth = $('body').width()/2;
				
				if (xcenter != null)
					{
						$layer.css( 'left', pageWidth - $layer.width()/2);
					}
				else
				{
					if( pageWidth < offSet.left ) $layer.css( 'left', (offSet.left-$layer.width()+$btn.width()) );
					else $layer.css( 'left', offSet.left  + xpos);				}
				

				$layerContainer.append( $layer );
			},

			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_detail] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 상세조회
				this.getDetailSchedule();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_detail] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_detail] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_detail] onDestroy Method' );
			}
	  }
});
