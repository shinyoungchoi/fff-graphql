defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipURL 				= $('#shipURL').val();
				this._postListURL 			= $('#postListURL').val();
				this._postReserveNotiURL 	= $('#postReserveNotiURL').val();
				this._postDetailFormURL 	= $('#postDetailFormURL').val();
				this._postInsertFormURL 	= $('#postInsertFormURL').val();
				this._imgUploadMultiURL 	= $('#imgUploadMultiURL').val();
				// element
				this.$listContainer 		= $('#postListContainer');
				this.$listTemplate 			= $('#postListTemplate');
				this.$postMainListContainer = $('#postMainListContainer');
				this.$tabContainer 			= $('#tabContainer');
				this.$postMainTab 			= $('#postMainTab');
				this.$postReserveTab 		= $('#postReserveTab');
				this.$searchShipSel 		= $('#searchShipSel');
				this.$searchListSel 		= $('#searchListSel');
				this.searchWord		 		= $('#searchWord');
				this.regBtn 				= $('#regBtn');
				this.searchBtn	 			= $('#searchBtn');
				this.$selectPage 			= $('#postMainSelectPage');
				this.menuType 				= $('#menuType').val();
				// 게시 종류 전역 설정
				this.RESERVE_TYPE 			= '108_120';
				this.MAIN_TYPE 				= '108_110';
				this.typeSel 				= this.MAIN_TYPE;
				this.listInit();
				this.P_WORD 				= '검색어';
				// 페이지 url
				this.pageUrl				= '';
				// 파라미터 값
				this.$pageNum				= '';
				this.page					= $('#page').val();
				this.itemCnt				= $('#itemCnt').val();
				this.menuType				= $('#menuType').val();
				this.searchType				= $('#searchType').val();
				this.word					= $('#word').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 검색
				_self.searchBtn.click( function(){
					if ( '' == _self.searchWord.val() ) {
						alert( '검색어를 입력하세요' );
						return false;
					}
					_self.movePage();
				});
				
				// 검색창 엔터시
				_self.searchWord.bind("input keyup paste", function(){
	            	if( 13 === event.keyCode ) {
	            		_self.searchBtn.trigger('click');
	    			}
				});
				
				// 등록페이지
				_self.regBtn.click( function(){
					/*_self.movePage( _self._postInsertFormURL );*/
					param = { 'url'	: window.location.href };
					Bplat.view.loadPage( 
						_self._postInsertFormURL 
						+ '?menuType=' + _self.$tabContainer.find('.jdg-selected').attr('tabKey')
						, param 
					);	
					return false;
				});
				
				// 상세페이지
				_self.$listContainer.delegate( ".clickEvent", "click", function() {
					/*var page 		= $('#postListPaging').find('.jdg-selected').text();
					var itemCnt 	= _self.$selectPage.val();
					var menuType 	= _self.$tabContainer.find('.jdg-selected').attr('tabKey'); 
					var searchType 	= _self.$searchListSel.val();
					var word 		= _self.searchWord.val();
					if ( '' == word ) { searchType = ''; }
					Bplat.view.loadPage( 
						_self._postDetailFormURL
						+ '?postId=' +  $(this).parent().attr('rowKey') + ''
						+ '&page=' + page + ''
				 		+ '&itemCnt=' + itemCnt + ''
						+ '&menuType=' + menuType + ''
						+ '&searchType=' + searchType + ''
						+ '&word=' + word + ''
					);*/
					param = { 'url'	: window.location.href };
					Bplat.view.loadPage( 
						_self._postDetailFormURL 
						+ '?postId=' +  $(this).parent().attr('rowKey') 
						+ '&menuType=' + _self.$tabContainer.find('.jdg-selected').attr('tabKey')
						, param 
					);	
					return false;
				});
				
				// 메인공지 탭
				_self.$postMainTab.bind( "click", function() {
					_self.mainTabInit();
					_self.movePage();
				});

				// 예약안내 탭 
				_self.$postReserveTab.bind( "click", function() {
					_self.reserveTabInit();
					_self.movePage();
				});
				
				// 선박선택시
				_self.$searchShipSel.bind( "change", function() {
					_self.getPostList();
				});
				
				// 페이지에 보여질 개수 선택시 
				_self.$selectPage.bind( "change", function() {
					var $this = $(this);
					$this.find( 'option:selected ').attr( 'option', 'selected' );
					// 검색어 placeHolder 초기화
					_self.searchWord.val('');
					_self.movePage();
				});
				
			},
			// 메인공지 탭 설정
			'mainTabInit'	: function(){
				var _self = this;
				// 컨테이너 초기화
				_self.$listContainer.empty();
				// 이미지 목록 보임
				_self.$postMainListContainer.find('col:eq(1)').show();
				_self.$postMainListContainer.find('th:eq(1)').show();
				_self.$postMainListContainer.find('tr:eq(1)').show();
				_self.$listTemplate.find('.listRow').find('td:eq(1)').show();
				_self.listInit();
				_self.searchWord.val('');
				// 탭설정
				_self.$tabContainer.find('#postReserveTab').removeClass('jdg-selected');
				_self.$tabContainer.find('#postMainTab').addClass('jdg-selected');
				_self.typeSel = _self.MAIN_TYPE;
			},
			// 예약안내 탭 설정
			'reserveTabInit'	: function(){
				var _self = this;
				// 컨테이너 초기화
				_self.$listContainer.empty();
				// 이미지 목록 숨김
				_self.$postMainListContainer.find('col:eq(1)').hide();
				_self.$postMainListContainer.find('th:eq(1)').hide();
				_self.$postMainListContainer.find('tr:eq(1)').hide();
				_self.$listTemplate.find('.listRow').find('td:eq(1)').hide();
				_self.listInit();
				_self.searchWord.val('');
				// 탭설정
				_self.$tabContainer.find('#postMainTab').removeClass('jdg-selected');
				_self.$tabContainer.find('#postReserveTab').addClass('jdg-selected');
				_self.typeSel = _self.RESERVE_TYPE;
			},
			// 리스트 정의
			'listInit'		: function() {
				var _self = this;
				this.list = new component.List({
					 'container' 	: _self.$listContainer
					,'template' 	: _self.$listTemplate.find('.listRow')
					,'nodata' 		: _self.$listTemplate.find('.nodataRow')
				});
			},
			// url 디코딩
			'getURLParameter' : function(name){
				return decodeURI(
				        (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search)||[,null])[1]
				);
			},
			// 페이지 URL 설정
			'movePage' : function( pageUrl, postId ) {
				var _self = this;
				var param = '';
				var mark = '?';
				var localPath = window.location.pathname;
				var page = _self.$pageNum;
				var menuTab = _self.$tabContainer.find('.jdg-selected').attr('tabKey');
				
				// 탭 선택
				if( menuTab != '' ){
					param = mark + 'menuType=' + menuTab; 
				}
				
				// 아이템 갯수
				if( _self.$selectPage.val() != '' ) {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					param = param + mark + 'itemCnt=' + _self.$selectPage.val();
				}
				
				// 검색어
				if( _self.searchWord.val() != '' ) {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					var searchType = _self.$searchListSel.val();
					param = param + mark + 'searchType=' + searchType + '&word=' + _self.searchWord.val();
				}
				
				// 페이지 이동
				if( page != '') {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					param = param + mark + 'page=' + page;
				}
				
				// 등록페이지로 이동할 때 
				/*if ( undefined != pageUrl && '' != pageUrl ) {
					localPath = pageUrl;
					if ( '' != _self.word ) {
						if( param != '' ){
							mark = '&';
						}
						param = param + mark + 'searchType=' + _self.searchType + '&word=' +  encodeURI(encodeURIComponent( _self.word, 'UTF-8' ));
					}
				}*/
				Bplat.view.loadPage( localPath + param );
//				$(location).attr( 'href', localPath + param );
				
			},
			// 공지사항 목록 조회
			'getPostList' : function() {
				var _self = this;
				// defaultParam 세팅
				var page 		= _self.page == '' ? 1 : _self.page;
				// 쿠기에 저장될 값이 있을때
				var itemCnt = jdg.util.setItemCnt();
				switch (itemCnt) {
					case '10':
						itemCnt = 10;
						break;
					case '20':
						itemCnt = 20;
						break;
					case '30':
						itemCnt = 30;
						break;
					default:
						itemCnt = 5;
						break;
				}
				var titleVal 	= '';
				var contentVal 	= '';
				if ( _self.searchType == 'title' ) {
					titleVal = _self.getURLParameter( "word" );
				}
				if ( _self.searchType == 'content' ) {
					contentVal = _self.getURLParameter( "word" );
				}
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: _self.typeSel
					,'SHIP_ID' 		: _self.$searchShipSel.find('option:selected').val()
					,'TITLE' 		: titleVal
					,'CONTENT' 		: contentVal
				};
				// 등록, 수정후에 가져오는 url 값이 있을경우
				if ( '' != _self.pageUrl ) {
					_self._postListURL = _self.pageUrl;
				}
				$.ajax({
					 url : _self._postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('postList') ) {
				    		// 리스트 번호 지정
//				    		_self.searchWord.val('');
				    		// 검색어 placeHolder
//							jdg.util.setPlaceHolder( _self.searchWord, _self.P_WORD );
				    		var list = data.postList;
				    		var rowCount = data.total;
				    		var selectPage = parseInt( itemCnt );
				    		if ( page > 1 ) {
				    			rowCount = rowCount - (page * selectPage) + selectPage;
							}
				    		$.each( list, function(idx, data) {
				    			data.CREATED_AT = data.CREATED_AT.substr(0, 10);
				    			data.rowNum = rowCount;
				    			rowCount--;
				    		});
				    		// 
				    		_self.$selectPage.val( itemCnt );
				    		// 리스트 목록 생성
				    		_self.list.createList( data.postList, 'POST_ID', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				data.UPDATED_AT = data.UPDATED_AT.substr(0, 10);
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    			}
				    		});
				    		// 모바일 예약 현황
				    		if ( _self.typeSel == _self.RESERVE_TYPE ) {
								_self.getReserveNoties();
								// 예약안내 조회된 결과가 없을 때
								if ( list.length == 0 ) {
									_self.$listContainer.find('td').attr( 'colspan', '3' );
								}
							}
				    		// 페이징 초기화
				    		$('#postListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,onclick:function(e,page){
									_self.$pageNum = page;
									_self.movePage();
								}
							});
				    	}
				    }
				});
			},
			// 예약 알림 사항 조회
			'getReserveNoties' : function( shipId ){
				var _self = this;
				$.ajax({
					 url : _self._postReserveNotiURL
					,type : 'POST'
					,data : { 'SHIP_ID' : _self.$searchShipSel.find('option:selected').val() }
			        ,dataType : 'json'
			        ,success : function( data ){
			        	var returnData = data.result;
			        	if( returnData == undefined )
			        		return false;
			        	if( returnData.hasOwnProperty( 'POST_ID' ) ){
			        		var $postIdEm = _self.$listContainer.find( '[data-key=POST_ID]' );
			        		var i = 0;
			        		while( i < $postIdEm.length ){
			        			var $em = $($postIdEm[i]);
			        			if( returnData['POST_ID'] == $em.text() ){
			        				$($postIdEm[i]).siblings('[data-key=TITLE]').css('color','blue').append(' <span style="color:red;">(화면 표시중)</span>'); 
			        			}
			        			i++;
			        		}
			        	}
			        }
			        ,error : function( e ){
			        	console.info( e );
			        }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선박 목록 설정
				if ( this.$searchShipSel.find('option').length == 1 ) {
					this.$searchShipSel.hide();
				}
				// 사업체목록조회
				if ( this.menuType == 'reserve' ) {
					this.reserveTabInit();
				}
				// 이전 페이지 Url
				if ( undefined != p_param.url ) {
					this.pageUrl = p_param.url;
				}
				this.getPostList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[biz_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[biz_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[biz_main] onDestroy Method' );
			}		
	  }
});