defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishListFormURL = $('#fishListFormURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				this._prevURL = '';
				
				// element
				this.$regBtn = $('#regBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$fishDate = $('#fishDate');
				this.$kind = $('#kind');
				
				// form
				this.$srchForm = $('#fishSearchForm');
				this.$insertForm = $('#fishInsertForm');

				// static variable
				this.context = $('#context').val();
				this.state = $('#state').val();
				this.shipId = $('#shipId').val();
				this.menuType = $('#menuType').val();
				this.fileList = null;
				this.MEMBER_FISH = '106_120';
				this.CPTN_FISH = '106_110';
			},
			'setEvent'		: function() {
				var _self = this;
				
				// datePicker 이벤트선언
				_self.$fishDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				
				// 신규등록
				_self.$regBtn.click( function() {
					_self.insertFish();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					if( _self._prevURL != '' )
						Bplat.view.loadPage( _self._prevURL );
					else 
						Bplat.view.loadPage( _self._fishListFormURL );
					return false;
				});
				
			},
			'setDefaultData' : function(){
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $kind = _self.$kind;
				$kind.text(_self.menuType == 'mem' ? '회원조행기' : '선장님 조행기');
				
				_self.fileList = new component.FileList({
					 'id' : $insertForm.attr('id')
					,'container' : $insertForm.find('[data-type=IMAGE_LIST]')
				});
				
				_self.fileList.init();
			},
			// 조과 등록
			'insertFish' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var menuType = _self.menuType == 'mem' ? _self.MEMBER_FISH : _self.CPTN_FISH;
				var moveUrl = _self.context + _self.state + _self.shipId + '/fish/detail_form';  
				var $fishDate = $insertForm.find('[data-key=FISH_DATE]');
				
				var shipSelect = $insertForm.find('[data-key=SHIP_ID] option:selected');
				var shipId = shipSelect.val();
				var shipName = shipSelect.text(); 
				
				if (shipId == "")
				{
					alert("선박을 선택해주십시오.");
					return;
				}
				
				
				// 회원일 경우 출조일은 validation 에서 제외
				if( menuType == _self.MEMBER_FISH ){
					$fishDate.removeAttr('vRequired');
				}
				
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				// 조과 등록
				var insertParam = {
					  SHIP_ID: shipId
					 ,SHIP_NAME: shipName
					 ,TYPE_CD: menuType
					 ,FISH_DATE: $fishDate.val().replaceAll('-','')
					 ,TITLE: $insertForm.find('[data-key=TITLE]').val()
					 ,CONTENT: $insertForm.find('[data-key=CONTENT]').val()
					 ,GPS_LAT: $insertForm.find('[data-key=GPS_LAT]').text()
					 ,GPS_LONG: $insertForm.find('[data-key=GPS_LONG]').text()
					 ,IMG_ID: JSON.stringify( _self.fileList.getFileList() )
					 ,LOC_DESC: $insertForm.find('[data-key=LOC_DESC]').val()
				};
				$.ajax({
					 url : _self._fishInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		// 등록된 상세 페이지 이동
				    		var mark = '?';
				    		var menuType = _self.menuType == 'mem' ? mark + 'menuType=mem' : '';
				    		if( menuType.indexOf('?') > -1 )
				    			mark = '&';
				    		var param    = menuType + mark + 'GALR_ID='+data.result.GALR_ID;
				    		
				    		Bplat.view.loadPage( moveUrl + param
				    				          , {'url' : _self.context + _self.state + _self.shipId + '/fish' + menuType});
				    	}
				    }
				});
				return false;
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				// 이전 페이지 URL 저장
				if( p_param.url != undefined )
					this._prevURL = p_param.url;
				
				this.setDefaultData();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});