defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishDetailURL = $('#fishDetailURL').val();
				this._fishDeleteURL = $('#fishDeleteURL').val();
				this._fishListFormURL = $('#fishListormURL').val();
				this._fishUpdateFormURL = $('#fishUpdateFormURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				this._prevURL = '';
				
				// element
				this.$detailForm = $('#fishDetailForm');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$listBtn = $('#listBtn');
				
				// form
				this.$updateForm = $('#fishUpdateForm');
				
				// static variable
				this.selectFishId = $('#GALR_ID').val();
				this.menuType = $('#menuType').val();
				this.selectFileList = null;
				this.fileList = null;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					var url = window.location.href;
					Bplat.view.loadPage( url.replace('detail_form', 'update_form'), { 'url' : _self._prevURL } );
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					_self.deleteFish();
					return false;
				});
				
				// 목록
				_self.$listBtn.click( function() {
					var url = _self._prevURL;
					Bplat.view.loadPage( url );
					return false;
				});
			},
			// 조과 상세 조회
			'getFishDetail' : function( galrId  ) {
				var _self = this;
				var $detailForm = _self.$detailForm;
				$.ajax({
					 url : _self._fishDetailURL
					,type : 'POST'
					,data : {
						'GALR_ID' : galrId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
					    	if( detail.hasOwnProperty('imageList') ) {
					    		var $imgContainer = _self.$detailForm.find('[data-type=IMAGE]');
					    		jdg.util.createImgList(detail.imageList, $imgContainer);
					    	}
							// 상세폼셋팅
					    	detail.FISH_DATE = jdg.util.replaceDate(detail.FISH_DATE);
							jdg.util.detailDataSetting( _self.$detailForm, detail );
				    	}
				    }
				});
			},
			// 조과삭제
			'deleteFish' : function() {
				var _self = this;
				var menuType = _self.menuType != '' ? '?menuType=mem' : '';
				$.ajax({
					 url : _self._fishDeleteURL
					,type : 'POST'
					,data : {
						 'GALR_ID' : _self.selectFishId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		Bplat.view.loadPage( _self._fishListFormURL + menuType);
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				// 이전 페이지의 URL 셋팅
				if( p_param.url != undefined )
					this._prevURL = p_param.url;
				
				this.getFishDetail( this.selectFishId );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});