defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._memberInfoDetailURL = $('#memberInfoDetailURL').val();
				this.memId = $('#memId').val();
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				
			},
			'pageInit'		: function() {
				var _self = this;

			},
			'getMemberInfo' :  function(memId){
				var _self = this;
				$.ajax({
					url : _self._memberInfoDetailURL
					,type : 'POST'
					,data : {
						'MEM_ID' : memId
					}
					,dataType : 'json'
					,success : function(data){
						console.info(data);
						var val = data.memberInfo;
						var grade_cd = val.GRADE_CD;
						
						// 회원 등급
						if(grade_cd == '107_000'){
							grade_cd = '일반회원';
						}else if(grade_cd == '107_110'){
							grade_cd = '선장';
						}else if(grade_cd == '107_130'){
							grade_cd = '사업체관리자';
						}else if(grade_cd == '107_170'){
							grade_cd = '시스템관리자';
						}else{
							grade_cd = '-';
						}
						
						//전화번호
						var tel = val.TEL;
						if(tel != null && tel != undefined){
							var telLength = tel.length;
							if( telLength == 11  ){
								tel = tel.substring(0,3) + "-" + tel.substring(3,7) + "-" + tel.substring(7);
							}
							if( telLength == 10 ){
								tel = tel.substring(0,3) + "-" + tel.substring(3,6) + "-" + tel.substring(6);
							}
						}
							
				    	$('#EMAIL').text(val.EMAIL);
				    	$('#GRADE_CD').text(grade_cd);
				    	$('#MEM_NAME').text(val.MEM_NAME);
				    	$('#NICK_NAME').text(val.NICK_NAME);
				    	$('#TEL').text(tel);
//				    	//가입선박
//						$.each(val.shipList, function( idx,ship ) {
//							var shipNm = ship.SHIP_NAME;
//							if( (val.shipList.length-1) > idx) shipNm += ', ';
//							$('#SHIP_NAME').append(shipNm);
//						});
					}
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				var _self = this;
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
				var _self = this;
				_self.getMemberInfo(_self.memId);
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
