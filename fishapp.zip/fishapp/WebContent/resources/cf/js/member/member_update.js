defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._memberInfoDetailURL = $('#memberInfoDetailURL').val();
				this._nickNameCheckURL = $('#nickNameCheckURL').val();
				this._memberInfoURL = $('#memberInfoURL').val();
				this._memberUpdateURL = $('#memberUpdateURL').val();

				this.$emailTd = $('#emailTd');
				this.$pwTd = $('#pwTd');
				this.$rePwTd = $('#rePwTd');
				this.$nameTd = $('#nameTd');
				this.$nickNameTd = $('#nickNameTd');
				this.$telTd = $('#telTd');
				this.$confirmBtn = $('#confirmBtn');
				this.$listBtn = $('#listBtn');
				this.$memberUpdateForm = $('#memberUpdateForm');
				this.$pwdInputBtn = $('#pwdInputBtn');
				this.$pwHide = $('#pwHide');
				this.$rePwHide = $('#rePwHide');
				this.$nickName = $('#nickName');
				
				this.memId = $('#memId').val();
				this.gradeCd = null;
				this.shipList = [];
				this.isHidePw = true;

			},
			'setEvent'		: function() {
				var _self = this;
				
				// 비밀번호 라인 숨기기 보이기
				_self.$pwdInputBtn.click(function(){
					var rePwHide = _self.$rePwHide;
					var pwHide = _self.$pwHide;
					if(_self.isHidePw){
						pwHide.show();
						rePwHide.show();
						_self.isHidePw = false;
						_self.$pwdInputBtn.find('span').text('비밀번호 수정취소');
					}else{
						pwHide.find('.jdg-entry-detail').empty().append('<span>비밀번호를 입력해 주세요.</span>');
						rePwHide.find('.jdg-entry-detail').empty().append('<span>비밀번호를 재 입력해 주세요.</span>');
						pwHide.hide().find('[type=password]').val("");
						rePwHide.hide().find('[type=password]').val("");
						_self.isHidePw = true;
						_self.$pwdInputBtn.find('span').text('비밀번호 수정');
					}
				});
				
				// 취소버튼 클릭시 회원정보보기 페이지로 이동
				_self.$listBtn.click(function(){
					Bplat.view.loadPage(_self._memberInfoURL);
				});
				
				// 확인버튼 클릭시 텍스트박스 요소 확인 후 폼 전송
				_self.$confirmBtn.click(function(){
					
					//비밀번호의 jdg-unused 카운트가 0개 초과일때
					if(_self.$pwTd.find('.jdg-unused').size() > 0 && !_self.isHidePw){
						alert('정상적인 비밀번호를 입력해주세요');
						_self.$pwTd.find('[type=password]').focus();
						return false;
					}
					
					//비밀번호 재확인의 jdg-unused 카운트가 0개 초과일때
					if(_self.$rePwTd.find('.jdg-unused').size() > 0 && !_self.isHidePw){
						alert('정상적인 비밀번호 재확인을 입력해주세요');
						_self.$rePwTd.find('[type=password]').focus();
						return false;
					}
					
					//전화번호의 jdg-unused 카운트가 0개 초과일때
					if(_self.$telTd.find('.jdg-unused').size() > 0){
						alert('정상적인 전화번호를 입력해주세요');
						_self.$telTd.find('[type=text]').focus();
						return false;
					}
					
					if( ((_self.$pwTd.find('.jdg-used').size() <= 0 || _self.$rePwTd.find('.jdg-used').size() <= 0)	&& !_self.isHidePw)
							|| _self.$nickNameTd.find('.jdg-used').size() <=0 ){
						alert("(*) 칸에 값을 모두 넣어주세요");
						return false;
					}

					_self.memberUpdate();
					
				});
				
				_self.$pwTd.find('[type=password]').focusout(function(){
					_self.$rePwTd.find('[type=password]').val("");
					var $entryDetail = _self.$rePwTd.find('.jdg-entry-detail');
					$entryDetail.empty().append("<span>비밀번호를 재 입력해 주세요</span>");
					
					var pwVal = _self.$pwTd.find('[type=password]').val();
					var $entryDetail = _self.$pwTd.find('.jdg-entry-detail');
					
					//빈칸체크
					if(pwVal == ""){
						$entryDetail.empty().append("<span class='jdg-unused'>X 비밀번호를 입력해주세요.</span>");
						return false;
					}
					
					//6~16자리 체크
					if(!(pwVal.length >= 6 && pwVal.length <= 16)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 비밀번호는 6~16자리까지 입력가능합니다.</span>");
						return false;
					}
					
					//문자,숫자,특수기호 중 2가지 이상 조합인지 체크
					if(_self.pwCheck(pwVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 영문/숫자/특수문자 중 2가지 이상 조합하셔야 합니다. 예)ja123,20*ja</span>");
						return false;
					}
					
					//같은 문자 3회 이상 반복되는지 체크
					var regExp = /(\w)\1\1/
					if(regExp.test(pwVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 같은 문자는 3회 이상 연결해서 사용하실 수 없습니다. 예)aaa,222</span>");
						return false;
					}
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 비밀번호입니다.</span>");
				});
				
				_self.$rePwTd.find('[type=password]').focusout(function(){
					var pwVal = _self.$pwTd.find('[type=password]').val();
					var rePwVal = _self.$rePwTd.find('[type=password]').val();
					var $entryDetail = _self.$rePwTd.find('.jdg-entry-detail');	
					
					if(_self.$pwTd.find('.jdg-unused').size() > 0){
						$entryDetail.empty().append("<span class='jdg-unused'>X 올바른 비밀번호를 먼저 입력해주세요.</span>");
						return false;
					}
					
					//빈칸 체크
					if(rePwVal == ""){
						$entryDetail.empty().append("<span class='jdg-unused'>X 비밀번호 재확인을 입력해주세요.</span>");
						return false;
					}
					
					//비밀번호와 일치하는지 체크
					if(pwVal != rePwVal){
						$entryDetail.empty().append("<span class='jdg-unused'>X 입력한 비밀번호가 서로 일치하지 않습니다.</span>");
						return false;
					}
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 비밀번호 재확인입니다.</span>");
				});	
				
				_self.$nameTd.find('[type=text]').focusout(function(){
					var nameVal = _self.$nameTd.find('[type=text]').val();
					var $entryDetail = _self.$nameTd.find('.jdg-entry-detail');
					
					//빈칸 체크
					if(nameVal == ""){
						$entryDetail.empty().append("<span class='jdg-unused'>X 이름을 입력해주세요.</span>");
						return false;
					}
					
					var regExp = /^[가-힣]+$/;
					if(!regExp.test(nameVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 이름은 한글만 사용가능합니다.</span>");
						return false;
					}
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 이름입니다.</span>");
				});	
				
				_self.$nickNameTd.find('[type=text]').focusout(function(){
					var nickNameVal = _self.$nickNameTd.find('[type=text]').val();
					var $entryDetail = _self.$nickNameTd.find('.jdg-entry-detail');
					
					//빈칸 체크
					if(nickNameVal == ""){
						$entryDetail.empty().append("<span class='jdg-unused'>X 닉네임을 입력해주세요.</span>");
						return false;
					}
					
					//한글,영어,숫자만 들어가 있는지 체크
					var regExp = /[0-9]|[a-z]|[A-Z]|[가-힣]/;
					if(!regExp.test(nickNameVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 닉네임은 한글, 영어, 숫자만 사용가능합니다.</span>");
						return false;
					}
					
					//다른 닉네임과 중복되는지 체크
					if(_self.nickNameCheck(nickNameVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 사용하실 수 없는 닉네임입니다.</span>");
						return false;
					}
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 닉네임입니다.</span>");
				});
				
				_self.$telTd.find('[type=text]').focusout(function(){
					var telVal = _self.$telTd.find('[type=text]').val();
					var $entryDetail = _self.$telTd.find('.jdg-entry-detail');
					
					// null 이면 표시 제거
					if(telVal == ""){
						$entryDetail.empty().append("<span class='jdg-used'>(-) 없이 전화번호 숫자만을 입력해주세요. (선택사항)</span>");
						return true;
					}
					
					//숫자만 사용가능
					var regExp = /[0-9]/;
					if(!regExp.test(telVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 전화번호는 숫자만 입력가능합니다.</span>");
						return false;
					}
					
					// 전화번호는 10자리 또는 11자리만 가능
					if(!(telVal.length >= 10 && telVal.length <= 11)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 전화번호는 10~11자리까지 입력가능합니다.</span>");
						return false;
					}
					
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 전화번호입니다.</span>");
				});	
				
				_self.$nickNameTd.find('[type=text]').focusout(function(){
					var nickNameVal = _self.$nickNameTd.find('[type=text]').val();
					var $entryDetail = _self.$nickNameTd.find('.jdg-entry-detail');
					
					//빈칸 체크
					if(nickNameVal == ""){
						$entryDetail.empty().append("<span class='jdg-unused'>X 닉네임을 입력해주세요.</span>");
						return false;
					}
					
					//한글,영어,숫자만 들어가 있는지 체크
					var regExp = /[0-9]|[a-z]|[A-Z]|[가-힣]/;
					if(!regExp.test(nickNameVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 닉네임은 한글, 영어, 숫자만 사용가능합니다.</span>");
						return false;
					}
					
					//다른 닉네임과 중복되는지 체크
					if(_self.nickNameCheck(nickNameVal)){
						$entryDetail.empty().append("<span class='jdg-unused'>X 사용하실 수 없는 닉네임입니다.</span>");
						return false;
					}
					
					$entryDetail.empty().append("<span class='jdg-used'>O 사용가능한 닉네임입니다.</span>");
				});	
				
			},
			'pageInit'		: function() {
				var _self = this;

			},
			//문자,숫자,특수기호 중 2가지 이상 조합인지 체크
			'pwCheck' : function(pwVal) {
				var _self = this;
				var count = 0;
				
				//문자 포함
				if(/[a-zA-Z]/.test(pwVal)){
					count++;
				}
				
				//숫자 포함
				if(/[0-9]/.test(pwVal)){
					count++;
				}
				
				//특수기호 포함
				if(/[^0-9a-zA-Zㄱ-ㅎㅏ-ㅣ가-힝]/.test(pwVal)){
					count++;
				}
				
				if( count >= 2){
					return false;
				}else{
					return true;
				}
			},
			//닉네임 중복 체크
			'nickNameCheck' : function(nickname) {
				var _self = this;
				
				var memId = _self.memId;
				var count = "";
				
				$.ajax({
					 url : _self._nickNameCheckURL
					,type : 'POST'
					,data : {
						'NICK_NAME' : nickname
						, 'NOT_MEM_ID' : memId
					}
					,async: false
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('count') ) {
				    		count = data.count;
				    	}
				    }
				});
			
				return count;
			
			},
			// 회원정보 표시
			'memDetail' : function(memId){
				var _self = this;
				$.ajax({
					url : _self._memberInfoDetailURL
					,type : 'POST'
					,data : {
						'MEM_ID' : memId
					}
					,dataType : 'json'
					,success : function(data){
						console.info(data);
						var val = data.memberInfo;
						var grade_cd = val.GRADE_CD;
						
						// 회원 등급
						if(grade_cd == '107_000'){
							grade_cd = '일반회원';
						}else if(grade_cd == '107_110'){
							grade_cd = '선장';
						}else if(grade_cd == '107_130'){
							grade_cd = '사업체관리자';
						}else if(grade_cd == '107_170'){
							grade_cd = '시스템관리자';
						}else{
							grade_cd = '-';
						}
						
				    	$('#emailTd').text(val.EMAIL);
				    	$('#gradeTd').text(grade_cd);
				    	$('#nameTd').text(val.MEM_NAME);
				    	$('#nickName').val(val.NICK_NAME);
				    	$('#tel').val(val.TEL);
				    	//가입선박
				    	_self.shipList = val.shipList;
				    	_self.gradeCd = val.GRADE_CD;
					}
				});
			},
			// 회원정보 수정 
			'memberUpdate' : function(){
				var _self = this;
				var pwd = null;
				if(!_self.isHidePw){
					pwd = _self.$pwTd.find('[type=password]').val();
				}
								
		    	var param = {
						  'MEM_ID' : _self.memId
						  , 'EMAIL' : _self.$emailTd.text()
						  , 'TEL' :  _self.$telTd.find('[type=text]').val()
						  , 'MEM_NAME' : _self.$nameTd.text()
						  , 'NICK_NAME' : _self.$nickNameTd.find('[type=text]').val()
						  , 'PWD' : pwd
						  , 'EMAIL_AUTH_KEY' : null
						  , 'GRADE_CD' : _self.gradeCd
		    	};
				$.ajax({
					url : _self._memberUpdateURL
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function( data ) {
				    	alert("수정 완료되었습니다.");
				    	
				    	Bplat.view.loadPage( _self._memberInfoURL);
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				var _self = this;
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
				var _self = this;
				_self.memDetail(_self.memId);
				
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
