defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._memberPwConfirmURL = $('#memberPwConfirmURL').val();
				
				this.$pwConfirmForm = $('#pwConfirmForm');
				this.$pw = $('#pw');
				
				this.msg = $('#msg').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				//엔터키 사용
				_self.$pw.keydown(function(e){
					  if (e.which == 13){
						  $('#confirmBtn').trigger('click');
					  }
				});
				
				$('#confirmBtn').click(function(){
					
					var pwVal = _self.$pw.val();
					if(pwVal == null || pwVal == ""){
						alert("비밀번호를 입력해주세요.");
					}else{
						_self.$pwConfirmForm.attr('action', _self._memberPwConfirmURL).submit();
					}
				});
				
			},
			'pageInit'		: function() {
				var _self = this;

			},
			'onCreate' : function( p_param, _viewClass ) {
				var _self = this;
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
				var _self = this;
				if(_self.msg != null && _self.msg != undefined && _self.msg != ""){
					alert(_self.msg);
				}
				_self.$pw.focus();
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
