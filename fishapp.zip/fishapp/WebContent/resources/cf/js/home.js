defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				
				// element
				this.$fishList = $('#fishList');
				this.$pcScheduleList = $('#pcScheduleList');
				this.$TabMobScheduleList = $('#TabMobScheduleList');
				this.$postList = $('#postList');
				this.$cptnImg = $('#cptnImg');
				this.$cptnFishImg = $('.cptnFishImg');
				this.$shipImg = $('#shipImg');
				this.$shopImg = $('#shopImg');
				
				this._intervalID = null;
				this._divShipsIdx = 0;
				this.$divShips = $('div.jdg-ui-ship');
				this._divShipsCount = this.$divShips.length;
				
				this.$thumbShips = $('#divThumbShips img');
				
				if (this._divShipsCount > 0)
				{
					$(this.$divShips[0]).show();
					$(this.$thumbShips[0]).css('border-style','solid');
				}
				
				this.$win = $(window);
				this._clicked = false;				
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				if (this._divShipsCount <= 2)
				{
					$("#divThumbShips").hide();
					return;
				}
				
				var shipTop = $("div.jdg-ui-ship-wrap").position().top;

			    $(window).scroll(function(){
			        var st = _self.$win.scrollTop();
			        
			        if (st > shipTop + 300 && _self._intervalID)
			        {
			        	clearInterval(_self._intervalID);			        	
			        	_self._intervalID = null;
			        }
			        
			        if (_self._intervalID == null && st > shipTop && st < shipTop + 300)
			        {
			        	_self.slideShip();
			        }
			    });				
				
				_self.slideShip();
				
				_self.$thumbShips.click(function(){
					
					clearInterval(_self._intervalID);
					_self._intervalID = null;
					
					for (var i=0; i < _self._divShipsCount; i++)
					{
						if (_self.$thumbShips[i] == this)
						{
							var d1 = $(_self.$divShips[_self._divShipsIdx]);
							var d2 = $(_self.$divShips[i]);
							
							if (_self._divShipsIdx == i) return;
							
							$(_self.$thumbShips[i]).css('border-style','solid');
							$(_self.$thumbShips[_self._divShipsIdx]).css('border-style','none');
							
							_self._divShipsIdx = i;
							
							_self.fadeSwap(d1,d2);
						}
					}
				});

			},
			//date 포맷 셋팅
			'setDateFormat': function() {
				var _self = this;
				
				//조행기
				var dates = _self.$fishList.find('.jdg-data-date');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(5,2) - 1;
					var day = $(dates[i]).text().trim().substr(8,2);
					
					$(dates[i]).text(new Date(year, month, day).toDateStr("mmdd","DAYS_SHORT"));
				}
				
				//출조 스케줄(pc)
				dates = _self.$pcScheduleList.find('.jdg-data-date > a');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(4,2) - 1;
					var day = $(dates[i]).text().trim().substr(6,2);
					var parseDate = new Date(year, month, day)
					
					if( parseDate.getDay() == 6){ //토요일이라면
						$(dates[i]).parents('li').addClass('jdg-sat');
					}else if( parseDate.getDay() == 0 ){//일요일이라면
						$(dates[i]).parents('li').addClass('jdg-sun');
					}
					
					$(dates[i]).text(parseDate.toDateStr("mmdd","DAYS"));
				}
				
				//출조 스케줄(태블릿,모바일)
				dates = _self.$TabMobScheduleList.find('.jdg-data-date');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(4,2) - 1;
					var day = $(dates[i]).text().trim().substr(6,2);
					
					$(dates[i]).text(new Date(year, month, day).toDateStr("mmdd","DAYS"));
				}
				
				
			},
			//이미지 태그를 컨테이너 안에 최대한 비율에 맞게 리사이즈
			'setImgRatio' : function( p_param, _viewClass ) {
				var _self = this;
				
				jdg.util.setImgRatio(_self.$cptnImg, _self.$cptnImg.attr('imgWidth'), _self.$cptnImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shipImg, _self.$shipImg.attr('imgWidth'), _self.$shipImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shopImg, _self.$shopImg.attr('imgWidth'), _self.$shopImg.attr('imgHeight'));
				
				if(_self.$cptnFishImg.size() > 0){
					for(i = 0; i < _self.$cptnFishImg.size(); i++){
						jdg.util.setImgRatio(_self.$cptnFishImg[i], _self.$cptnFishImg[i].attr('imgWidth'), _self.$cptnFishImg[i].attr('imgHeight'));
					}
				}
			},
			
			'runSlide' :function()
		    {				
				var _self = Bplat.viewPkg.BplatBody;
				
				var nextIdx = _self._divShipsIdx + 1;
				
				if (nextIdx >= _self._divShipsCount - 1)
					{
						nextIdx = 0;
					}
				
				var d1 = $(_self.$divShips[_self._divShipsIdx]);
				var d2 = $(_self.$divShips[nextIdx]);
				
				_self.fadeSwap(d1,d2);
				$(_self.$thumbShips[nextIdx]).css('border-style','solid');
				$(_self.$thumbShips[_self._divShipsIdx]).css('border-style','none');
				_self._divShipsIdx = nextIdx;
				
		    },
		    
			'fadeSwap' :function(d1, d2)
		    {				
				var _self = this;
				
				d1.fadeOut(800, function()
					{
						d2.fadeIn(800);
					}
				);
		    },		    
		    
		    
		    'slideShip': function()
		   {
		    	var _self = this;
		    	
		    	if (_self._divShipsCount < 2)
		    	{
		    		return;
		    	}
		    	
		    	_self._intervalID = setInterval(_self.runSlide, 3000);
		   },
		    
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				this.setDateFormat();
				
				var obj1 = $('#divship1');
				var obj2 = $('#divship2');

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});