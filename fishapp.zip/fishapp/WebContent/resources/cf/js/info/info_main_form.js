defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postListURL 		= $('#postListURL').val();
				this.postDetailFormURL 	= $('#postDetailFormURL').val();
				this.imageURL 			= $('#imageURL').val();
				this.noImageURL 		= $('#noImageURL').val();
				this.total 		 		= $('#total').val();
				// element
				this.$listContainer1 			= $('#postListContainer1');
				this.$listContainer2 			= $('#postListContainer2');
				this.$listContainer3 			= $('#postListContainer3');
				
				this.$postListTemplate 			= $('#postListTemplate');
				this.$pcListTemplate 			= $('#postListTemplate').find('.pcListRow');
				this.$mobileListTemplate 		= $('#postListTemplate').find('.mobileListRow');
				this.$nodataTemplate 			= $('#postListTemplate').find('.nodata');
				this.$selectPage 				= $('#postMainSelectPage');
				// 게시 종류 전역 설정
				this.MAIN_TYPE 				= '122_010';
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$listContainer1.delegate( ".clickEvent", "click", function() {
					Bplat.view.loadPage( 
							_self.postDetailFormURL	+ '?POST_ID=' +  $(this).attr('data-postid') + '&TYPE_CD=' +  $(this).attr('data-typecd') 
						);	
				});

				
				_self.$listContainer2.delegate( ".clickEvent", "click", function() {
					Bplat.view.loadPage( 
							_self.postDetailFormURL	+ '?POST_ID=' +  $(this).attr('data-postid') + '&TYPE_CD=' +  $(this).attr('data-typecd') 
						);	
				});
				

				_self.$listContainer3.delegate( ".clickEvent", "click", function() {
					Bplat.view.loadPage( 
							_self.postDetailFormURL	+ '?POST_ID=' +  $(this).attr('data-postid') + '&TYPE_CD=' +  $(this).attr('data-typecd') 
						);	
				});

				
				$('body').delegate( "a.jdg-btn-more,a.jdg-btn-mmore", "click", function(e) {
					
				    e.stopImmediatePropagation();
				    e.preventDefault();
				    
				    var tempId = e.target.id;
				    
				    switch(tempId)
				    {
				    	case "more1": _self.$listContainer1.children("tr:hidden").show(); break;
				    	case "more2": _self.$listContainer2.children("tr:hidden").show(); break;
				    	case "more3": _self.$listContainer3.children("tr:hidden").show(); break;
				    }
				});
				
				
				$('body').delegate( "em.jdg-icon-up-view", "click", function(e) {
					
				    e.stopImmediatePropagation();
				    e.preventDefault();
				    
				    var tempParent = $(e.target).parent().parent();
				    
				    tempParent.children(".jdg-ui-notice").show();
				    $(e.target).removeClass('jdg-icon-up-view').addClass('jdg-icon-down-view');
				});				

				$('body').delegate( "em.jdg-icon-down-view", "click", function(e) {
					
				    e.stopImmediatePropagation();
				    e.preventDefault();
				    
				    var tempParent =  $(e.target).parent().parent();
				    
				    tempParent.children(".jdg-ui-notice").hide();
				    $(e.target).removeClass('jdg-icon-down-view').addClass('jdg-icon-up-view');
				});	
				
			},
			'pageInit'		: function() {
				var _self = this;
			
				
			},
			
			
			// /pt 목록 조회
			'getPostList' : function( page ) {

				var _self = this;
				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt

				};
				$.ajax({
					 url : _self.postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('infoList') ) {

				    		var list = data.infoList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			
				    			var $nodata = _self.$nodataTemplate.clone();
				    			_self.$listContainer.append( $nodata );

					    	}else{

					    		//$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = 0;
					    		var postType = "";
					    		
					    		$.each( list, function(idx, data) {
					    			
					    			if (postType != data.TYPE_CD)
				    				{
					    				rowCount = 0;
					    				postType = data.TYPE_CD;
				    				}
					    			
					    			rowCount ++;
					    			
					    			var $pcRow = "<tr><th class='clickEvent' style='cursor:pointer' data-typecd='" + postType + "' data-postid='" + data.POST_ID +"'>" + data.TITLE + "</ht><td>" + data.VIEW_COUNT + "</td><td>" + data.CREATED_AT  + "</td></tr>";
					    			
					    			if (rowCount > 5)
					    			{
					    				$pcRow = $pcRow.replaceAll("<tr>", "<tr style='display:none'>");
					    			}
					    			
					    			if (postType == "122_010")
					    				{
					    					_self.$listContainer1.append( $pcRow );
					    				}
					    			else if (postType == "122_020")
					    				{
					    					_self.$listContainer2.append( $pcRow );
					    				}					    				
					    			else if (postType == "122_030")
					    				{
					    					_self.$listContainer3.append( $pcRow );
					    				}						    			
					    			
					    		});
					    		
					    	}
				    		
				    		// 페이징 초기화
				    		$('#postListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,itemClass: 'jdg-btn-page'
								,prevClass: 'jdg-btn-page-prev'
								,nextClass: 'jdg-btn-page-next'
								,firstClass: 'jdg-btn-page-first'
								,lastClass: 'jdg-btn-page-last'
								,onclick:function(e,page){
//									location.hash = page;
									_self.getPostList( page );
								}
							});
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
//				_self.pageInit();
				_self.getPostList( '1' );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
