defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._pwResetConfirmURL = $('#pwResetConfirmURL').val();
				this._loginFormURL = $('#loginFormURL').val();
				
				
				this.$okBtn = $('#okBtn');
				this.$cancelBtn = $('#cancelBtn');
				this.$infoForm = $('#infoForm');
				this.$infoBody = $('#infoBody');
				this.msg = $('#msg').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
			
				_self.$okBtn.click(function( event ){
					
					event.preventDefault();
					_self.$okBtn.focus();
					_self.loading();
											
					_self.$infoForm.attr('action', _self._pwResetConfirmURL).submit();
				});
				
				_self.$cancelBtn.click(function(){
					Bplat.view.loadPage(_self._loginFormURL);
				});
			},
			'loading': function(){
				var _self = this;
				var $loadingImg = $('#loading');
				$loadingImg.css("top", (($(window).height() - $loadingImg.outerHeight()) / 2) + $(window).scrollTop() + "px");
				$loadingImg.css("left", (($(window).width() - $loadingImg.outerWidth()) / 2) + $(window).scrollLeft() + "px");
				$loadingImg.show();
				setInterval(function(){
					$loadingImg.fadeOut('slow').fadeIn('slow');
				},2000);
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_simple3] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_simple3] onStart Method' );
				var _self = this;
				if(_self.msg !=  null && _self.msg != undefined && _self.msg != ""){
					alert(_self.msg);
				}
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_simple3] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_simple3] onDestroy Method' );
			}		
	  }
});
