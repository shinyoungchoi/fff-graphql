defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
			},
			'setEvent'		: function() {
				var _self = this;
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_step4] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_step4] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_step4] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step4] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step4] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_step4] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_step4] onDestroy Method' );
			}		
	  }
});
