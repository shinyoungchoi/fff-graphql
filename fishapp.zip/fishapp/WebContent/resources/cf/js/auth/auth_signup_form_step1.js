defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._nextStepURL = $('#nextStepURL').val();
				this._loginFormURL = $('#loginFormURL').val();
				
				// element
				this.$clauseForm = $('.jdg-ui-clause');
				this.$okBtn = $('#okBtn');
				this.$cancelBtn = $('#cancelBtn');
				this.userId = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				//확인 버튼
				_self.$okBtn.click(function(){
					var checkBox = true;
					
					//동의 체크
					$('.jdg-ui-clause').find('input:checkbox').each(function(){
						if(!$(this).is(':checked')){
							checkBox = false;
							alert('서비스이용약관과 개인정보 이용약관에 대해 모두 동의해주세요.');
							$(this).focus();
							return false;
						}
					});
					
					if( checkBox ){
						Bplat.view.loadPage( _self._nextStepURL ,{
							'USER_ID' : _self.userId
						});
					}
				});
				
				//취소 버튼
				_self.$cancelBtn.click(function(){
					Bplat.view.loadPage( _self._loginFormURL );
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				
				Bplat.log.debug( '[signup_step1] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				
				_self.userId = p_param.USER_ID;
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_step1] onStart Method' );
				var _self = this;
				
				if(p_param.USER_ID != null || p_param.USER_ID != undefined){
					_self.userId = p_param.USER_ID;
				}else{
					//Bplat.view.loadPage( _self._loginFormURL);
				}
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_step1] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_step1] onDestroy Method' );
			}		
	  }
});