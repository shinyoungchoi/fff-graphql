defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._sendAuthCodeURL = $('#sendAuthCodeURL').val();
				this._confirmAuthCodeURL = $('#confirmAuthCodeURL').val();
				this._resultUrl = $('#resultUrl').val();				
				
				this.$btnAction = $('.jdg-btn-action');
				this.$expTime = $('#expTime');
				this.$authCode = $('#AUTH_CODE');
				this.$divAuth = $('#divAuth');

				this.msg = $('#msg').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
					
				//확인 버튼
				_self.$btnAction.click(function(event){
					
					var evId = event.currentTarget.id;	
					var selectId = $('.radioUserId:checked').val();
					
					if (evId == "btnGoLogin")
						{				
							Bplat.view.loadPage( "login_form", {'selectId': selectId});					
						}

					if (evId == "btnGoPwd")
					{				
						Bplat.view.loadPage( "pwd_find_step1", {'selectId': selectId});						
					}
					
				});
			},
				
			'loading': function(){
				var _self = this;
				var $loadingImg = $('#loading');
				$loadingImg.css("top", (($(window).height() - $loadingImg.outerHeight()) / 2) + $(window).scrollTop() + "px");
				$loadingImg.css("left", (($(window).width() - $loadingImg.outerWidth()) / 2) + $(window).scrollLeft() + "px");
				$loadingImg.show();
				setInterval(function(){
					$loadingImg.fadeOut('slow').fadeIn('slow');
				},2000);
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[id_find_step2] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[id_find_step2] onStart Method' );
				var _self = this;
				if(_self.msg !=  null && _self.msg != undefined && _self.msg != ""){
					alert(_self.msg);
				}
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[id_find_step2] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[id_find_step2] onDestroy Method' );
			}		
	  }
});
