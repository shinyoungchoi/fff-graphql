defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._context = $('#context').val();
				this._state = $('#state').val();
				this._nextStepURL = $('#nextStepURL').val();
				this._loginFormURL = $('#loginFormURL').val();
				this._getEmailDetailURL = $('#getEmailDetailURL').val();
				this._nickNameCheckURL = $('#nickNameCheckURL').val();
				
				// element
				this.$memberInfoForm = $('#memberInfoForm');
				this.$rePwTd = $('#rePwTd');
				this.$nameTd = $('#nameTd');
				this.$nickNameTd = $('#nickNameTd');
				
				
				this.$okBtn = $('#okBtn');
				this.$cancelBtn = $('#cancelBtn');
				
				this.emailVal = '';
			},
			'setEvent'		: function() {
				var _self = this;
				
				$('#PW').keydown(function(e){
					if(e.which == 13){
						_self.$okBtn.trigger('click');
					}
				});
				
				//확인 버튼
				_self.$okBtn.click(function(){
					_self.createShipMem();
				});
					
				//취소 버튼
				_self.$cancelBtn.click(function(){
					Bplat.view.loadPage( _self._loginFormURL );
				});
			},
			'createShipMem' : function() {
				var _self = this;
		    	var id = $('#EMAIL').val();
		    	var pw = $('#PW').val();
		    	var param = {
				    	LOGIN_ID : id
				    	,PWD : pw
		    	};
				$.ajax({
					url : _self._nextStepURL
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function( data ) {
				    	if( null != data.msg ){
				    		alert( data.msg );
				    		return false;
				    	}
				    	var url = _self._context + data.redirectUrl;
				    	alert("가입 완료되었습니다.");
				    	Bplat.view.loadPage( url );
				    }

				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_simple2] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				console.info('simple2', p_param);


			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_simple2] onRestart Method' );
				console.info('onRestart2', p_param);

			},
			'onStart' : function( p_param ) {			

			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple2] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple2] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_simple2] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_simple2] onDestroy Method' );
			}		
	  }
});
