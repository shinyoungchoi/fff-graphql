defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._sendAuthCodeURL = $('#sendAuthCodeURL').val();
				this._changeNewPwdURL = $('#changeNewPwdURL').val();
				this._resultUrl = $('#resultUrl').val();				
				
				this.$btnAction = $('.jdg-btn-action');

				this.msg = $('#msg').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
					
				//확인 버튼
				_self.$btnAction.click(function(event){
					
					var evId = event.currentTarget.id;	
					var selectId = $('.radioUserId:checked').val();
					
					if (evId == "btnSetPwd")
						{	
							var pwd1 = $("#userPwd").val();
							var pwd2 = $("#userPwd2").val();
							
							if (pwd1 == "" || pwd1.length < 6 || pwd1.length > 15 )
								{
									alert("새 비밀번호를 6자리이상 15자이하로 입력하십시오.");
									return false;
								}
						
							if (pwd2 == "" || pwd2.length < 6 || pwd2.length > 15 )
								{
									alert("새 비밀번호 확인을 6자리이상 15자이하로 입력하십시오.");
									return false;
								}
							
							if(_self.pwCheck(pwd1))
								{
									alert("영문/숫자/특수문자 중 2가지 이상 조합하셔야 합니다");
									return false;
								}
							
							//같은 문자 3회 이상 반복되는지 체크
							var regExp = /(\w)\1\1/;
							if(regExp.test(pwd1)){
								alert("같은 문자는 3회 이상 연결해서 사용하실 수 없습니다. 예)aaa,222");
								return false;
							}
							
							if (pwd1 != pwd2)
								{
									alert("새 비밀번호와 새 비밀번호 확인을 동일하게 입력하십시오.");
									return false;								
								}
							
							var param = {'PWD': pwd1};
							
							$.ajax({
								url : _self._changeNewPwdURL
								,type : 'POST'
								,data : param
								,dataType : 'json'
								,success : function( data ) {
									
									if(data.msg == 'ok')
									{
										alert('패스워드가 변경되었습니다.\n 로그인화면으로 이동합니다.');
										
										Bplat.view.loadPage( "login_form",{'selectId': $("#userId").val()});	
									}
									else
									{
										alert(data.msg);									
										return false;										
									}
							    }

							});
											
						}

					if (evId == "btnGoPwd")
					{				
						Bplat.view.loadPage( "pw_reset_step");					
					}
					
				});
			},

			//문자,숫자,특수기호 중 2가지 이상 조합인지 체크
			'pwCheck' : function(pwVal) {
				var _self = this;
				var count = 0;
				
				//문자 포함
				if(/[a-zA-Z]/.test(pwVal)){
					count++;
				}
				
				//숫자 포함
				if(/[0-9]/.test(pwVal)){
					count++;
				}
				
				//특수기호 포함
				if(/[^0-9a-zA-Zㄱ-ㅎㅏ-ㅣ가-힝]/.test(pwVal)){
					count++;
				}
				
				if( count >= 2){
					return false;
				}else{
					return true;
				}
			},
			'loading': function(){
				var _self = this;
				var $loadingImg = $('#loading');
				$loadingImg.css("top", (($(window).height() - $loadingImg.outerHeight()) / 2) + $(window).scrollTop() + "px");
				$loadingImg.css("left", (($(window).width() - $loadingImg.outerWidth()) / 2) + $(window).scrollLeft() + "px");
				$loadingImg.show();
				setInterval(function(){
					$loadingImg.fadeOut('slow').fadeIn('slow');
				},2000);
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[id_find_step2] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[id_find_step2] onStart Method' );
				var _self = this;
				if(_self.msg !=  null && _self.msg != undefined && _self.msg != ""){
					alert(_self.msg);
				}
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[id_find_step2] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[id_find_step2] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[id_find_step2] onDestroy Method' );
			}		
	  }
});
