defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {

				// url
				this._myReserveListURL = $('#myReserveListURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleDateDetailURL = $('#scheduleDateDetailURL').val();
				this._watingReserveUrl = $("#watingReserveUrl").val();

				// element
				this.$dateYear = $('#dateYear');
				this.$dateMonth = $('#dateMonth');
				this.$prevMonth = $('#schedulePrevMonth');
				this.$nextMonth = $('#scheduleNextMonth');
				this.$calendarTemplate = $('#calendarTemplate');
				
				// Calendar
				this.$calendarContainer = $('#calendarContainer');
				this.$calendarRow = this.$calendarTemplate.find('#calendarRow');
				this.$scheduleRow = this.$calendarTemplate.find('.scheduleRow');
				
				// Calendar List
				this.$calendarListContainer = $('#calendarListContainer');
				this.$calendarListRow = this.$calendarTemplate.find('.calendarListRow');
				
				// static variable
				this.currentScheduleList = null;
				this.weekArr = ['일요일', '월요일','화요일','수요일','목요일','금요일','토요일'];
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
				
				this.bizId = $('#bizId').val();
				this.shipId = $('#shipId').val();
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				
				this._selectedDay = null;
				this._todayTd = null;
				this._selectedTd = null;
				
				this.$telOnly = $("input#telOnly").val().replaceAll(" ","");
				this._reserveNoMemCancleURL = $("#reserveNoMemCancleURL").val(); 
			},
			'setEvent'		: function() {
				var _self = this;
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 1 ) {
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 12 ) {
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});

				_self.$calendarListContainer.delegate('.jdg-status-a','click',function() {					
					Bplat.view.loadPage('schedule/detail_form?SCHD_ID=' + $(this).data('schdId'));
				});				
				
				_self.$calendarContainer.delegate('td.on','click',function() {	
					
					var $td = $(this);					
					if (_self._selectedTd.attr('id') != $td.attr('id'))
						{
							_self.getDaySchedule($td.attr('date'));	
						}
				});				
				
				//예약대기 화면
				$(document.body).on("click", ".watingBtn", function(){
					var schdId = $(this).attr("pid");
					location.href= _self._watingReserveUrl +"?SCHD_ID="+schdId;
				});
			},
			// 달력생성
			'createCalendar' : function( year, month ) {

				$('.jdg-ui-calendar').hide();
				// Calendar & Calendar List 생성
				var _self = this;
				_self.$calendarContainer.empty();
				var tmpDay = new Date();
				
				var isCurrentMonth = tmpDay.getFullYear() == year && tmpDay.getMonth() == month;
				var currentDate = tmpDay.getDate();
				
				tmpDay.setFullYear(year, month, 1);
				var dayOfMonth = tmpDay.getRangeDaysOfMonth(); //이번달
				var startDay = Number( dayOfMonth[0].split('-')[2] );
				var endDay = Number( dayOfMonth[1].split('-')[2] );
				var srhMonth = (month+1 < 10) ? '0'+(month+1) : (month+1);
				var weekCnt = 1;
				
				_self._todayTd = null;
				
				for( var i = startDay; i <= endDay ; i++ ) {
					tmpDay.setDate(i);
					var day = tmpDay.getDay();
					var date = tmpDay.getDate();
					if( i == 1 || day == 0 ) {
						// calendar
						var $week = _self.$calendarRow.clone();
						_self.$calendarContainer.append( $week );
						
						weekCnt++;
					}
					var $td = $week.find('[day='+day+']');
					$td.text(i);
					$td.attr('id', 'td_calendar_' + i);
					
					if (isCurrentMonth && currentDate == date)
					{
						$td.css('border','blue 3px solid');
						_self._todayTd = $td;
					}					
				}
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month+1);
				// 해당 Calendar의 출조 스케쥴 조회
				_self.getScheduleList({'SCHD_MONTH' : year + '' + srhMonth });

			},
			'getMyReserveList' : function() {
				var _self = this;
				
				var defaultParam = {
						 'PAGE' : 1
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    console.log(data);
				    	_self.renderReserveList(data.memReserveList);
				    }
				});				
			},
			'renderReserveList' : function(list){
				var _self = this;				
							
				console.log(list);
		    	$.each(list, function(key,value) {
		    		 $row = _self.$tmpReserveListRow.clone();
		    		 $row.attr('id', null);
		    		 				    		 
		    		 $schdDate = $row.find('[data-key="SCHD_DATE"]');
		    		 $schdDate.text(value.SCHD_DATE);

		    		 $schdTitle = $row.find('[data-key="SUB_TITLE"]');
		    		 $schdTitle.text(value.SUB_TITLE);

		    		 $shipName = $row.find('[data-key="SHIP_NAME"]');
		    		 $shipName.text(value.SHIP_NAME);

		    		 $manCnt = $row.find('[data-key="MAN_CNT"]');
		    		 $manCnt.text(value.MAN_CNT);

		    		 $totCost = $row.find('[data-key="TOT_COST"]');
		    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money'));

		    		 var statusCd = value.STATUS_CD;
	    			var status = null;
	    			$statusName = $row.find('[data-key="STATUS_NAME"]');
	    			if( statusCd == '104_300' || statusCd == '104_340'){
	    				$statusName.addClass('jdg-status-a');
	    			}else if( statusCd == '104_310'){
	    				$statusName.addClass('jdg-status-b');
	    			}else{
	    				$statusName.addClass('jdg-status-c');
	    			}
	    			$statusName.text(value.STATUS_NAME);
	    			
	    			$row.click( function(){
	    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
	    					'RSV_ID' : value.RSV_ID
	    				});
	    				return false;
	    			});

	    			_self.$reserveList.append($row);
	    			
		    		 $row = _self.$tmpMobileReserveListRow.clone();
		    		 $row.attr('id', null);
		    		 
		    		 $schdDate = $row.find('[data-key="SCHD_DATE"]');
		    		 $schdDate.text("출조:" + value.SCHD_DATE);

		    		 $schdTitle = $row.find('[data-key="SUB_TITLE"]');
		    		 $schdTitle.text(value.SUB_TITLE + " / " + value.SHIP_NAME);

		    		 $manCnt = $row.find('[data-key="MAN_CNT"]');
		    		 $manCnt.text(value.MAN_CNT + "명");

		    		 $totCost = $row.find('[data-key="TOT_COST"]');
		    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money')  + "원");

		    		 var statusCd = value.STATUS_CD;
	    			var status = null;
	    			$statusName = $row.find('[data-key="STATUS_NAME"]');
	    			if( statusCd == '104_300' || statusCd == '104_340'){
	    				$statusName.addClass('jdg-data-reservation-status jdg-status-a');
	    			}else if( statusCd == '104_310'){
	    				$statusName.addClass('jdg-data-reservation-status jdg-status-b');
	    			}else{
	    				$statusName.addClass('jdg-data-reservation-status jdg-status-c');
	    			}
	    			$statusName.text(value.STATUS_NAME);
	    			
	    			$row.click( function(){
	    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
	    					'RSV_ID' : value.RSV_ID
	    				});
	    				return false;
	    			});

	    			_self.$mobileReserveList.append($row);
		    	 });					  				
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var today = jdg.util.today().replaceAll('-','');
				$.ajax({
					 url : _self._scheduleListURL
					,async : false
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var scheduleList = data.scheduleList;
			    		_self.currentScheduleList = scheduleList;
			    		
				    	var seatimeList = data.seatimeList;
				    	//var seatimeMap = {};
				    	
				    	var _td;
						
						for (var idx = 0; idx < seatimeList.length; idx ++)
						{
							var item = seatimeList[idx];
							var tDay = item.SOLAR_DATE.substr(6,2) * 1;
							
							_td = _self.$calendarContainer.find('#td_calendar_'+tDay);
							_td.addClass("on");
							_td.append( "<span class='jdg-data-tide'>" + item.MOOL + "</span>" );	
							_td.attr('date', item.SOLAR_DATE);
							
							if (item.SOLAR_DATE < today)
							{
								_td.css('color','lightgray');
								_td.find('span').css('color','lightgray');
							}
							
							if (isHoliday(item.SOLAR_DATE))
							{
								_td.addClass("jdg-sun");
								_td.removeClass("jdg-sat");
							}	

						}
			    		
			    		//달력생성 및 예약가능선박수
			    		_self.renderScheduleList( scheduleList );
			    		
			    		// Loader 삭제
						$('.jdg-ui-calendar').show();
						jdg.util.removeLoader();
						
						var searchDate;
						
						if (_self._selectedDay)
						{
							searchDate = _self._selectedDay;
							_self._selectedDay = null;
						}
						else
						{
							searchDate = (today.substr(0,6) == param.SCHD_MONTH)? today : param.SCHD_MONTH + '01';
						}

						_self.getDaySchedule(searchDate);
				    }
				});
			},
			

			// 해당일 출조스케쥴 
			'getDaySchedule' : function( schdate ) {
				
				var _self = this;
				
				var $td = $('td#td_calendar_' + (schdate.substr(6,2) * 1));
				
				if (_self._selectedTd)
				{
					_self._selectedTd.css('border', '');
				}
					
				$td.css('border','red 2px solid');						
				_self._selectedTd = $td;
				
				if (_self._todayTd && _self._todayTd != $td)
				{
					_self._todayTd.css('border','blue 3px solid');
				}	
				
				_self._selectedDay = schdate;

				var param = {SCHD_DATE:schdate};				
				
				$.ajax({
					 url : 'schedule/daysc'
					,async : false
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var scheduleList = data.scheduleList;
				    	var reserveList = data.reserveList;
				    	
			    		var waitingList = data.waitingList;
			    		
				    	if (scheduleList.length == 0)
				    	{
				    		var _dateStr = $('span.jdg-data-month').text() + " " + (_self._selectedDay.substr(6,2) * 1) + '일';
				    		_self.$calendarListContainer.empty();
				    		_self.$calendarListContainer.append("<div style='background-color:#FFAEAE;font-size:12pt;padding:10px;color:white;font-weight:bold'>" + _dateStr  +"에는 출조일정이 없습니다.<div>");
				    		return;
				    	}
				    	
				    	var reserveMap = {};
				    	var item;
				    	var resv;
				    	var status;
				    	
				    	var dateStr;
				    	var timeStr;
				    	var dayStr;
				    	
				    	if (reserveList != null)
				    	{
				    		var seaTime = $("#td_calendar_" + (schdate.substr(6,2) * 1) + " .jdg-data-tide").text();
				    		
							for (var idx = 0;  idx < reserveList.length;idx++ )
							{
								item = reserveList[idx];
								resv = reserveMap[item.SCHD_ID];
								
								switch(item.STATUS_CD)
								{
								case "104_300": status = " 확정"; break;
								case "104_310": status = " 미입금"; break;
								case "104_320": status = " 부분입금"; break;
								case "104_340": status = " 확정"; break;
								case "104_410": status = " 취소"; break;
								case "104_420": status = " 취소(환불예정)"; break;
								case "104_430": status = " 취소(환불완료)"; break;
								}
								
								var dispText = "";
								if (item.DISP_TXT)
								{
									dispText = item.DISP_TXT.substr(0,12) 
								}
								
								var seatText = "";
								if (item.SEAT_TXT)
								{
									seatText = " 자리:" + item.SEAT_TXT;
								}
								var guest = "";
								
								//비회원 예약인 경우
				    			if(item.JOIN_TYPE == 'GUEST'){
				    				//비회원인경우 취소가능
				    				if(item.LEFT_DAY > 1){
				    					guest += "<a href='javascript:void(0);' pstatus='"+item.STATUS_CD+"' pid='"+ item.RSV_ID+"'  class='cancle_guest'>취소하기</a>";
				    				}else{
				    					//하루전날인 경우
				    					if(item.STATUS_CD == "104_310"){
				    						//미입금만 취소 가능.
				    						guest += "<a href='javascript:void(0);' pstatus='"+item.STATUS_CD+"' pid='"+ item.RSV_ID+"' class='cancle_guest'>취소하기</a>";
				    					}else{
				    						guest += "<a href='javascript:alert(\"출조전날은 예약취소가 불가능합니다\");' class='cancle_guest_disa'>취소하기</a>";
				    					}
				    				}
				    			}
								
								if (resv)
								{
									reserveMap[item.SCHD_ID] = resv + "<div>" + dispText + ' 님(' + item.MAN_CNT + seatText + ') ' + status + guest + "</div>";
								}
								else
								{
									reserveMap[item.SCHD_ID] = "<div>" + dispText + ' 님(' + item.MAN_CNT + seatText + ') ' + status +  guest+ "</div>";
								}
							}
				    	}
				    	
				    	if(waitingList != null){
				    		$.each(waitingList, function(idx, info){
			    					reserveMap[info.SCHD_ID] =  reserveMap[info.SCHD_ID] + "<p style='font-size:12px;' class='p2'>"+info.USER_NAME+"("+info.WATING_PSGR_CNT+"명) 예약대기</p>";
			    				});
				    	}
				    	
				    	var cont = _self.$calendarListContainer;
				    	var tmpl ;
				    	
				    	_self.$calendarListContainer.empty();

						for (var idx = 0; idx < scheduleList.length; idx ++)
						{
							item = scheduleList[idx];
							
							if (item.DEL_FLAG == 'Y') continue; //감춤처리
							
							if (idx == 0)
							{
				    			var schdDate = item.SCHD_DATE;
				    			var year = schdDate.substring(0,4);
				    			var month = schdDate.substring(4,6)-1;
				    			var date = schdDate.substring(6,8);
				    			var tmpDay = new Date();
				    			tmpDay.setFullYear(year, month, date);
				    			dayStr = _self.weekArr[tmpDay.getDay()];
				    			
								dateStr = (1 * schdDate.substr(4,2)) + '월'+ (1 * schdDate.substr(6,2)) + '일';								
							}
							
							if(item.SCHD_TIME != '' && item.SCHD_TIME != undefined)
								timeStr = item.SCHD_TIME.substr(0,2) + ':' + item.SCHD_TIME.substr(2,2);
							else
								timeStr = "";
							
							
							tmpl = _self.$calendarListRow.clone();
							
							$(tmpl[0]).text(item.SHIP_NAME);
							tmpl.find('#sub_title').text(item.SUB_TITLE);
							
							tmpl.find('#date').text(dateStr);
							tmpl.find('#schd_time').text(timeStr);
							tmpl.find('#day').text(dayStr);
							
							if (item.NOTICE_TEXT)
							{
								tmpl.find('#notice_text').text(item.NOTICE_TEXT);
							}
							else
							{
								tmpl.find('#notice_text').remove();
							}

						
							if (reserveMap[item.SCHD_ID] && '113_180' != item.STATUS_CD)
							{
								tmpl.find('#rsv').html(reserveMap[item.SCHD_ID]);
								tmpl.find(".cancle_guest").click(function(){
									var pid = $(this).attr("pid");
									var pStatus = $(this).attr("pStatus");
									Bplat.view.loadPage(_self._reserveNoMemCancleURL + "?STATUS_CD=" + pStatus+"&RSV_ID="+pid);
				    			
				    				return false;
								});
							}
							else
							{
								tmpl.find('#rsv').remove();
							}

							//장르 선택 전 일반 낚시
							if(item.SCHD_TIME_TYPE == '0' && ( item.CHOICE_GENRE == '' || item.CHOICE_GENRE == undefined)){
								var genreCnt = 0;
			    				var subtitle = "";
			    				if(item.GENRE_USEYN1 == 'Y'  && item.GENRE1_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE1;
			    				}
			    				if(item.GENRE_USEYN2 == 'Y'  && item.GENRE2_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE2;
			    				}
			    				if(item.GENRE_USEYN3 == 'Y'  && item.GENRE3_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE3;
			    				}
			    				
			    				var title = "출조합니다.";
			    				if(genreCnt == 1){
			    					title = subtitle;
			    				}
								if(item.SUB_SHIPNM != '' && item.SUB_SHIPNM != undefined){
									tmpl.find('#sub_title').text(item.SUB_SHIPNM +"| "+title);
								}else
									tmpl.find('#sub_title').text(title);
								
							}else{
								if(item.SUB_SHIPNM != '' && item.SUB_SHIPNM != undefined)
									tmpl.find('#sub_title').text(item.SUB_SHIPNM +"| "+item.SUB_TITLE);
								else
									tmpl.find('#sub_title').text(item.SUB_TITLE);
							}
							
							tmpl.find('#date').text(dateStr);
							tmpl.find('#schd_time').text(timeStr);
							tmpl.find('#day').text(dayStr);
							tmpl.find('#seaTime').text(seaTime);
							
			    			// 예약可인원
			    			//var reserveCnt = item.PSGR_CNT-item.RESERVE_CONFIRM_CNT-item.RESERVE_WAIT_CNT;
							var reserveCnt = item.PSGR_CNT-item.RESERVE_CONFIRM_CNT;
							if(item.WAIT_RESERVE_YN == "Y"){
								 reserveCnt = item.PSGR_CNT-item.RESERVE_CONFIRM_CNT-item.RESERVE_WAIT_CNT;
							}
							// Calendar & Calendar List 예약상태
			    			
			    			var statusObj = tmpl.find('em.statusCd');
			    			var watingObj = tmpl.find("span.watingBtn");
			    			
			    			if( '113_110' === item.STATUS_CD && reserveCnt <=0 ) {
			    				statusObj.text('마감').addClass('jdg-status-c');
			    				watingObj.text('예약대기').attr("pid",item.SCHD_ID).attr("style","padding:2px 3px");
			    			} else if( '113_110' === item.STATUS_CD ) {
		    	        		if (_self.$telOnly != "")
								{
		    	        			statusObj.css({cursor:'pointer',background:'blue',padding:'4px 10px','border-style': 'outset','border-width': '3px'});
		    	        			statusObj.html("<a style='color:white' href='tel:" + _self.$telOnly + "'>전화예약</a>");
								}
		    	        		else
		    	        		{
				    				statusObj.addClass('jdg-status-a');
				    				statusObj.data('schdId',item.SCHD_ID);
		    	        		}
			    				// 예약可인원
			    				tmpl.find('#avail_cnt').text( reserveCnt<0?0:reserveCnt + '명');
			    			} else if( '113_170' === item.STATUS_CD) {
			    				statusObj.text('마감').addClass('jdg-status-b');
			    			} else if( '113_180' === item.STATUS_CD) {
			    				statusObj.text('만료').addClass('jdg-status-c');
			    			} else if( '113_210' === item.STATUS_CD ) {
			    				statusObj.text('출조취소').addClass('jdg-status-d');
			    			}
			    			
							_self.$calendarListContainer.append(tmpl);
							scrollBottom();
						}

				    }
				});
			},
			
			
			'renderScheduleList' : function(list){
				
				var _self = this;
				
				_self._interval_objs = null;
				
				var isBlink = false;
				
    			if (_self._interval_id)
    			{
    				clearInterval(_self._interval_id);			    				
    				_self._interval_id = null;
    			}
				
				$.each( list, function( idx, data ) {
	    			// web calendar 셋팅
	    			var schdDate = data.SCHD_DATE;
	    			var year = schdDate.substring(0,4);
	    			var month = schdDate.substring(4,6)-1;
	    			var date = schdDate.substring(6,8);
	    			
	    			var dateNum = parseInt( date, 10 );

	    			var $td = $('#td_calendar_' + dateNum);

	    			if( data.AVAILS > 0 ) {
	    				
	    				$td.append( "<div class='jdg-bgbox1'></div>" );	

	    			} 
	    			else if( data.AVAILS == 0 && data.SOLDOUTS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox2'></div>" );	
	    				$td.css("text-decoration","line-through");
	    			} 
	    			else if( data.AVAILS == 0 && data.CANCELS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox3' style='z-index: 100'>취소</div>" );	
	    				
	    				isBlink = true;
	    			}
	    			

 
    				// mobile calendar 셋팅
	    			var $ul = $( '#ul_calendar_list_'  + _self.getWeekOfMonth( new Date(year, month, dateNum) ) );

	    		});
				
	    		if (isBlink)
	    		{
	    			_interval_objs = $("div.jdg-bgbox3");
	    			_interval_index = 0;			    			
	    			_self._interval_id = setInterval(_self.blinkEffect, 400);
	    		}
			},

			'blinkEffect' : function()
			{
				  var _self = this;
				  
				  _interval_index ++;		

				  var comp = _self._interval_objs;  
				  var status = _self._interval_index;				  
				  
				  if (status == 1)
				  {
				  	comp.hide();
				  }
				  else if (status == 2)
				  {
					comp.show();
					comp.text('출조');
				  }	
				  else if (status == 3)
				  {
					comp.hide();
				  }	
				  else if (status == 4)
				  {
					comp.show();  
					comp.text('취소');
				  	_self._interval_index = 0;
				  }					
			},
			
			'getWeekOfMonth' : function(date){
				var dayOfMonth = date.getDate();
				
				var first = new Date( date.getFullYear(), date.getMonth(), 1 );
				var monthFirstDateDay = first.getDay();
				
				return Math.ceil( (dayOfMonth + monthFirstDateDay) / 7 );
			},
		
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length >= 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(^[+-]?\d+)(\d{3})/;
					str += '';
					
					while(pattern.test(str)) {
						str = str.replace(pattern,'$1,$2');
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},			
			'onCreate' : function( p_param, _viewClass ) {
				// 로더 생성
				jdg.util.showLoader();
				
				var _self = this;

				// 초기화
				_self.setElement();
				
				var hsh = location.hash;
				var year;
				var month;
				
				if (hsh != null && hsh != "")
				{
					year = hsh.substr(1,4);
					month = hsh.substr(5,2);				
				}
				else
				{
					var today = new Date();
					year = today.getFullYear();
					month = today.getMonth() + 1;
				}
				
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month);
				
				_self.setEvent();

				//_self.getMyReserveList();
				
				// 캘린더 초기화
				var hash = location.hash;
				if( '' == hash ) {
					var today = new Date();
					var year = today.getFullYear();
					var month = today.getMonth() + 1;
					// set hash
					location.hash = year + '' + jdg.util.setStringFillZero(month,2);
				} else {
					var hashDay = hash.replace('#','');
					var year = hashDay.substring(0,4);
					var month = hashDay.substring(4,6);
					
					if (hashDay.length == 8)
					{
						_self._selectedDay = hashDay;
					}
					
					_self.createCalendar( year, month-1 );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
