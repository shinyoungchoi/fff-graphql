defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				this._portalShipURL = $('#portalShipURL').val();
			},
			'setEvent'		: function() {
			},
			// 해당일 스케줄 데이터 조회
			'getScheduleDateList' : function( schdDate ) {
				var _self = this;
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : {
						'SCHD_DATE' : schdDate
					}
				    ,dataType : 'json'
				    ,success : function( data ) {

					    var lst = data.scheduleList;
				    	
				    	
			    		$.each( lst, function( key, value ) {
			    			if(value.MAN_CNT== null)
			    				value.MAN_CNT=0;
			    			
			    			if( value.PSGR_CNT > value.MAN_CNT ){
			    				$li = $( "<li><span>" + value.AREA_DESC + " " + value.PORT 
			    						+ "</span> <span style='color:#2E2ECC;font-weight:bolder'>" + value.SHIP_NAME 
			    						+ "</span><br><span style='background-color: #E3F3F3;padding: 5px;color: black;'>" + value.SUB_TITLE 
			    						+ "</span><span style='float:right'> ( 가능인원 : " + (value.PSGR_CNT - value.MAN_CNT) + "명 )</span></li>" );
			    				
			    				$li.attr("schd_id", value.SCHD_ID);
			    				$li.attr("biz_id", value.BIZ_ID);
			    				$li.attr("ship_id", value.SHIP_ID);
			    				$li.attr("target", "_blank");
			    				$li.click( function(){
			    					
			    					location.href = '/pw/' + $(this).attr('biz_id') + '/' + $(this).attr('ship_id') + '/schedule/detail_form?SCHD_ID=' + $(this).attr('schd_id');
				    				return false;
				    			});

			    				$('#ulValidShipList').append( $li );

			    				
			    			} 
			    		} );
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_date_detail] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.getScheduleDateList( p_param.SCHD_DATE );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_date_detail] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_date_detail] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_date_detail] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_date_detail] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_date_detail] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_date_detail] onDestroy Method' );
			}		
	  }
});
