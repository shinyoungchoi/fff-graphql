defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._msgSendURL = $('#msgSendURL').val();
				this._msgDetailURL = $("#msgDetailURL").val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$insertForm = $('#frm');
				this.$insertBtn = $('#sendBbsBtn');
				this.$type;
								
				// 파일리스트
				this.fileList  = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				$('#textDatePicker').datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd'
				    ,showTrigger: '<a href="#" class="jdg-btn-calendar" style="display:inline-block;    vertical-align: middle;" title="달력"></a>'			    	
				});
				
				$('#textTimePicker').timepicker({
				    timeFormat: 'HH:mm',
				    interval: 1,
				    defaultTime: 'now',
				    startTime: '03:00',
				    dynamic: true,
				    dropdown: true,
				    scrollbar: true
				});
								
				$("#content").on("keyup", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){
						$("span.msg_type").html("LMS");
					}else{
						$("span.msg_type").html("SMS");
					}
					if(value > 1499){ // 최대 1500자
						var content_ = content.substr(0,1499);
						$("#content").val(content_);
						return false;
					}
				});
								
				//템플릿 선택 시
				$("select.temp_select").on("change", function(){
					var seq = $(this).val();
					$.ajax({
						 url : _self._msgDetailURL
						,type : 'POST'
						,data : {SEQ : seq}
					    ,dataType : 'json'
					    ,success : function( data ) {				    	
					    	console.log(data);
					    	var result = data.result;	
					    	if(result.SMS_TYPE == 'LMS'){
					    		$("#smsPopWrap").find("tr.title_div").show();
					    	}else{
					    		$("#smsPopWrap").find("tr.title_div").hide();
					    	}					    	
					    	$("#smsPopWrap").find("input[name='SEND_TITLE']").val(result.TITLE);
					      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val(result.CONTENT);
					      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
					      	if(result.MAIN_IMG_ID != null && result.MAIN_IMG_ID != ''){
					      		_self.fileList.init(result);
					      	}
					    }
					}); 
				});
				
				//전송 시간
				$("#smsPopWrap").on("click", "input:radio[name='SEND_TIME']", function(){
					var value = $(this).val();
					if(value == 'NOW'){
						$(".sendDate").hide();
					}else{
						$(".sendDate").show();
					}
				});
				
				//byte 체크
				$("#smsPopWrap").on("keyup", "textarea[name='SEND_CONTENT']", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){ //LMS인경우부터는 제목 가능
			    		$("#smsPopWrap").find("tr.title_div").show();
					}else{
						$("#smsPopWrap").find("tr.title_div").hide();
					}
					if(value > 1499){
						var content_ = content.substr(0,1499);
						$("#smsPopWrap textarea[name='SEND_CONTENT']").val(content_);
						return false;
					}
					
				});
				
				//발송
				_self.$insertBtn.on("click", function(){
					var param = { SEND_TEL : $("#smsPopWrap").find(".sendTel").html()};
					
					var schdDate = $("#smsPopWrap").find("input[name='schd_date']").val();
					param.SCHD_DATE = schdDate;
					
					var schdId = $("#smsPopWrap").find("input[name='schd_Id']").val();
					param.SCHD_ID = schdId;
					
					var sendTimeType = $("#smsPopWrap").find("input:radio[name='SEND_TIME']:checked").val();
					if(sendTimeType == 'RESERVE'){
						var textDatePicker = $("#smsPopWrap").find("#textDatePicker").val();
						param.SEND_DATE = textDatePicker;
						
						var textTimePicker = $("#smsPopWrap").find("#textTimePicker").val();
						if(!(/^[0-9\:]*$/.test(textTimePicker))){
							alert("00:00 형태로 입력하셔야 합니다.");
							return;
						}
						
						if(textTimePicker == ''){
							alert("예약 시간을 입력해주세요.");
							return;
						}
						param.SEND_TIME = textTimePicker; 
					}
					param.SEND_TIME_TYPE = sendTimeType;
																
					var content = $("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val();
					if(content == ''){
						alert("내용을 입력해주세요.");
						return;
					}
					param.SEND_CONTENT = content;
					
					var count = _self.checkBytes(content);
					param.MSG_TYPE = "SMS";
					
					if(count > 130){
						var title = $("#smsPopWrap").find("input[name='SEND_TITLE']").val();
						if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(title))){
							alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
							return;
						}else{
							param.SEND_TITLE = title;
						}
						param.MSG_TYPE = "LMS";
					}
											
					var phones = [];
					var checkYn = false;
					$("#smsPopWrap").find("input:checkbox[name='RSV_MEM']").each(function(){
						if($(this).is(":checked")){
							var id = $(this).attr("pid");
							var tel = $(this).attr("ptel");
							var name = $(this).attr("pname");
							phones.push({RSV_ID: id,RSV_TEL: tel, RSV_NAME : name});
							checkYn = true;
						}
					});
					
					if(!checkYn){
						alert("수신자를 한명이상 선택해주세요.");
						return;
					}
					
					//파일 정보 가져가기
					param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
					
					param.RSV_TELS = JSON.stringify(phones);
											
					if(confirm("전송하시겠습니까?")){
					$.ajax({
						 url : _self._msgSendURL
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ){
					    	if(data.msg == "success"){
					    		alert("문자 전송에 성공하였습니다.");
					    		return;
					    	}
					    	
					    	if(data.nosessionmsg != null){
					    		alert("세션이 종료되었습니다. 로그인해주세요.");
					    		return;
					    	}
					    	
					    	if(data.failmsg != null){
					    		alert(data.failmsg);
					    		return;
					    	}
					    	alert("문자 전송도중 오류가 발생하였습니다.");
					    	return;
					    }
					    ,error : function(error){
					    	alert("문자 전송도중 오류가 발생하였습니다.");
					    	return;
					    }
					});
					}
					
				});
								
				
			},
			 //byte 체크
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},
			// 템플릿 등록
			'insertTemplate' : function() {
				var _self = this;
				var param = {};
				
				var tempType = $("#tempType").val();
				if(tempType != 6){
					param.TEMP_TYPE = $("#tempType option:selected").html();
				}else{
					param.TEMP_TYPE = $("#tempType option:selected").html();
					var tempTitle = $("#temp_title").val();
					if(tempTitle == ''){
						alert("문구종류를 입력해주세요.");
						return;
					}
					param.TEMP_SUBTITLE = tempTitle;
				}
					
				param.TITLE = $('#title').val();
				
				if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(param.TITLE))){
					alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
					return;
				}
				param.CONTENT =$('#ir1').val();			
				param.CONTENT_LENGTH = _self.checkBytes(param.CONTENT);
				if(param.CONTENT_LENGTH > 130){
					param.SMS_TYPE = "LMS";
				}else{
					param.SMS_TYPE = "SMS";
				}
				
				$("div.jdg-ui-gallery-write").find("li.fileListRow").each(function(){
					console.log($(this).html());
					param.MAIN_IMG_ID = $(this).attr("img_id");
					param.SMS_TYPE = "MMS";
				});
				
				if (param.TITLE == '')
				{
					alert('제목을 입력해주십시오.');
					return false;
				}
				
				if (param.CONTENT == '')
				{
					alert('내용을 입력해주십시오.');
					return false;
				}
				
				$.ajax({
					 url : _self._msgInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {				    	
				    	if( data.hasOwnProperty('msg') ) {
				    		if(data.msg == "success"){
					    		alert('등록되었습니다.');
					    		location.href=_self._msgListURL;
					    		return;
				    		}
				    		
				    		alert("등록 도중 오류가 발생하였습니다.");
				    		return;
				    	} else {
				    		alert('로그인이 필요 합니다.');
				    		showLoginBox(null, false);
				    	}
				    }
				}); 
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				

		        var today = jdg.util.today();				
				$('#textDatePicker').val(today);
				
				// 파일리스트
				_self.fileList  = new component.FileList({
					 'id' : _self.$insertForm.attr('id')
					,'container' :_self.$insertForm.find('[data-type=IMAGE_LIST]')
					,'selection' : "N"
					,'max_file' : 3
				});
				// 파일리스트 초기화
				_self.fileList.init();
				
				$("div.jdg-ui-img-description").find("textarea").css("opacity","0");
				

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});