defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishMainURL = $('#fishMainURL').val();
				// element
				this.$prevMonth = $('#fishPrevMonthBtn');
				this.$nextMonth = $('#fishNextMonthBtn');
				// static variable
				this.fishYear = $('#dateYear').text();
				this.fishMonth = $('#dateMonth').text();;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {
					var year = Number(_self.fishYear);
					var month = Number(_self.fishMonth);
					if( month == 1 ) {
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					Bplat.view.loadPage( _self.fishMainURL + '?FISH_MONTH=' + year + jdg.util.setStringFillZero(month,2) );
				});
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					var year = Number(_self.fishYear);
					var month = Number(_self.fishMonth);
					if( month == 12 ) {
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					Bplat.view.loadPage( _self.fishMainURL + '?FISH_MONTH=' + year + jdg.util.setStringFillZero(month,2) );
				});
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
