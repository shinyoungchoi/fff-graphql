defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$insertForm = $('#memberFishInsertForm');
				this.$fishDate = $('#fishDate');
				this.$insertBtn = $('#insertFishBtn');
				this.$typeCd = $('#typeCd');
				this.$movieListRow = $('.movieListRow');
				
				this._lock = false;
				
				// 파일리스트
				this.fileList  = new component.FileList({
					 'id' : this.$insertForm.attr('id')
					,'container' : this.$insertForm.find('[data-type=IMAGE_LIST]')
				});
			},
			'setEvent'		: function() {
				var _self = this;

						//인낚
			$("input:checkbox[name='selectInish']").change(function(){
		
				var value = $(this).val();
				var checked_length = $("input[name='selectInish']:checked").length;

				if (value == 'N') {
					$("input:checkbox[name='selectInish']").each(function() {
						if ('N' != $(this).val()) {
							$("#select_fish_result").val('N');
							$(this).prop("checked", false);
						}
					});
					return;
				} else {
					$("input:checkbox[name='selectInish']:eq(7)").prop("checked", false);
				}

				if (checked_length > 2) {
					alert("게시판은 최대 두개까지 선택이 가능합니다.");
					$(this).prop("checked", false);
					return false;
				}
	
				var selectedInnak = "";
				$("input:checkbox[name='selectInish']").each(function() {
					if ($(this).is(":checked")) {
						selectedInnak += $(this).val() + ",";
					}
				});
				$("#select_fish_result").val(selectedInnak);
	
			});
				
				// 조과등록
				_self.$insertBtn.click( function() {
					_self.insertFish();
				});
				
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
					
							//debugger;
						}
				);

				
				_self.$insertForm.delegate("#movieAddBtn","click",function(event)
				{
					event.preventDefault();
					addMovieUrl(_self);
				});
			},
			// 조과 등록
			'insertFish' : function() {
				var _self = this;
				if (_self._lock) return; //중복등록방지
				_self._lock = true;
				
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) 
				{
					_self._lock = false;
					return false;
				}

				var typeCd = _self.$typeCd.val();				
				
				var param = autoDataGetter($insertForm);
				
				param.TYPE_CD = typeCd;
				param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
				
				
				try
				{	
				
					if (typeCd == "106_120")
					{	
						if (param.SHIP_NAME == undefined)
							param.SHIP_NAME = param.SHIP_ID_TEXT;
						
						if (param.PORT_NAME == undefined)
							param.PORT_NAME = param.PORT_CD_TEXT;
						
						if (param.FISH_NAME == undefined)
							param.FISH_NAME = param.FISH_TYPE_TEXT;	
						
						checkData(param.FISH_TYPE == "","어종을 입력해주십시오.");
						checkData(param.FISH_NAME == "" , "어종을 입력해주십시오.");
						
						checkData(param.FISH_LEN == "" && param.FISH_WEIGHT == "", "길이와 무게 둘중에 하나는 입력해야 합니다.");
						
						checkData(param.PORT_CD == "", "항구를 선택해주십시오.");
						checkData(param.PORT_NAME == "" , "항구명을 입력해주십시오.");
						
						checkData(param.SHIP_ID == "", "선박을 선택해주십시오.");
						checkData(param.SHIP_NAME == "" , "선박명을 입력해주십시오.");
						
						if (param.FISH_LEN != "")
						{
							var v = param.FISH_LEN;
							
							checkData(isNaN(v) , "길이는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "길이값이 너무 큽니다.");							
							checkData(v < 0 , "길이값이 0보다 작습니다.");
						}
						
						if (param.FISH_WEIGHT != "")
						{
							var v = param.FISH_WEIGHT;
							
							checkData(isNaN(v) , "무게는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "무게값이 너무 큽니다.");							
							checkData(v < 0 , "무게값이 0보다 작습니다.");
						}

/*  NAK-107 	
								로컬 홈피 조황 등록시 마릿수, 장소 설명 삭제 요청
						if (param.FISH_CNT != "")
						{
							var v = param.FISH_CNT;
							
							checkData(isNaN(v) , "마리수는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "마리수는 최대 9999마리까지 입력할수 있습니다.");							
							checkData(v < 0 , "마리수가 0보다 작습니다.");
						} */
					}
					else if(typeCd == "106_110"){
						checkData(param.PEOPLE_ONBOARD == '*' , "출조인원을 입력해주십시오.");
						//인낚
						var selectedInnak = "";
						$("input:checkbox[name='selectInish']").each(function(){
							if($(this).is(":checked")){
								if(selectedInnak == ""){
									selectedInnak = $(this).val();					
								}else{
									selectedInnak += ","+ $(this).val();
								}
							}
						});
						param.INNAK_BBS_CD = selectedInnak;
					}
					else
					{
						checkData(param.PEOPLE_ONBOARD == '*' , "출조인원을 입력해주십시오.");
					}					
				}			
				catch(err)
				{
					alert(err);
					_self._lock = false;
					return false;
				}
				
				
				$.ajax({
					 url : _self._fishInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('GALR_ID') ) {
				    		// 상세로 이동
				    		Bplat.view.loadPage( _self._fishDetailURL + '?GALR_ID='+data.GALR_ID );
				    	} else {
				    		alert('조황등록중 오류가 발생하였습니다.');
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				// 파일리스트 초기화
				_self.fileList.init();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});
