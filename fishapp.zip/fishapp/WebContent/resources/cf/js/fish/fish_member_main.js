defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishListURL = $('#fishListURL').val();
				this.fishDetailURL = $('#fishDetailURL').val();
				this.imageURL = $('#imageURL').val();
				this.noImageURL = $('#noImageURL').val();
				this.fishInsertURL = $('#fishInsertURL').val();
				// element
				this.$fishContainer = $('#fishContainer');
				this.$fishListContainer = $('#fishListContainer');
				this.$searchRow = $('#fishTemplate').find('.searchRow');
				this.$imageRow = $('#fishTemplate').find('.imageRow');
				this.$insertBtn = $('#insertBtn');
				// static variable
				this.fishMonth = $('#fishMonth').val();
				this.$typeCd = $('#TYPE_CD').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$insertBtn.click(function (){
					Bplat.view.loadPage(_self.fishInsertURL);
				});
			},
			'getFishList' : function( page ) {
				var _self = this;
				var $fishContainer = _self.$fishContainer;
				var $fishListContainer = _self.$fishListContainer;
				// 초기화
				$fishContainer.empty();
				$fishListContainer.empty();
				// 조회 데이터
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'TYPE_CD' : _self.$typeCd
				};
				$.ajax({
					 url : _self.fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
					    ,success : function( data ) {
					    	var fishList = data.fishList;
					    	var imgUrl;
					    	
					    	if( fishList.length <= 0 ) {
					    		// nodata
					    		$('.jdg-ui-nodata').show();
					    		$('.jdg-ui-gallery-list').hide();
					    	} else {
					    		$.each( fishList, function(idx,data) {
						    		var $row = _self.$searchRow.clone();
						    		if( idx == 0 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-left') );
						    		if( idx == 1 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-right') );
						    		$row.find('[data-key=FISH_DATE]').text( jdg.util.replaceDate(data.FISH_DATE,null,'.') );
						    		$row.find('[data-key=CREATED_NAME]').text( data.CREATED_NAME );
						    		$row.find('[data-key=TITLE]').text( data.TITLE );
				    				$row.find('[data-key=CONTENT]').html( data.CONTENT );
				    				$row.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
						    		if( undefined != data.MAIN_IMG_ID ) {
						    			
						    			imgUrl = (data.MAIN_IMG_ID.length == 10)? _self.imageURL + data.MAIN_IMG_ID + '/398' : 'https://i1.ytimg.com/vi/' + data.MAIN_IMG_ID + '/mqdefault.jpg';					    			
						    			
						    			$row.find('[data-key=MAIN_IMAGE]').attr('src', imgUrl );
						    			for( var i=0, iSize=data.imageList.length ; i < iSize ; i++ ) {
						    				var image = data.imageList[i];
						    				// 메인이미지는 서브리스트에 표시되지 않음
						    				if( ('Y' === data.MAIN_YN && 'N' === image.MAIN_YN) || ( 'N' === data.MAIN_YN && i > 0) ) {
							    				var $image = _self.$imageRow.clone();
							    				
							    				imgUrl = (data.imageList[i].MOVIE_YN == "N")? _self.imageURL + data.imageList[i].IMG_ID + '/84' : 'https://i1.ytimg.com/vi/' + data.imageList[i].IMG_ID + '/mqdefault.jpg';	
							    				
						    					$image.find('[data-key=SUB_IMAGE]').attr('src', imgUrl );
						    					$row.find('.imageList').append( $image );
						    				}
						    			}

					    		} else {
					    			$row.find('[data-key=MAIN_IMAGE]').attr('src', _self.noImageURL );
					    		}
			    				if( 0 == idx%2 ) {
					    			$fishContainer.find('.jdg-ui-gallery-left').append( $row );
					    		} else {
					    			$fishContainer.find('.jdg-ui-gallery-right').append( $row );
					    		}
			    				$row.find('a').attr('href', _self.fishDetailURL + '?GALR_ID=' + data.GALR_ID);
			    				
			    				// 모바일리스트에도추가
			    				$fishListContainer.append( $row.clone() );		    				
					    	});
				    		
				    		//페이징 초기화
				    		$('#fishListPaging').paging({
								 current: defaultParam.PAGE
								,max: (Math.ceil(data.total / 10))
								,itemClass: 'jdg-btn-page'
								,prevClass: 'jdg-btn-page-prev'
								,nextClass: 'jdg-btn-page-next'
								,firstClass: 'jdg-btn-page-first'
								,lastClass: 'jdg-btn-page-last'
								,onclick:function(e,page){
									location.hash = page;
								}
							});
				    		
				    		$('.jdg-ui-nodata').hide();
				    		$('.jdg-ui-gallery-list').show();
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				var hash = location.hash;
				if( '' == hash ) {
					// set hash
					location.hash = 1;
				} else {
					// 목록조회
					_self.getFishList( hash.replace('#','') );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
