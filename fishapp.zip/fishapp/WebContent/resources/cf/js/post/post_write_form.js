defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postDetailURL 		= $('#postDetailURL').val();
				this.postInsertURL 		= $('#postInsertURL').val();
				this.postUpdateURL 		= $('#postUpdateURL').val();
				this.imgMultiPopURL 	= $("#imgMultiPopURL").val();
				this.postListURL 		= $("#postListURL").val();
				this.imageURL 			= $('#imageURL').val();
				this.noImageURL 		= $('#noImageURL').val();
				// element
				// 게시 종류 전역 설정
				this.MAIN_TYPE 				= '108_110';
				this.$tbl = $('.jdg-table-notice-view');
				this.$vfrm = $("#vfrm");
				
				this.$insertBbsBtn = $("#insertBbsBtn");

			},
			'setEvent'		: function() {
				var _self = this;
				
				$("#imageList").on("click", "a.img_remove", function(){
					var fileId = $(this).attr("pid");
					$(this).parent().remove();
				});
				
				//확인 클릭 시
				_self.$insertBbsBtn.on("click", function(){
					var postId = $("#postId").val();
					var markupStr = $('#ir1').summernote('code');
					var param = {};
					param.CONTENT = markupStr;
					param.TITLE = $("#title").val();
					param.TYPE_CD = _self.MAIN_TYPE;
					
					var imageList = [];
					$("#imageList div").each(function(index){
						var $ele = $(this);
						var mainYn = "N";
						if(index == 0){
							mainYn = "Y";
						}
						var fileId = $ele.find("a").attr("pid");
						var params = { IMG_ID : fileId, CONTENT : "", MOVIE_YN : "N", MAIN_YN : mainYn};
						imageList.push(params);
					});
					
					param.IMG_ID = JSON.stringify(imageList);
					
					if(postId != null && postId != '')
					{
						param.POST_ID = postId;
						//수정	
						jQuery.ajax({
					           type:"POST",
					           url: _self.postUpdateURL,
					           data : param,
					           dataType:"json",
					           success : function(data) 
					           {	
					        	   if(data.result == "success"){
					        		   alert("수정되었습니다.");
					        		   location.href= _self.postListURL;
					        	   }else{
					        		   alert("오류가 발생하였습니다.");
					        		   return;
					        	   }
					           }
						});
					}		
					else{
						//등록
						jQuery.ajax({
					           type:"POST",
					           url: _self.postInsertURL,
					           data : param,
					           dataType:"json",
					           success : function(data) 
					           {	
					        	   if(data.result == "success"){
					        		   alert("등록되었습니다.");
					        		   location.href= _self.postListURL;
					        	   }else{
					        		   alert("오류가 발생하였습니다.");
					        		   return;
					        	   }
					           }
						});
					}
				});
			},
			//에디터 생성
			'makeEditor' : function(){				
				var _self = this;
				$("#ir1").summernote({
					height : 250,
					  focus: true     ,
					  disableDragAndDrop: true,
					  fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Open Sans', 'Impact','Times New Roman','Verdana','Tahoma'],
					  toolbar: [
						    ['style', ['bold', 'italic', 'underline', 'clear']],
						    ['fontname', ['fontname']],
						    ['fontsize', ['fontsize']],
						    ['color', ['color']],
						    ['para', ['ul', 'ol', 'paragraph','style']],
						    ['height', ['height']],
						    ['insert', ['picture', 'table','link']]
						  ],
					placeholder: '본문을 작성해주세요. 사진 업로드는 PC에서만 가능합니다.',
					 lang: 'ko-KR', // default: 'en-US',
					 callbacks: {
						    onImageUpload: function(files) {
						      // upload image to server and create imgNode...
						    	var formData = new FormData();
						    	for(var i = 0 ;i < files.length ;i++){
						    		var file = files[i];
						    		formData.append("file", file);
						    	}
						    		
							    	jQuery.ajax({
								           type:"POST",
								           url: _self.imgMultiPopURL +"/img_upload",
								           processData : false,
										   cache: false,
										   contentType: false,
						                   data: formData,
								           success : function(result){
								        	   if(result != null && result != ''){
								        		   var html = '<div style="border:1px solid #ddd;padding:5px;"><a href="javascript:void(0);" class="img_remove" pid="'+result.FILE_ID+'">이미지 삭제</a>';
								        		   html += '<img class="thumbnail" style="width:200px;height:200px;" src="/cm/file/image/'+result.FILE_ID+'/thumbnail">';
								        		   html += '</div>';
								        		   $("#imageList").append(html);
								        	   }
								        	   
								           },error: function(error){
								        	   alert("사진을 업로드하는 도중 오류가 발생하였습니다.");
								        		return;
								           }
							    	});
						    	}
					 }
				});
			},
			
			
			'pageInit'		: function() {
				var _self = this;
				
				
			},			
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.makeEditor();
				
				var postId = $("#postId").val();
				console.log(postId);
				if(postId != null && postId != ''){
				jQuery.ajax({
			           type:"POST",
			           url: _self.postDetailURL,
			           data : { "POST_ID": postId},
			           dataType:"json",
			           success : function(data) 
			           {	
			        	   var detail = data.detailPost;
			        	   var images = data.imageList;
			        	   for(var i = 0 ;i < images.length ;i++){
			        		   $("#imageList").append("<div style='border:1px solid #ddd;padding:5px;'><a href='javascript:void(0);' class='img_remove' pid='"+images[i].IMG_ID+"'>이미지 삭제</a><img class='thumbnail' style='width:200px;height:200px;' src='/cm/file/image/"+images[i].IMG_ID+"/600"+"'></div>");
			        	   }
				        	   if(detail != null){
				        		   $('#ir1').summernote('code', detail.CONTENT);
				        		  $("#title").val(detail.TITLE);
				        	   }
			        	   }
			           });
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
