defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postDetailURL 		= $('#postDetailURL').val();
				this.postListURL 		= $('#postListURL').val();
				this.imageURL 			= $('#imageURL').val();
				this.noImageURL 		= $('#noImageURL').val();
				this.postListPageURL	= $("#postListPageURL").val();
				this.postUpdateURL 		= $("#postUpdateURL").val();
				this.postDeleteURL		= $("#postDeleteURL").val();
				// element
				// 게시 종류 전역 설정
				this.MAIN_TYPE 				= '108_110';
				this.$updateBtn = $("#updateBtn");
				this.$listBtn = $("#listBtn");
				this.$deleteBtn = $("#deleteBtn");
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$deleteBtn.on("click", function(){
					if(confirm("삭제하시겠습니까?")){
						jQuery.ajax({
					           type:"POST",
					           url: _self.postDeleteURL,
					           data : { POST_ID : $("#postId").val()},
					           dataType:"json",
					           success : function(data) 
					           {	
					        	   if(data.result == "success"){
					        		   alert("삭제되었습니다.");
					        		   location.href= _self.postListPageURL;
					        	   }else{
					        		   alert("오류가 발생하였습니다.");
					        		   return;
					        	   }
					           }
						});
					}
				});
				
				_self.$updateBtn.on("click", function(){
					location.href=_self.postUpdateURL+"?POST_ID="+ $("#postId").val();
				});
				
				_self.$listBtn.on("click", function(){
					location.href=_self.postListPageURL;
				})
			},
			'pageInit'		: function() {
				var _self = this;
				
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
//				_self.pageInit();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
