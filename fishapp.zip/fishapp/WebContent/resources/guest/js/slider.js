$(document).ready(function(){

var slide1 = $('.slider_wide').bxSlider({
    auto:true, //자동플레이 유무
  	stopAutoOnClick:true,
    pause:5000, //자동플레이 머무는 시간
    speed:100, //슬라이드 이동속도
    slideWidth:520, //슬라이드 1개의 가로사이즈 px
    // minSlides:2, //최소 보여질 슬라이드 갯수
    // maxSlides:4, // 최대 보여질 슬라이드 갯수
    moveSlides:1, // 슬라이드 이동 갯수
    wrapperClass:'slide_box', //부모클래스명 재정의
  });
});
