defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._codeCateURL = $('#codeCateURL').val();
				this._codeListURL = $('#codeListURL').val();
				this._codeSubListURL = $('#codeSubListURL').val();
				this._codeInsertURL = $('#codeInsertURL').val();
				this._codeUpdateURL = $('#codeUpdateURL').val();
				this._codeDeleteURL = $('#codeDeleteURL').val();
				
				// element
				this.$listContainer = $('#codeListContainer');
				this.$listTemplate = $('#codeListTemplate');
				this.$detailForm = $('#codeDetailForm');
				this.$codeCateSel = $('#searchCodeCategorySel');

				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				
				// form
				this.$srchForm = $('#codeSearchForm');
				this.$insertForm = $('#codeInsertForm');
				this.$updateForm = $('#codeUpdateForm');
				
				// static variable
				this.selectCodeId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				// 코드 목록 조회
				_self.$srchForm.submit(function() {
					_self.getCodeList( '1', {'CODE_CATE' : _self.$codeCateSel.find('option:selected').val()} );
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertCode();
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData( _self.selectCodeId, 'CODE' ) );
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateCode();
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteCode();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
				
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectCodeId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData( _self.selectCodeId, 'CODE' ));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 코드 카테고리 목록 조회
			'getCodeList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '5'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._codeListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('codeList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.codeList, 'CODE', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			$row.find('.codeCateLink').click( function( e ) {
				    				// 코드관리로 이동
				    				Bplat.view.loadPage( _self._codeCateURL, {
				    					'CODE_CATE' : data.CODE_CATE
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    			$row.find('.parentCodeLink').click( function( e ) {
									// 코드목록 조회
									_self.getCodeList( '1', {'CODE' : data.PARENT_CODE} );
									_self.$codeCateSel.val('');
				    				e.stopPropagation();
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#codeListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getCodeList( page, {'CODE_CATE' : _self.$codeCateSel.find('option:selected').val()} );
								}
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.codeList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 코드 등록
			'insertCode' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var param = {
						 'CODE' : $insertForm.find('[data-key=CODE]').val()
						,'CODE_CATE' : $insertForm.find('[data-type=CODE_CATE] option:selected').val()
						,'VALUE' : $insertForm.find('[data-key=VALUE]').val()
						,'DESCR' : $insertForm.find('[data-key=DESCR]').val()
						,'USE_YN' : $insertForm.find('[data-type=USE_YN] option:selected').val()
						,'PARENT_CODE' : $insertForm.find('[data-key=PARENT_CODE]').val()
				};
				$.ajax({
					 url : _self._codeInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			// 코드 수정
			'updateCode' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var param = {
					 'CODE' : _self.selectCodeId
					,'CODE_CATE' : $updateForm.find('[data-key=CODE_CATE]').val()
					,'VALUE' : $updateForm.find('[data-key=VALUE]').val()
					,'DESCR' : $updateForm.find('[data-key=DESCR]').val()
					,'USE_YN' : $updateForm.find('[data-type=USE_YN] option:selected').val()
					,'PARENT_CODE' : $updateForm.find('[data-key=PARENT_CODE]').val()
				};
				$.ajax({
					 url : _self._codeUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			// 코드 삭제
			'deleteCode' : function() {
				var _self = this;
				$.ajax({
					 url : _self._codeDeleteURL
					,type : 'POST'
					,data : {
						 'CODE' : _self.selectCodeId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 하위코드검색
					_self.subCodeListSearch( data.CODE );
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=CODE_CATE] option:eq(0)').attr('selected',true);
					$insertForm.find('[data-type=USE_YN] option:eq(0)').attr('selected',true);
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.find('[data-type=USE_YN]').val(data['USE_YN']);
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			// 코드 상세데이터 내 하위코드 목록 조회
			'subCodeListSearch' : function( code ) {
				var _self = this;
				$.ajax({
					 url : _self._codeSubListURL
					,type : 'POST'
					,data : {
						'CODE' : code
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('subList') ) {
				    		var subList = data.subList;
				    		var str = "";
				    		for(var i=0,iSize=subList.length;i<iSize;i++) {
				    			var data = subList[i];
				    			str = str + data.CODE + '(' + data.VALUE + ')';
				    			if( i < (iSize-1) ) str = str + ', ';
				    		}
				    		_self.$detailForm.find('[data-type=subList]').text(str);
				    		_self.$detailForm.show();
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[code_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('CODE_CATE') ) {
					var codeCate = p_param.CODE_CATE;
					// 코드목록 조회
					this.getCodeList( '1', {'CODE_CATE' : codeCate} );
					this.$codeCateSel.val( codeCate );
				} else {
					// 코드목록 조회
					this.getCodeList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[code_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[code_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[code_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[code_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[code_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[code_main] onDestroy Method' );
			}		
	  }
});