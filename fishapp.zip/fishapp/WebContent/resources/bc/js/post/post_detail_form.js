defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipURL 				= $('#shipURL').val();
				this._postMainURL	 		= $('#postMainURL').val();
				this._postDetailURL	 		= $('#postDetailURL').val();
				this._postDeleteURL	 		= $('#postDeleteURL').val();
				this._postUpdateFormURL 	= $('#postUpdateFormURL').val();
				// element
				this.$postDetailContainer	= $('#postDetailContainer');
				this.$detailImageContainer	= $('#detailImageContainer');
				this.$searchShipSel 		= $('#searchShipSel');
				this.$modifyBtn				= $('#modifyBtn');
				this.$deleteBtn 			= $('#deleteBtn');
				this.$prevBtn 				= $('#prevBtn');
				// 게시 종류 전역 설정
				this.RESERVE_TYPE 			= '108_120';
				this.fileList = null;
				// 페이지 url
				this.pageUrl				= '';
				// 파라미터 값
				this.selectPostId 			= $('#postId').val();
				this.menuType				= $('#menuType').val();
				/*this.page					= $('#page').val();
				this.itemCnt				= $('#itemCnt').val();
				this.searchType				= $('#searchType').val();
				this.word					= $('#word').val();*/
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 수정
				_self.$modifyBtn.click( function(){
					param = { 'url'	: _self.pageUrl };
					Bplat.view.loadPage( 
						_self._postUpdateFormURL 
						+ '?postId=' + _self.selectPostId
						+ '&menuType=' + _self.menuType
						, param 
					);
					// url 방식
					/*Bplat.view.loadPage( 
						_self._postUpdateFormURL
						+ '?postId=' + _self.selectPostId + ''
						+ '&page=' + _self.page + ''
				 		+ '&itemCnt=' + _self.itemCnt + ''
						+ '&menuType=' + _self.menuType + ''
						+ '&searchType=' + _self.searchType + ''
					);*/
					return false;
				});
				
				// 삭제
				_self.$deleteBtn.click( function(){
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deletePost();
				});
				
				// 목록
				_self.$prevBtn.click( function(){
					// 이전 페이지 url이 있을경우
					if ( '' == _self.pageUrl ) {
						Bplat.view.loadPage( _self._postMainURL );
					}else{
						Bplat.view.loadPage( _self.pageUrl );
					}
					return false;
				});
				
				// 선박선택시
				_self.$searchShipSel.bind( "change", function() {
					_self.getPostList('1');
				});
				
			},
			// 공지사항 상세 정보
			'deletePost' : function() {
				var _self = this;
				var defaultParam = {
					 'POST_ID' 		: _self.selectPostId
				};
				$.extend( defaultParam );
				$.ajax({
					 url : _self._postDeleteURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
			    		alert('삭제 되었습니다');
			    		// 메인으로 이동
			    		Bplat.view.loadPage( _self._postMainURL );
						return false;
				    }
				});
			},
			// 공지사항 상세 정보
			'getDetailList' : function( param ) {
				var _self = this;
				var defaultParam = {
					 'POST_ID' 		: _self.selectPostId
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._postDetailURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if(data.hasOwnProperty('detailPost')){
				    		var detailList = data.detailPost;
				    		// 예약안내 상세일 경우
				    		if ( detailList.TYPE_CD == _self.RESERVE_TYPE ) {
								_self.$detailImageContainer.hide();
							}
				    		// 이미지 리스트
				    		var imageList = data.imageList;
				    		if( data.hasOwnProperty('imageList') ) {
				    			var $imgContainer = _self.$postDetailContainer.find('[data-type=IMAGE]');
				    	 		jdg.util.createImgList( imageList, $imgContainer);
				    		}
				    		// 상세 리스트 
				    		jdg.util.detailDataSetting( _self.$postDetailContainer, detailList );
				    		_self.$postDetailContainer.show();
				    	}
				    		
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 이전 페이지 Url
				if ( undefined != p_param.url ) {
					this.pageUrl = p_param.url;
				}
				this.getDetailList( p_param );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[biz_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[biz_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[biz_main] onDestroy Method' );
			}		
	  }
});