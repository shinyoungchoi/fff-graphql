defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipURL 				= $('#shipURL').val();
				this._postMainURL	 		= $('#postMainURL').val();
				this._postUpdateURL 		= $('#postUpdateURL').val();
				this._postDetailURL	 		= $('#postDetailURL').val();
				this._postDetailFormURL 	= $('#postDetailFormURL').val();
				this._imgUploadMultiURL 	= $('#imgUploadMultiURL').val();
				// element
				this.$postUpdateForm	 	= $('#postUpdateForm');
				this.$updateListContainer	= $('#updateListContainer');
				this.$imageListContainer 	= $('#imageListContainer');
				this.$searchShipSel 		= $('#searchShipSel');
				this.$updateBtn 			= $('#updateBtn');
				this.$cancelBtn 			= $('#cancelBtn');
				// 게시 종류 전역 설정
				this.RESERVE_TYPE 			= '108_120';
				this.MAIN_TYPE 				= '108_110';
				this.fileList = null;
				this.postId					= $('#postId').val();
				// 페이지 url
				this.pageUrl				= '';
				// 파라미터 값
				this.menuType				= $('#menuType').val();
				/*this.page					= $('#page').val();
				this.itemCnt				= $('#itemCnt').val();
				this.searchType				= $('#searchType').val();
				this.word					= $('#word').val();*/
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 수정
				_self.$updateBtn.click( function(){
					_self.updateList();
					return false;
				});
				
				// 취소
				_self.$cancelBtn.click( function(){
					// 상세 이동
					param = { 'url'	: _self.pageUrl };
					Bplat.view.loadPage( 
						_self._postDetailFormURL 
						+ '?postId=' +  _self.postId 
						+ '&menuType=' + _self.menuType
						, param
					);
					/*Bplat.view.loadPage( 
						_self._postDetailFormURL
						+ '?postId=' +  _self.postId + ''
						+ '&page=' + _self.page + ''
				 		+ '&itemCnt=' + _self.itemCnt + ''
						+ '&menuType=' + _self.menuType + ''
						+ '&searchType=' + _self.searchType + ''
						+ '&word=' + _self.word + ''
					);*/
					return false;
				});
				
				// 선박선택시
				_self.$searchShipSel.bind( "change", function() {
				});
				
			},
			// 게시물 수정
			'updateList' : function(){
				var _self = this;
				var $updateForm = _self.$updateListContainer;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 파일등록
				var updateParam = {
						  'POST_ID'   : _self.postId
						, 'TYPE_CD'   : $updateForm.find('[data-key=TYPE_CD]').attr( 'typeCd' )
						, 'SHIP_ID'   : _self.$searchShipSel.val()
						, 'TITLE'     : $updateForm.find('[data-key=TITLE]').val()
						, 'CONTENT'   : $updateForm.find('[data-key=CONTENT]').val()
						, 'IMG_ID'    : JSON.stringify( _self.fileList.getFileList() )
				};
				$.ajax({
					 url : _self._postUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		param = { 'url'	: _self.pageUrl };
				    		Bplat.view.loadPage( 
			    				_self._postDetailFormURL + '?postId=' +  _self.postId + '&menuType=' + _self.menuType, param
							);
							return false;
				    	}
				    }
				});
				return false;
			},
			// 상세 정보
			'getUpdateList' : function( param ) {
				var _self = this;
				var $updateForm = _self.$postUpdateForm;
				var defaultParam = {
					 'POST_ID' 		: _self.postId
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._postDetailURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if(data.hasOwnProperty('detailPost')){
				    		var detailList = data.detailPost;
				    		// 컨텐츠 내용중 <br> 에 대한 문자열은 \n 으로 변환
							var content = data.detailPost.CONTENT;
							if( null != content && content.indexOf('<br>') ){
								content = content.replace(/<br>/gi, '\n');
								data.detailPost.CONTENT = content;
							}
							var imageList = data.imageList;
							for ( var i = 0; nMax=imageList.length, i < nMax; i++) {
								if( null != imageList[i].CONTENT && imageList[i].CONTENT.indexOf('<br>') ){
									imageList[i].CONTENT = imageList[i].CONTENT.replace(/<br>/gi, '\n'); 
								}
							}
							// 수정데이터셋팅
							jdg.util.detailDataSetting( $updateForm, data.detailPost );
							// 파일리스트 초기화
							_self.fileList = new component.FileList({
								 'id' 				: $updateForm.attr('id')
								,'container' 		: $updateForm.find('[data-type=IMAGE_LIST]')
							});
							_self.fileList.init(data.imageList);
							// 공지타입 설정
							_self.updateInit();
				    	}
				    }
				});
			},
			// 공지타입 설정
			'updateInit' : function() {
				var _self = this;
				// 선박 목록 설정
				if ( _self.$searchShipSel.find('option').length == 1 ) {
					_self.$searchShipSel.hide();
				}
				// 메뉴타입에 값 설정
				var typeCd = _self.$updateListContainer.find('[data-key="TYPE_CD"]');
				if ( 'post' == _self.menuType ) {
					_self.$imageListContainer.show();
					typeCd.text( '메인공지' );
					typeCd.attr( 'typeCd', _self.MAIN_TYPE );
				}else{
					_self.$imageListContainer.hide();
					typeCd.text( '예약안내' );
					typeCd.attr( 'typeCd', _self.RESERVE_TYPE );
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 이전 페이지 Url
				if ( undefined != p_param.url ) {
					this.pageUrl = p_param.url;
				}
				// 수정정보 가져오기
				this.getUpdateList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[biz_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[biz_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[biz_main] onDestroy Method' );
			}		
	  }
});