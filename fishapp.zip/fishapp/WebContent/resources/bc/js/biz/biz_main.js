defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizDetailURL = $('#bizDetailURL').val();
				this._bizUpdateFormURL = $('#bizUpdateFormURL').val();
				this._context = $('#context').val();
				this._state = $('#state').val();
				this._shipId = $('#shipId').val();
				
				// element
				this.$mfyBtn = $('#mfyBtn');
				this.$emailBccYN = $('#emailBccYN');

				// form
				this.$bizDetailForm = $('#bizDetailForm');
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$mfyBtn.click(function(){
					Bplat.view.loadPage( _self._bizUpdateFormURL );
				});
			},
			//업체 정보 가져오기
			'getBizDetail' : function() {
				var _self = this;
				var $shopImgContainer = _self.$bizDetailForm.find('[data-type=SHOP_IMG_ID]').parent();
				
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('bizDetail') ) {
				    		var emailBccYN = data.bizDetail.EMAIL_BCC_YN;
				    		jdg.util.detailDataSetting( _self.$bizDetailForm, data.bizDetail );
				    		
				    		_self.setText();
				    		
				    		//이미지 셋팅
				    		if(data.bizDetail.ADDR_IMG_ID != null && data.bizDetail.ADDR_IMG_ID != undefined){//이미지가 있을때
				    			var leftImgSrc = _self._context + _self._state + _self._shipId + '/file/image/';
					    		_self.$bizDetailForm.find('[data-type=ADDR_IMG_ID]').attr('src' , leftImgSrc +data.bizDetail.ADDR_IMG_ID + '/155');
					    		_self.$bizDetailForm.find('[data-type=ADDR_IMG_ID]').click(function(){
					    			jdg.util.openImgPopup(leftImgSrc +data.bizDetail.ADDR_IMG_ID, data.bizDetail.ADDR_IMG_WIDTH, data.bizDetail.ADDR_IMG_HEIGHT);
					    		});
					    		_self.$bizDetailForm.find('[data-type=ADDR_IMG_ID]').css('cursor','pointer');//마우스 커서 셋팅
				    		}else{//이미지가 없을때
				    			_self.$bizDetailForm.find('[data-type=ADDR_IMG_ID]').remove();
				    		}
				    		
				    		if(data.bizDetail.SHOP_IMG_ID != null && data.bizDetail.SHOP_IMG_ID != undefined){//이미지가 있을때
				    			leftImgSrc = _self._context + _self._state + _self._shipId + '/file/image/';
					    		_self.$bizDetailForm.find('[data-type=SHOP_IMG_ID]').attr('src' , leftImgSrc +data.bizDetail.SHOP_IMG_ID + '/155');
					    		_self.$bizDetailForm.find('[data-type=SHOP_IMG_ID]').click(function(){
					    			jdg.util.openImgPopup(leftImgSrc +data.bizDetail.SHOP_IMG_ID , data.bizDetail.SHOP_IMG_WIDTH, data.bizDetail.SHOP_IMG_HEIGHT);
					    		});
					    		_self.$bizDetailForm.find('[data-type=SHOP_IMG_ID]').css('cursor','pointer');//마우스 커서 셋팅
				    		}else{//이미지가 없을때
				    			_self.$bizDetailForm.find('[data-type=SHOP_IMG_ID]').remove();
				    		}
				    		
				    		// bcc 여부 셋팅
				    		if( emailBccYN != undefined && emailBccYN != null && emailBccYN != '' ){
				    			_self.$emailBccYN.text(emailBccYN == 'Y' ? '예' : '아니오');
				    		}else{	// bcc 여부 값이 없을경우
				    			_self.$emailBccYN.text('아니오');
				    		}
			    			
				    	}
				    }
				});
			},
			//각종 text 셋팅
			'setText' : function() {
				var _self = this;
				
				var $bizRegNo = _self.$bizDetailForm.find('[data-key=BIZ_REG_NO]');
				var $telMobile = _self.$bizDetailForm.find('[data-key=TEL_MOBILE]');
				var $telEtc = _self.$bizDetailForm.find('[data-key=TEL_ETC]');
				var $mapUrl = _self.$bizDetailForm.find('[data-key=MAP_URL]');
				var $shopTel = _self.$bizDetailForm.find('[data-key=SHOP_TEL]');
				var $shopTelEtc = _self.$bizDetailForm.find('[data-key=SHOP_TEL_ETC]');
				
				$bizRegNo.text($bizRegNo.text().replace(/([0-9]{3})([0-9]{2})([0-9]{5})/, "$1-$2-$3"));
				$telMobile.text(jdg.util.setPhonNumber($telMobile.text()));
				$telEtc.text(jdg.util.setPhonNumber($telEtc.text()));
				$mapUrl.html("<a href='" + $mapUrl.text() + "' target='_blank'>"+ $mapUrl.text() +"</a>");
				$shopTel.text(jdg.util.setPhonNumber($shopTel.text()));
				$shopTelEtc.text(jdg.util.setPhonNumber($shopTelEtc.text()));
						
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getBizDetail();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
