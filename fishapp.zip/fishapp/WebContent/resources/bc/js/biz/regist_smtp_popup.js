defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._testMailURL = $('#testMailURL').val();
				this._bizDetailURL = $('#bizDetailURL').val();
				
				// element
				this.$mailServerList = $('#mailServerList');
				this.$smtpTestBtn = $('#smtpTestBtn');
				this.$smtpUser = $('#SMTP_USER');
				this.$smtpPass = $('#SMTP_PASS');
				this.$smtpHost = $('#SMTP_HOST');
				this.$smtpPort = $('#SMTP_PORT');
				this.$smtpTlsYN = $('#SMTP_TLS_YN');
				this.$smtpSslYN = $('#SMTP_SSL_YN');
				this.$mailServerList = $('#mailServerList');
				this.$smtpMfyBtn = $('#smtpMfyBtn');
				this.$smtpCancelBtn = $('#smtpCancelBtn');
				this.$server = $('#server');
				this.$resultMsg = $('#resultMsg');
				this.$wrapperDiv = $('#wrapperDiv');
				
				// form
				this.$smtpForm = $('#smtpForm');
				
				// static variable
				this.mailServerList = {};
				this.spinner = jdg.util.spinnerObj($('#wrapperDiv'));
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 테스트 버튼
				_self.$smtpTestBtn.click(function(){
					_self.spinner.start();
					_self.getTestSmtp();
					return false;
				});
				// 수정/등록 버튼
				_self.$smtpMfyBtn.click(function(){
					var smtpUser = '';
					if( _self.$mailServerList.val() == 'self' ){
						smtpUser = _self.$smtpUser.val() + '@' + _self.$server.val();
					} else {
						smtpUser = _self.$smtpUser.val() + '@'+ _self.$mailServerList.find('option:selected').text();
					}
					smtpUser = ($.trim(_self.$smtpUser.val()).length > 0 ? smtpUser : ''); 
					var param ={
						 'SMTP_USER' : smtpUser 
						,'SMTP_PASS' : _self.$smtpPass.val()
						,'SMTP_HOST' : _self.$smtpHost.val()
						,'SMTP_PORT' : _self.$smtpPort.val()
						,'SMTP_TLS_YN' : (_self.$smtpTlsYN.is(':checked') == true ? 'Y' : 'N')
						,'SMTP_SSL_YN' : (_self.$smtpSslYN.is(':checked') == true ? 'Y' : 'N')
					};
					opener.Bplat.view.closePopup({'smtpInfo' : param});
					window.close();
				});
				// 닫기 버튼
				_self.$smtpCancelBtn.click(function(){
					window.close();
				});
				
				// 셀렉트 박스 변경 이벤트 
				_self.$mailServerList.change(function(){
					var key = $(this).val();
					// 비밀번호 초기화
				    _self.$smtpPass.val('');
				    
				    // 호스트 초기화
				    _self.$smtpHost.val('');
				    
				    // 포트 초기화
				    _self.$smtpPort.val('');
				    
				    // TLS/SSL 초기화
				    _self.$smtpTlsYN.attr('checked', false);
				    _self.$smtpSslYN.attr('checked', false);
				    
					if( key == 'self' ){
						_self.$server.show();
					} else{
					    // 호스트 
					    _self.$smtpHost.val(_self.mailServerList[key].host);
						
					    // 기본포트
					    _self.$smtpPort.val(_self.mailServerList[key].SSLport);
					    // SSL 지정
					    _self.$smtpSslYN.attr('checked', true);
					    
					    _self.$server.hide();
					}
				});
				
			},
			// 사용자 smtp 정보 로드 하기
			'getBizDetail' : function() {
				var _self = this;
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('bizDetail') ) {
				    		jdg.util.detailDataSetting( _self.$smtpForm, data.bizDetail );
				    		// 계정 정보 셋팅
				    		var user = data.bizDetail.SMTP_USER;
				    		var tls = data.bizDetail.SMTP_TLS_YN;
				    		var ssl = data.bizDetail.SMTP_SSL_YN;
				    		var mailNotieYN = data.bizDetail.EMAIL_BCC_YN;
				    		if( user != undefined && user != null && user != '' ){
				    			_self.$smtpUser.val(user.split('@')[0]);
				    			var findKey = false;
				    			$.each(mailServerList, function(key, item){
				    				if( item.text == user.split('@')[1] )
				    					findKey = true;
				    			});
				    			if(findKey){
				    				_self.$mailServerList.find(":contains('"+ user.split('@')[1] +"')").attr('selected', true);
				    			} else {
				    				_self.$mailServerList.val('self');
				    				_self.$server.val(user.split('@')[1]).show();
				    			}
				    		}
				    		
				    		// 비밀번호 셋팅
				    		_self.$smtpPass.val(data.bizDetail.SMTP_PASS);
				    		
				    		// 체크 박스 셋팅
				    		if( tls != undefined && tls != null && tls != '' ){
				    			if( tls == 'Y' ){
				    				_self.$smtpTlsYN.attr('checked', true);
				    			}
				    		}
				    		if( ssl != undefined && ssl != null && ssl != '' ){
				    			if( ssl == 'Y' ){
				    				_self.$smtpSslYN.attr('checked', true);
				    			}
				    		}
				    	}
				    }
				});
			},
			// smtp 정보 테스트 하기
			'getTestSmtp' : function() {
				var _self = this;
				var smtpUser = '';
				_self.$resultMsg.parent().hide();
				if( _self.$mailServerList.val() == 'self' ){
					smtpUser = _self.$smtpUser.val() + '@' + _self.$server.val();
				} else {
					smtpUser = _self.$smtpUser.val() + '@'+ _self.$mailServerList.find('option:selected').text();
				}
				var param = 
				{
					 SMTP_USER : smtpUser  
					,SMTP_PASS : _self.$smtpPass.val()
					,RECV_EMAIL : _self.$smtpUser.val() + '@'+ _self.$mailServerList.find('option:selected').text()
					,SMTP_HOST : _self.$smtpHost.val()
					,SMTP_PORT : _self.$smtpPort.val()
					,SMTP_TLS_YN : (_self.$smtpTlsYN.is(':checked') == true ? 'Y' : 'N')
					,SMTP_SSL_YN : (_self.$smtpSslYN.is(':checked') == true ? 'Y' : 'N')
					,TITLE : '피쉬앱 이메일인증 테스트 메일'
					,CONTENT : '이메일 인증용 테스트 메일'
				};
				
				$.ajax({
					 url : _self._testMailURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	_self.$resultMsg.text('성공').parent().css('color','green').show();
				    	_self.spinner.stop();
				    }
				    ,error : function( error ){
				    	_self.$resultMsg.text('실패').parent().css('color','red').show();
				    	_self.spinner.stop();
				    }
				});
			},
			//각종 text 셋팅
			'setServerSel' : function() {
				var _self = this;
				var mailServerList = _self.mailServerList;
				var $mailServerList = _self.$mailServerList; 
				mailServerList.naver = {
					host : 'smtp.naver.com'
				   ,SSLport : '465'
				   ,TLSport : '587'
				   ,serverName : 'naver.com'
				};
				mailServerList.google = {
					host : 'smtp.gmail.com'
					,SSLport : '465'
					,TLSport : '587'
					,serverName : 'gmail.com'
				};
				mailServerList.daum = {
					host : 'smtp.daum.net'
					,SSLport : '465'
					,serverName : 'daum.net'
				};
				mailServerList.yahoo = {
					host : 'smtp.mail.yahoo.com'
					,SSLport : '465'
					,TLSport : '587'
					,serverName : 'yahoo.com'
				};
				mailServerList.nate = {
					host : 'smtp.mail.nate.com'
					,SSLport : '465'
					,TLSport : '25'
					,serverName : 'nate.net'
				};
				$.each(mailServerList, function(key, item){
					$mailServerList.append('<option value='+ key +'>'+ item.serverName +'</option>');
				});
				$mailServerList.append('<option value="self">직접입력</option>');
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.setServerSel();
				this.getBizDetail();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
