defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizMainURL = $('#bizMainURL').val();
				this._bizDetailURL = $('#bizDetailURL').val();
				this._bizUpdateURL = $('#bizUpdateURL').val();
				this._registSmtpURL = $('#registSmtpURL').val();
				
				// element
				this.$saveBtn = $('#saveBtn');
				this.$cancelBtn = $('#cancelBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$smtpInfoWrapper = $('#smtpInfoWrapper');
				this.$emailBccYN = $('[name=emailBccYN]');
				this.$vrBankingYN = $('[name=vrBankingYN]');
				
				// form
				this.$updateForm = $('#updateForm');
				
				// static variable
				this.beforeData = {};
				this.addrFileList = null;
				this.shopFileList = null;
				
				this.detailData = {};
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$saveBtn.click(function(){
					_self.updateBiz();
				});
				
				// SMTP 수정 버튼
				_self.$mfyBtn.click(function(){
					Bplat.view.openPopup({
						 'url' : _self._registSmtpURL
						,'width' : 435
						,'height' : 280
					}, 'regist_smtp_popup');
					return false;
				});
				
				_self.$cancelBtn.click(function(){
					Bplat.view.loadPage( _self._bizMainURL );
				});
				
			},
			//업체 정보 가져오기
			'getBizDetail' : function() {
				var _self = this;
				var $addrImgContainer = _self.$updateForm.find('[data-type=ADDR_IMG_ID]').parent();
				var $shopImgContainer = _self.$updateForm.find('[data-type=SHOP_IMG_ID]').parent();
				
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('bizDetail') ) {
				    		var emailBccYN = data.bizDetail.EMAIL_BCC_YN;
				    		var vrBankingYN = data.bizDetail.VR_BANKING_YN;
				    		
				    		_self.beforeData = data.bizDetail;
				    		
				    		jdg.util.detailDataSetting( _self.$updateForm, data.bizDetail );
				    		_self.detailData = data.bizDetail;
				    		
				    		_self.setText();
							
							jdg.util.setRegNo( _self.$updateForm.find('[data-key=BIZ_REG_NO_1]'), _self.$updateForm.find('[data-key=BIZ_REG_NO_2]'), _self.$updateForm.find('[data-key=BIZ_REG_NO_3]'), data.bizDetail.BIZ_REG_NO );
							jdg.util.setTelNum( _self.$updateForm.find('[data-key=TEL_MOBILE_1]'), _self.$updateForm.find('[data-key=TEL_MOBILE_2]'), _self.$updateForm.find('[data-key=TEL_MOBILE_3]'), data.bizDetail.TEL_MOBILE );
							jdg.util.setTelNum( _self.$updateForm.find('[data-key=TEL_ETC_1]'), _self.$updateForm.find('[data-key=TEL_ETC_2]'), _self.$updateForm.find('[data-key=TEL_ETC_3]'), data.bizDetail.TEL_ETC );
				    		
							// 파일리스트 초기화
							_self.addrFileList = new component.File({
								 'id' : 'UPDATE_ADDR_IMG_ID'
								,'container' : $('#UPDATE_ADDR_IMG_ID')
							});
							_self.addrFileList.init( data.bizDetail.ADDR_IMG_ID ? data.bizDetail : null );
							
							_self.shopFileList = new component.File({
								 'id' : 'UPDATE_SHOP_IMG_ID'
								,'container' : $('#UPDATE_SHOP_IMG_ID')
							});
							_self.shopFileList.init( data.bizDetail.SHOP_IMG_ID ? data.bizDetail : null );
							
							// bcc 여부 셋팅
				    		if( emailBccYN != undefined && emailBccYN != null && emailBccYN != '' ){
				    			_self.$emailBccYN.filter('[value='+emailBccYN+']').attr('checked', 'checked');
				    		}else{	// bcc 여부 값이 없을경우
				    			_self.$emailBccYN.filter('[value="N"]').attr('checked', 'checked');
				    		}
				    		
							// 가상계좌 여부 셋팅
				    		if( vrBankingYN != undefined && vrBankingYN != null && emailBccYN != '' ){
				    			_self.$vrBankingYN.filter('[value='+vrBankingYN+']').attr('checked', 'checked');
				    		}else{	// bcc 여부 값이 없을경우
				    			_self.$vrBankingYN.filter('[value="N"]').attr('checked', 'checked');
				    		}
				    		
				    	}
				    }
				});
			},
			//업체 정보 수정하기
			'updateBiz' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 관리자
				var mgrMemId = $updateForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId');
				var beforeMgrMemId = _self.beforeData.MGR_MEM_ID;
				// IMG_ID
				var addrImgId = _self.addrFileList.getFile();
				var shopImgId = _self.shopFileList.getFile();
				var beforeAddrImgId = _self.beforeData.ADDR_IMG_ID ? _self.beforeData.ADDR_IMG_ID : '';
				var beforeShopImgId = _self.beforeData.SHOP_IMG_ID ? _self.beforeData.SHOP_IMG_ID : '';
				
				// 사업체 수정
				var updateParam = {
					  'BIZ_ID' : _self.beforeData.BIZ_ID
					, 'BIZ_NAME' : $updateForm.find('[data-key=BIZ_NAME]').val()
					, 'CEO_NAME' : $updateForm.find('[data-key=CEO_NAME]').val()
					, 'MGR_MEM_ID' : _self.beforeData.MGR_MEM_ID
					, 'BEFORE_MGR_MEM_ID' : (beforeMgrMemId === mgrMemId || !beforeMgrMemId) ? "" : beforeMgrMemId
					, 'BIZ_REG_NO' : $updateForm.find('[data-key=BIZ_REG_NO_1]').val() + '-' + $updateForm.find('[data-key=BIZ_REG_NO_2]').val() + '-' + $updateForm.find('[data-key=BIZ_REG_NO_3]').val()
					, 'TEL_MOBILE' : $updateForm.find('[data-key=TEL_MOBILE_1]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_2]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_3]').val()
					, 'TEL_ETC' : $updateForm.find('[data-key=TEL_ETC_1]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_2]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_3]').val()
					, 'ADDR' : $updateForm.find('[data-key=ADDR]').val()
					, 'ADDR_DESC' : $updateForm.find('[data-key=ADDR_DESC]').val()
					, 'ADDR_IMG_ID' : (addrImgId ?  addrImgId : '')
					, 'BEFORE_ADDR_IMG_ID' : (beforeAddrImgId === addrImgId || !beforeAddrImgId) ? "" : beforeAddrImgId
					, 'SHOP_DESC' : $updateForm.find('[data-key=SHOP_DESC]').val()
					, 'SHOP_TEL' : $updateForm.find('[data-key=SHOP_TEL]').val()
					, 'SHOP_TEL_ETC' : $updateForm.find('[data-key=SHOP_TEL_ETC]').val()
					, 'SHOP_IMG_ID' : (shopImgId ?  shopImgId : '')
					, 'BEFORE_SHOP_IMG_ID' : (beforeShopImgId === shopImgId || !beforeShopImgId) ? "" : beforeShopImgId
					, 'MAP_URL' : $updateForm.find('[data-key=MAP_URL]').val()
					, 'BANK_CD' : $updateForm.find('[data-key=BANK_CD]').val()
					, 'BANK_ACCN' : $updateForm.find('[data-key=BANK_ACCN]').val()
					, 'BANK_HOLDER' : $updateForm.find('[data-key=BANK_HOLDER]').val()
					, 'VR_BANKING_YN' : _self.$vrBankingYN.filter(':checked').val()
					, 'PORT_CD' : $updateForm.find('[data-key=PORT_CD]').val()
					
					, 'SMTP_USER' : $updateForm.find('[data-key=SMTP_USER]').text()
					, 'SMTP_PASS' : $updateForm.find('[data-key=SMTP_PASS]').val()
					, 'SMTP_HOST' : $updateForm.find('[data-key=SMTP_HOST]').text()
					, 'SMTP_PORT' : $updateForm.find('[data-key=SMTP_PORT]').text()
					, 'SMTP_SSL_YN' : $updateForm.find('[data-key=SMTP_SSL_YN]').text()
					, 'SMTP_TLS_YN' : $updateForm.find('[data-key=SMTP_TLS_YN]').text()
					, 'EMAIL_BCC_YN' : _self.$emailBccYN.filter(':checked').val()
				};
				$.ajax({
					 url : _self._bizUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		Bplat.view.loadPage( _self._bizMainURL );
				    	}
				    }
				});
			},
			//각종 text 셋팅
			'setText' : function() {
				var _self = this;
				
				var $bizRegNo = _self.$updateForm.find('[data-key=BIZ_REG_NO]');
				
				$bizRegNo.text($bizRegNo.text().replace(/([0-9]{3})([0-9]{2})([0-9]{5})/, "$1-$2-$3"));
			},
			// 팝업을 닫은후 smtp 정보 셋
			'setSmtpData' : function(smtpData){
				var _self = this;
				$.extend(_self.detailData, smtpData);
				jdg.util.detailDataSetting( _self.$updateForm, _self.detailData );
				_self.$smtpInfoWrapper.show();
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getBizDetail();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
				if( p_param.value.smtpInfo.SMTP_USER != '' ){
					this.setSmtpData( p_param.value.smtpInfo );
				} 
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
