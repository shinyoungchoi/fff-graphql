defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleURL = $('#scheduleURL').val();
				this._reserveManURL = $('#reserveManURL').val();
				this._reserveListURL = $('#reserveListURL').val();
				this._reserveDetailURL = $('#reserveDetailURL').val();
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._reserveUpdateURL = $('#reserveUpdateURL').val();
				this._reserveDeleteURL = $('#reserveDeleteURL').val();
				this._reserveManCntURL = $('#reserveManCntURL').val();
				this._reserveUpdateStatusURL = $('#reserveUpdateStatusURL').val();
				// element
				this.$listContainer = $('#reserveListContainer');
				this.$listTemplate = $('#reserveListTemplate');
				this.$detailForm = $('#reserveDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$updateStatusBtn300 = $('#updateStatusBtn300');
				this.$updateStatusBtn310 = $('#updateStatusBtn310');				
				this.$updateStatusBtn410 = $('#updateStatusBtn410');
				this.$updateStatusBtn420 = $('#updateStatusBtn420');
				this.$updateStatusBtn430 = $('#updateStatusBtn430');
				// form
				this.$srchForm = $('#reserveSearchForm');
				this.$insertForm = $('#reserveInsertForm');
				this.$updateForm = $('#reserveUpdateForm');
				// static variable
				this.selectReserveId = '';
				this.selectDetailData = {};
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 스케쥴 Select box 변경
				_self.$insertForm.find('[data-type=SCHD_ID]').change( function() {
					// 승선 인원 셋팅
					_self.reserveManSetting( $( this ).find('option:selected') );
				});
				
				// 예약인원 Select box 변경
				_self.$insertForm.find('[data-type=MAN_CNT]').change( function() {
					_self.totalCost( _self.$insertForm);
				});
				
				// 독선예약 체크박스 선택
				_self.$insertForm.find('[data-type=WHOLE_YN]').click( function(e) {
					var $this = $( this );
					var $manCnt = _self.$insertForm.find('[data-type=MAN_CNT]');
					var $totCost = _self.$insertForm.find('[data-key=TOT_COST]');
					if( $this.is(':checked') ) {
						// 비활성화
						$manCnt.find('option:last').attr('selected', true);
						$manCnt.attr('disabled', true);
						$totCost.addClass('jdg-disabled');
						$totCost.attr('readonly', true);
						// 독선요금 셋팅
						var feeWhole = _self.$insertForm.find('[data-type=SCHD_ID] option:selected').attr('feeWhole');
						if( '' != feeWhole ) $totCost.val( feeWhole );
						else _self.totalCost();
					} else {
						// 활성화
						$manCnt.attr('disabled', false);
						$totCost.removeClass('jdg-disabled');
						$totCost.attr('readonly', false);
						_self.totalCost();
					}
				});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 예약목록조회
					_self.getReserveList('1');
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertReserve();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectDetailData );
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateReserve();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 예약상태수정.
				_self.$updateStatusBtn300.click( function() {
					if( confirm('예약확정 상태로 수정하시겠습니까?') ){
						_self.updateReserveStatus('104_300');
					}
				});
				_self.$updateStatusBtn410.click( function() {
					if( confirm('예약취소 하시겠습니까?') ){
						_self.updateReserveStatus('104_410');
					}
				});
				_self.$updateStatusBtn420.click( function() {
					if( confirm('예약취소 하시겠습니까?') ){
						_self.updateReserveStatus('104_420');
					}
				});
				_self.$updateStatusBtn430.click( function() {
					if( confirm('환불완료 상태로 수정하시겠습니까?') ){
						_self.updateReserveStatus('104_430');
					}
				});
				_self.$updateStatusBtn310.click( function() {
					if( confirm('미입금 상태로 수정하시겠습니까?') ){
						_self.updateReserveStatus('104_310');
					}
				});				
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteReserve();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectReserveId = $tr.attr('rowKey');
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				// 예약 상세 조회
				$.ajax({
					 url : _self._reserveDetailURL
					,type : 'POST'
					,data : {'RSV_ID' : _self.selectReserveId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		_self.selectDetailData = detail;
							_self.selectFormShow('search', detail);
				    	}
				    }
				});

			},
			// 예약 인원 셋팅
			'reserveManSetting' : function( $schdOption ) {
				var _self = this;
				var $wholeYn = _self.$insertForm.find('[data-type=WHOLE_YN]');
				$wholeYn.attr('checked', false);
				// 출조 선택
				if( '' !== $schdOption.val() ) {
					// 현재 스케줄의 예약인원 체크
					$.ajax({
						 url : _self._reserveManCntURL
						,type : 'POST'
						,data : {'SCHD_ID' : $schdOption.val()}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('count') ){
					    		if( data.count == 0 )  $wholeYn.attr('disabled', false);
					    		else $wholeYn.attr('disabled', true);
					    	}
					    }
					});
					// 예약인원 설정
					_self.createOptionSelect( _self.$insertForm.find('[data-type=MAN_CNT]'), $schdOption.attr('psgrCnt') );
				} else {
					$wholeYn.attr('disabled', true);
					// 예약인원 설정
					_self.createOptionSelect( _self.$insertForm.find('[data-type=MAN_CNT]'), $schdOption.attr('psgrCnt'), true );
				}
			},
			// 예약가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt, _flag ) {
				var _self = this;
				$sel.empty();
				if( _flag ) $sel.append( $('<option value="">선택해주세요</option>') );
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
				// 예약금액 변경
				_self.totalCost();
			},
			// 예약인원 * 1인당 금액을 계산하여 예약금액을 자동셋팅
			'totalCost' : function() {
				var $form = this.$insertForm;
				var man = $form.find('[data-type=MAN_CNT] option:selected').val();
				var money = $form.find('[data-type=SCHD_ID] option:selected').attr('feeMan');
				var sum = man * money;
				if( !sum ) sum = 0;
				$form.find('[data-key=TOT_COST]').val( sum );
			},
			// 예약 목록 조회
			'getReserveList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '5'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._reserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('reserveList') ) {
				    		var reserveList = data.reserveList;
				    		$.each( reserveList, function(idx, data) {
				    			data.SCHD_DATE = jdg.util.replaceDate(data.SCHD_DATE);
				    		});
				    		// 리스트 초기화
				    		_self.list.createList( reserveList, 'RSV_ID', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			$row.find('.scheduleLink').click( function( e ) {
				    				// 출조관리로 이동
				    				Bplat.view.loadPage( _self._scheduleURL, {
				    					'SCHD_ID' : data.SCHD_ID
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#reserveListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getReserveList(page);
								}
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.reserveList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 예약등록
			'insertReserve' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var $schdIdOption = $insertForm.find('[data-type=SCHD_ID] option:selected');
				// 과거 출조일에 대한 체크
				var today = jdg.util.today().replaceAll('-','');
				var schdData = $schdIdOption.attr('schdDate').replaceAll('-','');
				if( today <= schdData ) {
					if(!confirm('과거 또는 오늘에 대한 예약 시도입니다. 계속하시겠습니까?')) {
						return false;
					}
				}
				var insertParam = {
					  'SCHD_ID' : $schdIdOption.val()
					, 'MEM_ID' : $insertForm.find('[data-type=MEM_ID]').text()
					, 'RSV_NAME' : $insertForm.find('[data-type=RSV_NAME]').val()
					, 'RSV_TEL' : $insertForm.find('[data-type=RSV_TEL]').val()
					, 'RSV_EMAIL' : $insertForm.find('[data-type=RSV_EMAIL]').val()
					, 'MAN_CNT' : $insertForm.find('[data-type=MAN_CNT] option:selected').val()
					, 'TOT_COST' : $insertForm.find('[data-key=TOT_COST]').val()
					, 'DEPOSIT_NAME' : $insertForm.find('[data-key=DEPOSIT_NAME]').val()
					, 'MEMO' : $insertForm.find('[data-key=MEMO]').val()
					, 'PSGR_CNT' : $schdIdOption.attr('psgrCnt')
					, 'WHOLE_YN' : 'N'
				};
				// 독선예약 여부 체크 
				if( $insertForm.find('[data-type=WHOLE_YN]').is(':checked') ) {
					insertParam.WHOLE_YN = 'Y';
				}
				$.ajax({
					 url : _self._reserveInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    	alert(data.error.userMessage);
				    }
				});
			},
			// 예약수정
			'updateReserve' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateParam = {
					  'RSV_ID' : _self.selectReserveId
					, 'RSV_NAME' : $updateForm.find('[data-key=RSV_NAME]').val()
					, 'RSV_TEL' : $updateForm.find('[data-key=RSV_TEL]').val()
					, 'RSV_EMAIL' : $updateForm.find('[data-key=RSV_EMAIL]').val()
					, 'DEPOSIT_NAME' : $updateForm.find('[data-key=DEPOSIT_NAME]').val()
					, 'MEMO' : $updateForm.find('[data-key=MEMO]').val()
				};
				$.ajax({
					 url : _self._reserveUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			//예약상태 수정
			'updateReserveStatus' : function( statusCd ) {
				var _self = this;
				var updateParam = {
					  'RSV_ID' : _self.selectReserveId
					, 'STATUS_CD' : statusCd
				};
				$.ajax({
					 url : _self._reserveUpdateStatusURL
					,type : 'POST'
					,data : updateParam
					,dataType : 'json'
					,success : function( data ){
						if( data.hasOwnProperty('success') ){
							if( data.success === false ){
								alert( data.error.userMessage );
								location.reload();
								return false;
							}
						}
						if( data.hasOwnProperty('result') && data.result > 0 ){
							alert( '수정 되었습니다.' );
							location.reload();
							return false;
						}
						alert('수정에 실패하였습니다.');
					}
				});
			},
			// 예약 삭제
			'deleteReserve' : function() {
				var _self = this;
				$.ajax({
					 url : _self._reserveDeleteURL
					,type : 'POST'
					,data : {
						 'RSV_ID' : _self.selectReserveId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		if( data.result > 0 ) {
					    		alert('삭제 되었습니다');
					    		location.reload();
				    		} else {
				    			alert('해당 예약은 삭제할 수 없습니다.');
				    		}
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				var $updateStatusBtn300 = _self.$updateStatusBtn300;
				var $updateStatusBtn310 = _self.$updateStatusBtn310;
				var $updateStatusBtn410 = _self.$updateStatusBtn410;
				var $updateStatusBtn420 = _self.$updateStatusBtn420;
				var $updateStatusBtn430 = _self.$updateStatusBtn430;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 승선명부관리로 이동
					$detailForm.find('.reserveManLink').click( function() {
						Bplat.view.openPopup({
							 'url' : _self._reserveManURL + '?RSV_ID=' + _self.selectReserveId
							,'width' : 800
							,'height' : 600
						}, 'reserve_man_popup');
	    			});
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=SCHD_ID] option:eq(0)').attr('selected',true);
					_self.createOptionSelect( $insertForm.find('[data-type=MAN_CNT]'), $insertForm.find('[data-type=SCHD_ID] option:eq(0)').attr('psgrCnt'), true );
					$insertForm.show(); 
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.find('[data-type=SCHD_ID]').val( data.SCHD_ID );
					$updateForm.find('[data-type=STATUS_NAME]').val( data.STATUS_NAME );
					// 예약상태별 버튼 노출.
					if( data.STATUS_CD == '104_300' ){
						$updateStatusBtn300.hide();
						$updateStatusBtn310.hide();	
						$updateStatusBtn410.hide();
						$updateStatusBtn420.show();
						$updateStatusBtn430.hide();
					}else if( data.STATUS_CD == '104_310' ){
						$updateStatusBtn300.show();
						$updateStatusBtn310.hide();	
						$updateStatusBtn410.show();
						$updateStatusBtn420.hide();
						$updateStatusBtn430.hide();
					}else if( data.STATUS_CD == '104_340' ){
						$updateStatusBtn300.hide();
						$updateStatusBtn310.show();	
						$updateStatusBtn410.show();
						$updateStatusBtn420.hide();
						$updateStatusBtn430.hide();
					}else if( data.STATUS_CD == '104_410' ){
						$updateStatusBtn300.hide();
						$updateStatusBtn310.hide();	
						$updateStatusBtn410.hide();
						$updateStatusBtn420.hide();
						$updateStatusBtn430.hide();
					}else if( data.STATUS_CD == '104_420' ){
						$updateStatusBtn300.hide();
						$updateStatusBtn310.hide();	
						$updateStatusBtn410.hide();
						$updateStatusBtn420.hide();
						$updateStatusBtn430.show();
					}else if( data.STATUS_CD == '104_430' ){
						$updateStatusBtn300.hide();
						$updateStatusBtn310.hide();	
						$updateStatusBtn410.hide();
						$updateStatusBtn420.hide();
						$updateStatusBtn430.hide();
					}
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			// 예약등록용 출조 데이터 가공
			'initSchdSel' : function() {
				var _self = this;
				var $schdSelOption = _self.$insertForm.find('[data-type=SCHD_ID] option');
				$.each( $schdSelOption, function(){
					var $this = $( this );
					if( '' != $this.val() ) {
					  	var schdDate = jdg.util.replaceDate($this.attr('schdDate'));
						$this.text( schdDate + ' ' + $this.text() );
					}
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[reserve_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 예약등록용 출조 데이터 가공
				this.initSchdSel();
				// 예약목록조회
				if( p_param.hasOwnProperty('SCHD_ID') ) {
					var schdId = p_param.SCHD_ID;
					this.getReserveList('1', {'SCHD_ID' : schdId});
				} else {
					this.getReserveList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[reserve_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[reserve_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[reserve_main] onDestroy Method' );
			}		
	  }
});