defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberMainURL = $('#memberMainURL').val();
				this._memberListURL = $('#memberListURL').val();
				this._memberDetailtURL = $('#memberDetailtURL').val();
				
				// element
				this.$detailFormSendMail = $('#sendMail');
				this.$detailFormSendSms = $('#sendSms');

				// form
				this.$detailForm = $('#memberDetailForm');
			},
			'setEvent'		: function() {
				var _self = this;
				// 상세폼 메일보내기
				_self.$detailFormSendMail.click( function() {
					_self.sendMail();
				});
				
				// 상세폼 문자보내기
				_self.$detailFormSendSms.click( function() {
					_self.sendSms();
				});
				
			},
			
			
			'openDetailForm' : function( memId ) {
				var _self = this;
				var param = {'MEM_ID':memId};
				
				$.ajax({
					 url : _self._memberDetailtURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('memberDetail') ) {
				    		_self.selectFormShow('detail', data.memberDetail);
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'detail' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
					
					//상세폼이 보여질때 상세폼으로 포커스이동
					$detailForm.attr('tabindex',-1).focus().removeAttr('tabindex');
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$detailForm.hide();
				}
			},
			'sendMail' : function( mode, data ) {
				alert("메일보내기 버튼!!!");
			},
			'sendSms' : function( mode, data ) {
				alert("문자보내기 버튼!!!");
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				
				// 초기화
				this.setElement();
				this.setEvent();
				
				var memId = $('#memId').val();
				this.openDetailForm(memId);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
