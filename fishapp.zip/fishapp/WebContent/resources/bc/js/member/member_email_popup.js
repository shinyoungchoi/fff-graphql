defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._sendMailURL = $('#sendMailURL').val();
				this._bizDetailURL = $('#bizDetailURL').val();
				this._memberDetailtURL = $('#memberDetailtURL').val();
				// element
				this.$senderMailServerList = $('#senderMailServerList');
				this.$receiverMailServerList = $('#receiverMailServerList');
				this.$sendBtn = $('#sendBtn');
				this.$cancelBtn = $('#cancelBtn');
				this.$senderMail = $('#senderMail');
				this.$receiverMail = $('#receiverMail');
				this.$title = $('#title');
				this.$contents = $('#contents');
				
				this.$sendMailData = $('#sendMailData');
				
				//spinner
				this.spinner = jdg.util.spinnerObj($('#wrapperDiv'));
				
				//static
				
			},
			'setEvent'		: function() {
				var _self = this;
				//보내기 버튼
				_self.$sendBtn.click(function(){
					var sender = _self.$sendMailData.data("sender");
					var receiver = _self.$sendMailData.data("receiver");
					var param = {
							"RECV_EMAIL" : receiver.EMAIL,
							"RECV_NAME" : receiver.MEM_NAME,
							"TITLE" : _self.$title.val(),
							"CONTENT" : _self.$contents.val(),					
							"SMTP_HOST" : sender.SMTP_HOST,
							"SMTP_PORT" : sender.SMTP_PORT,
							"SMTP_SSL_YN" : sender.SMTP_SSL_YN,
							"SMTP_TLS_YN" : sender.SMTP_TLS_YN, 
							"SMTP_USER" : sender.SMTP_USER,
							"SMTP_PASS" : sender.SMTP_PASS
					};

					_self.spinner.start();
					_self.sendEmail(param);
				});
				//취소 버튼
				_self.$cancelBtn.click(function(){
					window.close();
				});
			},
			
			'sendEmail' : function(param){
				var _self = this;
				$.ajax({
					 url : _self._sendMailURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	_self.spinner.stop();
				    	alert('발송되었습니다.');
				    	window.close();
				    }
				});
			},
			'getBizDetail' : function(param){
				var _self = this;
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var email = data.bizDetail.SMTP_USER;
				    	_self.$senderMail.text(email);
				    	_self.$sendMailData.data("sender", data.bizDetail);
				    }
				});
			},
			'getMemberDetail' : function(memId){
				var _self = this;
				var param = {"MEM_ID" : memId};
				$.ajax({
					 url : _self._memberDetailtURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var email = data.memberDetail.EMAIL;
				    	var memNm = data.memberDetail.MEM_NAME;
				    	_self.$receiverMail.text(memNm+"<"+email+">");
				    	_self.$sendMailData.data("receiver", data.memberDetail);
				    }
				});
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				
				// 초기화
				this.setElement();
				this.setEvent();
				this.getBizDetail();
				
				this.getMemberDetail($.cookie("selectMemberId"));
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
