defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberDetailURL = $('#memberDetailURL').val();
				this._memberUpdateURL = $('#memberUpdateURL').val();
				this._memberNickCheckURL = $('#memberNickCheckURL').val();
				
				// element
				this.$updateForm = $('#updateForm');
				this.$pwUpdateForm = $('#pwUpdateForm');
				this.$updateBtn = $('#updateBtn');
				this.$pwUpdateBtn = $('#pwUpdateBtn');
				this.$regChkBtn = $('#regNickCheckBtn');
				this.$currentPw = $('#currentPw');
				this.$updatePw = $('#updatePw');
				this.$reCheckPw = $('#reCheckPw');
				
				// static variable
				this.memId = $('#memId').val();
				this.beforeData = {};
			},
			'setEvent'		: function() {
				var _self = this;
				
				//닉네임 중복 체크 클릭
				_self.$regChkBtn.click( function() {
					_self.checkNickName( _self.$updateForm.find('[data-key=NICK_NAME]') );
					return false;
				});

				// 개인정보 수정 버튼
				_self.$updateBtn.click( function() {
					_self.updateMember();
				});
				
				//비밀번호 수정 버튼
				_self.$pwUpdateBtn.click( function() {
					_self.updatePw();
				});
				
			},
			//회원 정보 가져오기
			'getMeberDetail'		: function() {
				var _self = this;
				
				$.ajax({
					 url : _self._memberDetailURL
					,type : 'POST'
					,data : {'MEM_ID': _self.memId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('memberDetail') ) {
				    		jdg.util.detailDataSetting( _self.$updateForm, data.memberDetail );
				    		
				    		_self.beforeData = data.memberDetail;
				    	}
				    }
				});
			},
			// 회원 수정
			'updateMember' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateData = _self.beforeData;
				// 닉네임 등록 여부 확인
				var $nickName = $updateForm.find('[data-key=NICK_NAME]');
				var checkFlag =$nickName.attr('checkFlag');
				var nickName = $nickName.val();
				var beforeNickName = ( updateData.NICK_NAME == undefined || updateData.NICK_NAME == null )? '' : updateData.NICK_NAME;
				if( '' === nickName || beforeNickName === nickName || checkFlag === 'true' ) {
					var updateParam = {
						  'MEM_ID' : updateData.MEM_ID
					    , 'EMAIL' : $updateForm.find('[data-key=EMAIL]').val()
						, 'TEL' : $updateForm.find('[data-key=TEL]').val()
						, 'MEM_NAME' : $updateForm.find('[data-key=MEM_NAME]').val()
						, 'NICK_NAME' : nickName
						, 'PWD' : updateData.PWD
					};
					if( '107_170' === updateData.GRADE_CD ) updateParam.GRADE_CD = '107_170';
					$.ajax({
						 url : _self._memberUpdateURL
						,type : 'POST'
						,data : updateParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('수정 되었습니다');
					    		location.reload();
					    	}
					    }
					});
				} else {
					alert('닉네임 중복체크를 해주세요');
				}
			},
			// 비밀번호 수정
			'updatePw' : function() {
				var _self = this;
				var NickName = ( _self.beforeData.NICK_NAME == undefined || _self.beforeData.NICK_NAME == null )? '' : _self.beforeData.NICK_NAME;
				
				if(_self.validator()){
					var updateParam = {
						  'MEM_ID' : _self.beforeData.MEM_ID
						, 'TEL' : _self.beforeData.TEL
						, 'MEM_NAME' : _self.beforeData.MEM_NAME
						, 'NICK_NAME' : NickName
						, 'PWD' : _self.$updatePw.val()
					};
					if( '107_170' === _self.beforeData.GRADE_CD ) _self.beforeData.GRADE_CD = '107_170';
					$.ajax({
						 url : _self._memberUpdateURL
						,type : 'POST'
						,data : updateParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('수정 되었습니다');
					    		location.reload();
					    	}
					    }
					});
				}
			},
			// 닉네임 체크
			'checkNickName' : function( $nickName ) {
				var _self = this;
				var nickName = $.trim( $nickName.val() );
				if( '' === nickName ) {
					alert('닉네임을 등록해주세요');
					return false;
				}
				$.ajax({
					 url : _self._memberNickCheckURL
					,type : 'POST'
					,data : {'NICK_NAME' : nickName}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('count') ) {
				    		if( data.count == 0 ) {
				    			alert('등록 가능한 닉네임 입니다');
				    			// 닉네임창 비활성화
				    			$nickName.addClass('jdg-disabled');
				    			$nickName.attr('readonly', true);
				    			$nickName.attr('checkFlag', 'true');
				    		} else {
				    			alert('사용중인 닉네임 입니다');
				    			$nickName.attr('checkFlag', 'false');
				    		}
				    	}
				    }
				});
			},
			'validator' : function(  ) {
				var _self = this;
				
				if( _self.$currentPw.val() == "" ){
					alert('현재 비밀번호를 입력해주세요.');
					return false;
				}else if( _self.$updatePw.val() == "" ){
					alert('변경 비밀번호를 입력해주세요.');
					return false;
				}else if( _self.$reCheckPw.val() == "" ){
					alert('재확인 비밀번호를 입력해주세요.');
					return false;
				}
				
				//현재 비밀번호가 틀리면 alert
				if( _self.beforeData.PWD != _self.$currentPw.val()){
					alert('현재 비밀번호가 일치하지 않습니다.');
					return false;
				}
				
				//바꿀 비밀번호와 재확인 비밀번호가 일치하지 않으면 alert
				if( _self.$updatePw.val() != _self.$reCheckPw.val()){
					alert('변경 비밀번호와 재확인 비밀번호가 일치하지 않습니다.');
					return false;
				}
				
				return true;
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_update] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getMeberDetail();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_update] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_update] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_update] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_update] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_update] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
