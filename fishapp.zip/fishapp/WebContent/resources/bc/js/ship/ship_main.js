defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipDetailURL = $('#shipDetailURL').val();
				this._shipUpdateFormURL = $('#shipUpdateFormURL').val();
				this._context = $('#context').val();
				this._state = $('#state').val();
				this._shipId = $('#shipId').val();
				
				this.$mfyBtn = $('#mfyBtn');
				
				// form
				this.$shipDetailForm = $('#shipDetailForm');
				
			},
			'setEvent'		: function() {
				var _self = this;

				_self.$mfyBtn.click(function(){
					Bplat.view.loadPage( _self._context + _self._state +"/" + _self._shipId.replace('/','')+"/ship/update_form" );
				});
			},
			//선박 정보 가져오기
			'getShipDetail' : function( param ) {
				var _self = this;

				$.ajax({
					 url : _self._shipDetailURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipDetail') ) {
				    		jdg.util.detailDataSetting( _self.$shipDetailForm, data.shipDetail );
				    		
				    		_self.setText();
				    		
				    		//이미지 셋팅
				    		if(data.shipDetail.MAIN_IMG_ID != null && data.shipDetail.MAIN_IMG_ID != undefined){//이미지가 있을때
				    			var leftImgSrc = _self._context + _self._state + _self._shipId + '/file/image/';
					    		_self.$shipDetailForm.find('[data-type=SHIP_IMG_ID]').attr('src' , leftImgSrc +data.shipDetail.MAIN_IMG_ID + '/155');
					    		_self.$shipDetailForm.find('[data-type=SHIP_IMG_ID]').click(function(){
					    			jdg.util.openImgPopup(leftImgSrc +data.shipDetail.MAIN_IMG_ID, data.shipDetail.MAIN_IMG_WIDTH, data.shipDetail.MAIN_IMG_HEIGHT);
					    		});
					    		_self.$shipDetailForm.find('[data-type=SHIP_IMG_ID]').css('cursor','pointer');//마우스 커서 셋팅
				    		}else{//이미지가 없을때
				    			_self.$shipDetailForm.find('[data-type=SHIP_IMG_ID]').remove();
				    		}
				    		
				    		if(data.shipDetail.CPTN_IMG_ID != null && data.shipDetail.CPTN_IMG_ID != undefined){//이미지가 있을때
				    			leftImgSrc = _self._context + _self._state + _self._shipId + '/file/image/';
					    		_self.$shipDetailForm.find('[data-type=CPTN_IMG_ID]').attr('src' , leftImgSrc +data.shipDetail.CPTN_IMG_ID + '/155');
					    		_self.$shipDetailForm.find('[data-type=CPTN_IMG_ID]').click(function(){
					    			jdg.util.openImgPopup(leftImgSrc +data.shipDetail.CPTN_IMG_ID , data.shipDetail.CPTN_IMG_WIDTH, data.shipDetail.CPTN_IMG_HEIGHT);
					    		});
					    		_self.$shipDetailForm.find('[data-type=CPTN_IMG_ID]').css('cursor','pointer');//마우스 커서 셋팅
				    		}else{//이미지가 없을때
				    			_self.$shipDetailForm.find('[data-type=CPTN_IMG_ID]').remove();
				    		}
				    	}
				    	
				    	if( data.hasOwnProperty('cptnDetail') ){ //선장 정보 셋팅
				    		if( data.cptnDetail.hasOwnProperty('MEM_NAME') ) {
				    			_self.$shipDetailForm.find('[data-key=MEM_NAME]').text(data.cptnDetail.MEM_NAME);
							}
				    		if( data.cptnDetail.hasOwnProperty('NICK_NAME') ) {
				    			_self.$shipDetailForm.find('[data-key=NICK_NAME]').text(data.cptnDetail.NICK_NAME);
				    		}
				    		if( data.cptnDetail.hasOwnProperty('MEM_ID') ) {
				    			_self.$shipDetailForm.find('[data-key=MEM_ID]').text(data.cptnDetail.MEM_ID);
				    		}
				    		if( data.cptnDetail.hasOwnProperty('TEL') ) {
				    			_self.$shipDetailForm.find('[data-key=TEL]').text(jdg.util.setPhonNumber(data.cptnDetail.TEL));
				    		}
				    		if( data.cptnDetail.hasOwnProperty('EMAIL') ) {
				    			_self.$shipDetailForm.find('[data-key=EMAIL]').text(data.cptnDetail.EMAIL);
				    		}
				    	}
				    }
				});
			},
			//각종 text 셋팅
			'setText' : function() {
				var _self = this;
				
				var $psgrCnt = _self.$shipDetailForm.find('[data-key=PSGR_CNT]');
				$psgrCnt.text($psgrCnt.text() + " 명");
				
				var $redirectName = _self.$shipDetailForm.find('[data-key=REDIRECT_NAME]');
				if( $redirectName.text() != "" ){
					$redirectName.text("/"+$redirectName.text() + ".ho");
				}
						
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				this.getShipDetail({'SHIP_ID':this._shipId.replace('/','') });
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
