defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipMainURL = $('#shipMainURL').val();
				this._shipDetailURL = $('#shipDetailURL').val();
				this._shipUpdateURL = $('#shipUpdateURL').val();
				this._memberSearchURL = $('#memberSearchURL').val();
				
				// element
				this.$updateForm = $('#updateForm');
				this.$saveBtn = $('#saveBtn');
				this.$cancelBtn = $('#cancelBtn');
				this.$searchCptnBtn = $('#searchCptnBtn');
				this.$searchNameTxt = $('#searchNameTxt');

				// static variable
				this.selectShipId = $('#selectShipId').val();
				this.shipFileList = null;
				this.cptnFileList = null;
				this.beforeData = {};
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 저장 버튼 처리
				_self.$saveBtn.click( function() {
					_self.updateShip();
				});
				
				// 취소 버튼 처리
				_self.$cancelBtn.click( function() {
					Bplat.view.loadPage( _self._shipMainURL );
				});
				
				// 회원 조회 팝업 오픈 (텍스트에서 엔터시)
				_self.$searchNameTxt.keypress( function() {
					var keyCode = ( window.netscape ) ? evt.which : event.keyCode ; 
				    if(keyCode==13) { //엔터일시
				    	Bplat.view.openPopup({
							'url' : _self._memberSearchURL +"?searchNameTxt=" + _self.$searchNameTxt.val()
							,'width' : 800
							,'height' : 600
						}, 'member_update_popup');
				    } 
				});
				
				// 회원 조회 팝업 오픈 (수정)
				_self.$searchCptnBtn.click( function() {
					
					var searchNameTxt = encodeURI(encodeURIComponent(_self.$searchNameTxt.val(), 'UTF-8'));
					
					Bplat.view.openPopup({
						'url' : _self._memberSearchURL+"?searchNameTxt=" + searchNameTxt
						,'width' : 800
						,'height' : 600
					}, 'member_update_popup');
				});
			},
			// 선박 상세 조회
			'getShipDetail' : function( shipId ) {
				var _self = this;
				$.ajax({
					 url : _self._shipDetailURL
					,type : 'POST'
					,data : {'SHIP_ID': shipId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipDetail') ) {
				    		jdg.util.detailDataSetting( _self.$updateForm, data.shipDetail );
				    		
				    		_self.beforeData.shipDetail = data.shipDetail;
				    		
							// 파일리스트 초기화
							_self.mainFileList = new component.File({
								 'id' : 'UPDATE_MAIN_IMG_ID'
								,'container' : $('#UPDATE_MAIN_IMG_ID')
							});
							_self.mainFileList.init( data.shipDetail.MAIN_IMG_ID ? data.shipDetail : null );
							
							_self.cptnFileList = new component.File({
								 'id' : 'UPDATE_CPTN_IMG_ID'
								,'container' : $('#UPDATE_CPTN_IMG_ID')
							});
							_self.cptnFileList.init( data.shipDetail.CPTN_IMG_ID ? data.shipDetail : null );
							
				    	}
				    	
				    	if( data.hasOwnProperty('cptnDetail') ){ //선장 정보 셋팅
				    		_self.beforeData.cptnDetail = data.cptnDetail;
				    		
				    		if( data.cptnDetail.hasOwnProperty('MEM_NAME') ) {
				    			_self.$updateForm.find('[data-key=MEM_NAME]').text(data.cptnDetail.MEM_NAME);
				    		}
				    		if( data.cptnDetail.hasOwnProperty('NICK_NAME') ) {
				    			_self.$updateForm.find('[data-key=NICK_NAME]').text(data.cptnDetail.NICK_NAME);
				    		}
				    		if( data.cptnDetail.hasOwnProperty('MEM_ID') ) {
				    			_self.$updateForm.find('[data-key=MEM_ID]').text(data.cptnDetail.MEM_ID);
				    		}
				    		if( data.cptnDetail.hasOwnProperty('TEL') ) {
				    			_self.$updateForm.find('[data-key=TEL]').text(jdg.util.setPhonNumber(data.cptnDetail.TEL));
				    		}
				    		if( data.cptnDetail.hasOwnProperty('EMAIL') ) {
				    			_self.$updateForm.find('[data-key=EMAIL]').text(data.cptnDetail.EMAIL);
				    		}
				    	}
				    }
				});
			},
			//선박 정보 수정하기
			'updateShip' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateData = _self.beforeData;
				// 선장
				var cptnMemId = $updateForm.find('[data-key=CPTN_MEM_ID]').text();
				var beforeCptnMemId = updateData.shipDetail.CPTN_MEM_ID;
				// IMG_ID
				var mainImgId = _self.mainFileList.getFile();
				var cptnImgId = _self.cptnFileList.getFile();
				var beforeMainImgId = updateData.shipDetail.MAIN_IMG_ID ? updateData.shipDetail.MAIN_IMG_ID : '';
				var beforeCptnImgId = updateData.shipDetail.CPTN_IMG_ID ? updateData.shipDetail.CPTN_IMG_ID : '';
				// 선박 수정
				var updateParam = {
					  'SHIP_ID' : updateData.shipDetail.SHIP_ID
					, 'BIZ_ID' : updateData.shipDetail.BIZ_ID
					, 'SHIP_NAME' : updateData.shipDetail.SHIP_NAME
					, 'SHIP_DESC' : $updateForm.find('[data-key=SHIP_DESC]').val()
					, 'MAIN_IMG_ID' : (mainImgId ? mainImgId : '')
					, 'BEFORE_MAIN_IMG_ID' : (beforeMainImgId === mainImgId || !beforeMainImgId) ? "" : beforeMainImgId
					, 'INTRODUCE' : $updateForm.find('[data-key=INTRODUCE]').val()
					, 'CPTN_MEM_ID' : cptnMemId
					, 'BEFORE_CPTN_MEM_ID' : (beforeCptnMemId === cptnMemId || !beforeCptnMemId) ? "" : beforeCptnMemId
					, 'CPTN_IMG_ID' : (cptnImgId ? cptnImgId : '')
					, 'BEFORE_CPTN_IMG_ID' : (beforeCptnImgId === cptnImgId || !beforeCptnImgId) ? "" : beforeCptnImgId
					, 'CPTN_NAME' : $updateForm.find('[data-key=MEM_NAME]').text()
					, 'CPTN_TEL' : $updateForm.find('[data-key=TEL]').text()
					, 'CPTN_EMAIL' : $updateForm.find('[data-key=EMAIL]').text()
					, 'DEPART_TIME' : $updateForm.find('[data-key=DEPART_TIME]').val()
					, 'RETURN_TIME' : $updateForm.find('[data-key=RETURN_TIME]').val()
					, 'PSGR_CNT' : $updateForm.find('[data-key=PSGR_CNT] option:selected').val()
					, 'FISHING_CD' : $updateForm.find('[data-key=FISHING_CD] option:selected').val()
					, 'AREA_DESC' : $updateForm.find('[data-key=AREA_DESC]').val()
					, 'PORT_CD'   : $updateForm.find('[data-key=PORT_CD]').val()
					, 'NAVIGATION' : $updateForm.find('[data-key=NAVIGATION]').val()
					, 'PORT_ADDR'  : $updateForm.find('[data-key=PORT_ADDR]').val()
					, 'ETC_DESC' : $updateForm.find('[data-key=ETC_DESC]').val()
					, 'CAFE_YN' : $updateForm.find('[data-key=CAFE_YN]').val()
					, 'CAFE_URL' : $updateForm.find('[data-key=CAFE_URL]').val()
				};
				$.ajax({
					 url : _self._shipUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		Bplat.view.loadPage( _self._shipMainURL );
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				// 선박목록조회
				this.getShipDetail(this.selectShipId);
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_update] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				
				if( 'member_update_popup' === p_param.id ) {
					if( data ) {
						
						if( data.hasOwnProperty('MEM_ID') ) {
							_self.$updateForm.find('[data-key=CPTN_MEM_ID]').text( data.MEM_ID );
							_self.$updateForm.find('[data-key=CPTN_MEM_ID]').attr('cptnMemId', data.MEM_ID );
						}else _self.$updateForm.find('[data-key=CPTN_MEM_ID]').text( "" );
						if( data.hasOwnProperty('NICK_NAME') ) {
							_self.$updateForm.find('[data-key=NICK_NAME]').text( data.NICK_NAME );
						}else _self.$updateForm.find('[data-key=NICK_NAME]').text( "" );
						if( data.hasOwnProperty('MEM_NAME') ) {
							_self.$updateForm.find('[data-key=MEM_NAME]').text( data.MEM_NAME );
						}else _self.$updateForm.find('[data-key=MEM_NAME]').text( "" );
						if( data.hasOwnProperty('EMAIL') ) {
							_self.$updateForm.find('[data-key=EMAIL]').text( data.EMAIL );
						}else _self.$updateForm.find('[data-key=EMAIL]').text( "" );
						if( data.hasOwnProperty('TEL') ) {
							_self.$updateForm.find('[data-key=TEL]').text( jdg.util.setPhonNumber(data.TEL) );
			    		}else _self.$updateForm.find('[data-key=TEL]').text( "" );
					}
				}
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_main] onDestroy Method' );
			}
	  }
});
