defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._context = $('#context').val();
				this._state = $('#state').val();
				this._loginURL = $('#loginURL').val();
				this._idFindURL = $('#idFindURL').val();
				this._pwdInitURL = $('#pwdInitURL').val();
				
				// element
				this.$loginForm = $('#loginForm');
				this.$idFindLayer = $('#idFindLayer');
				this.$pwInitLayer = $('#pwInitLayer');
				this.$pwdInitBtn = $('#pwdInitBtn');
				this.$idFindBtn = $('#idFindBtn');
				this.$idTxt = $('#jdg-id');
				this.$pwTxt = $('#jdg-pw');
				this.$saveId = $('#saveId');
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 로그인 폼 전송
				var options = {
					 type : 'POST'
					,url : _self._loginURL
				    ,dataType : 'json'
				    ,beforeSubmit : function( formData, jqForm, options ) {
				    	if(_self.$saveId.attr('checked') == "checked"){ //아이디 저장이 체크 되어 있다면 셋팅
							$.cookie('jdgLoginId' , _self.$idTxt.val(), { expires : 30, path : _self._context + _self._state });
						}else{
							$.cookie('jdgLoginId' , null, { path : _self._context + _self._state });
						}
						// validation
						if( !jdg.util.validator( _self.$loginForm, true ) ) return false;
				    }
				    ,success : function( data ) {
				    	if( data.msg || null != data.msg ) {
				    		alert( data.msg );
				    		return false;
				    	}
				    	var url = _self._context + data.redirectUrl;
				    	Bplat.view.loadPage( url );
				    }
				};
				_self.$loginForm.ajaxForm( options );
				
				//아이디찾기 버튼.
				_self.$idFindBtn.click(function(){
					_self.$idFindLayer = $('#idFindLayer');
					var $idFindLayer = _self.$idFindLayer; 
					
					//텍스트 초기화
					$idFindLayer.find('input:text').val("");
					
					//위치잡기
					$idFindLayer.css("top", (($(window).height() - $idFindLayer.outerHeight()) / 2) + $(window).scrollTop() + "px");
					$idFindLayer.css("left", (($(window).width() - $idFindLayer.outerWidth()) / 2) + $(window).scrollLeft() + "px");
					
					//찾기 버튼 처리
					$idFindLayer.find('#idFindLayerFindBtn').unbind('click');
					$idFindLayer.find('#idFindLayerFindBtn').click(function(){
						var options = {
								 type : 'POST'
								,url : _self._idFindURL
							    ,dataType : 'json'
							    ,beforeSubmit : function( formData, jqForm, options ) {
									// validation
									if( !jdg.util.validator( $idFindLayer.find('form'), true ) ) return false;
							    }
							    ,success : function( data ) {
							    	if( null != data.success && data.success === false  ) {
							    		alert( data.error.userMessage );
							    		return false;
							    	}
							    	if( null != data.msg ){
							    		alert( data.msg );
							    		$idFindLayer.hide();
							    	}
							    }
							};
							$idFindLayer.find('form').ajaxForm( options );
					});
					$idFindLayer.show();
					$idFindLayer.find('input:first').focus();
				});
				
				//비번초기화 버튼.
				_self.$pwdInitBtn.click(function(){
					_self.$pwInitLayer = $('#pwInitLayer');
					var $pwInitLayer = _self.$pwInitLayer; 
					
					//텍스트 초기화
					$pwInitLayer.find('input:text').val("");
					
					//위치잡기
					$pwInitLayer.css("top", (($(window).height() - $pwInitLayer.outerHeight()) / 2) + $(window).scrollTop() + "px");
					$pwInitLayer.css("left", (($(window).width() - $pwInitLayer.outerWidth()) / 2) + $(window).scrollLeft() + "px");
					
					//초기화 버튼 처리
					$pwInitLayer.find('#pwInitLayerInitBtn').unbind('click');
					$pwInitLayer.find('#pwInitLayerInitBtn').click(function(){
						var options = {
								 type : 'POST'
								,url : _self._pwdInitURL
							    ,dataType : 'json'
							    ,beforeSubmit : function( formData, jqForm, options ) {
									// validation
									if( !jdg.util.validator( $pwInitLayer.find('form'), true ) ) return false;
							    }
							    ,success : function( data ) {
							    	if( null != data.success && data.success === false  ) {
							    		alert( data.error.userMessage );
							    		return false;
							    	}
							    	if( null != data.msg ){
							    		alert( data.msg );
							    		$pwInitLayer.hide();
							    	}
							    }
							};
						$pwInitLayer.find('form').ajaxForm( options );
					});
					$pwInitLayer.show();
					$pwInitLayer.find('input:first').focus();
					
				});
				
				//ie 버전별로 placeholder가 작동 안되는 버그가 있어 같은 기능 구현
				jdg.util.setPlaceHolder(_self.$idTxt , '아이디를 입력해 주세요');
				jdg.util.setPlaceHolder(_self.$pwTxt , '비밀번호를 입력해 주세요');
			},
			'setSaveId' : function() {
				var _self = this;

				if($.cookie('jdgLoginId') != null && $.cookie('jdgLoginId') != ""){//쿠키에 아이디가 있다면 
					_self.$idTxt.val($.cookie('jdgLoginId'));
					_self.$saveId.attr("checked","checked");
				}
			},
			'onCreate' : function( p_param, _viewClass ) {

				if (/MSIE/.test(navigator.userAgent)) {
					$('.divChrome').show();
				}
				
				// 초기화
				this.setElement();
				this.setEvent();
				this.setSaveId();
				
				//레이어 가져오기
				jdg.util.getLayer('idFindLayer');
				jdg.util.getLayer('pwInitLayer');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[login] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[login] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[login] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[login] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[login] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[login] onDestroy Method' );
			}		
	  }
});
