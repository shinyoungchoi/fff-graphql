defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleDetailFormURL = $('#scheduleDetailFormURL').val();
				this._fishListURL = $('#fishListURL').val();
				// element
				this.$homeWeekLabel = $('#homeWeekLabel');
				this.$scheduleContainer = $('#mainScheduleContainer');
				this.$mainMemFishContainer = $('#mainMemFishContainer');
				this.$cptnMemFishContainer = $('#mainCptnFishContainer');
				this.$homeTemplate = $('#mainHomeTemplate');
				this.$fishTemplate = $('#mainFishTemplate');
				this.$scheduleRow = this.$homeTemplate.find('.scheduleRow');
				this.$scheduleNodata = this.$homeTemplate.find('.scheduleNodata');
				this.$reserveRow = this.$homeTemplate.find('.reserveRow');
				this.$reserveMemRow = this.$homeTemplate.find('.reserveMemRow');
				this.$reserveMemNodata = this.$homeTemplate.find('.reserveMemRowNodata');
				this.$prevWeekBtn = $('#prevWeekBtn');
				this.$nextWeekBtn = $('#nextWeekBtn');
				this.memFishList = new component.List({
					 'container' : this.$mainMemFishContainer
					,'template' : this.$fishTemplate.find('.searchRow')
				});
				this.cptnFishList = new component.List({
					'container' : this.$cptnMemFishContainer
					,'template' : this.$fishTemplate.find('.searchRow')
				});
				// static variable
				this._shipId = $('#ship_id').val();
				this.currentWeek = null;
				this.currentStartDay = null;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 전주 조회
				_self.$prevWeekBtn.click( function() {
					var prevDay = _self.currentSearchDay;
					prevDay.setDate( prevDay.getDate()-7 );
					_self.getWeekScheduleList( prevDay );
				});
				
				// 다음주 조회
				_self.$nextWeekBtn.click( function() {
					var nextDay = _self.currentSearchDay;
					nextDay.setDate( nextDay.getDate()+7 );
					_self.getWeekScheduleList( nextDay );
				});
				
				// 출조 상세 조회 클릭 이벤트
				_self.$scheduleContainer.delegate('[data-key=SUB_TITLE]', 'click', function() {
					Bplat.view.loadPage( _self._scheduleDetailFormURL + '?SCHD_ID=' + $( this ).attr('SCHD_ID') );
				});
				
				// 회원 조행기 조회 클릭 이벤트
				_self.$mainMemFishContainer.delegate('li', 'click', function(){
					var url = window.location.href;
					var GALR_ID = $(this).attr('rowkey');
					Bplat.view.loadPage( url.replace('home', 'fish') + '/detail_form?GALR_ID=' + GALR_ID + '&menuType=mem' );
				});
				
				// 선장 조행기 조회 클릭 이벤트
				_self.$cptnMemFishContainer.delegate('li', 'click', function(){
					var url = window.location.href;
					var GALR_ID = $(this).attr('rowkey');
					Bplat.view.loadPage( url.replace('home', 'fish') + '/detail_form?GALR_ID=' + GALR_ID );
				});
				
			},
			// 최근 회원 조행기 조회
			'getMemberFish' : function(){
				var _self = this;
				var fishType = '106_120';
				var page = 1;
				$.ajax({
					 url : _self._fishListURL
					,type : 'POST'
					,data : {
						 'PAGE' : page
						,'PERPAGE' : 5
						,'TYPE_CD' : fishType
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('fishList') ) {
				    		var fishList = data.fishList;
				    		$.each(fishList, function(key, item){
				    			fishList[key].CONTENT = jdg.util.subStr(item.CONTENT, 0, 45, '...');
								fishList[key].TITLE = jdg.util.subStr(item.TITLE, 0, 24, '...');
				    		});
				    		_self.memFishList.createList( fishList, 'GALR_ID');
				    	}
				    }
				});
			},
			// 최근 선장 조행기 조회
			'getCptnFish' : function(){
				var _self = this;
				var fishType = '106_110';
				var page = 1;
				$.ajax({
					url : _self._fishListURL
					,type : 'POST'
					,data : {
							 'PAGE' : page
							,'PERPAGE' : 5
							,'TYPE_CD' : fishType
							}
					,dataType : 'json'
					,success : function( data ) {
						if( data.hasOwnProperty('fishList') ) {
							var fishList = data.fishList;
							$.each(fishList, function(key, item){
								fishList[key].CONTENT = jdg.util.subStr(item.CONTENT, 0, 45, '...');
								fishList[key].TITLE = jdg.util.subStr(item.TITLE, 0, 24, '...');
							});
							_self.cptnFishList.createList( fishList, 'GALR_ID');
						}
					}
				});
			},
			// 한주간의 출조 조회
			'getWeekScheduleList' : function() {
				var _self = this;
				var array = _self.currentSearchDay.getRangeDaysOfWeek('',1);
				var startDay = array[0].split('-');
				var endDay = array[1].split('-');
				// 상단 조회기간 셋팅
				_self.$homeWeekLabel.text( 
					startDay[0] + '년 ' + startDay[1] + '월 ' + startDay[2] + '일 ~ '
					+ endDay[0] + '년 ' + endDay[1] + '월 ' + endDay[2] + '일' 
				);
				var weekArr = [];
				weekArr.push({'SCHD_DATE' : startDay[0] + '' + startDay[1] + '' + startDay[2] });
				
				var tempday = new Date();
				var temp;
				
				tempday.setFullYear(startDay[0], startDay[1] - 1, startDay[2]);
				for( var i=0; i < 6 ; i++ ) {
					tempday.setDate(tempday.getDate()+1);
					temp = tempday.getFullYear() + '' 
							+ jdg.util.setStringFillZero(tempday.getMonth() + 1,2)  + ''
							+ jdg.util.setStringFillZero(tempday.getDate(),2);
					
					weekArr.push({'SCHD_DATE' : temp});
				}
				_self.currentWeek = weekArr;
				
				_self.getScheduleList({'SCHD_DATE' : startDay[0] + '' + startDay[1] + '' + startDay[2]});
			},
			// 출조정보 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var defaultParam = {
					 'SHIP_ID' : _self._shipId
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	_self.initScheduleRegisterWeek(data.scheduleList);
				    }
				});
			},
			// 최근 스케줄 데이터 셋팅
			'initScheduleRegisterWeek' : function( scheduleList ) {
				var _self = this;
				_self.$scheduleContainer.empty();
				var week = ['월요일','화요일','수요일','목요일','금요일','토요일','일요일'];
				// 1. 기간 LOOP
				for( var i=0,iSize=_self.currentWeek.length ; i < iSize ; i++ ) {
					var scheduleFlag = false;
					var schdDate = _self.currentWeek[i].SCHD_DATE;
					var $schedule = _self.$scheduleRow.clone();
					$schedule.find('[data-key=SCHD_DATE]').text( schdDate.substring(4,6) +'월 '+schdDate.substring(6,8)+ '일 ' + week[i] );
					$schedule.find('.reserveContainer').empty();
					// 2. 출조 LOOP
					$.each( scheduleList, function( idx, data ) {
						if( schdDate === data.SCHD_DATE ) {
							scheduleFlag = true;
							var reserveList = data.reserveList;
							var $reserveRow = _self.$reserveRow.clone();
							$reserveRow.find('[data-key=SUB_TITLE]').attr('SCHD_ID', data.SCHD_ID);
							$reserveRow.find('[data-key=SUB_TITLE]').text( jdg.util.setStringOverview(data.SUB_TITLE,5) );
							if(data.CHOICE_GENRE == '' || data.CHOICE_GENRE == undefined){
								$reserveRow.find('[data-key=SUB_TITLE]').text("출조합니다.");
							}
							// 3. 예약 LOOP
							if( reserveList.length <= 0 ) {
								var noDataLi = _self.$reserveMemNodata.clone();
								
								if (data.STATUS_CD == "113_170")
								{
									noDataLi.text('예약마감(관리자)');
								}
								
								$reserveRow.find('.jdg-list-member').append(noDataLi);
							} else {
								$.each( reserveList, function( idx, data ) {
									var $rm = _self.$reserveMemRow.clone();
									$rm.find('[data-key=RSV_NAME]').text( data.RSV_NAME );
									$rm.find('[data-key=MAN_CNT]').text( data.MAN_CNT );
									$rm.find('[data-key=STATUS_NAME]').text( data.STATUS_NAME );
									$reserveRow.find('.jdg-list-member').append( $rm );
								});
							}
							$schedule.find('.reserveContainer').append( $reserveRow );
						}
					});
					if( i == iSize-2 ) $schedule.addClass('jdg-sat');
					if( i == iSize-1 ) $schedule.addClass('jdg-sun');
					if( !scheduleFlag ) $schedule.append( _self.$scheduleNodata.clone() );
					_self.$scheduleContainer.append( $schedule );
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 최근 스케쥴
				var today = new Date();
				this.currentSearchDay = today;
				this.getWeekScheduleList( today );
				
				// 최근 회원 조행기 
				this.getMemberFish();
				
				// 최근 선장 조행기 
				this.getCptnFish();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
