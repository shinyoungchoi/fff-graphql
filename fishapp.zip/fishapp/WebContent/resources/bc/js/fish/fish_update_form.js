defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishDetailURL = $('#fishDetailURL').val();
				this._fishUpdateURL = $('#fishUpdateURL').val();
				this._fishDetailFormURL = $('#fishDetailFormURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				this._prevURL = '';
				
				// element
				this.$mfyBtn = $('#mfyBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$fishDate = $('#fishDate');
				
				// form
				this.$updateForm = $('#fishUpdateForm');
				
				// static variable
				this.galrId = $('#GALR_ID').val();
				this.menuType = $('#menuType').val();
				this.shipId = $('#shipId').val();
				this.selectFileList = null;
				this.fileList = null;
				this.MEMBER_FISH = '106_120';
				this.CPTN_FISH = '106_110';
			},
			'setEvent'		: function() {
				var _self = this;
				
				// datePicker 이벤트선언
				_self.$fishDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				
				_self.$fishDate.click(function() {
					$(".jdg-btn-calendar").click();
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateFish();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					var url = window.location.href;
					Bplat.view.loadPage( url.replace('update_form', 'detail_form' ), {'url' : _self._prevURL } );
					return false; 
				});
			},
			// 조과 상세 조회
			'getFishDetail' : function( galrId  ) {
				var _self = this;
				var $updateForm = _self.$updateForm;
				$.ajax({
					 url : _self._fishDetailURL
					,type : 'POST'
					,data : {
						'GALR_ID' : galrId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		// 업데이트에서 호출하는 상세 컨트롤러도 <br> 처리되므로 다시 /n 으로 치환
				    		var imgList = detail.imageList;
				    		if( imgList.length > 0 ){
				    			$.each(imgList, function(key, item){
				    				if( item.CONTENT != null && item.CONTENT != undefined )
				    					imgList[key].CONTENT = item.CONTENT.replace(/<br>/g, '\n');
				    			});
				    		}
				    		
							// 상세폼셋팅
							jdg.util.detailDataSetting( _self.$updateForm, detail );
							
							// 파일리스트 초기화
							_self.fileList = new component.FileList({
								'id' : $updateForm.attr('id')
								,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
							});
							_self.fileList.init(detail.imageList);
						}
				    }
				});
			},
			// 조과수정
			'updateFish' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				var menuType = _self.menuType == 'mem' ? _self.MEMBER_FISH : _self.CPTN_FISH;
				var $fishDate = $updateForm.find('[data-key=FISH_DATE]');
				
				// 회원일 경우 출조일은 validation 에서 제외
				if( menuType == _self.MEMBER_FISH ){
					$fishDate.removeAttr('vRequired');
				}
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 조과 수정
				var updateParam = {
					 GALR_ID: _self.galrId
    				,SHIP_ID: _self.shipId.replace('/', '')
					,TYPE_CD: menuType
					,FISH_DATE: $updateForm.find('[data-key=FISH_DATE]').val().replaceAll('-','')
					,TITLE: $updateForm.find('[data-key=TITLE]').val()
					,LOC_DESC: $updateForm.find('[data-key=LOC_DESC]').val()
					,CONTENT: $updateForm.find('[data-key=CONTENT]').val()
					,IMG_ID: JSON.stringify( _self.fileList.getFileList() )
					,GPS_LAT: $updateForm.find('[data-key=GPS_LAT]').text()
					,GPS_LONG: $updateForm.find('[data-key=GPS_LONG]').text()
				};
				$.ajax({
					 url : _self._fishUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		var url = window.location.href;
							Bplat.view.loadPage( url.replace('update_form', 'detail_form' ), {'url' : _self._prevURL } );
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				// 이전 페이지의 URL 셋팅
				if( p_param.url != undefined )
					this._prevURL = p_param.url;
				
				this.getFishDetail( this.galrId );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});