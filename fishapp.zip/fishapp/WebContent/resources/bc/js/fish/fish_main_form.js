defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishListURL       = $('#fishListURL').val();
				this._fishInsertFormURL = $('#fishInserFormURL').val();
				this._fishDetailFormURL = $('#fishDetailFormURL').val();
				
				// element
				this.$listContainer = $('#fishListContainer');
				this.$listTemplate = $('#fishListTemplate');
				this.$regBtn = $('#regBtn');
				this.$jdgListTab = $('.jdg-list-tab');
				this.$listPerItemSel = $('#listPerItemSel');
				this.$menuType = $('#menuType');
				this.$itemCnt = $('#itemCnt');
				this.$page = $('#page');
				this.$word = $('#word');
				this.$searchWord = $('#searchWord');
				this.$searchType = $('#searchType');
				this.$searchTypeSel = $('#searchTypeSel');
				this.$searchBtn = $('#searchBtn');
				
				// form
				this.$srchForm = $('#fishSearchForm');
				
				this.searchType = $('#searchType').val();
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				this.MEMBER_FISH = '106_120';
				this.CPTN_FISH = '106_110';
				this.fileList = null;
				
				this.P_WORD = '검색어';
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$searchBtn.click(function() {
					_self.$word.val(_self.$searchWord.val());
					_self.$searchType.val(_self.$searchTypeSel.find('option:selected').val());
					
					_self.movePage();
					
					return false;
				});
				
				// 검색창 엔터시
				_self.$searchWord.bind("input keyup paste", function(){
	            	if( 13 === event.keyCode ) {
	            		_self.$searchBtn.trigger('click');
	    			}
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					var param = '';
					if( _self.$menuType.val() != '' ){
						param = '?menuType='+_self.$menuType.val();
					}
					Bplat.view.loadPage( _self._fishInsertFormURL + param, { 'url' : window.location.href } );
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('td[data-key=TITLE]','click', function() {
					var param = '';
					if( _self.$menuType.val() != '' ){
						param = '&menuType='+_self.$menuType.val();
					}
					Bplat.view.loadPage( _self._fishDetailFormURL + '?GALR_ID='+$(this).parent().attr('rowKey') + param
							           , {'url': window.location.href } );
				});
				
				// 아이템을 가져오는 수 선택 변경 이벤트.
				_self.$listPerItemSel.unbind('change');
				_self.$listPerItemSel.bind('change', function(){
					var $this = $(this);
					var getItemCnt = $this.find('option:selected').val();
					_self.$itemCnt.val(getItemCnt);
					// 페이지 초기화
					_self.$page.val('');
					_self.movePage();
				});
				
			},
			'initMainList' : function(){
				var _self = this;
				
				// 탭 메뉴 초기화
//				_self.$jdgListTab.find('li').removeClass();
				if( _self.$menuType.val() == 'mem'){
					_self.$jdgListTab.find('li#mem').addClass('jdg-selected');
					$('h2').text('회원 조행기 목록');
					$('#regBtn').hide();
				} else {
					_self.$jdgListTab.find('li#cptn').addClass('jdg-selected');
				}
//				
				// 검색 조건 셀렉트 박스 셋팅
				var searchType = _self.$searchType.val();
				var searchTypeSel = _self.$searchTypeSel.find('option');
				$.each(searchTypeSel, function(key, item){
					if( $(item).val() == searchType )
						$(item).prop('selected','selected');
				});
				
				// 검색어 placeHolder
				jdg.util.setPlaceHolder(_self.$searchWord, _self.P_WORD);
				
				// 검색어 셋팅
				var decodedWord = decodeURI(_self.$word.val());
				_self.$searchWord.val(decodedWord);
				
			},
			'movePage' : function() {
				var _self = this;
				var param = '';
				var mark = '?';
				var localPath = window.location.pathname;
				
				// 조행기 선택
				if( _self.$menuType.val() != '' ){
					param = mark + 'menuType=' + _self.$menuType.val(); 
				}
				
				// 아이템 갯수
				if( _self.$itemCnt.val() != '' ) {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					param = param + mark + 'itemCnt=' + _self.$itemCnt.val();
				}
				
				// 검색어
				if( _self.$word.val() != '' ) {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					var word = encodeURI(encodeURIComponent(_self.$word.val(), 'UTF-8'));
					param = param + mark + 'searchType=' + _self.$searchType.val() + '&word=' + word;
				}
				
				// 페이지 이동
				if(_self.$page.val() != '') {
					if( param != '' ){
						if( param.indexOf(mark) > -1 )
							mark = '&';
					}
					param = param + mark + 'page=' + _self.$page.val();
				}
				Bplat.view.loadPage( localPath + param );
			},
			// 조과 목록 조회
			'getFishList' : function() {
				var _self = this;
				var fishType = _self.$menuType.val() == 'mem' ? _self.MEMBER_FISH : _self.CPTN_FISH;
				var page = _self.$page.val() == '' ? 1 : _self.$page.val();
				var itemCnt = jdg.util.setItemCnt();
				switch (itemCnt) {
					case '10':
						itemCnt = 10;
						break;
					case '20':
						itemCnt = 20;
						break;
					case '30':
						itemCnt = 30;
						break;
					default:
						itemCnt = 5;
						break;
				}
				$.ajax({
					 url : _self._fishListURL
					,type : 'POST'
					,data : {
						 'PAGE' : page
						,'PERPAGE' : itemCnt
						,'TYPE_CD' : fishType
						,'searchType' : _self.$searchType.val()
						,'word' : _self.$word.val()
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('fishList') ) {
				    		var fishList = data.fishList;
				    		var dataLen = data.total - ((page-1) * itemCnt);
				    		$.each( fishList, function(idx, data) {
				    			data.FISH_DATE = jdg.util.replaceDate(data.FISH_DATE, 'yymmdd');
				    			data.IDX = dataLen;
				    			dataLen--;
				    		});
				    		
				    		// 리스트 초기화
				    		_self.list.createList( fishList, 'GALR_ID');
				    		
				    		 //페이징 초기화
				    		$('#fishListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,onclick:function(e,page){
									_self.$page.val(page);
									_self.movePage();
								}
							});
				    		
				    		// 리스트 카운트 초기화
				    		_self.$listPerItemSel.val(itemCnt);
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				// 조과목록조회
				this.getFishList();
				
				// 화면 초기화
				this.initMainList();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});