defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveManUpdateURL = $('#reserveManUpdateURL').val();
				this.$mfyBtn = $('#reserveManMfyBtn');
				this.$cancelBtn = $('#reserveManCancelBtn');
			},
			'setEvent'		: function() {
				var _self = this;
				
				//등록/수정
				_self.$mfyBtn.click(function() {
					Bplat.view.loadPage( _self._reserveManUpdateURL  );
				});
				
				//취소
				_self.$cancelBtn.click(function(){
					opener.Bplat.view.closePopup();
					window.close();
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[reserve_man_popup] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[reserve_man_popup] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[reserve_man_popup] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[reserve_man_popup] onDestroy Method' );
			}		
	  }
});
