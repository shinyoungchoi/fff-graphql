defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipId = $('#ship_id').val();
				this._scheduleMainURL = $('#scheduleMainURL').val();
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleInsertURL = $('#scheduleInsertURL').val();
				// element
				this.$listContainer = $('#scheduleRegisterConatiner');
				this.$listTemplate =  $('#scheduleRegisterTempalte');
				this.$registerRow = this.$listTemplate.find('.registerRow');
				this.$btnRow = this.$listTemplate.find('.buttonRow');
				
				this.$btnAdd = $('.jdg-btn-add');
				
				this.$insertForm = $('#scheduleInsertForm');
				this.$insertBtn = $('#scheduleInsertBtn');
				this.$cancelBtn = $('#registerCancelBtn');
				this.$prevSchduleFrom = $('#prevSchedule');
				this.$prevSchduleTo = $('#prevSchedule2');
				this.$prevSchduleBtn = $('#prevScheduleBtn');
				// resultList
				this.$resultListContainer = $('#scheduleResultConatiner');
				this.$resultRow = this.$listTemplate.find('.resultRow');
				this.$nodata = this.$listTemplate.find('.nodateRow');
				this.resultList = new component.List({
					 'container' : this.$resultListContainer
					,'template' : this.$resultRow
					,'nodata' : this.$nodata
				});
				this.$resultConfirmBtn = $('#scheduleResultConfirm');
				this.$resultContinue = $('#scheduleResultContinue');
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 지난출조 DatePicker
				_self.$prevSchduleFrom.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				
				_self.$prevSchduleTo.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
			
				// 지난 출조 정보 가져오기
				_self.$prevSchduleBtn.click( function() {
					// 해당 Calendar의 출조 스케쥴 조회
					var startDate = _self.$prevSchduleFrom.val().replaceAll('-','');
					var endDate = _self.$prevSchduleTo.val().replaceAll('-','');
					
					if( '' === startDate ) {
						alert("시작일을 선택해 주세요");
						return false;
					}
					
					if( '' === endDate ) {
						alert("종료일을 선택해 주세요");
						return false;
					}
					
					if( startDate > endDate ) {
						alert("종료일이 시작일보다 과거입니다.");
						return false;
					}

					if( !confirm(startDate+' ~ '+endDate+'\n까지의 출조정보를 가져오시겠습니까?') ) return;
					
					_self.getScheduleList({'FROM_DATE' : startDate ,'TO_DATE' : endDate});
				});

				// 출조등록
				_self.$insertForm.submit( function() {
					_self.insertSchedule();
					return false;
				});
				
				// 등록취소
				_self.$cancelBtn.click( function() {
    				// 출조메인으로 이동
    				Bplat.view.loadPage( _self._scheduleMainURL );
    				return false;
				});

				// 행추가
				_self.$btnAdd.click( function() {
					var lst = _self.$listContainer;
					
					for (var i=0; i<5; i++)
						{
							var $regRow = _self.$registerRow.clone();
							$regRow.find('[data-key=SCHD_DATE]').datepick({dateFormat:'yyyy-mm-dd'});
							$regRow.attr('index', lst.find('th').length);
							lst.append( $regRow );
						}
						
				});
				
				
				// 등록완료
				_self.$resultConfirmBtn.click( function() {
					// 출조메인으로 이동
					Bplat.view.loadPage( _self._scheduleMainURL );
				});
				// 계속등록
				_self.$resultContinue.click( function() {
					location.reload();
				});
				
				/**
				 * COPY EVENT
				 */
				// 날짜 copy
				$('.scheduleDateCopy').click(function(){
					_self.copyRowData('SCHD_DATE','날짜');
				});
				
				// 시간 copy
				$('.scheduleTimeCopy').click(function(){
					_self.copyRowData('SCHD_TIME','시간');
				});

				// 제목 copy
				$('.subTitleCopy').click(function(){
					_self.copyRowData('SUB_TITLE','제목');
				});
				
				// 출조위치 copy
				$('.locDescCopy').click(function(){
					_self.copyRowData('LOC_DESC','출조위치');
				});
				
				// 승선인원 copy
				$('.psgrCntCopy').click(function(){
					_self.copyRowData('PSGR_CNT','승선인원');
				});
				
				// 어종 copy
				$('.fishKindCopy').click(function(){
					_self.copyRowData('FISH_KIND','어종');
				});
				
				// 채비 copy
				$('.prepareCopy').click(function(){
					_self.copyRowData('PREPARE','채비');
				});
				
				// 1인비용 copy
				$('.feeManCopy').click(function(){
					_self.copyRowData('FEE','1인비용');
				});
				
				// 독선비용 copy
				$('.feeWholeCopy').click(function(){
					_self.copyRowData('FEE_WHOLE','독선비용');
				});
				
				// 설명 copy
				$('.descrCopy').click(function(){
					_self.copyRowData('DESCR','설명');
				});
				
				// ROW copy
				_self.$listContainer.delegate('.btn', 'click', function(){
					var $this = $( this );
					var mode = $this.attr('mode');
					// 행복사
					if( 'rowCopy' === mode ) {
						if( !confirm('아래 행으로 내용을 복사하시겠습니까?') ) return;
						var $listForm = _self.$listContainer;
						var rowIndex = $this.parent().parent().attr('index');
						var nextIndex = Number(rowIndex) + 1;
						var $copyRow = $listForm.find('[index='+rowIndex+']');
						
						var $regRow = _self.$registerRow.clone();
						$regRow.find('[data-key=SCHD_DATE]').datepick({dateFormat:'yyyy-mm-dd'});						
						
						var ctr = $('#scheduleRegisterConatiner tr')[rowIndex * 2 + 1];
						
						$(ctr).after($regRow);						

						var comps = $copyRow.find('select,textarea,input')

						for (var i=0; i < comps.length; i++)
						{
							var comp = $(comps[i]);
							var dataKey = comp.data('key');
							
							if (dataKey != null)
							{
								$regRow.find('[data-key="' + dataKey + '"]').val(comp.val());
							}
							
						}
						
						$trs = $listForm.find('tr');
						
						for (var i=0; i < $trs.length; i++)
						{
							$($trs[i]).attr('index', Math.floor(i / 2));
						}

					}
					// 삭제
					else if( 'rowDel' === mode ) {						
						if (confirm('선택된 행을 삭제하시겠습니까?'))
							{							
								var $listForm = _self.$listContainer;
								var rowIndex = $this.parent().parent().attr('index');
								$listForm.find('[index='+rowIndex+']').remove();							
							}
					}

					// 출조위치 레이어
					else if( 'locDesc' === mode ) {
						_self.openLayerPopup('locDescLayer', $this );
					}
					// 어종 레이어
					else if( 'fishkind' === mode ) {
						_self.openLayerPopup('fishKindLayer', $this );
					}
					// 채비 레이어
					else if( 'prepare' === mode ) {
						_self.openLayerPopup('prepareLayer', $this );
					}
					return false;
				});
			},
			// 출조 등록 데이터 COPY 처리
			'copyRowData' : function( type, label ) {
				var _self = this;
				var $listForm = _self.$listContainer;
				var $copyRow = $listForm.find('[index=0]');
				var nMax = $listForm.find('tr:last').attr('index');
				if( 'SCHD_DATE' === type ) {
					var beforeDate = $copyRow.find('[data-key='+type+']').val();
					if( '' !== beforeDate ) {
						if( confirm('모든 열의 '+label+'값을 복사하시겠습니까?') ) {
							for( var i=1 ; i <= nMax ; i++ ) {
								var $row = $listForm.find('[index='+i+']');
								beforeDate = jdg.util.tommorow(beforeDate);
								$row.find('[data-key='+type+']').val( beforeDate );
							}
						}
					}
				} else if( 'SCHD_TIME' === type ) {
					var beforeHour = $copyRow.find('.hour').val();
					var beforeMinute = $copyRow.find('.minute').val();
					if( confirm('모든 열의 '+label+'값을 복사하시겠습니까?') ) {
						for( var i=1 ; i <= nMax ; i++ ) {
							var $row = $listForm.find('[index='+i+']');
							$row.find('.hour').val( beforeHour );
							$row.find('.minute').val( beforeMinute );
						}
					}
				} else if( 'PSGR_CNT' === type ) {
					var beforeData = $copyRow.find('[data-key='+type+']').val();
					if( confirm('모든 열의 '+label+'값을 복사하시겠습니까?') ) {
						for( var i=1 ; i <= nMax ; i++ ) {
							var $row = $listForm.find('[index='+i+']');
							$row.find('[data-key='+type+']').val( beforeData );
						}
					}
				} else {
					var beforeData = $copyRow.find('[data-key='+type+']').val();
					if( '' !== beforeData ) {
						if( confirm('모든 열의 '+label+'값을 복사하시겠습니까?') ) {
							for( var i=1 ; i <= nMax ; i++ ) {
								$listForm.find('[index='+i+']').find('[data-key='+type+']').val( beforeData );
							}
						}
					}
				}
			},
			// 출조스케줄 등록
			'insertSchedule' : function() {
				var _self = this;
				var insertFlag = false;
				var $insertForm = _self.$insertForm;
				var insertArray = [];
				var nMax = Number( $insertForm.find('tr:last').attr('index') );
				for( var i=0 ; i <= nMax ; i++ ) {
					var $regRow = $insertForm.find('[index='+i+']');
					// 출조일 체크
					var $schdDate = $regRow.find('[data-key=SCHD_DATE]');
					var schdDate = $schdDate.val();
					// 출조날짜가 등록된 데이터만 입력
					if( undefined != schdDate && '' !== schdDate ) {
						// validation
						if( !jdg.util.validator( $regRow, true ) ) return false;						
						
						var feeMan = $regRow.find('[data-key=FEE]').val();
						
						if (feeMan < 10000)
						{
							alert('1인 선비는 만원이하로 입력할수 없습니다.');
							return;
						}
						
						var insertParam = {
							  'SHIP_ID' : _self._shipId
							, 'SCHD_DATE' : schdDate.replaceAll('-','')
							, 'SCHD_TIME' : $regRow.find('.hour option:selected').val() + $regRow.find('.minute option:selected').val()
							, 'SUB_TITLE' : $regRow.find('[data-key=SUB_TITLE]').val()
							, 'DESCR' : $regRow.find('[data-key=DESCR]').val()
							, 'PSGR_CNT' : $regRow.find('[data-key=PSGR_CNT] option:selected').val()
							, 'FEE' : $regRow.find('[data-key=FEE]').val()
							, 'FEE_WHOLE' : $regRow.find('[data-key=FEE_WHOLE]').val()
							, 'STATUS_CD' : '113_110'
							, 'LOC_DESC' : $regRow.find('[data-key=LOC_DESC]').val()
							, 'FISH_KIND' : $regRow.find('[data-key=FISH_KIND]').val()
							, 'PREPARE' : $regRow.find('[data-key=PREPARE]').val()
						};
						insertArray.push( insertParam );
					}
				}
				// 중복시간 체크
				for( var i=0,iSize=insertArray.length; i < iSize; i++ ) {
					var beforeDate = insertArray[i].SCHD_DATE +""+ insertArray[i].SCHD_TIME;
					for( var j=0,jSize=insertArray.length; j < jSize; j++ ) {
						if( i != j ) {
							var afterDate = insertArray[j].SCHD_DATE +""+ insertArray[j].SCHD_TIME;
							if( i != j && beforeDate == afterDate ) {
								alert( jdg.util.replaceDate(beforeDate) + ' 출조시간이 중복됩니다.\n변경 후 다시 등록해주세요');
								return false;
							}
						}
					}
				}
				if( confirm('등록하시겠습니까?') ) {
					$.ajax({
						 url : _self._scheduleInsertURL
						,type : 'POST'
						,data : {
							'insertData' : JSON.stringify( insertArray )
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	_self.initScheduleResult( data.resultList );
					    }
					});
				}
			},
			// 지난 출조정보 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var defaultParam = {
					 'SHIP_ID' : _self._shipId
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		_self.initScheduleRegisterList(data.scheduleList);
				    	}
				    }
				});
			},
			// 출조 등록 목록 초기화
			'initScheduleRegisterList' : function( scheduleList ) {
				var _self = this;
				_self.$listContainer.empty();
				if( undefined != scheduleList && scheduleList.length > 0 ) {
					// 지난 출조정보가 1개 이상일경우 해당 데이터로 초기화
					for( var i=0 ; i < scheduleList.length ; i++ ) {
						var scheduleData = scheduleList[i];
						var $regRow = _self.$registerRow.clone();
						$regRow.find('[data-key=SCHD_DATE]').datepick({dateFormat:'yyyy-mm-dd'});
						$regRow.find('[data-key=SCHD_DATE]').val( jdg.util.replaceDate(scheduleData.SCHD_DATE) );
						var schdTime = scheduleData.SCHD_TIME;
						$regRow.find('.hour').val( schdTime.substr(0,2));
						$regRow.find('.minute').val( schdTime.substr(3,4));
						$regRow.find('[data-key=SUB_TITLE]').val(scheduleData.SUB_TITLE);
						$regRow.find('[data-key=LOC_DESC]').val(scheduleData.LOC_DESC);
						$regRow.find('[data-key=PSGR_CNT]').val(scheduleData.PSGR_CNT);
						$regRow.find('[data-key=FISH_KIND]').val(scheduleData.FISH_KIND);
						$regRow.find('[data-key=PREPARE]').val(scheduleData.PREPARE);
						$regRow.find('[data-key=FEE]').val(scheduleData.FEE);
						$regRow.find('[data-key=FEE_WHOLE]').val(scheduleData.FEE_WHOLE);
						$regRow.find('[data-key=DESCR]').val(scheduleData.DESCR);
						$regRow.attr('index', i);
						_self.$listContainer.append( $regRow );
					}
				} else {
					// 7일치 초기화
					for( var i=0 ; i < 7 ; i++ ) {
						var $regRow = _self.$registerRow.clone();
						$regRow.find('[data-key=SCHD_DATE]').datepick({dateFormat:'yyyy-mm-dd'});
						$regRow.attr('index', i);
						_self.$listContainer.append( $regRow );
					}
				}
			},
			// 출조등록결과 목록 초기화 및 화면 전환
			'initScheduleResult' : function( resultList ) {
				var _self = this;
				_self.resultList.createList( resultList, 'SCHD_ID', function( data, $row ) {
					$row.find('[data-key=SCHD_DATE]').text( jdg.util.replaceDate(data.SCHD_DATE + data.SCHD_TIME) );
					var $result = $row.find('[data-key=result]');
					if( data.result == 1 ) {
						$result.addClass('jdg-success');
						$result.text('성공');
					} else {
						$result.addClass('jdg-fail');
						$result.html('실패<br/>(출조시간중복)');
					}
				});
				// 화면전환
				$('#insertContentArea').hide();
				$('#resultContentArea').show();
			},
			// 레이어팝업
			'openLayerPopup' : function( id, $btn ) {
				var _self = this;
				var $layerContainer = $('#layerContainer');
				// 초기화
				$layerContainer.empty();
				// 레이어팝업생성
				var offSet = $btn.offset();
				var $layer = $('#layerTemplate').find('.'+id).clone();
				$layer.find('.jdg-btn-close').click( function() {
					$layer.remove();
				});
				$layer.find('.item').click( function() {
					var $this = $(this);
					var $input = $btn.prev();
					var beforeVal =  $input.val();
					var val = ' ' + $this.find('strong').text() + ' ';
					if( beforeVal.search(val) == -1 ) {
						if( '' === beforeVal ) {
							$input.val( val );
						} else { 
							$input.val( beforeVal + ',' + val );
						}
					}
				});
				$layer.css( 'top', (offSet.top+$btn.height()) );
				var pageWidth = $('body').width()/2;
				if( pageWidth < offSet.left ) $layer.css( 'left', (offSet.left-$layer.width()+$btn.width()) );
				else $layer.css( 'left', offSet.left );
				$layerContainer.append( $layer );
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_register] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 목록 초기화
				this.initScheduleRegisterList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_register] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_register] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_register] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_register] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_register] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_register] onDestroy Method' );
			}		
	  }
});
