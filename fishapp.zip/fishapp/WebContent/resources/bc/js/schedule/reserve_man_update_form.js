defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveManURL = $('#reserveManURL').val();
				this._reserveManListURL = $('#reserveManListURL').val();
				this._reserveManUpdateURL = $('#reserveManUpdateURL').val();
				this.$updateBtn = $('#reserveManUpdateBtn');
				this.$cancelBtn = $('#reserveManCancelBtn');
				// element
				this.$listContainer = $('#reserveManListContainer');
				this.$insertRow = $('#reserveManListTemplate').find('.insertRow');
				// static variable
				this.rsvId = $('#rsvId').val();
				this.manCnt = $('#manCnt').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				//등록/수정
				_self.$updateBtn.click(function() {
					_self.updateReserveMan();
				});
				
				//취소
				_self.$cancelBtn.click(function(){
					opener.Bplat.view.closePopup();
					window.close();
				});
				
				// 승선명부 내용 삭제
				_self.$listContainer.delegate('.deleteBtn', 'click', function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					var $row = _self.$listContainer.find('[index='+$( this ).attr('deleteRow')+']');
	    			$row.find('[data-key=NAME]').val('');
	    			$row.find('[data-key=REG_NO]').val('');
	    			$row.find('[data-key=TEL]').val('');
	    			$row.find('[data-key=ADDR]').val('');
				});
			},
			// 현재 승선명부 목록 갱신
			'updateReserveMan' : function() {
				var _self = this;
				var $listForm = _self.$listContainer;
				var insertArray = [];
				var nMax = $listForm.find('tr:last').attr('index');
				for( var i=0; i <= nMax ; i++ ) {
					var $regRow = $listForm.find('[index='+i+']');
					// validation
					if( !jdg.util.validator( $regRow, true ) ) return false;
					// 이름이 등록되어야 승선명부가 등록됨
					var name = $regRow.find('[data-key=NAME]').val();
					if( '' !== name ) {
						var insertParam = {
							  'RSV_ID' : _self.rsvId
							, 'MAN_SEQ' : (i+1)+""
							, 'NAME' : name
							, 'REG_NO' : $regRow.find('[data-key=REG_NO]').val()
							, 'TEL' : $regRow.find('[data-key=TEL]').val()
							, 'ADDR' : $regRow.find('[data-key=ADDR]').val()
						};
						insertArray.push( insertParam );
					}
				}
				$.ajax({
					 url : _self._reserveManUpdateURL
					,type : 'POST'
					,data : {
						 'RSV_ID' : _self.rsvId
						,'insertData' : JSON.stringify( insertArray )
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	Bplat.view.loadPage( _self._reserveManURL  );
				    }
				});
			},
			// 예약인원만큼 ROW 초기화
			'initReserveManList' : function() {
				var _self = this;
				for( var i=0, iSize=Number(_self.manCnt) ; i < iSize ; i++ ) {
					var $row = _self.$insertRow.clone();
					$row.attr('index',i);
					$row.find('.deleteBtn').attr('deleteRow',i);
					_self.$listContainer.append( $row );
				}
				_self.getReserveManList();
			},
			// 현재 예약의 기존 승선명부 데이터를 목록에 셋팅
			'getReserveManList' : function() {
				var _self = this;
				$.ajax({
					 url : _self._reserveManListURL
					,type : 'POST'
					,data : { 'RSV_ID' : _self.rsvId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('reserveManList') ) {
				    		var reserveList = data.reserveManList;
				    		for(var i=0,iSize=reserveList.length-1; i <= iSize; i++) {
				    			var $row = _self.$listContainer.find('[index='+i+']');
				    			$row.find('[data-key=NAME]').val( reserveList[i].NAME );
				    			$row.find('[data-key=REG_NO]').val( reserveList[i].REG_NO );
				    			$row.find('[data-key=TEL]').val( reserveList[i].TEL );
				    			$row.find('[data-key=ADDR]').val( reserveList[i].ADDR );
				    		}
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[reserve_man_popup] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 목록 초기화
				this.initReserveManList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[reserve_man_popup] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[reserve_man_popup] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[reserve_man_popup] onDestroy Method' );
			}		
	  }
});
