defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();
				this._session = $('#session').val();

				this.$divControl = $('.divControl');		
				this.$emo_select_con = $('.emo_select_con');	
				
				this.prev = null;
				this.next = null;
				this.auth = 'N';
				this.page = '';
				this.postId;
				
				this.emo_select_con_visible = false;
				
				this.$insertBtn = $('#insertBtn');
				this.$updateBtn = $('#updateBtn');
				this.$deleteBtn = $('#deleteBtn');
				
				this.$chkSecret = $('#chkSecret');

			},
			'setEvent'		: function() {
				var _self = this;

				
				$('#reply_content').live('focus', function() {
					
		        	if (_self._session == "")
		        	{
		        		showLoginBox(null, false);
		        	}
		        	
				});

		        $(".emo_img").on("click", function(event){
		        	
		        	if (_self.emo_select_con_visible)
		        	{
		        		_self.$emo_select_con.hide();
		        	}
		        	else
		        	{
		        		_self.$emo_select_con.show();
		        	}
		        	
		        	_self.emo_select_con_visible = !_self.emo_select_con_visible;
		        });
		        

		        
		        $(".cmt_reg_btn").on("click", function(event){
		        	
		        	if (_self._session == "")
		        	{
		        		showLoginBox(null, false);
		        	}
		        	
		        	
		        	var content = $('#reply_content').val();
		        	
		        	if (content.length < 5)
		        	{
		        		alert('댓글은 5자 이상 입력하십시오.');
		        		return;
		        	}
		        	
		        	var emo_src = $(".emo_img img").attr('src');
		        	
		        	var emo_idx = emo_src.indexOf('emoticon') + 8;
		        	
		        	var emo_cd = emo_src.substr(emo_idx,2);
		        	
		        	var chkselect = _self.$chkSecret.is(':checked') ? "Y" : "N";
					
					$.ajax({
						 url : '../reply/insertReply'
						,type : 'POST'
						,data : {
							 'POST_ID' : _self.postId
							 ,'REPLY_ID' : ""
							 ,'CONTENT': content
							 , 'EMOTICON' : emo_cd
							 , 'SECRET_YN' : chkselect
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
				    		alert('등록 되었습니다');
				    		location.reload();
					    }
					});				
					
				});
		        
		        $("#writerInfo").on("click", function(event){
		        	
		        	var vi = $('div.cdt_view_info');
		        	
		        	if(vi.is(':hidden') == false)
		        	{
		        		vi.hide();
		        		return;
		        	}
		        	
		        	vi.show();
		        	
		        	if(vi.text() != "")
		        	{
		        		vi.show();
		        		return;
		        	}
		        	
					$.ajax({
						 url : '../bbs/getUserInfo'
						,type : 'POST'
						,data : {
							 'POST_ID' : _self.postId
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	var ui = data.userInfo;					    	
					    	vi.text(ui.MEM_NAME + " " + ui.TEL + " " + ui.EMAIL);					    	
					    }
					});			        	
		        });

		        $("span.replyInfo").live("click", function(event){
		        	
		        	var vi = $(event.target);
		        	vi.removeClass("replyInfo");

					$.ajax({
						 url : '../bbs/getUserInfo'
						,type : 'POST'
						,data : {
							 'POST_ID' : _self.postId
							 ,'REPLY_ID' : vi.attr('replyId')
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	var ui = data.userInfo;					    	
					    	vi.text("[ " + ui.MEM_NAME + " " + ui.TEL + " " + ui.EMAIL + " ]");					    	
					    }
					});			        	
		        });		        
		        
		        $(".emo_select_con span").on("click", function(event){
		        	
		        	var src = $(this).find('img').attr('src');
		        	
		        	$(".emo_img img").attr('src', src);
		        	
		        	_self.emo_select_con_visible = false;
		        	
		        	_self.$emo_select_con.hide();
		        });		        
				
				
				
				$(".divControl>img").click(function(event){
					
					var alt = this.alt;
					
					if (alt == "수정")
					{
						location.href = 'update_form?POST_ID=' + _self.postId;
					}
					else if (alt == "삭제")
					{

						if(!confirm("삭제하시겠습니까?")) {return;}

						$.ajax({
							 url : 'delete'
							,type : 'POST'
							,data : {
								 'POST_ID' : _self.postId
							}
						    ,dataType : 'json'
						    ,success : function( data ) {
						    	if( data.hasOwnProperty('result') ) {
						    		alert('삭제 되었습니다');				    		
						    		location.href = 'main#' + _self.page;
						    	}
						    }
						});
					}
					
				});
				
				$('.prev_btn').click(function(event){
					
					if (_self.prev)
					{
						location.href = 'detail_form?POST_ID=' + _self.prev;
					}
					else
					{
						alert('이전 글이 없습니다.');
					}
				});
				
				$('.next_btn').click(function(event){
					
					if (_self.next)
					{
						location.href = 'detail_form?POST_ID=' + _self.next;
					}
					else
					{
						alert('다음 글이 없습니다.');
					}					
				});
	
				$('.list_btn').click(function(event){
					
					location.href = 'main#' + _self.page;
				});
				
				
		        $(".rep_btn").live('click', function(event){
		        	
					if(!confirm("삭제하시겠습니까?")) {return;}
		        	
		        	var replyId = $(this).data('pid');
		        	
		        	var liComp = $(this).parent().parent();
		        	
					$.ajax({
						 url : '../reply/deleteReply'
						,type : 'POST'
						,data : {
							 'REPLY_ID' : replyId
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	liComp.remove();
				    		alert('삭제 되었습니다');				    		
					    }
					});	
		        });
			},
			
			'loadBbs' : function(postId)
			{
				var _self = this;
				
				_self.postId = postId;
				
				var defaultParam = {
						 'POST_ID' 		: postId
					};
				
				$.ajax({
					 url : 'detailview'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data )
					    {
				    		var dtl = data.detailBbs;
				    		var content = dtl.CONTENT;
				    		
							$('.title').text(dtl.TITLE);
							$('.nickname').text(dtl.NICK_NAME);
							$('.created_at').text(dtl.CREATED_AT);
							
							$('.bbs_content').html(dtl.CONTENT);
							
							_self.prev = dtl.PREV_ID;
							_self.next = dtl.NEXT_ID;
							
							
							if (dtl.TYPE_CD == '108_130')
							{
								_self.page = 'c' + dtl.PAGE;
								
								$('.cdt_tab_menu li:eq(0)').attr('class','on');
							}
							else
							{
								_self.page = 'q' + dtl.PAGE;
								$('.cdt_tab_menu li:eq(1)').attr('class','on');
							}
							
			    			if (dtl.updateAuth == "Y")
			    			{
			    				_self.$divControl.show();
			    			}
			    			else if (dtl.deleteAuth == "Y")
			    			{
			    				_self.$divControl.show();
			    				_self.$divControl.find('#updateBtn').hide();
			    			}
			    			
			    			var lst = data.replyList;
			    			var replyCon = $('.cmt_list_con');
			    			
			    			var btn;
			    			
			    			if (lst != null && lst.length > 0)
			    			{
			    				var template = $("#replyTemplate").html();
			    				
			    				for (var i=0 ; i < lst.length; i++)
			    				{
			    					var temp = template;
			    					
			    					temp = temp.replace('#nickname#', lst[i].CREATED_BY);
			    					temp = temp.replace('#emo_cd#', lst[i].EMOTICON);
			    					temp = temp.replace('#created_at#', lst[i].CREATED_AT);
			    					temp = temp.replace('#reply_content#', lst[i].CONTENT);
			    					temp = temp.replace('#replyId#', lst[i].REPLY_ID);
			    					
			    					btn = "";
			    					
			    					if (_self._session == lst[i].REPLY_CREATED_BY)
			    					{
			    						btn = '&nbsp;&nbsp;<span id="btn_reply_delete" class="rep_btn" data-pid="' + lst[i].REPLY_ID + '"><img src="https://img.fishapp.co.kr/legacy/wp/cmt_delete_btn.png" alt="삭제"/></span>';
			    					}
			    					
			    					temp = temp.replace('#btn#', btn);
			    					
			    					replyCon.append(temp);
			    				}
			    			}
							

					    }
				});
				
			},

			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();				
				
				var sPageURL = window.location.search.substring(1);
				
				var postId = sPageURL.replace('POST_ID=','');	
				
				if (postId != null && postId != '')
				{
					_self.loadBbs(postId);
				}


			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});