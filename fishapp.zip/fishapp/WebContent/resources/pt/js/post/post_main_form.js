defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postListURL 		= $('#postListURL').val();
				this.postDetailFormURL 	= $('#postDetailFormURL').val();
				this.imageURL 			= $('#imageURL').val();
				this.noImageURL 		= $('#noImageURL').val();
				this.total 		 		= $('#total').val();
				// element
				this.$listContainer 			= $('#postListContainer');
				this.$mobileListContainer 		= $('#postMobileListContainer');
				this.$postListTemplate 			= $('#postListTemplate');
				this.$pcListTemplate 			= $('#postListTemplate').find('.pcListRow');
				this.$mobileListTemplate 		= $('#postListTemplate').find('.mobileListRow');
				this.$nodataTemplate 			= $('#postListTemplate').find('.nodata');
				this.$selectPage 				= $('#postMainSelectPage');
				// 게시 종류 전역 설정
				this.MAIN_TYPE 				= $('#TYPE_CD').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$listContainer.delegate( ".clickEvent", "click", function() {
					Bplat.view.loadPage( 
						_self.postDetailFormURL 
						+ '?POST_ID=' +  $(this).parent().parent().attr('rowKey') 
					);	
				});
				
				_self.$mobileListContainer.delegate("tr", "click",  function() {
					Bplat.view.loadPage( 
							_self.postDetailFormURL 
							+ '?POST_ID=' +  $(this).attr('rowKey') 
						);	
				});
			},
			'pageInit'		: function() {
				var _self = this;
				/*var hash = location.hash;
				if( '' == hash ) {
					// set hash
					location.hash = 1;
				} else {
					// 목록조회
					_self.getPostList( hash.replace('#','') );
				}*/
				
				
			},
			// 공지사항 목록 조회
			'getPostList' : function( page ) {
				var _self = this;
				// defaultParam 세팅
//				var page 		= _self.page == '' ? 1 : _self.page;
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: _self.MAIN_TYPE
				};
				$.ajax({
					 url : _self.postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('postList') ) {
				    		// 초기화
				    		_self.$listContainer.empty();
			    			_self.$mobileListContainer.empty();
				    		var list = data.postList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$nodataTemplate.clone();
				    			_self.$listContainer.append( $nodata );
				    			_self.$mobileListContainer.append( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $pcRow = _self.$pcListTemplate.clone();
					    			var $mobileRow = _self.$mobileListTemplate.clone();
					    			
					    			$pcRow.attr( 'rowKey', data.POST_ID );
					    			$mobileRow.attr( 'rowKey', data.POST_ID );
					    			// 번호
					    			data.rowNum = rowCount;
					    			$pcRow.find('[data-key=rowNum]').text( data.rowNum );
					    			rowCount--;
					    			// 섬네일
					    			if( undefined != data.IMG_ID ) {
					    				$pcRow.find('[data-key=IMG_ID]').attr( 'src', _self.imageURL + data.IMG_ID + '/84' );
					    				$mobileRow.find('[data-key=IMG_ID]').attr( 'src', _self.imageURL + data.IMG_ID + '/84' );
					    			}else{
					    				$pcRow.find('[data-key=IMG_ID]').attr( 'src', _self.noImageURL );
					    				$mobileRow.find('[data-key=IMG_ID]').attr( 'src', _self.noImageURL );
					    			}
					    			// 제목
					    			$pcRow.find('[data-key=TITLE]').text( data.TITLE );
				    				$mobileRow.find('[data-key=TITLE]').text( data.TITLE );
					    			// 등록일
					    			if( data.UPDATED_AT ) {	// 업데이트 시간이 있을경우
					    				data.UPDATED_AT = data.UPDATED_AT.substr(0, 10);
					    				$pcRow.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
					    				$mobileRow.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
					    			}else{	// 없을경우
					    				data.CREATED_AT = data.CREATED_AT.substr(0, 10);
					    				$pcRow.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    				$mobileRow.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			}
					    			
					    			_self.$listContainer.append( $pcRow );
					    			_self.$mobileListContainer.append( $mobileRow );
					    		});
					    		
					    	}
				    		
				    		// 페이징 초기화
				    		$('#postListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,itemClass: 'jdg-btn-page'
								,prevClass: 'jdg-btn-page-prev'
								,nextClass: 'jdg-btn-page-next'
								,firstClass: 'jdg-btn-page-first'
								,lastClass: 'jdg-btn-page-last'
								,onclick:function(e,page){
//									location.hash = page;
									_self.getPostList( page );
								}
							});
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
//				_self.pageInit();
				_self.getPostList( '1' );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
