defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				
				// element
				this.$fishList = $('#fishList');
				this.$postList = $('#postList');
				this.$selectArea = $('#selectArea');
				this.$selectPort = $('#selectPort');
				this.$cptnImg = $('#cptnImg');
				this.$cptnFishImg = $('.cptnFishImg');
				this.$shipImg = $('#shipImg');
				this.$shopImg = $('#shopImg');
				this.$btnSearch = $("#btnSearch");

			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$selectArea.change( function()
						{
							_self.changeArea();
						});
				
				_self.$btnSearch.click( function() {

					_self.searchShipList();
					
				});				
			},
			
			"changeArea" : function()
			{
				
				var areaCode = $("#selectArea option:selected").val();
				$('#selectPort option[value!=""]').remove();
				
			    var options = $('#selectPort_options option[data-pcode=' + areaCode +']').clone();
			    $('#selectPort').append(options);
			},
			
			
			// 선박검색
			'searchShipList' : function() {
				
				// 로더 생성
				//showLoader();	
				
				var _self = this;				
				var tbl = $("#tblShipSearch tbody");
				
				var shipName = $("#shipName").text();
				
				var areaCode = _self.$selectArea.val();
				var portCode = _self.$selectPort.val();
				var shipName = $("#shipName").val().trim();
				
				if (areaCode == "" && portCode == "" && shipName == "")
					{
					 alert("해역 또는 항구를 선택하거나 선박이름을 한글자 이상 입력하시고 검색하세요.");
					 return;
					}
	

				var defaultParam = {'AREA_CODE' : areaCode, 'PORT_CODE' : portCode, 'SHIP_NAME' : shipName};

				
				//$.extend( defaultParam, param );
				$.ajax({
					 url : "/pt/searchShipList.json"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	tbl.empty();
				    	
				    	var list = data.list;
				    	
				    	$("#tblShipSearch").show();
				    	
				    	if (list.length == 0)
				    		{
				    			$("#divNoShip").show();
				    			$("#tblShipSearch").hide();				    			
				    		}
				    	else
				    		{
				    			$("#divNoShip").hide();
				    			$("#tblShipSearch").show();
				    		}

			    		$.each( list, function( idx, data ) {

			    			tbl.append("<tr onClick=\"window.open('/pw/" + data.BIZ_ID + "/" + data.SHIP_ID + "'); void(0)\"><td>"+ data.AREA_NAME +"</td><td>" + data.PORT_NAME  + "</td><td>" + data.SHIP_NAME  + "</td></tr>");

			    		});
			    		
			    		//hideLoader();
				    }
				});	
				
			},			
			
			//date 포맷 셋팅
			'setDateFormat': function() {
				var _self = this;
				
				//조행기
				var dates = _self.$fishList.find('.jdg-data-date');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(4,2) - 1;
					var day = $(dates[i]).text().trim().substr(6,2);
					
					$(dates[i]).text(new Date(year, month, day).toDateStr("mmdd","MM.DD(D)"));
					$(dates[i]).show();
				}
				
				
				//공지사항 출조일
				dates = _self.$postList.find('td');
				
				if(_self.$postList.find('td').attr('colspan') != "2"){//등록된 공지사항이 있을때
					for(var i = 0 ; i < dates.size(); i ++){
						var year = $(dates[i]).text().trim().substr(0,4);
						var month = $(dates[i]).text().trim().substr(5,2) - 1;
						var day = $(dates[i]).text().trim().substr(8,2);
						
						$(dates[i]).text(year+"."+month+"."+day );
					}
				}
				
			},
			
			//이미지 태그를 컨테이너 안에 최대한 비율에 맞게 리사이즈
			'setImgRatio' : function( p_param, _viewClass ) {
				var _self = this;
				
				jdg.util.setImgRatio(_self.$cptnImg, _self.$cptnImg.attr('imgWidth'), _self.$cptnImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shipImg, _self.$shipImg.attr('imgWidth'), _self.$shipImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shopImg, _self.$shopImg.attr('imgWidth'), _self.$shopImg.attr('imgHeight'));
				
				if(_self.$cptnFishImg.size() > 0){
					for(i = 0; i < _self.$cptnFishImg.size(); i++){
						jdg.util.setImgRatio(_self.$cptnFishImg[i], _self.$cptnFishImg[i].attr('imgWidth'), _self.$cptnFishImg[i].attr('imgHeight'));
					}
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				this.setDateFormat();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
