defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				//url
				this._updateFishURL = $('#updateFishURL').val();
				this._listFishURL = $('#listFishURL').val();
				this._deleteFishURL = $('#deleteFishURL').val();
				// element
				this.$detailForm = $('#detailForm');
				this.$fishImageList = $('#fishImageList');
				this.$updateBtn = $('#updateBtn');
				this.$deleteBtn = $('#deleteBtn');
				this.$listBtn = $('#listBtn');
				// static variable
				this.fishGalrId = $('#fishGalrId').val();
				this.fishTypeCd = $('#fishTypeCD').val();
				this.fishTypeName =  this.fishTypeCd == '106_120' ? 'member' : 'cptn';
				this.fishGpsLat = $('#fishGpsLat').val();
				this.fishGpsLong = $('#fishGpsLong').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$listBtn.click( function() {
					Bplat.view.loadPage( _self._listFishURL + _self.fishTypeName);
				});
				
				_self.$updateBtn.click( function(){
					Bplat.view.loadPage(_self._updateFishURL + '?GALR_ID=' + _self.fishGalrId );
				});
				
				_self.$deleteBtn.click(function(){
					
					_self.deleteFish();
				});
				
				$(".spanbtn").click(function(event){
					
					var tg = event.currentTarget;
					var replyId = tg.parentNode.id;
					var urlstr;
					var content;					
					
					if (tg.textContent == "[수정]")
					{
						var tmp = tg.parentNode.parentNode;
						var cont = tmp.childNodes[4].childNodes[5];
						var content = cont.textContent;
						
						cont.innerHTML = $("#replyForm").html().replace(/new/g, replyId).replace(/댓글 등록/,"댓글 수정");

						$("textarea[name='" +  replyId + "']").text(content);
						
						_self.setEvent();
						
					}
					else if (tg.textContent == "[삭제]")
					{
						// 삭제확인(아니오를 하면 삭제를 취소함
						if(!confirm("삭제하시겠습니까?")) {return;}
						
						urlstr = "deleteReply";
						
						$.ajax({
							 url : urlstr
							,type : 'POST'
							,data : {
								 'REPLY_ID' : replyId
								 ,'CONTENT': content
							}
						    ,dataType : 'json'
						    ,success : function( data ) {
						    	
						    	
						    	if( data.hasOwnProperty('result') ) {
						    		alert('삭제 되었습니다');						    		
						    		location.reload();

						    	}
						    }
						});						
					}
					
				});

				$("#rpSubmit").click(function(event){
					
					
					var tg = event.currentTarget;
					var replyId = tg.name;
					var urlstr;
					var content = $("textarea[name='" +  replyId + "']").val();
					
					
					
					if (replyId == "new")
						{
							replyId = "";
							urlstr = "insertReply";				
						}
					else
						{
							urlstr = "updateReply";	
						}
					
					$.ajax({
						 url : urlstr
						,type : 'POST'
						,data : {
							 'POST_ID' : _self.fishGalrId
							 ,'REPLY_ID' : replyId
							 ,'CONTENT': content
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
				    		alert('등록 되었습니다');
				    		location.reload();
					    }
					});				
				});
			},
			'createFishMap' : function() {
				var _self = this;
				
				if (_self.fishGpsLat == '' && !$.isNumeric(_self.fishGpsLat))
				{
					$('#naverMap').remove();
					return;
				}
				
				var data = {
					 'GPS_LAT' : _self.fishGpsLat != '' ? _self.fishGpsLat : undefined
					,'GPS_LONG' : _self.fishGpsLong != '' ? _self.fishGpsLong : undefined
				};
				var formWidth = $('.jdg-data-content').width();
				var mapWidth = 400;
				if(formWidth < mapWidth){
					mapWidth = formWidth;
				}
				// 지도생성 (상세용)
				jdg.util.createNaverMap({
					 'mode' : 'search'
					,'container' : _self.$detailForm
					, 'width' : mapWidth
					,'data' : data
				});
			},
			// 조행기 삭제
			'deleteFish' : function() {

				// 삭제확인(아니오를 하면 삭제를 취소함
				if(!confirm("삭제하시겠습니까?")) {return;}
				
				var _self = this;
				$.ajax({
					 url : _self._deleteFishURL
					,type : 'POST'
					,data : {
						 'GALR_ID' : _self.fishGalrId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		Bplat.view.loadPage( _self._listFishURL + _self.fishTypeName);
				    	}
				    }
				});
			},
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_detail_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				// 지도생성
				_self.createFishMap();
				// 비디오 화면 사이즈 자동조절
				resizeMovieFrame();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_detail_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_detail_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_detail_form] onDestroy Method' );
			}		
	  }
});
