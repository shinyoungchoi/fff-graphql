defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._fishUpdateURL = $('#fishUpdateURL').val();
				this._fishUpdateDetailURL = $('#fishUpdateDetailURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$updateForm = $('#memberFishUpdateForm');
				this.$fishDate = $('#fishDate');
				this.$updateBtn = $('#updateFishBtn');
				this.$detailFishBtn = $('#detailFishBtn');
				this.fishgalrId = $('#fishgalrId').val();
				this.fishTypeCd = this.fishgalrId == '106_120' ? '?menuType=mem' : '';
				this.$typeCd;
				this.$movieListRow = $('.movieListRow');
				
				// 파일리스트
				this.fileList  = new component.FileList({
					 'id' : this.$updateForm.attr('id')
					,'container' : this.$updateForm.find('[data-type=IMAGE_LIST]')
				});
			},
			'setEvent'		: function() {
				var _self = this;
			
			_self.$updateBtn.click( function() {
				_self.updateFish();
			});
			
			_self.$detailFishBtn.click( function(){
				Bplat.view.loadPage(_self._fishDetailURL + '?GALR_ID=' + _self.fishgalrId  );
			})
			
			$("select[data-handle]").change(function(evt)
					{
						var tgt = $(evt.target);							
						var hd = tgt.attr('data-handle');
						
						var hdObj = _self.$updateForm.find('input[data-key=' + hd + ']');
						
						if (tgt.val() == "etc")
						{
							hdObj.show();
						}
						else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
						{
							hdObj.hide();
							hdObj.val('');
						}
				
						//debugger;
					}
			);
			
			
			_self.$detailFishBtn.click( function(){
				Bplat.view.loadPage(_self._fishDetailURL + '?GALR_ID=' + _self.fishgalrId  );
			});
			
			_self.$updateForm.delegate("#movieAddBtn","click",function(event)
					{
						event.preventDefault();
						addMovieUrl(_self);
					});
			
			$("[data-type='IMAGE_LIST']").delegate('div.up','click', function() {
				event.preventDefault();
				_self.changeImageIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
			});

			$("[data-type='IMAGE_LIST']").delegate('div.down','click', function() {
				event.preventDefault();
				_self.changeImageIndex(this, +1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
			});
			
			},

			'changeImageIndex' : function(btnObj, c)
			{
				if (c == null || isNaN(c)) return;
				
				var me = $(btnObj).parent().parent();
				var brothers = $("[data-type='IMAGE_LIST']").find('li');
				var cnt = brothers.length;
				var idx = me.index();
				
				if (c == -1)
					{
						if (cnt == 1 || idx == 0) return;		
						brothers.eq(idx - 1).before(me);
					}
				else if (c == +1)
					{
						if (idx == cnt - 1) return;	
						brothers.eq(idx + 1).after(me);		
					}

			},
			
			//조행기 상세 조회
			'getFishDetail' : function( galrId ) {
				var _self = this;
				var $updateForm = _self.$updateForm;
				$.ajax({
					 url : _self._fishUpdateDetailURL
					,type : 'POST'
					,data : {
						'GALR_ID' : galrId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		// 업데이트에서 호출하는 상세 컨트롤러도 <br> 처리되므로 다시 /n 으로 치환

				    		var imgList = detail.imageList;
				    		if( imgList.length > 0 ){
				    			$.each(imgList, function(key, item){
				    				if( item.CONTENT != null && item.CONTENT != undefined )
				    					imgList[key].CONTENT = item.CONTENT.replace(/<br>/g, '\n');
				    			});
				    		}
				    		
				    		var cdate = detail.CREATED_AT.substr(0,10);
				    		var dt = new Date(cdate);
				    		
				    		$("#fishDate").append(new Option(cdate, cdate.replace(/-/g,'')));
				    		
				    		for (var i=0; i < 3; i++)
				    		{
					    		dt.setDate(dt.getDate() - 1);
					    		cdate = dateToString(dt);
					    		$("#fishDate").append(new Option(cdate, cdate.replace(/-/g,'')));				    			
				    		}

				    		
				    		if (detail.SHIP_ID != null)
				    		{
				    			_self.shipId = detail.SHIP_ID;
				    		}
				    		
				    		_self.$typeCd = detail.TYPE_CD;
				    		
				    		var hdr = detail.HEADER_TEXT;
				    		var fot = detail.FOOTER_TEXT;
				    		
				    		if (hdr)
				    		{
				    			hdr = hdr.replace(/<br>/g,'\n').replace(/<\/p>/g,'\n').replace(/<p>/g,'\n');
				    			var temp = "";
				    			try{
				    				temp = $(hdr).text();
				    			}catch(e){}
				    			
				    			detail.HEADER_TEXT = (temp == "") ? hdr : temp;
				    		}

				    		if (fot)
				    		{
				    			fot = fot.replace(/<br>/g,'\n').replace(/<\/p>/g,'\n').replace(/<p>/g,'\n');
				    			
				    			var temp = "";
				    			try{
				    				temp = $(fot).text();
				    			}catch(e){}

				    			detail.FOOTER_TEXT = (temp == "") ? fot : temp;
				    		}
				    		
							// 상세폼셋팅
							jdg.util.detailDataSetting( _self.$updateForm, detail );

							//기타 입력칸 셋팅
							setupEtcInput(_self.$updateForm, detail );	
							
							// 파일리스트 초기화
							_self.fileList = new component.FileList({
								'id' : $updateForm.attr('id')
								,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
							});
							_self.fileList.init(detail.imageList);
							//네비메뉴 하이라이트
							if(detail.TYPE_CD == '106_110'){
								$('#cptnNav').addClass("jdg-selected");
							}else{
								$('#memNav').addClass("jdg-selected");
							}
							
							var formWidth = $('.jdg-input-text').width();
							var mapWidth = 500;
							if(formWidth < mapWidth){
								mapWidth = formWidth;
							}
							// 지도생성 (수정용)
							jdg.util.createNaverMap({
								 'mode' : 'insert'
								,'container' : $updateForm
								,'width' : mapWidth
								,'data' : detail
							});
						}
				    }
				});
			},
			// 조행기 업데이트
			'updateFish' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				var menuType = _self.fishTypeCd;
				var $fishDate = $updateForm.find('[data-key=FISH_DATE]');
				
				// 회원일 경우 출조일은 validation 에서 제외
				if( menuType == _self.MEMBER_FISH ){
					$fishDate.removeAttr('vRequired');
				}
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				var param = autoDataGetter($updateForm);
				var typeCd = _self.$typeCd;
				
				param.TYPE_CD = typeCd;
				param.FISH_DATE = _self.$fishDate.val().replaceAll('-','');
				param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
				param.GALR_ID = $('#fishgalrId').val();				
			
				param.HEADER_TEXT = param.HEADER_TEXT.replace(/\n/g,'<br>');
				param.FOOTER_TEXT = param.FOOTER_TEXT.replace(/\n/g,'<br>');
				
				try
				{	
				
					if (typeCd == "106_120")
					{	
						if (param.SHIP_NAME == undefined)
							param.SHIP_NAME = param.SHIP_ID_TEXT;
						
						if (param.PORT_NAME == undefined)
							param.PORT_NAME = param.PORT_CD_TEXT;
						
						if (param.FISH_NAME == undefined)
							param.FISH_NAME = param.FISH_TYPE_TEXT;	
						
						checkData(param.FISH_TYPE == "","어종을 입력해주십시오.");
						checkData(param.FISH_NAME == "" , "어종을 입력해주십시오.");
						
						checkData(param.FISH_LEN == "" && param.FISH_WEIGHT == "", "길이와 무게 둘중에 하나는 입력해야 합니다.");
						
						checkData(param.PORT_CD == "", "항구를 선택해주십시오.");
						checkData(param.PORT_NAME == "" , "항구명을 입력해주십시오.");
						
						checkData(param.SHIP_ID == "", "선박을 선택해주십시오.");
						checkData(param.SHIP_NAME == "" , "선박명을 입력해주십시오.");
						
						if (param.FISH_LEN != "")
						{
							var v = param.FISH_LEN;
							
							checkData(isNaN(v) , "길이는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "길이값이 너무 큽니다.");							
							checkData(v < 0 , "길이값이 0보다 작습니다.");
						}
						
						if (param.FISH_WEIGHT != "")
						{
							var v = param.FISH_WEIGHT;
							
							checkData(isNaN(v) , "길이는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "무게값이 너무 큽니다.");							
							checkData(v < 0 , "무게값이 0보다 작습니다.");
						}
/*  NAK-107 	
								로컬 홈피 조황 등록시 마릿수, 장소 설명 삭제 요청
						if (param.FISH_CNT != "")
						{
							var v = param.FISH_CNT;
							
							checkData(isNaN(v) , "마리수는 숫자로 입력해야 합니다.");							
							len = parseInt(v);							
							checkData(v > 9999 , "마리수는 최대 9999마리까지 입력할수 있습니다.");							
							checkData(v < 0 , "마리수가 0보다 작습니다.");
						}
						*/
					}
					
				}				
				catch(err)
				{
					alert(err);
					return false;
				}
				
				

				$.ajax({
					 url : _self._fishUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		var url = window.location.href;
							Bplat.view.loadPage(_self._fishDetailURL + '?GALR_ID=' + _self.fishgalrId  );
				    	}
				    }
				});
			},
			'pageInit'		: function() {
				var _self = this;
				
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				_self.getFishDetail(_self.fishgalrId);

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
