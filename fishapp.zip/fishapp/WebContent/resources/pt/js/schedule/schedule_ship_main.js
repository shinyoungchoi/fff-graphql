defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleSeatimeListURL = $('#scheduleSeatimeListURL').val();
				this._scheduleDetailFormURL = $('#scheduleDetailFormURL').val();
				
				this._scheduleWeatherURL = $('#scheduleWeatherURL').val();
				this._scheduleWeatherDateURL = $('#scheduleWeatherDateURL').val();
				// element 
				this.$dateYear = $('#dateYear');
				this.$dateMonth = $('#dateMonth');
				this.$prevMonth = $('#schedulePrevMonth');
				this.$nextMonth = $('#scheduleNextMonth');
				this.$calendarTemplate = $('#calendarTemplate');
				this.$weatherOkBtn = $('#weatherOkBtn');
				this.$bizId = $('#bizId').val();
				this.$shipId = $('#shipId').val();
				this.$weatherDiv = $('.jdg-data-weather');
				this.$weatherInfoTbl = $('#weatherInfoTbl');
				
				// Calendar
				this.$calendarContainer = $('#calendarContainer');
				this.$calendarRow = this.$calendarTemplate.find('.calendarRow');
				this.$scheduleRow = this.$calendarTemplate.find('.scheduleRow');
				// Calendar List
				this.$calendarListContainer = $('#calendarListContainer');
				this.$calendarListRow = this.$calendarTemplate.find('.calendarListRow');
				this.$scheduleListRow = this.$calendarTemplate.find('.scheduleListRow');
				// static variable
				this.currentScheduleList = null;
				this.weekArr = ['월요일','화요일','수요일','목요일','금요일','토요일','일요일'];
				
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
			},
			'setEvent'		: function() {
				var _self = this;
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 1 ) {
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					
					_self.createCalendar( year, month-1 );
				});
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 12 ) {
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					
					_self.createCalendar( year, month-1 );
				});				
				
				// 상세이동
				_self.$calendarContainer.delegate('.scheduleRow','click',function() {
					Bplat.view.loadPage(_self._scheduleDetailFormURL + '?SCHD_ID=' + $(this).attr('scheId') );
				});
				_self.$calendarListContainer.delegate('.scheduleListRow','click',function() {
					Bplat.view.loadPage(_self._scheduleDetailFormURL + '?SCHD_ID=' + $(this).attr('scheId') );
				});
				
				//날씨 버튼 클릭
				$(document).on('click','.jdg-btn-weather',function() {
					var year =  $('#dateYear').text();
					var month =  new Number($('#dateMonth').text());
					var srhMonth = (month+1 < 10) ? '0'+month : month;
					var day = $(this).parent().parent().find('.jdg-data-date').text();
					var srhDate = (day<10) ? '0'+day : day;
					var date = year+srhMonth+srhDate;
					
					var insertParam = {
							'WEATHER_DATE' :  date
						   ,'SHIP_ID'  :  _self.$shipId.replace('/', '')
					};
					
					$.ajax({
						url : _self._scheduleWeatherURL
						,type : 'POST'
						,data : insertParam
						,dataType : 'json'
						,success : function( data ) {
							if(data.hasOwnProperty('marineWeather')){
								
								var weatherCond = data.marineWeather.WEATHER_COND;
								var windDirect = data.marineWeather.WIND_DIRECT;
								var waveHeight = data.marineWeather.WAVE_HEIGHT;
								var windSpeed = data.marineWeather.WIND_SPEED;

								var arrweatherCond = weatherCond.split(",");
								var arrWindDirect = windDirect.split(",");
								var arrWaveHeight =  waveHeight.split(",");
								var arrWindSpeed = windSpeed.split(",");
								
								var weatherTr = _self.$weatherInfoTbl.find('[data-key=WEATHER_TR]');
								var windDirectTr = _self.$weatherInfoTbl.find('[data-key=WIND_DIRECT_TR]');
								var windSpeedTr = _self.$weatherInfoTbl.find('[data-key=WIND_SPEED_TR]');
								var waveHeightTr = _self.$weatherInfoTbl.find('[data-key=WAVE_HEIGHT_TR]');
								
								// 날씨 정보 테이블에 remove 된것이 있으면 다시 팝업을 초기화 해준다.
								if(_self.$weatherInfoTbl.find('thead').find('th').length != 3 ){
									 var weatherInfoTblTh = "<th>오후</th>";
									_self.$weatherInfoTbl.find('thead').find('tr').eq(0).append(weatherInfoTblTh);
									_self.$weatherInfoTbl.find('thead').find('th').eq(1).text("오전");
									
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(i){
										var weatherInfoTblTd = "<td></td>";
										$(this).find('td').eq(i).empty();
										$(this).append(weatherInfoTblTd);
									});
								}else{
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(){
										$(this).find('td').empty();
									});
									
								}
								
								//데이터가 오후만 있는 경우, 
								if( arrweatherCond[0] == "" ){
									var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[1]+"' width='30px' height='30px'>";

									_self.$weatherInfoTbl.find('thead').find('th').eq(1).remove();
									_self.$weatherInfoTbl.find('tr').each(function(){
										$(this).find('td').eq(0).remove();
									});
									
									weatherTr.find('td').eq(0).append(weatherImg);
									windDirectTr.find('td').eq(0).text(arrWindDirect[1]);
									windSpeedTr.find('td').eq(0).text(arrWaveHeight[1]);
									waveHeightTr.find('td').eq(0).text(arrWindSpeed[1]);
									
								}else{ 
									 //오전, 오후 일떄
										for(var i=0; i<arrweatherCond.length; i++ ){
											var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[i]+"' width='30px' height='30px'>";
											
											weatherTr.find('td').eq(i).append(weatherImg);
											windDirectTr.find('td').eq(i).text(arrWindDirect[i]);
											windSpeedTr.find('td').eq(i).text(arrWaveHeight[i]);
											waveHeightTr.find('td').eq(i).text(arrWindSpeed[i]);
										}
								}
								_self.$weatherDiv.css('display','block');
							}
						}
					});
				});
				
				_self.$weatherOkBtn.click(function(){
					_self.$weatherDiv.css('display','none');
				});
			},
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length >= 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(^[+-]?\d+)(\d{3})/;
					str += '';
					
					while(pattern.test(str)) {
						str = str.replace(pattern,'$1,$2');
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},			
			'getMyReserveList' : function() {
				var _self = this;

				var defaultParam = {
						 'PAGE' : 1
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	$.each(data.memReserveList, function(key,value) {
				    		 $row = _self.$tmpReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('[data-key="SCHD_DATE"]');
				    		 $schdDate.text(value.SCHD_DATE);

				    		 $schdTitle = $row.find('[data-key="SUB_TITLE"]');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 $manCnt = $row.find('[data-key="MAN_CNT"]');
				    		 $manCnt.text(value.MAN_CNT);

				    		 $totCost = $row.find('[data-key="TOT_COST"]');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money'));

				    		 var statusCd = value.STATUS_CD;
			    			var status = null;
			    			$statusName = $row.find('[data-key="STATUS_NAME"]');
			    			if( statusCd == '104_300' || statusCd == '104_340'){
			    				$statusName.addClass('jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$reserveList.append($row);
			    			
				    		 $row = _self.$tmpMobileReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('[data-key="SCHD_DATE"]');
				    		 $schdDate.text(value.SCHD_DATE);

				    		 $schdTitle = $row.find('[data-key="SUB_TITLE"]');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 $manCnt = $row.find('[data-key="MAN_CNT"]');
				    		 $manCnt.text(value.MAN_CNT);

				    		 $totCost = $row.find('[data-key="TOT_COST"]');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money'));

				    		 var statusCd = value.STATUS_CD;
			    			var status = null;
			    			$statusName = $row.find('[data-key="STATUS_NAME"]');
			    			if( statusCd == '104_300' || statusCd == '104_340'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$mobileReserveList.append($row);
			    			
				    	 });				    	
				    }
				});				
			},			
			// 달력생성
			'createCalendar' : function( year, month ) {
				// 로더 생성
				jdg.util.showLoader();
				$('.jdg-ui-calendar').hide();
				// Calendar & Calendar List 생성
				var _self = this;
				_self.$calendarContainer.empty();
				_self.$calendarListContainer.empty();
				var tmpDay = new Date();
				tmpDay.setFullYear(year, month, 1);
				var dayOfMonth = tmpDay.getRangeDaysOfMonth(); //이번달
				var startDay = Number( dayOfMonth[0].split('-')[2] );
				var endDay = Number( dayOfMonth[1].split('-')[2] );
				var srhMonth = (month+1 < 10) ? '0'+(month+1) : (month+1);
				var weekCnt = 1;
				var flag = 0;
				var insertParam = {
						   'SHIP_ID'  :  _self.$shipId.replace('/', '')
					};
				$.ajax({
					url : _self._scheduleWeatherDateURL
					,type : 'POST'
					,data : insertParam
					,dataType : 'json'
					,success : function( data ) {
						if(data.hasOwnProperty('weatherDateList')){
							var weatherDateList = data.weatherDateList;
							for( var i = startDay; i <= endDay ; i++ ) {
								flag= 0;
								tmpDay.setDate(i);
								var day = tmpDay.getDay();
								var date = tmpDay.getDate();
								var srhDate = (date<10) ? '0'+date : date;
								
								if( i == 1 || day == 1 ) {
									// calendar
									var $week = _self.$calendarRow.clone();
									_self.$calendarContainer.append( $week );
									// calendar list
									var $weekList = _self.$calendarListRow.clone();
									$weekList.eq(0).text( weekCnt + '주차' );
									$weekList.attr('week', tmpDay.getMondayWeek());
									_self.$calendarListContainer.append( $weekList );
									weekCnt++;
								}
								var $td = $week.find('[day='+day+']');
								$td.find('[data-type=day]').text(i);
								$td.attr('schdDate', year + '' + srhMonth + '' + srhDate);
								
								for(var j =0; j<weatherDateList.length; j++){
									var fullDate =  year+srhMonth+srhDate;
									var compareDate = weatherDateList[j].WEATHER_DATE;
									if(fullDate == compareDate){
										var weatherBtn ="<a style='cursor:pointer;'><span class='jdg-btn-weather' title='날씨' onclick='test();'></span></a>";
										//var weatherBtn = "<input type='button' value='버튼' class='btn' onclick='test()'>";
										flag++;
										
										if( flag == 1 ){
											$td.append(weatherBtn);
										}
										break;
									}
								}
								
							}
						}
					}
				});
				
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month+1);
				// 해당 Calendar의 물때 조회
				_self.getSeaTimeList( year + '' + srhMonth );
				// 해당 Calendar의 출조 스케쥴 조회
				_self.getScheduleList({'SCHD_MONTH' : year + '' + srhMonth });
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				
				var tmpDay = new Date();
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var scheduleList = data.scheduleList;
			    		_self.currentScheduleList = scheduleList;
			    		$.each( scheduleList, function( idx, data ) {
			    			// Calendar 데이터 셋팅
			    			var $td = _self.$calendarContainer.find('[schdDate='+data.SCHD_DATE+']');
			    			var $scheduleRow = _self.$scheduleRow.clone();
			    			var scheTime = data.SCHD_TIME;
			    			$scheduleRow.find('[data-key=SCHD_TIME]').text( scheTime.substring(0,2) + ':' + scheTime.substring(2,4) );
			    			$scheduleRow.find('[data-key=SUB_TITLE]').text( data.SUB_TITLE );
			    			$scheduleRow.attr('scheId', data.SCHD_ID);
			    			// Calendar List 셋팅
			    			var schdDate = data.SCHD_DATE;
			    			var year = schdDate.substring(0,4);
			    			var month = schdDate.substring(4,6)-1;
			    			var date = schdDate.substring(6,8);
			    			tmpDay.setFullYear(year, month, date);
			    			var $scheduleListContainer = _self.$calendarListContainer.find('[week='+tmpDay.getMondayWeek()+']');
			    			var $scheduleListRow = _self.$scheduleListRow.clone();
			    			$scheduleListRow.attr('scheId', data.SCHD_ID);
			    			$scheduleListRow.attr('schddate', data.SCHD_DATE);
			    			$scheduleListRow.find('.date').text( date + '일' );
			    			$scheduleListRow.find('.day').text( _self.weekArr[tmpDay.getDay()] );
			    			$scheduleListRow.find('[data-key=SCHD_TIME]').text( data.SCHD_TIME.substring(0,2) + ':' + data.SCHD_TIME.substring(2,4) );
			    			$scheduleListRow.find('[data-key=SUB_TITLE]').text( data.SUB_TITLE);
			    			// 예약가능인원
			    			var reserveCnt = data.PSGR_CNT-data.RESERVE_CONFIRM_CNT-data.RESERVE_WAIT_CNT-data.WAIT_CNT;
			    			// Calendar & Calendar List 예약상태
			    			if( '113_110' === data.STATUS_CD && reserveCnt <=0 ) {
			    				$scheduleRow.find('[data-key=STATUS_NAME]').addClass('jdg-status-b');
			    				$scheduleRow.find('[data-key=STATUS_NAME]').text( '(대기예약)' );
			    				$scheduleListRow.find('.statusCd').addClass('jdg-status-b');
			    				$scheduleListRow.find('.statusCd').attr('title','대기예약');
			    			} else if( '113_110' === data.STATUS_CD ) {
			    				$scheduleRow.find('[data-key=STATUS_NAME]').addClass('jdg-status-a');
			    				$scheduleRow.find('[data-key=STATUS_NAME]').text( '(예약가능)' );
			    				$scheduleListRow.find('.statusCd').addClass('jdg-status-a');
			    				$scheduleListRow.find('.statusCd').attr('title','예약가능');
			    				// 예약가능인원
			    				$scheduleRow.find('[data-key=RESERVE_CONFIRM_CNT]').text( reserveCnt<0?0:reserveCnt + '명');
			    				$scheduleListRow.find('[data-key=RESERVE_CONFIRM_CNT]').text( reserveCnt<0?0:reserveCnt + '명');
			    			} else if( '113_170' === data.STATUS_CD ) {
			    				$scheduleRow.find('[data-key=STATUS_NAME]').addClass('jdg-status-c');
			    				$scheduleRow.find('[data-key=STATUS_NAME]').text( '(마감)' );
			    				$scheduleListRow.find('.statusCd').addClass('jdg-status-c');
			    				$scheduleListRow.find('.statusCd').text('마감');
			    			}
			    			// APPEND
			    			$td.find('.scheduleContainer').append( $scheduleRow );
			    			$scheduleListContainer.find('.scheduleListContainer').append( $scheduleListRow );
			    		});
			    		// Loader 삭제
						$('.jdg-ui-calendar').show();
						jdg.util.removeLoader();
				    }
				});
			},
			// 물때 초기화
			'getSeaTimeList' : function( schdDate ) {
				var _self = this;
				$.ajax({
					 url : _self._scheduleSeatimeListURL
					,type : 'POST'
					,data : {
						'SCHD_MONTH' : schdDate
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var seatimeList = data.seatimeList;
						for( var i=0, iSize=seatimeList.length ; i < iSize ; i++ ) {
							var data = seatimeList[i];
							_self.$calendarContainer.find('[schddate='+data.date+']').find('.seaTime').text( data.seatime );
							_self.$calendarListContainer.find('[schddate='+data.date+']').find('.seaTime').text( data.seatime );
						}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				
				var today = new Date();
				var year = today.getFullYear();
				var month = today.getMonth() + 1;
				
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month);
				
				_self.setEvent();
				
				_self.getMyReserveList();
				
				// 캘린더 초기화
				_self.createCalendar( year, month-1 );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
