defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleMainURL = $('#scheduleMainURL').val();
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._loginURL = $('#loginURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				// element
				this.$reserveForm = $('#reserveInsertForm');
				this.$reserveBtn = $('#reserveBtn');
				this.$reserveCancelBtn = $('#reserveCancelBtn');
				this.$loginBtn = $('#loginBtn');
				this.$wholeYnCheck = $('#wholeYnCheck');
				// static variable
				this.scheId = $('#scheId').val();
				this.scheDate = $('#scheDate').val();
				this.feeMan = $('#feeMan').val();
				this.feeWhole = $('#feeWhole').val();
			},
			'setEvent'		: function() {
				var _self = this;

				// 승선 인원 변경
				_self.$reserveForm.find('[data-key=MAN_CNT]').change( function() {
					_self.totalCost();
				});
				
				// 독선여부 체크
				_self.$wholeYnCheck.click( function() {
					var $manCntSel = _self.$reserveForm.find('[data-key=MAN_CNT]');
					if( $(this).is(':checked') ) {
						if( undefined != _self.feeWhole && '' != _self.feeWhole ) {
							_self.$reserveForm.find('[data-key=TOT_COST]').val( _self.feeWhole );
						} else {
							_self.totalCost();
						}
						$manCntSel.val( $manCntSel.find('option:last').val() );
						$manCntSel.attr('disabled', true);
					} else {
						$manCntSel.attr('disabled', false);
					}
				});
				
				// 예약 등록
				_self.$reserveBtn.click( function() {
					_self.insertReserve();
				});
				
				// 예약 취소
				_self.$reserveCancelBtn.click( function() {
					window.history.back();
				});
				
				// 예약하기 위해 로그인
				_self.$loginBtn.click( function() {
					Bplat.view.loadPage( _self._loginURL );
				});
				
			},
			// 예약금액 자동 셋팅
			'totalCost' : function() {
				var _self = this;
				var man = _self.$reserveForm.find('[data-key=MAN_CNT] option:selected').val();
				var sum = man * _self.feeMan;
				if( !sum ) sum = 0;
				_self.$reserveForm.find('[data-key=TOT_COST]').val( sum );
				$(".jdg-page-schedule").css("width","+=1");
				$(".jdg-page-schedule").removeAttr("style");
			},
			// 예약등록
			'insertReserve' : function() {
				var _self = this;
				var $insertForm = _self.$reserveForm;
				// validation
				var today = jdg.util.today().replaceAll('-','');
				if( today >= _self.scheDate ) {
					alert('과거 또는 오늘에 대한 예약은 등록할 수 없습니다. 반드시 필요한 예약이라면 출조점에 문의하여 주세요');
					return false;
				}
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').val();
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').val();
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
				if( rsvName == '' && rsvTel == '' &&  rsvEmail == '' ) {
					alert('예약자 정보를 입력해 주세요');
					return false;
				}
				if( confirm('예약하시겠습니까?') ) {
					var insertParam = {
						  'SCHD_ID' : _self.scheId
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : rsvEmail
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'WHOLE_YN' : 'N'
					};
					// 독선예약 여부 체크 
					if( _self.$wholeYnCheck.is(':checked') ) {
						insertParam.WHOLE_YN = 'Y';
					}
					$.ajax({
						 url : _self._reserveInsertURL
						,type : 'POST'
						,data : insertParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.info(data);
					    	var rsv_Id = data.rsv_Id;
					    	if( rsv_Id != null &&  rsv_Id != undefined ) {
								if (confirm('예약이 완료되었습니다.\n예약내역을 확인하시겠습니까?') == true) {   
									Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + rsv_Id);
								} else {   
									location.reload();
								}
					    		
					    	}
					    }
					});
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_detail_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				// 예약금액 초기셋팅
				_self.totalCost();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_detail_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_detail_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_detail_form] onDestroy Method' );
			}		
	  }
});
