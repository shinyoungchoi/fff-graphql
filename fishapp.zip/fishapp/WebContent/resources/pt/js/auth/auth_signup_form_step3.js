defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._loginUrl = $('#loginUrl').val();
				this._sendAuthCodeURL = $('#sendAuthCodeURL').val();
				this._confirmAuthCodeURL = $('#confirmAuthCodeURL').val();
				
				// element
				this.$btnReqSMS = $('#btnReqSMS');
				this.$btnAuthSend = $('#btnAuthSend');
				this.$divAuth = $('#divAuth');
				this.$authCode = $('#AUTH_CODE');
				
				
				this.$expTime = $('#expTime');				
				
				this.$timerId;
				
				this.$phoneNum = $('#TEL');
				this.$phoneNum1 = $('#PHONE_NUM_1');
				this.$phoneNum2 = $('#PHONE_NUM_2');
				this.$phoneNum3 = $('#PHONE_NUM_3');
				
				this.tel = this.$phoneNum.val();
				
				var telnum = this.tel.split('-');
				this.$phoneNum1.val(telnum[0]);
				this.$phoneNum2.val(telnum[1]);
				this.$phoneNum3.val(telnum[2]);
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				//확인 버튼
				_self.$btnReqSMS.click(function(){
					
					var userId = $('#UID').val();
					var memId = $('#MID').val();
					_self.tel = _self.$phoneNum1.val() + '-' + _self.$phoneNum2.val() + '-' + _self.$phoneNum3.val();
						
					//전화번호 형식 체크
					var regExp = /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/;
					if(!regExp.test(_self.tel)){
						alert('정상적인 전화번호를 입력해주세요.');
						return false;
					}
					
					_self.$btnReqSMS.hide();

			    	var param = {
					    	USER_ID : userId
					    	,MEM_ID : memId
					    	,TEL: _self.tel 
			    	};
					
					$.ajax({
						url : _self._sendAuthCodeURL
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
					
					    	if( data.count == null || data.count < 1){
					    		alert( "인증문자발송에 오류가 발생하였습니다.");
					    		return false;
					    	}
					    	
					    	if (data.count == 999)
					    	{
								var str = "이미 가입이 완료된 회원[" + userId +"] 입니다.";
					    		alert(str);
								$('#message').html("<font color=red>" + str + "</font>" + "<br>가입하신 아이디로 로그인이 가능합니다.");
								$('#message').show();
					    		return false;					    		
					    	}
					    	
							$('#message').show();
					
							window.$timeLeft = 180;
							_self.$expTime.text(window.$timeLeft + '초');
							_self.$authCode.val('');
							_self.$divAuth.show();
							
							window.$timerId = setInterval(_self.countdown, 1000);
					    	alert('인증문자가 발송되었습니다.');
							
					    	return false;
					    }

					});
					
					
				});
					
				//확인 버튼
				_self.$btnAuthSend.click(function(){
					
					var authcode = _self.$authCode.val();
					
					if (authcode == "" || authcode.length != 6 || isNaN(authcode))
					{
					   alert("인증번호는 6자리 숫자입니다.");	
					   return;
					}

					var memId = $('#MID').val();

			    	var param = {
					    	MEM_ID : memId
					    	,AUTH_CODE: authcode
					    	,TEL: _self.tel
			    	};
					
					$.ajax({
						url : _self._confirmAuthCodeURL
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
					    	if( data.msg == 'ok' ){
						    	var url = _self._loginUrl;
						    	Bplat.view.loadPage( url );
					    	}
					    	else
					    	{
					    		alert(data.msg);
					    		return false;					    		
					    	}
					    }

					});

				});
			},
			

			'countdown': function(event) {
			
			  var expTime = $('#expTime');	
			  var timeLeft = window.$timeLeft;
				
			  if (timeLeft== 0) {
				  
				  clearTimeout(window.$timerId);
				  $('#message').hide();
				  expTime.text('만료');
				  
				  $("#btnReqSMS").show();
				  $('#divAuth').hide();

			  } else {
				  timeLeft --;
				  window.$timeLeft = timeLeft;
				  expTime.text(timeLeft + '초');
			  }
			},			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_step3] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_step3] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_step3] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step3] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step3] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_step3] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_step3] onDestroy Method' );
			}		
	  }
});
