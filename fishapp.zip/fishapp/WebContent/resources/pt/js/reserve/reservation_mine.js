defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._loginURL = $('#loginURL').val();
				this.$loginBtn = $('#loginBtn');
				this._memReserveListURL = $('#memReserveListURL').val();
				this.$memList = $( '#memList' );
				this.$listRow = $( '#listRow' );
				this.$memListMobile = $( '#memListMobile' ).find('#sys-row-template_mobile');
				this.$mobileList = $('#memMobileList');
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				
				// 리스트 정의
				this.$listContainer = $('#listContainer');
				this.$rowTemp = this.$memList.find( '.sys-row-template' ); 
				
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$rowTemp
				});
				
				this.listMobile = new component.List({
					 'container' : this.$mobileList
					,'template' : this.$memListMobile
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 예약하기 위해 로그인
				_self.$loginBtn.click( function() {
					Bplat.view.loadPage( _self._loginURL );
				});
			},

			// 회원 목록 조회
			'getMemberList' : function( page ) {
				var _self = this;
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._memReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	// 리스트 초기화
			    		_self.list.createList( data.memReserveList, 'RSV_ID' , function( data, $row ) {
			    			var statusCd = data.STATUS_CD;
			    			var status = null;
			    			$classTd = $row.find('[data-key="STATUS_NAME"]');
			    			if( statusCd == '104_300'){
			    				$classTd.addClass('jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$classTd.addClass('jdg-status-b');
			    			}else{
			    				$classTd.addClass('jdg-status-c');
			    			}
			    			
			    			var subTitle = data.SUB_TITLE;
			    			if( null == subTitle || undefined == subTitle ) {
			    				$row.find('[data-key="SUB_TITLE"]').text('(제목 없음)');
			    			}
			    			
			    			//  제목 $row를 찾아서 이벤트를 건다.
			    			$row.find('.jdg-title').click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + data.RSV_ID, {
			    					'RSV_ID' : data.RSV_ID
			    				});
			    				return false;
			    			});
			    		});
			    		
			    		_self.listMobile.createList( data.memReserveList, 'RSV_ID' , function( data, $row ) {
			    			var statusCd = data.STATUS_CD;
			    			var status = null;
			    			$classTd = $row.find('[data-key="STATUS_NAME"]');
			    			if( statusCd == '104_300'){
			    				$classTd.addClass('jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$classTd.addClass('jdg-status-b');
			    			}else{
			    				$classTd.addClass('jdg-status-c');
			    			}
			    			
			    			var subTitle = data.SUB_TITLE;
			    			if( null == subTitle || undefined == subTitle ) {
			    				$row.find('[data-key="SUB_TITLE"]').text('(제목 없음)');
			    			}
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + data.RSV_ID, {
			    					'RSV_ID' : data.RSV_ID
			    				});
			    				return false;
			    			});
			    		});
			    		
			    		//페이징 초기화
			    		$('#memListPaging').paging({
							 current: defaultParam.PAGE
							,max: (Math.ceil(data.total / 5))
							,itemClass: 'jdg-btn-page'
							,prevClass: 'jdg-btn-page-prev'
							,nextClass: 'jdg-btn-page-next'
							,firstClass: 'jdg-btn-page-first'
							,lastClass: 'jdg-btn-page-last'
							,onclick:function(e,page){
								_self.getMemberList(page);
							}
						});
			    		$('.jdg-ui-reservation-mobile').css("width","+=100");
			    		console.info("test",$('.jdg-ui-reservation-mobile').width());
			    		$('.jdg-ui-reservation-mobile').removeAttr("style");
			    		console.info("test1",$('.jdg-ui-reservation-mobile').width());
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				var _self = this;
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				//TODO 나의 예약 정보 데이터 가져오기
				_self.getMemberList(1);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
