defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$detailForm = $('#shipDetailForm');
				this.$shipCateSel = $('#searchShipCategorySel');

				this.$regBtn = $('#regBtn');
				this.$dinakBtn = $('#dinakBtn');
				this.$refreshBtn = $('#refreshBtn');
				
				// form
				this.$srchForm = $('#shipSearchForm');
				this.$insertForm = $('#shipInsertForm');
				this.$updateForm = $('#shipUpdateForm');
				
				this.$selRegdays = $('#select_regdays');
				this.$selRegship = $('#select_regship');
				
				
				// static variable
				this.selectShipId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.page = 1;
				this.param = null;
				this.total_rows = 1;
				
				this.alllist = null;
				
				opener = null;
				
				// window.name = "부모창 이름"; 
          		window.name = "parentForm";
				
			},
			'setEvent'		: function() {
				var _self = this;
				// 코드 목록 조회
				_self.$srchForm.submit(function() {
					
					var param = {};
					
					var key = $('[name="shipSearchTerms"]').filter(':checked').val();
					var searchText = $("#searchText").val().trim();
					
					if( '' !== key && searchText != '') {
						param[key] = '%' + searchText + '%';
					}
					
					_self.getShipList( '1', param);
					return false;
				});
				
				//ERROR로 변경(인낚)
							$(document).on("click",".changebtn1", function(){
								var galrId = $(this).attr("pGalrid");
								var type = $(this).attr("pType");
								if(confirm("E 에러상태로 변경하시겠습니까? \n인낚 금지어로 인해 만들어진 기능입니다.")){
									_self.changeStatus(galrId, type);
								}
							});
				
				// logindo
				$("#shipListContainer").on("click", ".loginBtn",function(){
					var pid = $(this).attr("pid");
					var year = "2021";
					var alllist = _self.alllist;
					let innak_id;
					let innak_pwd;
					let bbs_cd;
					var board_id;
					for(var i = 0 ;i < alllist.length ;i++){
						var item = alllist[i];
						if(item.GALR_ID == pid){
							innak_id = item.INNAK_ID;
							innak_pwd = item.INNAK_PWD;
							bbs_cd = item.INNAK_BBS_CD;
						}
					}
					$("#mb_id").val(innak_id);
					$("#mb_password").val(innak_pwd);
					
					if(bbs_cd != null){
						if(bbs_cd == 'boat'){
							board_id = "D03_"+year;
						}else if(bbs_cd == 'rock'){
							board_id = "D02_"+year;
						}else if(bbs_cd == 'break'){
							board_id = "D04_"+year;
						}else if(bbs_cd == 'lure'){
							board_id = "D21_"+year;
						}else if(bbs_cd == 'fam'){
							board_id = "D05_"+year;
						}else if(bbs_cd == 'bhotfisheroctopus'){
							board_id = "D13_"+year;
						}else if(bbs_cd == 'bhotfisherbeltfish'){
							board_id = "D12_"+year;
						}
					}
        
        			$("#upload-boardid").val(board_id);
       				var url = "%2Fbbs%2Fboard.php%3Fbo_table%3D"+board_id;
					$("#login-url").val(url);
					
					opener = window.open("", "openWin"); 
					var df = document.formname1;

					df.target = "openWin";
					df.action = "https://www.innak.kr/bbs/login_check.php";
					df.method = "post";
					df.submit();
					
				});
				
				// logindo
				$("#shipListContainer").on("click", ".contentBtn",function(){
					var pid = $(this).attr("pid");
					var alllist = _self.alllist;
					
					var wf = document.formname2;
					var board_id = $("#upload-boardid").val();
					$("#bo_table").val(board_id);
					wf.action="https://www.innak.kr/bbs/write.php";
					wf.method = "GET";
					wf.target = "openWin";
					wf.submit();
				});
				
				
								
				_self.$refreshBtn.click(function(){
					location.reload();
				});
				
			},
			'changeStatus': function(galrId, type){
				var _self = this;
				var defaultParam = {
					 'GALR_ID' : galrId
					,'TYPE' :type
				};
				$.ajax({
					 url : 'change_status'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
						console.log(data);
						//this.getShipList('1');
					},
					error : function(){
						alert("처리도중 오류가 발생하였습니다");
						return;
					}
				});
			},
			
			// 코드 카테고리 목록 조회
			'getShipList' : function( page, param ) {
				
				var _self = this;
				
				_self.page = page;
				_self.param = param;
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : 'innak_list'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('innakList') ) {
					
				    		// 리스트 초기화
				    		_self.list.createList( data.innakList, 'GALR_ID', function( data, $row ) {
									console.log(data);
				    				if(data.INNAK_STATUS == 'S'){
				    					var statusHtml = data.INNAK_BBS_CD_STR +"-"+ data.INNAK_STATUS_STR;
										$row.find("[class=data_status1]").html(statusHtml );
				    				}else if(data.INNAK_STATUS != undefined){
				    					var statusHtml = data.INNAK_BBS_CD_STR +"-"+ data.INNAK_STATUS_STR+"("+data.INNAK_STATUS+")";
				    					statusHtml += "<button type='button' pType='1' class='changebtn1' style='padding:5px;'  pGalrid='"+data.GALR_ID+"'>상태변경</button>";
										$row.find("[class=data_status1]").html(statusHtml);
				    				}else {
				    					$row.find("[class=data_status1]").html("선택안함");
				    				}				 
				    				
				    				if(data.INNAK_STATUS_2 == 'S'){
				    					$row.find("[class=data_status2]").html(data.INNAK_BBS_CD_STR_2 +"-"+data.INNAK_STATUS_STR_2);
				    				}else if(data.INNAK_STATUS_2 != undefined){
				    					var statusHtml =data.INNAK_BBS_CD_STR_2 +"-"+ data.INNAK_STATUS_STR_2+"("+data.INNAK_STATUS_2+")";
				    					statusHtml += "<button type='button' class='changebtn1' pType='2' style='padding:5px;' pGalrid='"+data.GALR_ID+"'></button>";
										$row.find("[class=data_status2]").html(statusHtml);
				    				}	   			
				    				
				    				$row.find("[class=button-area] button").each(function(){
				    					$(this).attr("pid", data.GALR_ID);
				    				});
				    		});

				    		_self.alllist = data.innakList;
				    		_self.total_rows = data.total;
				    		
							
							
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: Math.ceil(data.total / 10)
								,onclick:function(e,page){
									_self.getShipList(page,param);
								}
			    				,prev : '이전'
				    			,next : '다음'
							});

				    	}
				    }
				});
			},

			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[autopost_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getShipList('1');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[autopost_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[autopost_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[autopost_main] onDestroy Method' );
			}		
	  }
});