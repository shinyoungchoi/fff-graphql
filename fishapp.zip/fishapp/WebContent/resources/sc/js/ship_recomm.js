defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizURL = $('#bizURL').val();
				this._shipListURL = $('#shipListURL').val();
				this._shipInsertURL = $('#shipInsertURL').val();
				this._shipSearchURL = $('#shipSearchURL').val();
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');

				this.$rldBtn = $('#rldBtn');
				this.$regBtn = $('#regBtn');
				this.$delBtn = $('#delBtn');
				this.$addBtn = $('#addBtn');
				
				this.$upBtn = $('#upBtn');
				this.$dnBtn = $('#dnBtn');

				this.$updated = false;
				
				// static variable
				this.selectedRow;
				
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				// 파일 리스트 초기화
				this.mainFileList = null;
				this.cptnFileList = null;
				this.redirectNameTemp = "";
			},
			'setEvent'		: function() {
				var _self = this;


				// 추천선박 추가
				_self.$addBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_insert_popup' );
					
					return false;
				});
				
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.insertRecommShip();
				});

				// 위로 버튼클릭
				_self.$upBtn.click( function() {
					
					_self.$updated = true;
					
					var sr = _self.selectedRow;						
					if (sr == null) return false;					
					sr.insertBefore(sr.prev());
					return false;
				});
				
				
				// 아래로 버튼 클릭
				_self.$dnBtn.click( function() {
					
					_self.$updated = true;
					
					var sr = _self.selectedRow;
					if (sr == null) return false;
					sr.insertAfter(sr.next());
					return false;
				});

				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.$updated = true;
					
					_self.selectedRow.remove();	
					return false;
				});
				
				
				// 새로고침(reload)
				_self.$rldBtn.click( function() {
					
					if (_self.$updated)
					{
						if(!confirm("변경내용을 취소하고 새로고침 하시겠습니까?")) {return;}						
					}
					
					_self.$updated = false;
					
					_self.getShipList();	
					return false;
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.rowSelect( $this );
				});
			},
			// 상세 펼침
			'rowSelect' : function( $tr ) {
				var _self = this;
				_self.$listContainer.find('tr').removeClass('jdg-selected');				
				_self.selectedRow = $tr;				
				$tr.addClass('jdg-selected');
				return;

			},
			// 선박 목록 조회
			'getShipList' : function() {
				var _self = this;

				$.ajax({
					 url : _self._shipListURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		
				    		var rowcount = 0;
				    		
				    		_self.list.createList( data.shipList, 'SHIP_ID', function( data, $row ) {
				    			if (rowcount == 0)
				    			{
				    				_self.selectedRow = $row;
				    				$row.addClass('jdg-selected');
				    			}
				    			rowcount ++;
				    			
				    		});
				    	}
				    }
				});
			},
			// 선박 등록
			'insertRecommShip' : function() {
				var _self = this;
				
				if (_self.$updated == false)
				{
					alert('변경된 추천선박이 없습니다.');
					return;
				}
				
				if(!confirm("저장하시겠습니까?")) {return;}
				
				var insertParam = {};
				var ships = [];
			
				_self.$listContainer.find('[data-key=SHIP_ID]').each(function (index) {
	            	
	            	var shipId = this.innerText;
	            	
	            	for (var i=0; i < ships.length; i++)
	            	{
	            		if (ships[i].SHIP_ID == shipId)
            			{
	            			alert("중복된 선박이 있습니다.(" + index + "번째)" );
	            			return false;
            			}
	            	}
	            	
	            	var item = {SHIP_ID: shipId, SORT_KEY: "" + index};
	            	ships.push(item);
	            });				
				
	            insertParam.ships = JSON.stringify(ships);

				$.ajax({
					 url : _self._shipInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	_self.$updated = false;
				    	
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});

			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선박목록조회
				this.getShipList('1');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				// 관리자 팝업 close
				if( 'ship_insert_popup' === p_param.id ) {
					
					_self.$updated = true;
					
					var sr = _self.$listTemplate.find('.searchRow');
					
					var $shipId = sr.find('[data-type=SHIP_ID]');
					var $shipName = sr.find('[data-type=SHIP_NAME]');
					var $bizName = sr.find('[data-type=BIZ_NAME]');
					var $portName = sr.find('[data-type=PORT_NAME]');
					
					var $tmp = _self.$listTemplate.find('.searchRow').clone();
					
					jdg.util.detailDataSetting( $tmp, data );
					
					_self.$listContainer.append($tmp);
					
				} 
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_main] onDestroy Method' );
			}
	  }
});
