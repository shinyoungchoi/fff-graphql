defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// element
				this.$listContainer = $('#postListContainer');
				this.$postThreadContainer = $('#postThreadContainer');
				this.$listTemplate = $('#postListTemplate');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$searchTypeSel = $('#searchPostSel');
				this.$searchShipSel = $('#searchShipSel');
				this.$sortArrow = $('.sortArrow');
				this.$typeCdEm = $('#TYPE_CD');
				this.$typeNameEm = $('#TYPE_NAME');
				this.$postDetailTbl = $('#postDetailTbl');
				// form
				this.$srchForm = $('#postSearchForm');
				this.$insertForm = $('#postInsertForm');
				this.$updateForm = $('#postUpdateForm');
				this.$detailForm = $('#postDetailForm');
				
				this.$selectView = $('#selectView');

				// static variable
				this.selectPostId = '';
				this.selectedRowData = {};
				this.selectFileList = null;
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					/*,'nodata' : this.$listTemplate.find('.nodataRow')*/
				});
				// 파일 리스트 초기화
				this.fileList = null;
				
				// 추천선박 선택된 행
				this.selectedRow = null;

				
				this.bannerListData = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
	

				// 조회
				_self.$srchForm.submit(function() {
					// 사업체목록조회
					_self.getPostList();
				});				
				
				// 조회범위select
				_self.$selectView.change( function() {
					
					_self.selectBannerList();
				});
				
				function ImageExist(url) 
				{
					var img = new Image();
					$(img).load(url, function(response, status, xhr) {
					    if (status == "error") 
					       return false;
					    else
					       return true;
					    });
				}
				
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertPost();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.fileList.removeFile();
					_self.selectFormShow('none');
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					// 현재 셀렉트된 아이템을 수정화면에 셋팅
					_self.selectFormShow('update', _self.selectedRowData );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updatePost();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.fileList.removeFile();
					_self.selectFormShow( 'search', _self.selectedRowData.detailPost );
					return false;
				});

			
				
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					var defaultParam = {
							 'BN_ID': _self.selectPostId
					   };
					$.ajax({
						 url : '/sc/info/delete_banner'
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		if( data.result > 0 ) {
						    		alert('삭제 되었습니다');
						    		location.reload();
					    		} else {
					    			alert('삭제를 실패하였습니다.');
					    		}
					    	}
					    }
					});
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});

			},
			
		
			'selectBannerList':function(){
				
				var _self = this;
				
				var listData = _self.bannerListData;
				
				if (listData == null) return;
			
				var vType = _self.$selectView.val();
				
				var lst = [];
				
				if (vType == 'ALL')
				{
					lst = _self.bannerListData.slice();
				}
				else
				{
					for (var i=0; i < listData.length; i++)
					{
						var item = listData[i];
				
						if (vType == 'CY') 
							{
								if (item.CURR_STATUS == '공개중') lst.push(item);
							}
						else if (vType == 'CN')
							{
								if (item.CURR_STATUS != '공개중') lst.push(item);
							}
						else if (vType == 'OY')
							{
								if (item.OPEN_YN == 'Y') lst.push(item);
							}
						else if (vType == 'ON')
							{
								if (item.OPEN_YN != 'Y') lst.push(item);
							}
					}
				}
				
	    		// 리스트 초기화
	    		if(lst && lst.length > 0 ){
	    			_self.list.createList( lst, 'BN_ID', function( data, $row) {
	    				
	    				$row.find('img').attr('src',data.BN_IMG_URL);

		    		});
	    			
		    		_self.selectFormShow('none');
		    		// 데이터1개일 경우 자동 펼침
		    		if( lst.length == 1 )
		    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
	    			
	    		}else{

	    			_self.$listContainer.empty();
	    			_self.$listContainer.append( $('#postListTemplate .nodataRow').clone());
	    		}				
				
			},

			// 게시물 등록
			'insertPost' : function(){
				var _self = this;
				var $insertForm = _self.$insertForm;
				var typeCd = _self.$typeCdEm.text();
				var $insertForm = _self.$insertForm;

				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var imgId = _self.fileList.getFile();
				if (imgId == null) imgId = "";
				
				
				var insertParam = {
							 'BN_TITLE1'   : $insertForm.find('[data-key=BN_TITLE1]').val()
							, 'BN_TITLE2'   : $insertForm.find('[data-key=BN_TITLE2]').val()
							, 'LINK_URL'     : $insertForm.find('[data-key=LINK_URL]').val()
							, 'OPEN_YN'   : $insertForm.find('[data-key=OPEN_YN]').val()
							, 'OPEN_FROM'   : $insertForm.find('[data-key=OPEN_FROM]').val()
							, 'OPEN_TO'   : $insertForm.find('[data-key=OPEN_TO]').val()
							, 'SEQ'   : $insertForm.find('[data-key=SEQ]').val()
							, 'BN_IMG_ID' : imgId
				};
				
				$.ajax({
					 url : '/sc/info/insert_banner'
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
			    			_self.getPostList();
				    	}
				    }
				});
				return false;
			},
			// 게시물 수정
			'updatePost' : function(){
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				var imgId = _self.fileList.getFile();
				if (imgId == null) imgId = "";
				// 파일등록
		    	// set update parameters
				var updateParam = {
						  'BN_ID'   : _self.selectPostId
						, 'BN_TITLE1'   : $updateForm.find('[data-key=BN_TITLE1]').val()
						, 'BN_TITLE2'   : $updateForm.find('[data-key=BN_TITLE2]').val()
						, 'LINK_URL'     : $updateForm.find('[data-key=LINK_URL]').val()
						, 'OPEN_YN'   : $updateForm.find('[data-key=OPEN_YN]').val()
						, 'OPEN_FROM'   : $updateForm.find('[data-key=OPEN_FROM]').val()
						, 'OPEN_TO'   : $updateForm.find('[data-key=OPEN_TO]').val()
						, 'SEQ'   : $updateForm.find('[data-key=SEQ]').val()
						, 'BN_IMG_ID' : imgId
				};
				$.ajax({
					 url : '/sc/info/update_banner'
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getPostList();
				    	}
				    }
				});
				return false;
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;

				_self.selectPostId = $tr.attr('rowKey');
				var param = {BN_ID:_self.selectPostId};
				$.ajax({
					 url : '/sc/info/banner_detail'
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function(data){
						// 데이터 초기화
						_self.selectedRowData = {};
						if(data.hasOwnProperty('detail')){

							_self.selectFormShow('search', data.detail );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							
							$tr.addClass('jdg-selected');

						}

						_self.selectedRowData = data;
					}
				});
			},
			// 게시물 목록 조회
			'getPostList' : function() {
				
				var _self = this;
				var param = {};
				 paramURL = '/sc/info/banner_list';

				$.ajax({
				 url : paramURL
				,type : 'POST'
				,data : param
			    ,dataType : 'json'
			    ,success : function( data ) {
 
			    	_self.bannerListData = data.list;
			    	
			    	_self.selectBannerList();



			    }
			});
				
				
				
			},

			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;

				var typeCd = (data == null)? $('#searchPostSel').val() : data.TYPE_CD;
				
				if (typeCd < '122_050')
				{
					$('#recomShipForm').hide();
					$('#msg').hide();
				}
				else
				{
					$('#recomShipForm').show();
					$('#msg').show();
					
					if (mode == 'insert')
					{
						$('#mfyShipBtn').hide();
						$('#shipListContainer').empty();
					}
					else
					{
						$('#mfyShipBtn').show();
					}
				}
				
				
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$('#detail_img').attr('src', data.BN_IMG_URL);
					
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					
					// 파일리스트 초기화
					_self.fileList = new component.File({
						 'id' : 'INSERT_BANNER_IMG_ID'
						,'container' : $('#INSERT_BANNER_IMG_ID')
					});
					_self.fileList.init();

					$insertForm.show();

				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
			
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data.detail );
					//$('#update_img').attr('src', data.detail.BN_IMG_URL);
					
					// 파일리스트 초기화
					_self.fileList = new component.File({
						 'id' : 'UPDATE_BANNER_IMG_ID'
						,'container' : $('#UPDATE_BANNER_IMG_ID')
					});
					_self.fileList.init(data.detail.BN_IMG_ID ? data.detail : null );
					
					$updateForm.show();

				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
				
				return false;
			},
			
			
			
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 사업체목록조회
				this.getPostList();
				$("a[href='#']").attr('href','javascript:void(0);');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[post_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[post_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var item = p_param.value;
				// 관리자 팝업 close
				if( 'ship_insert_popup' === p_param.id ) {
					
					_self.$updated = true;
					
		    		var $cont =$('#shipListContainer');
		    		var $templ = $('#shipListTemplate tr.searchRow');
	    			var $row = $templ.clone();
	    			var tds = $row.find('td');
	    			
	    			$(tds[0]).text('new');
	    			$(tds[1]).text(item.SHIP_ID);
	    			$(tds[2]).text(item.SHIP_NAME);
	    			$(tds[3]).text(item.PORT_NAME);
		    			
	    			$cont.append($row);
					
				} 
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[post_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[post_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[post_main] onDestroy Method' );
			}		
	  }
});
