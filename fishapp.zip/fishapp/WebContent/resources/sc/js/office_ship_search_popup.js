defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipListURL = $('#shipListURL').val();
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$searchForm = $('#shipSearchForm');
				this.$mGradeSel = $('#shipGradeSel');
				this.$mSrhKeySel = $('#shipSearchKeySel');
				this.$mSrhVal = $('#shipSearchVal');
				this.$confirmBtn = $('#shipConfirmBtn');
				this.$closeBtn = $('#shipCloseBtn');
				// static variable
				this.selectShipId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.selectShipId = $this.attr('rowKey');
					// style
					_self.$listContainer.find('tr').removeClass('jdg-selected');
					$this.addClass('jdg-selected');
				});
				
				// 조회 버튼 클릭
				_self.$searchForm.submit( function() {
					_self.getShipList('1');
					return false;
				});
				
				// 확인 버튼 클릭
				_self.$confirmBtn.click(function() {
					if( '' === _self.selectShipId ) {
						if( ! confirm("선택한 선박이 없습니다.")){
							return false;
						}
					}
					var selectShipData = _self.list.getListRowData(_self.selectShipId, 'SHIP_ID');
					opener.Bplat.view.closePopup( selectShipData );
					window.close();
				});
				
				// 취소 버튼 클릭
				_self.$closeBtn.click(function() {
					opener.Bplat.view.closePopup();
					window.close();
				});
			},
			// 선박 목록 조회
			'getShipList' : function( page ) {
				var _self = this;
				var param = {
					  'PAGE' : page
					, 'PERPAGE' : '5'
					, 'GRADE_CD' : _self.$mGradeSel.find('option:selected').val()
					, 'NOT_GRADE_CD' : '107_170'
				};
				
				var key = _self.$mSrhKeySel.val();

				if( '' !== key ) {
					param[key] = $.trim(_self.$mSrhVal.val());
				}
				$.ajax({
					 url : _self._shipListURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.shipList, 'SHIP_ID' , function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    		});
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getShipList(page);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_search_popup] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 사업체목록조회
				this.getShipList('1');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_search_popup] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_search_popup] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_search_popup] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_search_popup] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_search_popup] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_search_popup] onDestroy Method' );
			}
	  }
});
