defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipId = $('#shipId').val();
				this._statListURL = $('#statListURL').val();
				// element
				this.$selectShip = $('#selectShip');
				this.$startDate = $('#startDate');
				this.$endDate = $('#endDate');
				this.$executeBtn = $('#executeBtn');
				this.$listContainer = $('#statListContainer');
				this.$listTemplate = $('#statListTemplate');
				this.$searchType = $(':radio[name="searchRdo"]');
				this.$startDate = $('#startDate');
				this.$endDate = $('#endDate');
				
				this.$thisWeek = $('#thisWeek');
				this.$lastWeek = $('#lastWeek');
				this.$thisMonth = $('#thisMonth');
				this.$lastMonth = $('#lastMonth');
				this.$lastSixMonth = $('#lastSixMonth');
				this.$thisYear = $('#thisYear');
				this.$lastYear = $('#lastYear');
				
				
				// form
				this.$srchForm = $('#codeSearchForm');
				
				//static variable
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});

				this.list2 = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.jdg-tr-total')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				//초기 셋팅
				this.$startDate.val(this.getSerchCookie('stat.startDate'));
				this.$endDate.val(this.getSerchCookie('stat.endDate'));
				$(':radio[name="searchRdo"][data-key='+this.getSerchCookie('stat.type')+']').attr('checked', 'true');
				this.setTypeButton();
				
				
				//header fix
				$(window).scroll(function(){
			        if ($(this).scrollTop() > 100) {
			        	$('.jdg-ui-table-thead').hide();
			        	$('.jdg-ui-table-thead-fix').show();
			        } else {
			        	$('.jdg-ui-table-thead-fix').hide();
			        	$('.jdg-ui-table-thead').show();
			        };
			    });
				
			},
			'setEvent'		: function() {
				var _self = this;

				
				//datepicker set
				_self.$startDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				_self.$endDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				
				
				// 검색 라디오버튼 변경시
				_self.$searchType.change(function(){
					_self.setTypeButton();
				});
				
				 
				
				//click button
				_self.$thisWeek.click(function(){
					_self.clickTypeButton(_self.$thisWeek);
				});
				_self.$lastWeek.click(function(){
					_self.clickTypeButton(_self.$lastWeek);
				});
				_self.$thisMonth.click(function(){
					_self.clickTypeButton(_self.$thisMonth);
				});
				_self.$lastMonth.click(function(){
					_self.clickTypeButton(_self.$lastMonth);
				});
				_self.$lastSixMonth.click(function(){
					_self.clickTypeButton(_self.$lastSixMonth);
				});
				_self.$thisYear.click(function(){
					_self.clickTypeButton(_self.$thisYear);
				});
				_self.$lastYear.click(function(){
					_self.clickTypeButton(_self.$lastYear);
				});
				
				_self.$srchForm.submit(function() {

					var URL =  $(':radio[name="searchRdo"]:checked').val();
					var param = {
							"START_DATE" : _self.stringFilter(_self.$startDate.val(), "removeHyphen"),
							"END_DATE" : _self.stringFilter(_self.$endDate.val(), "removeHyphen"),
							"SHIP_ID": $("#selectShip").val(),
							"URL" : URL
					};
					
					
					if(_self.$startDate.val() == '' ||  _self.$endDate == '' ){
						alert('기간을 입력해주세요.');
					}
					
					
					//기간체크
					var dataKey = $(':radio[name="searchRdo"]:checked').attr('data-key');
					var startDate = _self.stringFilter(_self.$startDate.val(), 'date');
					startDate = new Date(startDate);
					var endDate = _self.stringFilter(_self.$endDate.val(), 'date');
					endDate = new Date(endDate);
					
					if(dataKey == 'day'){
						var temp = new Date(endDate.getFullYear(), endDate.getMonth()-2, endDate.getDate());
						if(temp > startDate){
							alert('최대 2개월까지 조회할수 있습니다.');
							return;
						}
					}
					if(dataKey == 'week'){
						var temp = new Date(endDate.getFullYear(), endDate.getMonth()-6, endDate.getDate());
						if(temp > startDate){
							alert('최대 6개월까지 조회할수 있습니다.');
							return;
						}
					}
					if(dataKey == 'month'){
						var temp = new Date(endDate.getFullYear()-2, endDate.getMonth(), endDate.getDate());
						if(temp > startDate){
							alert('최대 2년까지 조회할수 있습니다.');
							return;
						}
					}
					_self.setSearchCookie();
					_self.getStatList(param);
					
					return false;
				});
			},
			
			'getStatList' : function(param){
				var _self = this;
				$.ajax({
					 url : param.URL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	//리스트
				    	_self.list.createList( data.statList, 'SCHD_DATE' , function( data, $row ) {
				    		var schdGb = data.SCHD_GB;
				    		if(schdGb == 'SAT'){
				    			//토요일일때 blue
				    			$row.children('td').attr('style', 'color:blue');
				    			$row.find('[data-key=SCHD_DATE]').text(_self.stringFilter($row.find('[data-key=SCHD_DATE]').text(), 'date'));
				    		}else if(schdGb == 'SUN'){
				    			//일요일일때 red
				    			$row.children('td').attr('style', 'color:red');
				    			$row.find('[data-key=SCHD_DATE]').text(_self.stringFilter($row.find('[data-key=SCHD_DATE]').text(), 'date'));
				    		}else if(schdGb == 'SUM1'){
				    			//중간 sum1 이탤릭체
				    			$row.children('td').children('em').attr('style', 'font-style:italic');
				    			$row.find('[data-key=SCHD_DATE]').text(_self.stringFilter($row.find('[data-key=SCHD_DATE]').text(), 'date'));
				    		}else if(schdGb == 'SUM2'){
				    			//중간 sum2 굵게
				    			$row.children('td').children('em').attr('style', 'font-weight:bold;');
				    			$row.find('[data-key=SCHD_DATE]').text(_self.stringFilter($row.find('[data-key=SCHD_DATE]').text(), 'date'));
				    		}else if(schdGb == 'SUM'){
				    			//전체 sum
				    			$row.addClass('jdg-tr-total');
				    			$row.find('[data-key=SCHD_DATE]').text("합계");
				    		}else{
				    			$row.find('[data-key=SCHD_DATE]').text(_self.stringFilter($row.find('[data-key=SCHD_DATE]').text(), 'date'));	
				    		}
				    		
				    		//금액 comma
				    		$row.find('[data-key=MAN_CNT1_300]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_300]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT1_310]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_310]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT1_340]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_340]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT1_410]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_410]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT1_420]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_420]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT1_430]').text(_self.stringFilter($row.find('[data-key=MAN_CNT1_430]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_300]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_300]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_310]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_310]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_340]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_340]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_410]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_410]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_420]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_420]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST1_430]').text(_self.stringFilter($row.find('[data-key=TOT_COST1_430]').text(), 'money'));

				    		$row.find('[data-key=MAN_CNT2_300]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_300]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT2_310]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_310]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT2_340]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_340]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT2_410]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_410]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT2_420]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_420]').text(), 'money'));
				    		$row.find('[data-key=MAN_CNT2_430]').text(_self.stringFilter($row.find('[data-key=MAN_CNT2_430]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_300]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_300]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_310]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_310]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_340]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_340]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_410]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_410]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_420]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_420]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST2_430]').text(_self.stringFilter($row.find('[data-key=TOT_COST2_430]').text(), 'money'));
			    		});
				    	
				    	
				    	if (data.statList != null && data.statList.length > 0)
				    		{				    	
						    	var lastRow = data.statList[data.statList.length - 1];
						    	
						    	_self.list2.appendList( lastRow, 'SCHD_DATE' , function( data, $row ) {	

						    		
						    		//금액 comma
						    		$row.find('[data-key=TOTAL_CNT_300]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_300]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_CNT_310]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_310]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_CNT_340]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_340]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_CNT_410]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_410]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_CNT_420]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_420]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_CNT_430]').text(_self.stringFilter($row.find('[data-key=TOTAL_CNT_430]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_300]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_300]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_310]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_310]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_340]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_340]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_410]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_410]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_420]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_420]').text(), 'money'));
						    		$row.find('[data-key=TOTAL_COST_430]').text(_self.stringFilter($row.find('[data-key=TOTAL_COST_430]').text(), 'money'));
						    		
						    	});
				    	
				    		}
				    	
				    }
				});
			},
			
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length == 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(-?[0-9]+)([0-9]{3})/;
					while(pattern.test(str)) {
						str = str.replace(pattern,"$1,$2");
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},
			
			//일,주,월 선택별로 보여지는 버튼 세팅
			'setTypeButton' : function(){
				var _self = this;
				if($(':radio[name="searchRdo"]:checked').attr('data-key') == 'day'){
					_self.$thisWeek.show();
					_self.$lastWeek.show();
					_self.$thisMonth.show();
					_self.$lastMonth.show();
					_self.$lastSixMonth.hide();
					_self.$thisYear.hide();
					_self.$lastYear.hide();
				}else if ($(':radio[name="searchRdo"]:checked').attr('data-key') == 'week'){
					_self.$thisWeek.hide();
					_self.$lastWeek.hide();
					_self.$thisMonth.show();
					_self.$lastMonth.show();
					_self.$lastSixMonth.show();
					_self.$thisYear.hide();
					_self.$lastYear.hide();
				}else if ($(':radio[name="searchRdo"]:checked').attr('data-key') == 'month'){
					_self.$thisWeek.hide();
					_self.$lastWeek.hide();
					_self.$thisMonth.hide();
					_self.$lastMonth.hide();
					_self.$lastSixMonth.show();
					_self.$thisYear.show();
					_self.$lastYear.show();
				}
			},
			
			//버튼 클릭시 날짜 셋팅
			'clickTypeButton' : function( $button ){
				var _self = this;
				var now = new Date();
				var nowDayOfWeek = now.getDay();
				var nowMonth = now.getMonth(); 
				var nowDay = now.getDate(); 
				var nowYear = now.getYear(); 
				nowYear += (nowYear < 2000) ? 1900 : 0; 
				 
				if($button == _self.$thisWeek){
					//이번주
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));
					_self.$startDate.val(_self.converDateString(weekStartDate));
					_self.$endDate.val(_self.converDateString(weekEndDate));
				}
				if($button == _self.$lastWeek){
					//지난주
					nowDay += -7;
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));
					_self.$startDate.val(_self.converDateString(weekStartDate));
					_self.$endDate.val(_self.converDateString(weekEndDate));
				}
				if($button == _self.$thisMonth){
					//이번달
					var monthStartDate = new Date(nowYear, nowMonth, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$lastMonth){
					//지난달
					var monthStartDate = new Date(nowYear, nowMonth-1, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$lastSixMonth){
					//최근6개월
					var monthStartDate = new Date(nowYear, nowMonth-5, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$thisYear){
					//이번해
					var yearStartDate = new Date(nowYear, 0, 1); 
				    var yearEndDate = new Date(nowYear, 12, 0);
					_self.$startDate.val(_self.converDateString(yearStartDate));
					_self.$endDate.val(_self.converDateString(yearEndDate));
				}
				if($button == _self.$lastYear){
					//지난해
					var yearStartDate = new Date(nowYear-1, 0, 1); 
				    var yearEndDate = new Date(nowYear-1, 12, 0);
					_self.$startDate.val(_self.converDateString(yearStartDate));
					_self.$endDate.val(_self.converDateString(yearEndDate));
				}
			},
			
			//date를 String으로 변경.
			'converDateString' : function(dt){
				function addZero(i){
					var rtn = i + 100;
					return rtn.toString().substring(1,3);
				}
				return dt.getFullYear() + "-" + addZero(eval(dt.getMonth()+1)) + "-" + addZero(dt.getDate());
			},
			
			//쿠키 set
			'setSearchCookie' : function(){
				var _self = this;
				$.cookie('stat.startDate', _self.$startDate.val());
				$.cookie('stat.endDate', _self.$endDate.val());
				$.cookie('stat.type', $(':radio[name="searchRdo"]:checked').attr('data-key'));
				
			},
			
			//쿠키 get
			'getSerchCookie' : function(cookieName){
				return $.cookie(cookieName);
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
