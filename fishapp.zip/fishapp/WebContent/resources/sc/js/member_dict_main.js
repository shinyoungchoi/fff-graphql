defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				
				this._dictListURL = "/sc/member/dictionary/list";
				this._dictSaveUrl = "/sc/member/dictionary/save";
				this._dictUpdateUrl = "/sc/member/dictionary/update";
				this._dictRemoveUrl = "/sc/member/dictionary/remove";
				this._page = 1;
				this._btnType="register";
			
				this.$dictForm = $("#dictSearchForm");
				this.$dictContainer = $('#dictContainer');
				this.$dictTemplate = $('#keywordDictTemplate');
				
				
				this.$regBtn = $('#regBtn');
			
				this.selectSubPage = ''; //포인트 내역 목록 페이징
				
				this.list_dict = new component.List({
					 'container' : this.$dictContainer
					,'template' : this.$dictTemplate.find('.searchRow')
					,'nodata' : this.$dictTemplate.find('.nodataRow')
				});
				
				this.$selectedSortOption = "";
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$dictForm.submit(function() {
					// 회원목록조회
					
					var searchType = $("input[name=searchType]:checked").val();
					var searchText = $("#searchText").val();
					if(searchText == ""){
						alert("조회하시려는 단어를 입력해주세요.");
						return false;
					}
					
					var param = {
							SEARCH_TYPE : searchType,
							SEARCH_TEXT : searchText
					}
					_self.getDictList('1',param);
					return false;
				});
						
				$("#removeBtn").click(function(){
					if(!confirm("삭제하시겠습니까?")){
						return;
					}
					
					if($("#dic_word").val() == ""){
						alert("삭제하시려는 단어를 선택해주세요.");
						return;
					}
					
					var param = {
							WORD : $("#dic_word").val()
					}
					
					$.ajax({
						 url : _self._dictRemoveUrl
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if(data.result == "success"){
					    		alert("삭제되었습니다.");
					    		location.reload();
					    	}else{
					    		if(data.message != undefined && data.message != "")
					    			alert(data.message);
					    		else
					    			alert("삭제도중 오류가 발생하였습니다.");
					    		return;
					    	}
					    	
					    }
					});
				});

				$("#regBtn").click(function(){
					
					if($("#dic_word").val() == ""){
						alert("단어를 입력해주세요.");
						return;
					}
					
					if($("#dic_keyword").val() == ""){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					if($("#dic_type").val() == ""){
						alert("타입을 입력해주세요.");
						return;
					}
					
					var param = {
							WORD : $("#dic_word").val()
							, KEYWORD : $("#dic_keyword").val()
							, WORD_TYPE : $("#dic_type").val() 
					}
					
					var url = _self._dictSaveUrl;
					if(_self._btnType == "update"){
						url = _self._dictUpdateUrl;
					}
					
					$.ajax({
						 url : url
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if(data.result == "success"){
					    		alert("검색어 사전에 저장되었습니다.");
								location.reload();
					    	}else{
					    		if(data.message != undefined && data.message != "")
					    			alert(data.message);
					    		else
					    			alert("저장도중 오류가 발생하였습니다.");
					    		return;
					    	}
					    	
					    }
					});
				});
				
				//답변 입력 취소시
				$("#cancleBtn").click(function(){
					//검색 사전 입력 폼 초기화
					$("#dic_word").val("");
					$("#dic_keyword").val("");
					$("#dic_type").val("");
					
					$("#dic_word").removeAttr("disabled");
					//삭제버튼 사라짐.
					$("#removeBtn").hide();
					//테이블 선택 초기화
					$('#dictContainer tr').each(function(){
						$(this).attr("style", "background:#fff;");
					});
					_self._btnType="register";
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$dictContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.showDetail( $this );
				});
			},
			
			'showDetail' : function($tr){
				var _self = this;
				
				$('#dictContainer tr').each(function(){
					$(this).attr("style", "background:#fff;");
				});
				
				$tr.attr("style", "background:#fce711;");
				
				var word = $tr.find("td:eq(0)").text();
				var keyword = $tr.find("td:eq(1)").text();
				var type = $tr.find("td:eq(2)").text();
				
				$("#dic_word").val(word);
				$("#dic_keyword").val(keyword);
				$("#dic_type").val(type);
				$("#dic_word").attr("disabled", "disabled");
				$("#removeBtn").show();
				_self._btnType="update";
			},
			// 검색 사전 조회
			'getDictList' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._dictListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('dict_list') ) {
				    		// 리스트 초기화
				    		_self.list_dict.createList( data.dict_list, 'WORD' , function( data, $row ) {
				    		});
				    		
				    		var max_ = 0;
				    		if(data.dict_list != null && data.dict_list.length > 0){
				    			max_ = Math.ceil(data.dict_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#dictContainerPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getDictList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
		
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				//사전 검색
				this.getDictList('1', p_param);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
