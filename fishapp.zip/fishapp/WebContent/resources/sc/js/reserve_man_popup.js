defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveManListURL = $('#reserveManListURL').val();
				this._reserveManInsertURL = $('#reserveManInsertURL').val();
				this._reserveManUpdateURL = $('#reserveManUpdateURL').val();
				this._reserveManDeleteURL = $('#reserveManDeleteURL').val();
				// element
				this.$listContainer = $('#reserveManListContainer');
				this.$listTemplate = $('#reserveManListTemplate');
				this.$detailForm = $('#reserveManDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$confirmBtn = $('#reserveManConfirmBtn');
				// form
				this.$insertForm = $('#reserveManInsertForm');
				this.$updateForm = $('#reserveManUpdateForm');
				// static variable
				this.rsvId = $('#rsvId').val();
				this.selectReserveId = '';
				this.selectManSeq = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					var $insertForm = _self.$insertForm;
					// validation
					if( !jdg.util.validator( $insertForm, true ) ) return false;
					var insertParam = {
						  'RSV_ID' : $insertForm.find('[data-type=RSV_ID]').text()
						, 'NAME' : $insertForm.find('[data-key=NAME]').val()
						, 'REG_NO' : $insertForm.find('[data-key=REG_NO]').val()
						, 'TEL' : $insertForm.find('[data-key=TEL]').val()
						, 'ADDR' : $insertForm.find('[data-key=ADDR]').val()
					};
					$.ajax({
						 url : _self._reserveManInsertURL
						,type : 'POST'
						,data : insertParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		if( data.result > 0 ) {
						    		alert('등록 되었습니다');
						    		location.reload();
					    		} else {
					    			alert('해당 예약의 승선명부가 모두 등록되었습니다.');
					    		}
					    	}
					    }
					});
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowDataFromDouble(_self.selectReserveId,'RSV_ID',_self.selectManSeq,'MAN_SEQ') );
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					var $updateForm = _self.$updateForm;
					// validation
					if( !jdg.util.validator( $updateForm, true ) ) return false;
					var updateParam = {
						  'RSV_ID' : _self.selectReserveId
						, 'MAN_SEQ' : _self.selectManSeq
						, 'NAME' : $updateForm.find('[data-key=NAME]').val()
						, 'REG_NO' : $updateForm.find('[data-key=REG_NO]').val()
						, 'TEL' : $updateForm.find('[data-key=TEL]').val()
						, 'ADDR' : $updateForm.find('[data-key=ADDR]').val()
					};
					$.ajax({
						 url : _self._reserveManUpdateURL
						,type : 'POST'
						,data : updateParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('수정 되었습니다');
					    		location.reload();
					    	}
					    }
					});
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					$.ajax({
						 url : _self._reserveManDeleteURL
						,type : 'POST'
						,data : {
							  'RSV_ID' : _self.selectReserveId
							 ,'MAN_SEQ' : _self.selectManSeq
						}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('삭제 되었습니다');
					    		location.reload();
					    	}
					    }
					});
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.selectReserveId = $this.find('[data-key=RSV_ID]').text();
					_self.selectManSeq = $this.find('[data-key=MAN_SEQ]').text();
					_self.selectFormShow('search', _self.list.getListRowDataFromDouble(_self.selectReserveId,'RSV_ID',_self.selectManSeq,'MAN_SEQ'));
					// style
					_self.$listContainer.find('tr').removeClass('jdg-selected');
					$this.addClass('jdg-selected');
				});
				
				// 확인 버튼 클릭
				_self.$confirmBtn.click(function() {
					opener.Bplat.view.closePopup();
					window.close();
				});
				
			},	
			// 승선명부 목록 조회
			'getReserveManList' : function( page ) {
				var _self = this;
				$.ajax({
					 url : _self._reserveManListURL
					,type : 'POST'
					,data : {
						 'PAGE' : page
						,'PERPAGE' : '5'
						,'RSV_ID' : _self.rsvId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('reserveManList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.reserveManList, null, function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}	    			
				    		});
				    		// 페이징 초기화
				    		$('#reserveManListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getReserveManList(page);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=RSV_ID] option:eq(0)').attr('selected',true);
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[reserve_man_popup] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 승선명부목록조회
				this.getReserveManList( '1' );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[reserve_man_popup] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_man_popup] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[reserve_man_popup] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[reserve_man_popup] onDestroy Method' );
			}		
	  }
});
