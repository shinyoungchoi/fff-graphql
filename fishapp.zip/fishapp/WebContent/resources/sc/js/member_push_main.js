defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = "/sc/point/list";
				
				// element
				this.$commentForm = $('#commentForm');
				
				this.$targetListContainer = $("#targetListContainer");
				this.$targetListTemplate= $("#targetListTemplate");
				
				this.$rec_type = $('#rec_type');
				
				this.$regBtn = $('#regBtn');
				
				this.clickable = true;
				
				// static variable
				this.ShipMemberList = [];
				this.selectMemberId = '';
				this.selectDetailData = {};
				
				this.list = new component.List({
					 'container' : this.$targetListContainer
					,'template' : this.$targetListTemplate.find('.searchRow')
					,'nodata' : this.$targetListTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				//푸쉬 목록 검색 조건 변경
				$("input:radio[name='checkType']").change(function(){
					var value = $(this).val();
					_self.getTargetList(1);
				});
				
				// 알림 보내기
				_self.$regBtn.click(function() {
					if(!_self.clickable){
						return;
					}
					_self.clickable = false;
					
					var param = {
						'TYPE' : _self.$commentForm.find('#rec_type option:selected').val(),
						'MEMTYPE' : _self.$commentForm.find('#rec_mem option:selected').val(),
						'TITLE' : _self.$commentForm.find('#rec_title').val(),
						'CONTENT' : _self.$commentForm.find('#rec_content').val(),
						'FISHES' : _self.$commentForm.find("#rec_fish").val(),
						'LOCS' : _self.$commentForm.find("#rec_loc").val(),
						'LINK' : _self.$commentForm.find("#rec_link").val()
					};
					
					if(param.TYPE == null || param.TYPE == ''){
						alert("수신타입을 선택해주세요.");
						return;
					}
					
					if(param.TITLE == null || param.TITLE == ''){
						alert("제목을 입력해주세요.");
						return;
					}
					
					if(param.CONTENT == null || param.CONTENT == ''){
						alert("알림 내용을 입력해주세요.");
						return;
					}
					
										
					_self.sendPush(param);
					return false;
				});
				
				
				_self.$rec_type.change(function() {
					var value = $(this).val();
					if(value == '2'){
						$("#rec_type2_1").attr("style", "display:none;");
						$("#rec_type2_2").attr("style", "display:none;");
						$("#rec_type2_3").attr("style", "display:none;");
						$("#rec_fish").val("");
						$("#rec_loc").val("");
						$("#rec_mem").val("1");
					}else{
						$("#rec_type2_1").attr("style", "display:;");
						$("#rec_type2_2").attr("style", "display:;");
						$("#rec_type2_3").attr("style", "display:;");
					}
					
					return false;
										
				});
				
			},
			// 상세 펼침
			'sendPush' : function( param ) {
				var _self = this;
				
				$.ajax({
					 url : '/sc/member/send'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
						    	console.log(data.msg);
						    	if(data.msg == 'ok'){
						    		_self.clickable = true;
						    		alert("전송되었습니다.");
						    		_self.$commentForm.find("input:text").attr("value","");
						    		_self.getTargetList(1);
						    		return;
						    	}
						    	
						    	_self.clickable = true;
						    	alert("전송도중 오류가 발생하였습니다.");
						    	return;
				    	}
				    	
				    }
				});
			},
			// 회원별 적립금 내역 조회
			'getTargetList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : 10
				    ,'TYPE': $("input:radio[name='checkType']:checked").val()
				};
				
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectSubPage = page;
				$.ajax({
					 url : '/sc/member/push/list'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('list') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.list, 'CREATED_AT' , function( data, $row ) {

				    		});
				    		
				    		var max_ = 0;
				    		if(data.list != null && data.list.length > 0){
				    			max_ = Math.ceil(data.list[0].TOTAL / defaultParam.PERPAGE);
				    		}
				    		// 페이징 초기화
				    		$('#targetListPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getTargetList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getTargetList(1);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
