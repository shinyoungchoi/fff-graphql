defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = $('#memberListURL').val();
				this.$pointInsertForm = $('#pointInsertForm');
				this.$plusDiv = $(".plus_div");
				this.$minusDiv = $(".minus_div");
				this.$point_value_d = $("#point_value_d");
				this.$pointCode = $("#point_code");
				this.$pointValue = $("#point_value");
				this.$confirmBtn = $('#memberConfirmBtn');
				this.$closeBtn = $('#memberCloseBtn');
			},
			'setEvent'		: function() {
				var _self = this;
				
				//포인트 코드명 선택시 적립/사용으로 나뉨
				_self.$pointCode.change(function(){
					var value = $(this).val();
					if(value == "140_099"){
						_self.$plusDiv.removeClass("is_selected");
						_self.$minusDiv.addClass("is_selected");
					}else{
						_self.$plusDiv.addClass("is_selected");
						_self.$minusDiv.removeClass("is_selected");
					}
				});
				
				//포인트 금액 변경 시
				_self.$pointValue.change(function(){
					var value = $(this).val();
					if(value == ""){
						_self.$point_value_d.show();
					}else{
						_self.$point_value_d.hide();
					}
				});
				
				// 저장 버튼 클릭
				_self.$confirmBtn.click(function() {
					
					_self.savePoint();
				});
				
				// 취소 버튼 클릭
				_self.$closeBtn.click(function() {
					opener.Bplat.view.closePopup();
					window.close();
				});
			},
			// 회원 목록 조회 (시스템관리자 제외)
			'savePoint' : function( ) {
				var _self = this;
				var $pointInsertForm = _self.$pointInsertForm;
				// validation
				if( !jdg.util.validator( $pointInsertForm, true ) ) return false;
				
				var point = 0;
				if(_self.$pointValue.val() == ""){
					//직접입력
					point = _self.$point_value_d.val();
				}else{
					point = _self.$pointValue.val();
				}
				
				if(point == 0){
					alert("포인트 금액을 입력해주세요.");
					return;
				}
				
				if(!(/^\d+$/.test(point)) ) {
					alert( '포인트는 숫자로만 입력 가능합니다.');
					return;
				}
				
				var param = {
					  'MEM_ID' : this.mem_id,
					  'USER_ID' : $("#userId").text(),
					  'CATE_CODE' : $pointInsertForm.find("[data-key=CATE_CODE]").val(),
					  'REMARK'	 :  $pointInsertForm.find("[data-key=REMARK]").val(),
					  'POINT' 	: point
				};
			
				$.ajax({
					 url : "/sc/point/save"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if(data.result == "success"){
				    		alert("포인트 내역을 저장하였습니다.");
				    		opener.Bplat.view.closePopup( param.MEM_ID );
							window.close();
				    	}else{
				    		if(data.message != ""){
				    			alert(data.message);
				    			return;
				    		}
				    		alert("포인트 내역 저장도중 오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_search_popup] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				this.mem_id = p_param.MEM_ID;
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_search_popup] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_search_popup] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_search_popup] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_search_popup] onShowPopup Method', JSON.stringify( p_param ) );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_search_popup] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_search_popup] onDestroy Method' );
			}
	  }
});
