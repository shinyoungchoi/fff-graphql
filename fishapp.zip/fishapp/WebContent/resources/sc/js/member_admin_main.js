defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._adminMemberListURL = $('#adminMemberListURL').val();
				this._adminMemberInsertURL = $('#adminMemberInsertURL').val();
				this._adminMemberUpdateURL = $('#adminMemberUpdateURL').val();
				this._adminMemberDeleteURL = $('#adminMemberDeleteURL').val();
				this._memberListURL = $("#memberListURL").val();
				// element
				this.$listContainer = $('#adminMemberListContainer');
				this.$listTemplate = $('#adminMemberListTemplate');
				this.$detailForm = $('#adminMemberDetailForm');
				
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$mSrhKeyRadio = $('[name=memberSearchTerms]');
				this.$mSrhVal = $('#memberSearchVal');
				
				this.$adminSearchTermsRadio = $("[name='adminSearchTerms']");
				this.$adminSearchVal = $("#adminSearchVal");
				this.$memSearchBtn = $("#memSearchBtn");
				this.$registerMemselect = $("#registerMemselect");
				
				// form
				this.$srchForm = $('#adminMemberSearchForm');
				this.$insertForm = $('#adminMemberInsertForm');
				this.$updateForm = $('#adminMemberUpdateForm');
				// static variable
				this.selectAdminMemberId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$srchForm.submit(function() {
					// 회원목록조회
					var param = {};
				    var key = _self.$mSrhKeyRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$mSrhVal.val());
					}
					_self.getAdminMemberList('1', param);
					return false;
				});
				
				//등록폼에서 회원 검색
				_self.$memSearchBtn.click(function(){
					var param = {};
				    var key = _self.$adminSearchTermsRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$adminSearchVal.val());
					}
					_self.getSearchmberList(param);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertAdminMember();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectAdminMemberId, 'MEM_ID') );
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateAdminMember();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteAdminMember();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );

				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectAdminMemberId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectAdminMemberId, 'MEM_ID'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			//등록시 회원 검색
			'getSearchmberList': function(param){
				var _self = this;
				param.PAGE =1;
				param.PERPAGE = 10000;
				
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				   			 console.log(data);
				   			  _self.$registerMemselect.html("");
				    	if( data.hasOwnProperty('memberList') ) {
				    	 	var list = data.memberList;
					    	 for(var i = 0 ;i < list.length ;i++){
						    	  var item = list[i];
						    	  _self.$registerMemselect.append("<option value='"+item.MEM_ID+"'>"+item.MEM_NAME+"</option>");
					    	 }
				    	}
				    	
				    }
				});
			
			},
			// 회원 목록 조회
			'getAdminMemberList' : function( page, param, showDetailId ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;	
				console.log(defaultParam);
							
				$.ajax({
					 url : _self._adminMemberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				   			 console.log(data);
				    	if( data.hasOwnProperty('adminMemberList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.adminMemberList, 'MEM_ID' , function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    		});
				    		// 페이징 초기화
				    		$('#adminMemberListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getAdminMemberList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.adminMemberList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 시스템 관리자 등록
			'insertAdminMember' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var insertParam = {
					  'MEM_ID' : $insertForm.find('[data-type=MEM_ID] option:selected').val()
					, 'LOGIN_ID' : $insertForm.find('[data-key=LOGIN_ID]').val()
					, 'PWD' : $insertForm.find('[data-key=PWD]').val()
					, 'EMAIL' : $insertForm.find('[data-key=EMAIL]').val()
				};
				$.ajax({
					 url : _self._adminMemberInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 시스템 관리자 수정
			'updateAdminMember' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateParam = {
					  'MEM_ID' : $updateForm.find('[data-key=MEM_ID]').text()
					, 'LOGIN_ID' : $updateForm.find('[data-key=LOGIN_ID]').val()
					, 'PWD' : $updateForm.find('[data-key=PWD]').val()
					, 'EMAIL' : $updateForm.find('[data-key=EMAIL]').val()
				};
				$.ajax({
					 url : _self._adminMemberUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getAdminMemberList( _self.selectPage, {}, _self.selectFishId);
				    	}
				    }
				});
			},
			// 시스템 관리자 삭제
			'deleteAdminMember' : function() {
				var _self = this;
				$.ajax({
					 url : _self._adminMemberDeleteURL
					,type : 'POST'
					,data : {
						 'MEM_ID' : _self.selectAdminMemberId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_admin_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 회원목록조회
				this.getAdminMemberList('1', p_param);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_admin_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_admin_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_admin_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_admin_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_admin_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_admin_main] onDestroy Method' );
			}		
	  }
});
