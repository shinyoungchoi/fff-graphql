defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// element
				this.$srhSel = $('#searchShipSel');
				this.$chkYear = $('#checkYear');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				this.$detailForm = $('#scheduleDetailForm');

				//출조 당월 등록
				this.$registerMonthBtn = $("#register_month");
				this.$updateScheduleBtn = $("#updateScheduleBtn");
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$deleteScheduleBtn = $('#deleteScheduleBtn');
				//해당 월 스케쥴 전체 보이기, 감추기
				this.$showAll = $("#show_all");
				this.$hideAll = $("#hide_all");
				
				this.$useAll = $("#use_all");
				this.$removeAll = $("#remove_all");
				
				this.$btnDelete = $("input.btn_delete");
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				//수정 form
				this.$updateForm = $('#scheduleUpdateForm');
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				var date = new Date();
				
				$("#checkYear").val(date.getFullYear());
				$("#selectYear").val(date.getFullYear());
				
				//모든 스케쥴 삭제를 위한 클릭
				$("#allselected").click(function(){
					if(!confirm("화면에 보이는 모든 스케쥴을 선택하시겠습니까?"))
						return;
					
					$("input:checkbox[name=delCheck]").each(function(){
						if($(this).attr("ptype") == '0')
							$(this).trigger("click");
					})
				});
				
				//년도에 따라 월별 등록 여부 표가 바뀜.
				$("#checkYear").change(function(){
					var year = $(this).val();
					if(_self.$srhSel.find('option:selected').val() == ""){
						alert("선박을 선택해주세요.");
						return;
					}
					_self.getScheduleByMonth({SCHD_DATE : year, SHIP_ID : _self.$srhSel.find('option:selected').val()});
				});
					
				//스케쥴 삭제
				_self.$btnDelete.click(function(){
					if(!confirm("선택하신 스케쥴 및 장르를 삭제하시겠습니까? \n (장르 삭제를 원하시면 스케쥴 삭제 후 낚시장르에서도 삭제해주세요.)")){
						 return;
					}
					var params = [];
					$("input:checkbox[name='delCheck']").each(function(index, item){
						var checkYn = $(this).is(":checked");
						
						if(checkYn){
							var pType = $(this).attr("ptype");
							var pSchdId = $(this).attr("pschdid");
							var pGenre = $(this).attr("pgenre");
							
							var param = { TYPE : pType, SCHD_ID : pSchdId, GENRE : pGenre};
							params.push(param);
						}
					});
				
					if(params == null || params.length < 1){
						alert("삭제하실 스케쥴을 선택해주세요.");
						return;
					}
					_self.deleteScheduleGenre(params);
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 조회만 하기
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val(),
						'DOTYPE' : 'SELECT'
					});
					//월별 등록 여부
					_self.getScheduleByMonth({ 'SHIP_ID' : _self.$srhSel.find('option:selected').val(), 'SCHD_DATE' : _self.$chkYear.find('option:selected').val()});
					
					//상세 장르 템플릿 승선 인원수 초기화
					//_self.createOptionSelect( $("#updateDetailForm").find('[data-type=PSGR_CNT]'), $("#updateDetailForm").find('[data-type=PSGR_CNT]').attr('psgrcnt'));
					
					return false;
				});
				
				//년, 월에 등록
				_self.$registerMonthBtn.click(function(){
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val(),
						'DOTYPE' : 'REGISTER'
					});
					//상세 장르 템플릿 승선 인원수 초기화
					//_self.createOptionSelect( $("#updateDetailForm").find('[data-type=PSGR_CNT]'),_self.$srhSel.find('option:selected').attr('psgrCnt'));
				});
				
				//체크한 장르 사용함으로 변경.
				_self.$useAll.click(function(){

					var params = [];
					$("table.jdg-cmpt-list").find("input:checkbox[name='genreUse']").each(function(index, item){
						var schdId = $(this).attr("pschdid");
						var genreId = $(this).attr("pgenre");
						var type = $(this).attr("ptype");
						var checked = $(this).is(":checked");
						console.log(schdId, genreId, checked);
						
						if(checked){
							var param = { SCHD_ID : schdId, GENRE : genreId, USE_YN : 'Y', TYPE : type};
							params.push(param);
						}
						
					});

					
					_self.updateGenre(params);
				});
				
				//체크한 장르 사용안함으로 변경
				_self.$removeAll.click(function(){
					
					var params = [];
					$("table.jdg-cmpt-list").find("input:checkbox[name='genreUse']").each(function(index, item){
						var schdId = $(this).attr("pschdid");
						var genreId = $(this).attr("pgenre");
						var type = $(this).attr("ptype");
						var checked = $(this).is(":checked");
						console.log(schdId, genreId, checked);
						
						if(checked){
							var param = { SCHD_ID : schdId, GENRE : genreId, USE_YN : 'N', TYPE : type};
							params.push(param);
						}
					});
					_self.updateGenre(params);
				})
				
				//해당 월의 스케쥴 전체 보이기
				_self.$showAll.click(function(){
					var shipId =  _self.$srhSel.find('option:selected').val();
					var year =  $("#selectYear option:selected").val();
					var month = $("#selectMonth option:selected").val();
					_self.updateAllShow('show', shipId, year, month);
				});
				
				//해당 월의 스케쥴 전체 감추기
				_self.$hideAll.click(function(){
					var shipId =  _self.$srhSel.find('option:selected').val();
					var year =  $("#selectYear option:selected").val();
					var month = $("#selectMonth option:selected").val();
					_self.updateAllShow('hide', shipId, year, month);
				});
				
				//리스트에서 스케쥴 별 노출 여부 변경
				$("#scheduleListContainer").on("change", "select[name=delFlagsBy]" , function(){
					var value= $(this).val();
					var pid = $(this).attr("pid");
					_self.changeDelFlag(value, pid);
				});
				
				//수정
				_self.$updateScheduleBtn.click(function(){
					_self.updateSchedule();
					return false;
				});
				
				//삭제
				_self.$deleteScheduleBtn.click(function(){
					_self.deleteSchedule("Y");
					return false;
				});
				
				//출조 취소시 사유쓰는 input 보임
				_self.$updateForm.find("[data-key=STATUS_CD]").change(function(){
					$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").val("");
					if($(this).val() == '113_210'){
						$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").show();
					}else
						$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").hide();
				});
				
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					if($(this).attr("rowkey") != undefined)
						_self.openDetailForm( $this );
				});
			},
			//체크박스 선택된 장르, 스케쥴 삭제
			'deleteScheduleGenre' : function(param){
				var _self = this;
				$.ajax({
					 url : "/sc/schedule/deleteScheduleGenre"
					,type : 'POST'
					,data : { param : JSON.stringify(param)}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}else if( data.hasOwnProperty('error') ){
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			'updateGenre' : function(param){
				var _self = this;
				$.ajax({
					 url : "/sc/schedule/updateGenreStatus"
					,type : 'POST'
					,data : { param : JSON.stringify(param)}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			'updateAllShow' : function(type, shipId, year, month){
				var _self = this;
				if(shipId == ''){
					alert("배를 선택해주세요.");
					return;
				}
				month = ("0" + month).slice(-2);
				var param = { TYPE : type, SHIP_ID :shipId ,SCHD_COMPARE_DATE: year+month};
				
				if(type == 'show'){
					type = "전체 보임";
				}else{
					type = "전체 숨김";
				}
				
				if(!confirm( _self.$srhSel.find('option:selected').text() +"의 "+ year+"년도 "+ month +"월의 스케쥴을 "+type+"으로 변경하시겠습니까?"))
					return;
				$.ajax({
					 url : "/sc/schedule/changeShowStatus"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : shipId});
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
				
			},
			'changeDelFlag' : function(value, pid){
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				var param = { SCHD_ID : pid, DEL_FLAG : value};
				$.ajax({
					 url : "/sc/schedule/changeDelFlag"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		$updateForm.hide();
				    		_self.getScheduleList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, pid);
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'SCHD_ID'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option value="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			// 년도 월별 등록 여부 조회 
			'getScheduleByMonth' : function(param){
				$.ajax({
					 url : "/sc/schedule/selectScheduleByMonth"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('monthList') ) {
				    		for(var i = 1 ;i < 13 ; i++){
				    			$("#monthTr").find("[tdkey='m_"+ i +"']").html("-");
				    		}
				    		
				    		for(var i =0 ;i < data.monthList.length ; i++){
				    			var item = data.monthList[i];
				    			if(item != null && item != undefined){
				    				var registerYn = item.REGISTER_YN;
					    			var month = item.MONTH;
				    				$("#monthTr").find("[tdkey='m_"+ month +"']").text(registerYn+"("+item.CNT+"개)");
				    			}
				    		}
				    	}
				    }
				});
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( page, param, showDetailId ) {
				var _self = this;
				
				var shipId = _self.$srhSel.val();
				
				if (shipId == '')
				{
					alert('선택된 선박이 없습니다!');
					return false;
				}
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : $("#selectPerPage").val()
					,'YEAR' : $("#selectYear").val()
					,'MONTH' : $("#selectMonth").val()
					,'STATUS_CD' : $("#selectReserve").val()
					,'SHIP_ID' : _self.$srhSel.find('option:selected').val()
				};

				$.extend( defaultParam, param );
				
				if(defaultParam.SCHD_ID != undefined && defaultParam.SCHD_ID != ''){
					//예약화면에서 넘어온 경우.
					defaultParam.YEAR = null;
					defaultParam.MONTH = null;
					defaultParam.STATUS_CD = null;
					defaultParam.SHIP_ID = null;
				}
				
				//전체선택시 조회 안되도록.
				if(_self.$srhSel.find('option:selected').val() == "" && (defaultParam.SCHD_ID == '' || defaultParam.SCHD_ID == undefined)){
					alert("선박을 선택해주세요.");
					return;
				}
				
				$('#span_ship_nm').text(_self.$srhSel.find("option:selected").text() + '의 스케쥴');
				$('#span_ship_nm').show();
				
				$('#loadingbar').attr("style", "display:;");
				
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/schedule/scheduleList2"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.scheduleList, 'SCHD_ID',  function( data, $row ) {
				    			$row.find("[data-key=SCHD_DATE]").attr("style", "font-weight:600;");
				    			var selectGenreYn ="";
				    			if(data.CHOICE_GENRE != undefined && data.CHOICE_GENRE != ''){
				    				selectGenreYn = "◆ ";
				    			}
				    			var time =  ( data.SCHD_TIME_STR == undefined || data.SCHD_TIME_STR == "-" )? "" : "("+data.SCHD_TIME_STR+")";  			
				    			// 날짜
				    			var selectDate = new Date(data.SCHD_DATE_STR);
				    			if(selectDate.getDay() == '1'){
				    				selectDate = "일";
				    			}else if(selectDate.getDay() == '2'){
				    				selectDate = "월";
				    			}else if(selectDate.getDay() == '3'){
				    				selectDate = "화";
				    			}else if(selectDate.getDay() == '4'){
				    				selectDate = "수";
				    			}else if(selectDate.getDay() == '5'){
				    				selectDate = "목";
				    			}else if(selectDate.getDay() == '6'){
				    				selectDate = "금";
				    			}else if(selectDate.getDay() == '7'){
				    				selectDate = "토";
				    			}else{
				    				selectDate = "-";
				    			}
				    			
				    			if( data.SCHD_DATE ) $row.find('[data-key=SCHD_DATE]').text( selectGenreYn + data.SCHD_DATE_STR + "("+ selectDate +")"+time );
				    			if( data.STATUS_CD == '113_110'){
				    				$row.find('[data-key=STATUS_NAME]').attr("style", "color:blue;");
				    			}else{
				    				$row.find('[data-key=STATUS_NAME]').attr("style", "color:red;");
				    			}
				    			
				    			if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined){
				    				$row.find('[data-key=SUB_SHIPNM]').html("<br/>("+data.SUB_SHIPNM+")");
				    			}
				    			var delCheck ="&nbsp;<input type='checkbox' name='delCheck' pType='0' pSchdId='"+data.SCHD_ID+"'>";				    					
				    			$row.find("[data-type=SCHD_DELETE]").html(delCheck);
		    					
				    			$row.find('[data-type=DEL_FLAG]').val(data.DEL_FLAG);
				    			$row.find('[data-type=DEL_FLAG]').attr("pId", data.SCHD_ID);
				    			
				    		}, function(data, $row){
				    			
				    			if($row.prev().find("[data-key=SCHD_DATE]").text().substring(0,10) != data.SCHD_DATE_STR){
				    				$row.css({"border-top-style": "double", "border-top-color":"#a7a7a7"});
				    			}
				    			
				    			if(data.detail != null && data.SCHD_TIME_TYPE == '0'){
				    				for(var i = 0 ;i < data.detail.length ;i++){
				    					var item = data.detail[i];
				    					console.log(item);
				    					if(i == 0){
				    						var header = "<tr id='t_0_"+ data.SCHD_ID +"' style='text-align:center;color:#ddd;'><td rowspan="+(data.detail.length+1) +"></td><td>삭제</td><td>날짜</td><td>낚시종류</td><td>장르제목</td><td>사용여부</td><td>1인당요금</td><td>독배요금</td><td>출조인원</td><td>어종</td><td>출조위치</td><td>적립률</td><td>할인금액</td><td>독배할인금액</td></tr>";
				    						$("tr[rowkey='"+data.detail[i].SCHD_ID+"']").after(header);
				    					}
				    					
				    					if(item.SUB_TITLE == null || item.SUB_TITLE == ""){
				    						continue;
				    					}
				    					
				    					var $tmp = $("#subListTemplate").clone();
				    					var time_ = (item.SCHD_TIME_STR != "-" ) ? "("+item.SCHD_TIME_STR+")" : "";
				    					$tmp.find("tr").attr("confKey", item.GENRE);
				    					if(data.detail.length != 1){
				    						var delCheck ="&nbsp;<input type='checkbox' name='delCheck' ptype='"+item.TYPE+"' pSchdId='"+data.SCHD_ID+"' pGenre='"+item.GENRE+"'>";				    					
				    						$tmp.find("[data-type=SCHD_DELETE]").html(delCheck);
				    					}else{			    						
				    						$tmp.find("[data-type=SCHD_DELETE]").html("-");
				    					}
				    					$tmp.find("[data-key=SCHD_DATE]").html(item.SCHD_DATE_STR + time_);
				    					$tmp.find("[data-key=SCHD_TIME_TYPE_STR]").html(item.SCHD_TIME_TYPE_STR+"<br/>["+item.GENRE +"]");
				    					$tmp.find("[data-key=SUB_TITLE]").text(item.SUB_TITLE);
				    					if(data.detail.length != 1 && data.CHOICE_GENRE != item.GENRE){
					    					var check = "&nbsp;<input type='checkbox' name='genreUse' ptype='"+item.TYPE+"' pSchdId='"+data.SCHD_ID+"' pGenre='"+item.GENRE+"'>";
					    					$tmp.find("[data-key=GENRE_USEYN_STR]").html(item.GENRE_USEYN_STR + check );
				    					}else{
				    						$tmp.find("[data-key=GENRE_USEYN_STR]").html(item.GENRE_USEYN_STR);
				    					}
				    				
				    					$tmp.find("[data-key=REG_FEE]").html(item.FEE);
				    					$tmp.find("[data-key=HOL_FEE]").html(item.FEE_WHOLE);
				    					$tmp.find("[data-key=LOC_DESC]").text(item.LOC_DESC);
				    					$tmp.find("[data-key=FISH_KIND]").text(item.FISH_KIND);
				    					$tmp.find("[data-key=PSGR_CNT]").text(item.PSGR_CNT);
				    					$tmp.find("[data-key=DSC_FEE]").text(item.DSC_FEE+"원");
				    					$tmp.find("[data-key=PNT_RATE]").text(item.PNT_RATE+"%");
				    					$tmp.find("[data-key=DSC_WHOLE_FEE]").text(item.DSC_WHOLE_FEE+"원");
				    					$("#t_0_"+ data.SCHD_ID).after($tmp.find("tbody").html());
				    				}
				    			}
				    		});
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total /  $("#selectPerPage").val()))
								,onclick:function(e,page){
									_self.getScheduleList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.scheduleList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    	
				    	$('#loadingbar').attr("style", "display:none;");
				    }
				});
			},
			// 출조스케줄 수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				// 출조일 가공
				var updateParam = {
					  'SCHD_ID' : _self.selectScheduleId
					, 'SCHD_TIME_TYPE' :  $updateForm.find('[data-key=SCHD_TIME_TYPE]').val()
					, 'CHOICE_GENRE' : $updateForm.find('[data-key=CHOICE_GENRE]').text()
					, 'CANCEL_DESC' : $updateForm.find('[data-key=CANCEL_DESC]').val() //취소사유
					, 'STATUS_CD' : $updateForm.find('[data-key=STATUS_CD] option:selected').val()
					, 'DEL_FLAG' :$updateForm.find("input:radio[name='delFlag']:checked").val()
					, 'FISH_KIND' : $updateForm.find('[data-key=FISH_KIND]').val()
					, 'RESERVE_CONFIRM_CNT' : $updateForm.find('[data-key=RESERVE_CONFIRM_CNT]').text()
					, 'RESERVE_WAIT_CNT' : $updateForm.find('[data-key=RESERVE_WAIT_CNT]').text()
				};
				
				if(updateParam.STATUS_CD == "113_210" && updateParam.DESC == ""){
					alert("출조스케쥴 출조 취소사유를 입력해주세요.");
					return;
				}
				
				if(updateParam.CHOICE_GENRE != ''){
					//선택된 장르가 있는 경우 위의 서머리 정보가 수정가능해짐.
					updateParam.SCHD_TIME = $updateForm.find('[data-type=SCHD_TIME]').val();
					if(updateParam.SCHD_TIME == ''){
						alert("출조시간을 입력해주세요.");
						return;
					}
					updateParam.SCHD_TIME = updateParam.SCHD_TIME.replace(":", "");
					if (updateParam.SCHD_TIME < "0000" || updateParam.SCHD_TIME > "2359" || updateParam.SCHD_TIME.length != 4 || isNaN(updateParam.SCHD_TIME))
					{
						alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
						return;
					}
					updateParam.PSGR_CNT = $updateForm.find('[data-key=PSGR_CNT]').val();
					updateParam.SUB_TITLE = $updateForm.find('[data-key=SUB_TITLE]').val();
					updateParam.LOC_DESC = $updateForm.find('[data-key=LOC_DESC]').val();
					updateParam.FISH_KIND = $updateForm.find('[data-key=FISH_KIND]').val();
					updateParam.REWARD_RATE = $updateForm.find('[data-key=REWARD_RATE]').val();
					updateParam.PREPARE = $updateForm.find('[data-key=PREPARE]').val();
					updateParam.FEE = $updateForm.find('[data-key=FEE]').val();
					updateParam.FEE_WHOLE = $updateForm.find('[data-key=FEE_WHOLE]').val();
					updateParam.DISCOUNT_FEE = $updateForm.find('[data-key=DISCOUNT_FEE]').val();
					updateParam.DISCOUNT_WHOLE_FEE = $updateForm.find('[data-key=DISCOUNT_WHOLE_FEE]').val();
				}
				
				var detail = {};
				if($("#updateDetailForm").find(".type_1") != "" && $("#updateDetailForm").find(".type_1").length > 1){
					detail.SCHD_TIME1 = $("#updateDetailForm tr.type_1").find("[data-key=SCHD_TIME]").val();
					if(detail.SCHD_TIME1 == ''){
						alert("출조시간을 입력해주세요.");
						return;
					}
					detail.SCHD_TIME1 = detail.SCHD_TIME1.replace(":", "");
					if (detail.SCHD_TIME1 < "0000" || detail.SCHD_TIME1 > "2359" || detail.SCHD_TIME1.length != 4 || isNaN(detail.SCHD_TIME1))
					{
						alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
						return;
					}
					detail.GENRE1 =	$("#updateDetailForm tr.type_1").find("[data-key=GENRE]").text();
					detail.TYPE1 =	$("#updateDetailForm tr.type_1").find("[data-key=TYPE]").text();
					detail.FISH_KIND1=$("#updateDetailForm tr.type_1").find("[data-key=FISH_KIND]").val();
					detail.SUB_TITLE1=$("#updateDetailForm tr.type_1").find("[data-key=SUB_TITLE]").val();
					detail.PSGR_CNT1= $("#updateDetailForm tr.type_1").find("[data-type=PSGR_CNT] option:selected").val();
					detail.LOC_DESC1= $("#updateDetailForm tr.type_1").find("[data-key=LOC_DESC]").val();
					detail.PREPARE1=$("#updateDetailForm tr.type_1").find("[data-key=PREPARE]").val();
					detail.FEE1=$("#updateDetailForm tr.type_1").find("[data-key=FEE]").val();
					detail.FEE_WHOLE1=$("#updateDetailForm tr.type_1").find("[data-key=FEE_WHOLE]").val();
					detail.DSC_FEE1= $("#updateDetailForm tr.type_1").find("[data-key=DSC_FEE]").val();
					detail.PNT_RATE1= $("#updateDetailForm tr.type_1").find("[data-key=PNT_RATE]").val();
					detail.DSC_WHOLE_FEE1 = $("#updateDetailForm tr.type_1").find("[data-key=DSC_WHOLE_FEE]").val();
					detail.GENRE_USEYN1 = $("#updateDetailForm tr.type_1").find("[data-type=GENRE_USE_YN] option:selected").val();
				}
				

				if($("#updateDetailForm").find(".type_2") != "" && $("#updateDetailForm").find(".type_2").length > 1){
					detail.SCHD_TIME2 = $("#updateDetailForm tr.type_2").find("[data-key=SCHD_TIME]").val();
					if(detail.SCHD_TIME2 == ''){
						alert("출조시간을 입력해주세요.");
						return;
					}
					detail.SCHD_TIME2 = detail.SCHD_TIME2.replace(":", "");
					if (detail.SCHD_TIME2 < "0000" || detail.SCHD_TIME2 > "2359" || detail.SCHD_TIME2.length != 4 || isNaN(detail.SCHD_TIME2))
					{
						alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
						return;
					}
					detail.GENRE2 =	$("#updateDetailForm tr.type_2").find("[data-key=GENRE]").text();
					detail.TYPE2 =	$("#updateDetailForm tr.type_2").find("[data-key=TYPE]").text();
					detail.FISH_KIND2=$("#updateDetailForm tr.type_2").find("[data-key=FISH_KIND]").val();
					detail.SUB_TITLE2=$("#updateDetailForm tr.type_2").find("[data-key=SUB_TITLE]").val();
					detail.PSGR_CNT2= $("#updateDetailForm tr.type_2").find("[data-type=PSGR_CNT] option:selected").val();
					detail.LOC_DESC2= $("#updateDetailForm tr.type_2").find("[data-key=LOC_DESC]").val();
					detail.PREPARE2=$("#updateDetailForm tr.type_2").find("[data-key=PREPARE]").val();
					detail.FEE2=$("#updateDetailForm tr.type_2").find("[data-key=FEE]").val();
					detail.FEE_WHOLE2=$("#updateDetailForm tr.type_2").find("[data-key=FEE_WHOLE]").val();
					detail.DSC_FEE2= $("#updateDetailForm tr.type_2").find("[data-key=DSC_FEE]").val();
					detail.PNT_RATE2= $("#updateDetailForm tr.type_2").find("[data-key=PNT_RATE]").val();
					detail.DSC_WHOLE_FEE2 = $("#updateDetailForm tr.type_2").find("[data-key=DSC_WHOLE_FEE]").val();
					detail.GENRE_USEYN2 = $("#updateDetailForm tr.type_2").find("[data-type=GENRE_USE_YN] option:selected").val();
				}
				
				if($("#updateDetailForm").find(".type_3") != "" && $("#updateDetailForm").find(".type_3").length > 1){
					detail.SCHD_TIME3 = $("#updateDetailForm tr.type_3").find("[data-key=SCHD_TIME]").val();
					if(detail.SCHD_TIME3 == ''){
						alert("출조시간을 입력해주세요.");
						return;
					}
					detail.SCHD_TIME3 = detail.SCHD_TIME3.replace(":", "");
					if (detail.SCHD_TIME3 < "0000" || detail.SCHD_TIME3 > "2359" || detail.SCHD_TIME3.length != 4 || isNaN(detail.SCHD_TIME3))
					{
						alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
						return;
					}
					detail.GENRE3 =	$("#updateDetailForm tr.type_3").find("[data-key=GENRE]").text();
					detail.TYPE3 =	$("#updateDetailForm tr.type_3").find("[data-key=TYPE]").text();
					detail.FISH_KIND3=$("#updateDetailForm tr.type_3").find("[data-key=FISH_KIND]").val();
					detail.SUB_TITLE3=$("#updateDetailForm tr.type_3").find("[data-key=SUB_TITLE]").val();
					detail.PSGR_CNT3= $("#updateDetailForm tr.type_3").find("[data-type=PSGR_CNT] option:selected").val();
					detail.LOC_DESC3= $("#updateDetailForm tr.type_3").find("[data-key=LOC_DESC]").val();
					detail.PREPARE3=$("#updateDetailForm tr.type_3").find("[data-key=PREPARE]").val();
					detail.FEE3=$("#updateDetailForm tr.type_3").find("[data-key=FEE]").val();
					detail.FEE_WHOLE3=$("#updateDetailForm tr.type_3").find("[data-key=FEE_WHOLE]").val();
					detail.DSC_FEE3= $("#updateDetailForm tr.type_3").find("[data-key=DSC_FEE]").val();
					detail.PNT_RATE3= $("#updateDetailForm tr.type_3").find("[data-key=PNT_RATE]").val();
					detail.DSC_WHOLE_FEE3 = $("#updateDetailForm tr.type_3").find("[data-key=DSC_WHOLE_FEE]").val();
					detail.GENRE_USEYN3 = $("#updateDetailForm tr.type_3").find("[data-type=GENRE_USE_YN] option:selected").val();
				}
				
				$.extend( updateParam, detail );
								
				$.ajax({
					 url : "/sc/schedule/updateScheduleList"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		$updateForm.hide();
				    		_self.getScheduleList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, _self.selectScheduleId);
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 출조스케줄 삭제
			'deleteSchedule' : function(type) {
				var _self = this;
				var $updateForm = _self.$updateForm;
			
				if(!confirm("스케쥴을 삭제하시겠습니까?")){
					return false;
				}
				
				$.ajax({
					 url : "/sc/schedule/deleteScheduleList"
					,type : 'POST'
					,data : {
						 'SCHD_ID' : _self.selectScheduleId,
						 'DEL_TYPE' : type
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		$updateForm.hide();
				    		_self.getScheduleList( "1", {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 수정하기
				if('search' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					console.log(data);
					
					if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined){
						$updateForm.find("[data-key=SUB_SHIPNM]").text("("+ data.SUB_SHIPNM +")");
					}
					
					if(data.STATUS_CD == '113_210'){
						$updateForm.find("[data-key=CANCEL_DESC]").show();
					}else{
						$updateForm.find("[data-key=CANCEL_DESC]").hide();
					}
					
					$updateForm.find("input:radio[name=delFlag]:input[value='"+ data.DEL_FLAG +"']").attr("checked","checked");
					
					// 출조일 셋팅
					var schdDate = data.SCHD_DATE;
					if( schdDate ) {
						$updateForm.find('[data-type=SCHD_DATE]').text(jdg.util.replaceDate(schdDate));
					}
					
					var schdTime = data.SCHD_TIME_STR;
					$updateForm.find('[data-type=SCHD_TIME]').text(schdTime);
					
					//승선인원 세팅
					if(data.PSGR_CNT){
						$updateForm.find('[data-type=PSGR_CNT]').val(data.PSGR_CNT);
					}
					
					//예약자가 있는 경우 삭제 못하도록 막음.
					if(data.RESERVE_CONFIRM_CNT > 0 && data.RESERVE_WAIT_CNT > 0){
						$('#deleteScheduleBtn').attr("style", "display:none;");
					}
					
					if(data.CHOICE_GENRE != '' && data.CHOICE_GENRE != undefined){
						//선택된 장르가 있는 경우 날짜, 제목, 어종, 적립율,승선가능인원, 설명, 할인율, 채비, 출조위치 수정가능
						$updateForm.find("[data-type=SCHD_TIME]").parent().html("( 시간 : <input  class='jdg-input-text' style='width:100px;' type=text data-type='SCHD_TIME' value='"+data.SCHD_TIME_STR+"'> )");
						$updateForm.find("[data-key=PSGR_CNT]").parent().html("<input class='jdg-input-text' type=text data-key='PSGR_CNT' value='"+data.PSGR_CNT+"'>");
						$updateForm.find("[data-key=SUB_TITLE]").parent().html("<input class='jdg-input-text' type=text data-key='SUB_TITLE' value='"+data.SUB_TITLE+"'>");
						$updateForm.find("[data-key=FISH_KIND]").parent().html("<input class='jdg-input-text' type=text data-key='FISH_KIND' value='"+data.FISH_KIND+"'>");
						$updateForm.find("[data-key=PREPARE]").parent().html("<input class='jdg-input-text' type=text data-key='PREPARE' value='"+ ( data.PREPARE != undefined ? data.PREPARE : '' )+"'>");
						$updateForm.find("[data-key=LOC_DESC]").parent().html("<input class='jdg-input-text' type=text data-key='LOC_DESC' value='"+( data.LOC_DESC != undefined ? data.LOC_DESC : '' )+"'>");
						$updateForm.find("[data-key=REWARD_RATE]").parent().html("<input class='jdg-input-text' type=text data-key='REWARD_RATE' value='"+data.REWARD_RATE+"'>");
						$updateForm.find("[data-key=FEE]").parent().html("<input class='jdg-input-text' type=text data-key='FEE' value='"+data.FEE+"'>");
						if(data.FEE_WHOLE == undefined){
							data.FEE_WHOLE = "";
						}
						$updateForm.find("[data-key=FEE_WHOLE]").parent().html("<input  class='jdg-input-text' type=text data-key='FEE_WHOLE' value='"+data.FEE_WHOLE+"'>");
						
						if(data.DISCOUNT_FEE == undefined)
							data.DISCOUNT_FEE = "";
						$updateForm.find("[data-key=DISCOUNT_FEE]").parent().html("<input  class='jdg-input-text' type=text data-key='DISCOUNT_FEE' value='"+data.DISCOUNT_FEE+"'>");
						if(data.DISCOUNT_WHOLE_FEE == undefined)
							data.DISCOUNT_WHOLE_FEE = "";
						$updateForm.find("[data-key=DISCOUNT_WHOLE_FEE]").parent().html("<input  class='jdg-input-text' type=text data-key='DISCOUNT_WHOLE_FEE' value='"+data.DISCOUNT_WHOLE_FEE+"'>");
						
					}else{
						$updateForm.find("[data-type=SCHD_TIME]").parent().html("<span data-type='SCHD_TIME'>( 시간 :"+data.SCHD_TIME_STR+" )</span>");
						$updateForm.find("[data-key=PSGR_CNT]").parent().html("<span data-key='PSGR_CNT'></span>");
						$updateForm.find("[data-key=SUB_TITLE]").parent().html("<span data-key='SUB_TITLE'></span>");
						$updateForm.find("[data-key=FISH_KIND]").parent().html("<span data-key='FISH_KIND'></span>");
						$updateForm.find("[data-key=PREPARE]").parent().html("<span data-key='PREPARE'></span>");
						$updateForm.find("[data-key=LOC_DESC]").parent().html("<span data-key='LOC_DESC'></span>");
						$updateForm.find("[data-key=REWARD_RATE]").parent().html("<span data-key='REWARD_RATE'></span>");
						$updateForm.find("[data-key=FEE]").parent().html("<span data-key='FEE'></span>");
						$updateForm.find("[data-key=FEE_WHOLE]").parent().html("<span data-key='FEE_WHOLE'></span>");
						$updateForm.find("[data-key=DISCOUNT_FEE]").parent().html("<span data-key='DISCOUNT_FEE'></span>");
						$updateForm.find("[data-key=DISCOUNT_WHOLE_FEE]").parent().html("<span data-key='DISCOUNT_WHOLE_FEE'></span>");
					}
					
					
					
					//상세 장르 생성
					$("#updateDetailForm").html("");
					if(data.detail != null && data.detail.length > 0){
						for(var i = 0 ;i < data.detail.length ;i++){
							var $tmp = $("#detailUpdateTemplate").clone();
							var item = data.detail[i];
						
							$tmp.find("tr").attr("class", "type_"+ item.TYPE);
							$tmp.find("[data-key=SCHD_TIME]").attr("value", item.SCHD_TIME_STR);
							$tmp.find("[data-key=TYPE]").text(item.TYPE);
							$tmp.find("[data-key=GENRE]").text(item.GENRE);
							$tmp.find("[data-key=SCHD_DATE_STR]").text(item.SCHD_DATE_STR);
							$tmp.find("[data-key=FISH_KIND]").attr("value", item.FISH_KIND);
							$tmp.find("[data-key=PREPARE]").attr("value", item.PREPARE);
							$tmp.find("[data-key=SUB_TITLE]").attr("value", item.SUB_TITLE);
							$tmp.find("[data-key=LOC_DESC]").attr("value", item.LOC_DESC);
							$tmp.find("[data-key=FEE]").attr("value", item.FEE);
							$tmp.find("[data-key=FEE_WHOLE]").attr("value", item.FEE_WHOLE);
							$tmp.find("[data-key=PNT_RATE]").attr("value", item.PNT_RATE);
							$tmp.find("[data-key=DSC_FEE]").attr("value", item.DSC_FEE);
							$tmp.find("[data-key=DSC_WHOLE_FEE]").attr("value", item.DSC_WHOLE_FEE);
							$tmp.find("[data-type=GENRE_USE_YN] option[value='"+ item.GENRE_USEYN+"']").attr("selected", "selected");
							
							for( var k=0 ; k < item.PSGR_CNT ; k++ ) {
								$tmp.find("[data-type=PSGR_CNT]").append( $('<option value="'+(k+1)+'">'+(k+1)+'</option>') );
							}
							$tmp.find("[data-type=PSGR_CNT] option[value='"+ item.PSGR_CNT+"']").attr("selected", "selected");
							
							//장르가 하나거나 선택된 장르인 경우 삭제 못함.
							if(data.detail.length <= 1 || data.CHOICE_GENRE == item.GENRE){
								$tmp.find("[data-type=GENRE_USE_YN]").attr("disabled","disabled");
								
							}
							
							//정해진 장르가있는 경우 장르 옵션 변경이 불가함.
							if(data.CHOICE_GENRE != ''&& data.CHOICE_GENRE != undefined && data.CHOICE_GENRE == item.GENRE){
								$tmp.find("input").attr("disabled", "disabled").attr("style", "border-color:#aaa;width:95%;color:#aaa;");
								$tmp.find("select").attr("disabled", "disabled");
							}
							
							$("#updateDetailForm").append($tmp.find("tbody").html());
						}
						
					}
					
					//선택된 장르가 있는 경우 아래 서브 장르들의 상세가 보이지 않음.
					if(data.CHOICE_GENRE != '' && data.CHOICE_GENRE != undefined){
						$("#updateDetailForm").hide();
					}else{
						$("#updateDetailForm").show();
					}
					
					$updateForm.show();
				}
				
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				if( p_param.hasOwnProperty('SCHD_ID') ) {
					var schdId = p_param.SCHD_ID;
					// 출조스케쥴 목록 조회
					this.getScheduleList('1', {'SCHD_ID' : schdId});
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getScheduleList('1', {'SHIP_ID' : p_param.SHIP_ID});
				}
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
