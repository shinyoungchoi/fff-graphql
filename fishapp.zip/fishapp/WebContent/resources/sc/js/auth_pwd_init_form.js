defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._context = $('#context').val();
				this._pwdInitURL = $('#pwdInitURL').val();
				// element
				this.$pwdInitForm = $('#pwdInitForm');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 로그인 폼 전송
				var options = {
					 type : 'POST'
					,url : _self._pwdInitURL
				    ,dataType : 'json'
				    ,beforeSubmit : function( formData, jqForm, options ) {
						// validation
						if( !jdg.util.validator( _self.$pwdInitForm, true ) ) return false;
				    }
				    ,success : function( data ) {
				    	if( null != data.success && data.success === false  ) {
				    		alert( data.error.userMessage );
				    		return false;
				    	}
				    	if( null != data.msg ){
				    		alert( data.msg );
				    	}
				    }
				};
				_self.$pwdInitForm.ajaxForm( options );
			
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[pwdInitForm] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[pwdInitForm] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[pwdInitForm] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[pwdInitForm] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[pwdInitForm] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[pwdInitForm] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[pwdInitForm] onDestroy Method' );
			}		
	  }
});
