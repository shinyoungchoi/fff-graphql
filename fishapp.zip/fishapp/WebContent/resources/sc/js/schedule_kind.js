defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveURL = $('#reserveURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				
				//신규 등록시
				this.$regBtn = $('#regBtn');
				//장르 등록 버튼
				this.$regSubmitBtn = $('#regSubmitBtn');
				//상세 -> 수정시
				this.$updateSubmitBtn = $('#updateSubmitBtn');
				this.$mfyBtn = $('#modifyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				//장르 복제
				this.$dupConfBtn = $("#dupConf");
				this.$dupBtn = $('#dupBtn');
				this.$dupCancelBtn = $('#dupCancelBtn');
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				this.$detailForm = $('#scheduleConfDetailForm');
				this.$insertForm = $('#scheduleConfInsertForm');
				this.$updateForm = $('#scheduleConfUpdateForm');
				this.$scheduleConfUpdateForRegisterForm = $("#scheduleConfUpdateForRegisterForm");
				
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				
				this.fileList = null;
				this.prepare1FileList= null;
				this.prepare2FileList= null;
				this.fishing1FileList= null;
				this.fishing2FileList= null;
				
			},
			'setEvent'		: function() {
				var _self = this;
							
				// datePicker 이벤트선언
				_self.$insertForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$updateForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$scheduleConfUpdateForRegisterForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				
				// 전화협의 유무 체크
				_self.$insertForm.find("[data-key='HOL_TEL_YN']").on("change", function(){
					var value  = $(this).val();
					if(value == "Y"){
						_self.$insertForm.find("[data-key='SAT_HOL_FEE']").val("0");
						_self.$insertForm.find("[data-key='HOL_FEE']").val("0");
						_self.$insertForm.find("[data-key='SUN_HOL_FEE']").val("0");
					}
				});
				
				// 전화협의 유무 체크
				_self.$updateForm.find("[data-key='HOL_TEL_YN']").on("change", function(){
					var value  = $(this).val();
					if(value == "Y"){
						_self.$updateForm.find("[data-key='SAT_HOL_FEE']").val("0");
						_self.$updateForm.find("[data-key='HOL_FEE']").val("0");
						_self.$updateForm.find("[data-key='SUN_HOL_FEE']").val("0");
					}
				});
				
				//채비법 선택(등록)
				_self.$insertForm.find("#select_fising1").on("click", function(){
					var bizid = _self.$insertForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$insertForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#registerPrepare").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'PREPARE', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#registerPrepareTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.PREPARE_TITLE1+"</td><td>"+ item.PREPARE_CONTENT1+"</td>";
					    			html += "<td>"+item.PREPARE_TITLE2+"</td><td>"+item.PREPARE_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#registerPrepareTable").append(html);					    		
					    	}
					    }
					});
					
				});
				
				//채비법 선택
				$("#registerPrepareTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ1").val(seq);
					$("#PREPARE_SEQ_TEXT1").val(title);
					$("#registerPrepare").hide();
				});
				
				//낚시법 선택(등록)
				_self.$insertForm.find("#select_fising2").on("click", function(){
					var bizid = _self.$insertForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$insertForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#registerFishing").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'FISHING', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#registerFishingTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			console.log(item);
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.FISHING_TITLE1+"</td><td>"+ item.FISHING_CONTENT1+"</td>";
					    			html += "<td>"+item.FISHING_TITLE2+"</td><td>"+item.FISHING_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#registerFishingTable").append(html);					    		
					    	}
					    }
					});
				});
				
				//낚시법 선택
				$("#registerFishingTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ2").val(seq);
					$("#PREPARE_SEQ_TEXT2").val(title);
					$("#registerFishing").hide();
				});
				
				
				
				//채비법 선택(수정)
				_self.$updateForm.find("#select_fising3").on("click", function(){
					var bizid = _self.$updateForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$updateForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#updatePrepare").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'PREPARE', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#updatePrepareTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.PREPARE_TITLE1+"</td><td>"+ item.PREPARE_CONTENT1+"</td>";
					    			html += "<td>"+item.PREPARE_TITLE2+"</td><td>"+item.PREPARE_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#updatePrepareTable").append(html);					    		
					    	}
					    }
					});
					
				});
				
				//채비법 선택
				$("#updatePrepareTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ3").val(seq);
					$("#PREPARE_SEQ_TEXT3").val(title);
					$("#updatePrepare").hide();
				});
				
				//낚시법 선택(수정)
				_self.$updateForm.find("#select_fising4").on("click", function(){
					var bizid = _self.$updateForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$updateForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#updateFishing").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'FISHING', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#updateFishingTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.FISHING_TITLE1+"</td><td>"+ item.FISHING_CONTENT1+"</td>";
					    			html += "<td>"+item.FISHING_TITLE2+"</td><td>"+item.FISHING_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#updateFishingTable").append(html);					    		
					    	}
					    }
					});
				});
				
				//낚시법 선택
				$("#updateFishingTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ4").val(seq);
					$("#PREPARE_SEQ_TEXT4").val(title);
					$("#updateFishing").hide();
				});
				
				
				//채비법 선택(복제)
				_self.$scheduleConfUpdateForRegisterForm.find("#select_fising5").on("click", function(){
					var bizid = _self.$scheduleConfUpdateForRegisterForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$scheduleConfUpdateForRegisterForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#duplicatePrepare").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'PREPARE', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#duplicatePrepareTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.PREPARE_TITLE1+"</td><td>"+ item.PREPARE_CONTENT1+"</td>";
					    			html += "<td>"+item.PREPARE_TITLE2+"</td><td>"+item.PREPARE_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#duplicatePrepareTable").append(html);					    		
					    	}
					    }
					});
					
				});
				
				//채비법 선택
				$("#duplicatePrepareTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ5").val(seq);
					$("#PREPARE_SEQ_TEXT5").val(title);
					$("#duplicatePrepare").hide();
				});
				
				//낚시법 선택(수정)
				_self.$scheduleConfUpdateForRegisterForm.find("#select_fising6").on("click", function(){
					var bizid = _self.$scheduleConfUpdateForRegisterForm.find("select[data-key='SHIP_ID'] option:selected").attr("bizid");
					var shipid = _self.$scheduleConfUpdateForRegisterForm.find("select[data-key='SHIP_ID'] option:selected").val();
					$("#duplicateFishing").show();
					$.ajax({
						 url : "/sc/schedule/prepareFishingList"
						,type : 'POST'
						,data : {SHIP_ID : shipid, TYPE: 'FISHING', PAGE:'1', PERPAGE:'30'}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('list') ) {
					    		var list = data.list;
					    		var html = "";
					    		$("#duplicateFishingTable").empty();
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			html += "<tr class='row'  ptitle='"+item.TITLE+"' pid='"+item.SEQ+"'><td>"+item.ROW_NUMBER+"</td><td>"+item.FISHING_TITLE1+"</td><td>"+ item.FISHING_CONTENT1+"</td>";
					    			html += "<td>"+item.FISHING_TITLE2+"</td><td>"+item.FISHING_CONTENT2+"</td></tr>";					    			
					    		}
					    		$("#duplicateFishingTable").append(html);					    		
					    	}
					    }
					});
				});
				
				//낚시법 선택
				$("#duplicateFishingTable").on("click", "tr", function(){
					var seq = $(this).attr("pid");
					var title = $(this).attr("ptitle");
					$("#PREPARE_FISH_SEQ6").val(seq);
					$("#PREPARE_SEQ_TEXT6").val(title);
					$("#duplicateFishing").hide();
				});
				
				
				
				//등록폼
				_self.$insertForm.find("input:checkbox[name='fishTimeType']").change(function(){
					var checkedYn = $(this).is(":checked");
					
					_self.$insertForm.find(".hour").val('00');
					_self.$insertForm.find(".minute").val('00');
					
					if(checkedYn){
						//생활낚시선택시
						_self.$insertForm.find("select[name='fishHour1']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishMinute1']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishHour2']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishMinute2']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishHour3']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishMinute3']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishHour4']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishMinute4']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishHour']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishMinute']").attr("disabled","disabled");
					}else{
						_self.$insertForm.find("select[name='fishHour1']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishMinute1']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishHour2']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishMinute2']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishHour3']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishMinute3']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishHour4']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishMinute4']").attr("disabled","disabled");
						_self.$insertForm.find("select[name='fishHour']").removeAttr("disabled");
						_self.$insertForm.find("select[name='fishMinute']").removeAttr("disabled");
					}
				});
				
				//변경폼
				_self.$updateForm.find("input:checkbox[name='fishTimeType']").change(function(){
					var checkedYn = $(this).is(":checked");
					_self.$updateForm.find(".hour").val('00');
					_self.$updateForm.find(".minute").val('00');
					if(checkedYn){
						//생활낚시선택시
						_self.$updateForm.find("select[name='fishHour1']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute1']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishHour2']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute2']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishHour3']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute3']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishHour4']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute4']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishHour']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute']").removeAttr("disabled");
					}else{
						_self.$updateForm.find("select[name='fishHour1']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishMinute1']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishHour2']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishMinute2']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishHour3']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishMinute3']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishHour4']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishMinute4']").attr("disabled","disabled");
						_self.$updateForm.find("select[name='fishHour']").removeAttr("disabled");
						_self.$updateForm.find("select[name='fishMinute']").removeAttr("disabled");
					}
				});
				
				//복제폼
				_self.$scheduleConfUpdateForRegisterForm.find("input:checkbox[name='fishTimeType']").change(function(){
					var checkedYn = $(this).is(":checked");
					_self.$scheduleConfUpdateForRegisterForm.find(".hour").val('00');
					_self.$scheduleConfUpdateForRegisterForm.find(".minute").val('00');
					if(checkedYn){
						//생활낚시선택시
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour1']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute1']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour2']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute2']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour3']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute3']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour4']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute4']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute']").removeAttr("disabled");
					}else{
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour1']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute1']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour2']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute2']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour3']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute3']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour4']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute4']").attr("disabled","disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishHour']").removeAttr("disabled");
						_self.$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute']").removeAttr("disabled");
					}
				});
				
				//복제하기(수정폼처럼 보이는 등록 폼)
				_self.$dupConfBtn.click(function(){
					_self.selectFormShow('duplicate', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ') );
				});
				
				//복제된 장르 등록
				_self.$dupBtn.click(function(){
					_self.duplicateConf();
					return false;
				});				
				
				// 신규등록 취소
				_self.$dupCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 보조 select box 변경
				$('.helpSel').change( function() {
					var $this = $( this );
					var val = $this.val();
					if( '' !== val ) {
						var prevVal = $this.prev().val();
						if( '' === prevVal ) $this.prev().val( $this.find('option:selected').text() );
						else $this.prev().val(prevVal + ', ' + $this.find('option:selected').text() );
					}
				});
				
				//1인당 요금 넣는 경우
				_self.$insertForm.find('[data-key=REG_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$insertForm.find('[data-key=SAT_REG_FEE]').val(value);
					_self.$insertForm.find('[data-key=SUN_REG_FEE]').val(value);
				});
				
				_self.$updateForm.find('[data-key=REG_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$updateForm.find('[data-key=SAT_REG_FEE]').val(value);
					_self.$updateForm.find('[data-key=SUN_REG_FEE]').val(value);
				});
				
				_self.$scheduleConfUpdateForRegisterForm.find('[data-key=REG_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_REG_FEE]').val(value);
					_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SUN_REG_FEE]').val(value);
				});
				
				
				//독비 요금 넣는 경우
				_self.$insertForm.find('[data-key=HOL_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$insertForm.find('[data-key=SAT_HOL_FEE]').val(value);
					_self.$insertForm.find('[data-key=SUN_HOL_FEE]').val(value);
				});
				
				_self.$updateForm.find('[data-key=HOL_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$updateForm.find('[data-key=SAT_HOL_FEE]').val(value);
					_self.$updateForm.find('[data-key=SUN_HOL_FEE]').val(value);
				});
				
				_self.$scheduleConfUpdateForRegisterForm.find('[data-key=HOL_FEE]').keyup(function(){
					var value = $(this).val();
					_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_HOL_FEE]').val(value);
					_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SUN_HOL_FEE]').val(value);
				});
				
				
				// 승선인원 변경(등록)
				_self.$insertForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.createOptionSelect( _self.$insertForm.find('[data-type=PSGR_CNT]'), $this.attr('psgrcnt'));
				});
				
				// 승선인원 변경(수정)
				_self.$updateForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.createOptionSelect( _self.$updateForm.find('[data-type=PSGR_CNT]'), $this.attr('psgrcnt'));
				});
				
				// 승선인원 변경(복제)
				_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.createOptionSelect( _self.$scheduleConfUpdateForRegisterForm.find('[data-type=PSGR_CNT]'), $this.attr('psgrcnt'));
				});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$regSubmitBtn.click( function() {
					_self.insertSchedule();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				//수정 취소
				_self.$mfyCancelBtn.click(function(){
					_self.selectFormShow('none');
				});
								
				// 수정화면 보이기
				_self.$updateSubmitBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ') );
				});
				
				//수정하기
				_self.$mfyBtn.click(function(){
					_self.updateSchedule();
				});
				
				//삭제하기
				_self.$delBtn.click(function(){
					if(!confirm("삭제하시겠습니까?")){
						return false;
					}
					_self.deleteSchedule();
					
				});
				
				//수정폼에서 펜션코드 검색
				_self.$updateForm.find("#house1_button").click(function(){
					var value = _self.$updateForm.find("#house1").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$updateForm.find("#house1_rec").empty();
					    		_self.$updateForm.find("#house1_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$updateForm.find("#house1_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$updateForm.find("#house1_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				_self.$updateForm.find("#house2_button").click(function(){
					var value = _self.$updateForm.find("#house2").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$updateForm.find("#house2_rec").empty();
					    		_self.$updateForm.find("#house2_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$updateForm.find("#house2_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$updateForm.find("#house2_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				_self.$updateForm.find("#house3_button").click(function(){
					var value = _self.$updateForm.find("#house3").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$updateForm.find("#house3_rec").empty();
					    		_self.$updateForm.find("#house3_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$updateForm.find("#house3_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$updateForm.find("#house3_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				_self.$updateForm.find("#house1_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$updateForm.find("#house1_rec_dir").show();
					} else{
						_self.$updateForm.find("#house1_rec_dir").hide();
					}
				});
				
				_self.$updateForm.find("#house2_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$updateForm.find("#house2_rec_dir").show();
					} else{
						_self.$updateForm.find("#house2_rec_dir").hide();
					}
				});
				
				_self.$updateForm.find("#house3_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$updateForm.find("#house3_rec_dir").show();
					} else{
						_self.$updateForm.find("#house3_rec_dir").hide();
					}
				});
				
				
				_self.$insertForm.find("#house1_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$insertForm.find("#house1_rec_dir").show();
					} else{
						_self.$insertForm.find("#house1_rec_dir").hide();
					}
				});
				
				_self.$insertForm.find("#house2_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$insertForm.find("#house2_rec_dir").show();
					} else{
						_self.$insertForm.find("#house2_rec_dir").hide();
					}
				});
				
				_self.$insertForm.find("#house3_rec").change(function(){
					if($(this).val() ==  "dir"){
						_self.$insertForm.find("#house3_rec_dir").show();
					} else{
						_self.$insertForm.find("#house3_rec_dir").hide();
					}
				});
				
				//등록폼에서 펜션코드 검색
				_self.$insertForm.find("#house1_button").click(function(){
					var value = _self.$insertForm.find("#house1").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$insertForm.find("#house1_rec").empty();
					    		_self.$insertForm.find("#house1_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$insertForm.find("#house1_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$insertForm.find("#house1_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				_self.$insertForm.find("#house2_button").click(function(){
					var value = _self.$insertForm.find("#house2").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$insertForm.find("#house2_rec").empty();
					    		_self.$insertForm.find("#house2_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$insertForm.find("#house2_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$insertForm.find("#house2_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				_self.$insertForm.find("#house3_button").click(function(){
					var value = _self.$insertForm.find("#house3").val();
					if(value == "" || value == null){
						alert("검색어를 입력해주세요.");
						return;
					}
					
					var param = { 'SEARCH_TEXT' : value};
					$.ajax({
						 url : "/sc/schedule/search_pension"
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if( data.hasOwnProperty('pensionList') ) {
					    		var list = data.pensionList;
					    		console.log(list);
					    		_self.$insertForm.find("#house3_rec").empty();
					    		_self.$insertForm.find("#house3_rec").append("<option value='dir'>직접입력</option>");
					    		for(var i = 0 ; i < list.length ; i++){
					    			var item = list[i];
					    			_self.$insertForm.find("#house3_rec").append("<option value='"+item.SHIP_ID+"'>"+item.SHIP_NAME+"</option>");
					    		}
					    		_self.$insertForm.find("#house3_rec_dir").hide();
					    	}
					    }
					});
					
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
												
				loadbbsEditor("PREPARE_UPDATE_CONTENT1", "");
				loadbbsEditor("PREPARE_UPDATE_CONTENT2", "");
				loadbbsEditor("FISHING_UPDATE_CONTENT1", "");
				loadbbsEditor("FISHING_UPDATE_CONTENT2", "");
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			
			// 장르  목록 조회
			'getScheduleList' : function( page, param, showDetailId ) {
				var _self = this;
				console.log(param);
				console.log(showDetailId);
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/schedule/confListForSchedule"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		
				    		var shipName =  _self.$srhSel.find("option:selected").text();
				    		if (shipName == '*선박선택')
				    		{
				    			shipName = "전체 선박";
				    		}
				    		
							$('#span_ship_nm').text(shipName + '의 장르');
							$('#span_ship_nm').show();
							
				    		// 리스트 초기화
				    		_self.list.createList( data.scheduleList, 'CONF_SEQ');
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getScheduleList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.scheduleList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 장르 등록
			'insertSchedule' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var filesParam = {};
				var files = _self.fileList.getFile(); //FILEID 반환.
				if(files != null && files != ""){
					filesParam.mainFile = { IMG_ID : files , type :"MAIN_IMG"};
				}
						
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				// 출조일 가공
				var schdDateFr = $insertForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $insertForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = $insertForm.find("input:checkbox[name='fishTimeType']").is(":checked");
				var fishTime = $insertForm.find('.hour option:selected').val() + $insertForm.find('.minute option:selected').val();
				var fishTimes = [];
				//생활낚시 인경우.
				if(fishTimeType){
					fishTimeType =  "1";	
					var fishTime1 = $insertForm.find('select[name=fishHour1] option:selected').val() + $insertForm.find('select[name=fishMinute1]  option:selected').val();
					var fishTime2 = $insertForm.find('select[name=fishHour2] option:selected').val() + $insertForm.find('select[name=fishMinute2]  option:selected').val();
					var fishTime3 = $insertForm.find('select[name=fishHour3] option:selected').val() + $insertForm.find('select[name=fishMinute3]  option:selected').val();
					var fishTime4 = $insertForm.find('select[name=fishHour4] option:selected').val() + $insertForm.find('select[name=fishMinute4]  option:selected').val();
					
					if(fishTime1 != '0000' && (fishTime1 == fishTime2 || fishTime1 == fishTime3 || fishTime1 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime2 != '0000' && (fishTime2 == fishTime3 || fishTime2 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime3 != '0000' && (fishTime3 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					
					if(fishTime1 != null && fishTime1 != ''){
						fishTimes.push(fishTime1);
					}
					
					if(fishTime2 != null && fishTime2 != ''){
						fishTimes.push(fishTime2);
					}
					
					if(fishTime3 != null && fishTime3 != ''){
						fishTimes.push(fishTime3);
					}
					
					if(fishTime4 != null && fishTime4 != ''){
						fishTimes.push(fishTime4);
					}
				}else{
					fishTimeType = "0";
				}
				
				if(fishTimeType == "0" && fishTime == "0000"){
					alert("시간을 선택해주세요.");
					return false;
				}else if(fishTimeType == "1" && fishTimes.length < 1){
					alert("생활낚시 시간을 입력해주세요.");
					return false;
				}
				
				//추천숙박정보
				var house1_rec = _self.$insertForm.find("#house1_rec").val();
				if(house1_rec == 'dir'){
					house1_rec = _self.$insertForm.find("#house1_rec_dir").val();
				}
				
				var house2_rec = _self.$insertForm.find("#house2_rec").val();
				if(house2_rec == 'dir'){
					house2_rec = _self.$insertForm.find("#house2_rec_dir").val();
				}
				
				var house3_rec = _self.$insertForm.find("#house3_rec").val();
				if(house3_rec == 'dir'){
					house3_rec = _self.$insertForm.find("#house3_rec_dir").val();
				}
				
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_FR' : schdDateFr
					, 'SCHD_TO' : schdDateTo
					, 'SCHD_TIME_TYPE' : fishTimeType
					, 'SCHD_MAIN_IMG' : ( filesParam.mainFile != undefined )? filesParam.mainFile.IMG_ID : null
					, 'SCHD_TIME' : fishTime
					, 'SCHD_TIMES' : JSON.stringify(fishTimes)
					, 'SUB_TITLE' : $insertForm.find('[data-key=SUB_TITLE]').val()
					, 'PREPARE_FISH_SEQ1' : $insertForm.find('[data-key=PREPARE_FISH_SEQ1]').val()
					, 'PREPARE_FISH_SEQ2' : $insertForm.find('[data-key=PREPARE_FISH_SEQ2]').val()
					, 'PSGR_CNT' : $insertForm.find('[data-type=PSGR_CNT] option:selected').val()
					, 'REG_FEE' : $insertForm.find('[data-key=REG_FEE]').val()
					, 'HOL_FEE' : $insertForm.find('[data-key=HOL_FEE]').val()
					, 'REG_PNT_RATE' : $insertForm.find('[data-key=REG_PNT_RATE]').val()
					, 'HOL_PNT_RATE' : $insertForm.find('[data-key=HOL_PNT_RATE]').val()
					, 'REG_DSC_FEE' : $insertForm.find('[data-key=REG_DSC_FEE]').val()
					, 'HOL_DSC_FEE' : $insertForm.find('[data-key=HOL_DSC_FEE]').val()
					, 'SAT_REG_FEE' :$insertForm.find('[data-key=SAT_REG_FEE]').val()
					, 'SUN_REG_FEE' :$insertForm.find('[data-key=SUN_REG_FEE]').val()
					, 'SAT_HOL_FEE' :$insertForm.find('[data-key=SAT_HOL_FEE]').val()
					, 'SUN_HOL_FEE' :$insertForm.find('[data-key=SUN_HOL_FEE]').val()
					, 'SAT_REG_PNT_RATE': $insertForm.find('[data-key=SAT_REG_PNT_RATE]').val()
					, 'SUN_REG_PNT_RATE' :$insertForm.find('[data-key=SUN_REG_PNT_RATE]').val()
					, 'SAT_HOL_PNT_RATE' :$insertForm.find('[data-key=SAT_HOL_PNT_RATE]').val()
					, 'SUN_HOL_PNT_RATE': $insertForm.find('[data-key=SUN_HOL_PNT_RATE]').val()
					, 'SAT_REG_DSC_FEE': $insertForm.find('[data-key=SAT_REG_DSC_FEE]').val()
					, 'SAT_HOL_DSC_FEE' :$insertForm.find('[data-key=SAT_HOL_DSC_FEE]').val()
					, 'SUN_REG_DSC_FEE': $insertForm.find('[data-key=SUN_REG_DSC_FEE]').val()
					, 'SUN_HOL_DSC_FEE': $insertForm.find('[data-key=SUN_HOL_DSC_FEE]').val()
					, 'HOL_TEL_YN': $insertForm.find('[data-key=HOL_TEL_YN] option:selected').val()
					, 'SHOW_YN' : $insertForm.find("[data-key='SHOW_YN'] option:selected").val()
					, 'LOC_DESC' : $insertForm.find('[data-key=LOC_DESC]').val()
					, 'SERVICE_INFO' : $insertForm.find('[data-key=SERVICE_INFO]').val()
					, 'FISH_KIND' : $insertForm.find('[data-key=FISH_KIND]').val()
					, 'DESCR' : $insertForm.find('[data-key=DESCR]').val()
					, 'PREPARE' : $insertForm.find('[data-key=PREPARE]').val()
					, 'TOOL_TYPE1' : $insertForm.find('[data-key=TOOL_TYPE1]').val()
					, 'TOOL_TYPE2' : $insertForm.find('[data-key=TOOL_TYPE2]').val()
					, 'TOOL_TYPE3' : $insertForm.find('[data-key=TOOL_TYPE3]').val()
					, 'TOOL_TYPE4' : $insertForm.find('[data-key=TOOL_TYPE4]').val()
					, 'TOOL_TYPE1_STATUS' : ($insertForm.find('[data-key=TOOL_TYPE1_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE2_STATUS'  : ($insertForm.find('[data-key=TOOL_TYPE2_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE3_STATUS'  :  ($insertForm.find('[data-key=TOOL_TYPE3_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE4_STATUS'  : ($insertForm.find('[data-key=TOOL_TYPE4_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'PENSION1' : ( house1_rec == "dir") ? "" : house1_rec
					, 'PENSION2' : ( house2_rec == "dir") ? "" : house2_rec
					, 'PENSION3' : ( house3_rec == "dir") ? "" : house3_rec
				};
		
			
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/schedule/insertConf"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/schedule/conf?SHIP_ID="+ $("#searchShipSel").val();
				    		return;
				    	}
				    	
				    	if( data.hasOwnProperty('error') ) {
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("오류가 발생하였습니다.");
				    	return;
				    }
				});
				
			},
			'duplicateConf' : function(){
				//복제한 장르 저장.
				var _self = this;
				var $scheduleConfUpdateForRegisterForm = _self.$scheduleConfUpdateForRegisterForm;
				var filesParam = {};
				var files = _self.fileList.getFile(); //FILEID 반환.
				if(files != null && files != ""){
					filesParam.mainFile = { IMG_ID : files , type :"MAIN_IMG"};
				}
								
				// validation
				if( !jdg.util.validator( $scheduleConfUpdateForRegisterForm, true ) ) return false;
				// 출조일 가공
				var schdDateFr = $scheduleConfUpdateForRegisterForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $scheduleConfUpdateForRegisterForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = $scheduleConfUpdateForRegisterForm.find("input:checkbox[name='fishTimeType']").is(":checked");
				var fishTime = $scheduleConfUpdateForRegisterForm.find('.hour option:selected').val() + $scheduleConfUpdateForRegisterForm.find('.minute option:selected').val();
				var fishTimes = [];
				//생활낚시 인경우.
				if(fishTimeType){
					fishTimeType =  "1";	
					var fishTime1 = $scheduleConfUpdateForRegisterForm.find('select[name=fishHour1] option:selected').val() + $scheduleConfUpdateForRegisterForm.find('select[name=fishMinute1]  option:selected').val();
					var fishTime2 = $scheduleConfUpdateForRegisterForm.find('select[name=fishHour2] option:selected').val() + $scheduleConfUpdateForRegisterForm.find('select[name=fishMinute2]  option:selected').val();
					var fishTime3 = $scheduleConfUpdateForRegisterForm.find('select[name=fishHour3] option:selected').val() + $scheduleConfUpdateForRegisterForm.find('select[name=fishMinute3]  option:selected').val();
					var fishTime4 = $scheduleConfUpdateForRegisterForm.find('select[name=fishHour4] option:selected').val() + $scheduleConfUpdateForRegisterForm.find('select[name=fishMinute4]  option:selected').val();
					
					if(fishTime1 != '0000' && (fishTime1 == fishTime2 || fishTime1 == fishTime3 || fishTime1 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime2 != '0000' && (fishTime2 == fishTime3 || fishTime2 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime3 != '0000' && (fishTime3 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					
					if(fishTime1 != null && fishTime1 != ''){
						fishTimes.push(fishTime1);
					}
					
					if(fishTime2 != null && fishTime2 != ''){
						fishTimes.push(fishTime2);
					}
					
					if(fishTime3 != null && fishTime3 != ''){
						fishTimes.push(fishTime3);
					}
					
					if(fishTime4 != null && fishTime4 != ''){
						fishTimes.push(fishTime4);
					}
				}else{
					fishTimeType = "0";
				}
				
				if(fishTimeType == "0" && fishTime == "0000"){
					alert("시간을 선택해주세요.");
					return false;
				}else if(fishTimeType == "1" && fishTimes.length < 1){
					alert("생활낚시 시간을 입력해주세요.");
					return false;
				}
				
				//추천숙박정보
				var house1_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house1_rec").val();
				if(house1_rec == 'dir'){
					house1_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house1_rec_dir").val();
				}
				
				var house2_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house2_rec").val();
				if(house2_rec == 'dir'){
					house2_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house2_rec_dir").val();
				}
				
				var house3_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house3_rec").val();
				if(house3_rec == 'dir'){
					house3_rec = _self.$scheduleConfUpdateForRegisterForm.find("#house3_rec_dir").val();
				}
				
				var insertParam = {
					  'SHIP_ID' : $scheduleConfUpdateForRegisterForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_FR' : schdDateFr
					, 'SCHD_TO' : schdDateTo
					, 'SCHD_TIME_TYPE' : fishTimeType
					, 'SCHD_MAIN_IMG' : ( filesParam.mainFile != undefined )? filesParam.mainFile.IMG_ID : null
					, 'SCHD_TIME' : fishTime
					, 'SCHD_TIMES' : JSON.stringify(fishTimes)
					, 'SUB_TITLE' : $scheduleConfUpdateForRegisterForm.find('[data-key=SUB_TITLE]').val()
					, 'PREPARE_FISH_SEQ1' : $scheduleConfUpdateForRegisterForm.find('[data-key=PREPARE_FISH_SEQ5]').val()
					, 'PREPARE_FISH_SEQ2' : $scheduleConfUpdateForRegisterForm.find('[data-key=PREPARE_FISH_SEQ6]').val()
					, 'PSGR_CNT' : $scheduleConfUpdateForRegisterForm.find('[data-type=PSGR_CNT] option:selected').val()
					, 'REG_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_FEE]').val()
					, 'HOL_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_FEE]').val()
					, 'REG_PNT_RATE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_PNT_RATE]').val()
					, 'HOL_PNT_RATE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_PNT_RATE]').val()
					, 'REG_DSC_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_DSC_FEE]').val()
					, 'HOL_DSC_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_DSC_FEE]').val()
					, 'SAT_REG_FEE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_REG_FEE]').val()
					, 'SUN_REG_FEE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SUN_REG_FEE]').val()
					, 'SAT_HOL_FEE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_HOL_FEE]').val()
					, 'SUN_HOL_FEE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SUN_HOL_FEE]').val()
					, 'SAT_REG_PNT_RATE': $scheduleConfUpdateForRegisterForm.find('[data-key=SAT_REG_PNT_RATE]').val()
					, 'SUN_REG_PNT_RATE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SUN_REG_PNT_RATE]').val()
					, 'SAT_HOL_PNT_RATE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_HOL_PNT_RATE]').val()
					, 'SUN_HOL_PNT_RATE': $scheduleConfUpdateForRegisterForm.find('[data-key=SUN_HOL_PNT_RATE]').val()
					, 'SAT_REG_DSC_FEE': $scheduleConfUpdateForRegisterForm.find('[data-key=SAT_REG_DSC_FEE]').val()
					, 'SAT_HOL_DSC_FEE' :$scheduleConfUpdateForRegisterForm.find('[data-key=SAT_HOL_DSC_FEE]').val()
					, 'SUN_REG_DSC_FEE': $scheduleConfUpdateForRegisterForm.find('[data-key=SUN_REG_DSC_FEE]').val()
					, 'SUN_HOL_DSC_FEE': $scheduleConfUpdateForRegisterForm.find('[data-key=SUN_HOL_DSC_FEE]').val()
					, 'HOL_TEL_YN': $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_TEL_YN] option:selected').val()
					, 'SHOW_YN' : $scheduleConfUpdateForRegisterForm.find("[data-key='SHOW_YN'] option:selected").val()
					, 'LOC_DESC' : $scheduleConfUpdateForRegisterForm.find('[data-key=LOC_DESC]').val()
					, 'SERVICE_INFO' : $scheduleConfUpdateForRegisterForm.find('[data-key=SERVICE_INFO]').val()
					, 'FISH_KIND' : $scheduleConfUpdateForRegisterForm.find('[data-key=FISH_KIND]').val()
					, 'DESCR' : $scheduleConfUpdateForRegisterForm.find('[data-key=DESCR]').val()
					, 'PREPARE' : $scheduleConfUpdateForRegisterForm.find('[data-key=PREPARE]').val()
					, 'TOOL_TYPE1' : $scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE1]').val()
					, 'TOOL_TYPE2' : $scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE2]').val()
					, 'TOOL_TYPE3' : $scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE3]').val()
					, 'TOOL_TYPE4' : $scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE4]').val()
					, 'TOOL_TYPE1_STATUS' : ($scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE1_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE2_STATUS'  : ($scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE2_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE3_STATUS'  :  ($scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE3_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'TOOL_TYPE4_STATUS'  : ($scheduleConfUpdateForRegisterForm.find('[data-key=TOOL_TYPE4_STATUS]').is(":checked") == true ) ? "Y":"N"
					, 'PENSION1' : (house1_rec == "dir") ? "" : house1_rec
					, 'PENSION2' : (house2_rec == "dir") ? "" : house2_rec
					, 'PENSION3' : (house3_rec == "dir") ? "" : house3_rec
				};
		
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/schedule/insertConf"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/schedule/conf?SHIP_ID="+ $("#searchShipSel").val();
				    		return;
				    	}
				    	
				    	if( data.hasOwnProperty('error') ) {
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			// 장르  수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				var remainFiles= [];
				var mainImgId = $updateForm.find("div.fileContainer").attr("img_id");
				if(mainImgId != "" && mainImgId != undefined){
					remainFiles.push({IMG_ID : mainImgId,  TYPE_CD :"MAIN_IMG" , SEQ : 1});
				}
				
				$updateForm.find("[data-type=PREPARE1_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"PREPARE_FILE1", SEQ : index + 1});
				});
				
				$updateForm.find("[data-type=PREPARE2_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"PREPARE_FILE2", SEQ : index + 1});
				});
				$updateForm.find("[data-type=FISHING1_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"FISHING_FILE1", SEQ : index + 1});
				});
				
				$updateForm.find("[data-type=FISHING2_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"FISHING_FILE2", SEQ : index + 1});
				});
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 출조일 가공
				var schdDateFr = $updateForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $updateForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = $updateForm.find("input:checkbox[name='fishTimeType']").is(":checked");
				var fishTime = $updateForm.find('.hour option:selected').val() + $updateForm.find('.minute option:selected').val();
				var fishTimes = []; //수정할 생활낚시 시간대 정보
				var fishOldConf = []; // 기존 저장된 생활낚시 시간대 conf_seq
				//생활낚시 인경우.
				if(fishTimeType){
					fishTimeType =  "1";	
					var fishTime1 = $updateForm.find('select[name=fishHour1] option:selected').val() + $updateForm.find('select[name=fishMinute1]  option:selected').val();
					var fishTime2 = $updateForm.find('select[name=fishHour2] option:selected').val() + $updateForm.find('select[name=fishMinute2]  option:selected').val();
					var fishTime3 = $updateForm.find('select[name=fishHour3] option:selected').val() + $updateForm.find('select[name=fishMinute3]  option:selected').val();
					var fishTime4 = $updateForm.find('select[name=fishHour4] option:selected').val() + $updateForm.find('select[name=fishMinute4]  option:selected').val();
					
					if(fishTime1 != '0000' && (fishTime1 == fishTime2 || fishTime1 == fishTime3 || fishTime1 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime2 != '0000' && (fishTime2 == fishTime3 || fishTime2 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					if(fishTime3 != '0000' && (fishTime3 == fishTime4)){
						alert("같은 시간대를 입력하실 수 없습니다.");
						return;
					}
					
					if(fishTime1 != null && fishTime1 != ''){
						if(fishTime1 == '0000'){
							//첫번째꺼는 무조건 있어야한다.
							alert("첫번째 타임 시간을 입력해주세요.");
							return;
						}
						var confKey = $updateForm.find('input[name=fishConf1]').val();
						fishTimes.push({ time : fishTime1, key : confKey});
						if(confKey != '')
							fishOldConf.push(confKey);
					}
										
					if(fishTime2 != null && fishTime2 != ''){
						if(fishTime2 == '0000' && (fishTime3 != '0000' || fishTime4 != '0000')){
							alert("시간을 순번대로 입력해주세요.");
							return;
						}
						var confKey = $updateForm.find('input[name=fishConf2]').val();
						fishTimes.push({ time : fishTime2, key : confKey});
						if(confKey != '')
							fishOldConf.push(confKey);
					}
					
					if(fishTime3 != null && fishTime3 != ''){
						if(fishTime3 == '0000' && fishTime4 != '0000'){
							alert("시간을 순번대로 입력해주세요.");
							return;
						}
						var confKey = $updateForm.find('input[name=fishConf3]').val();
						fishTimes.push({ time : fishTime3, key : confKey});
						if(confKey != '')
							fishOldConf.push(confKey);
					}
					
					if(fishTime4 != null && fishTime4 != ''){
						var confKey = $updateForm.find('input[name=fishConf4]').val();
						fishTimes.push({ time : fishTime4, key : confKey});
						if(confKey != '')
							fishOldConf.push(confKey);
					}
				}else{
					fishTimeType = "0";
				}
				
				if(fishTimeType == "0" && fishTime == "0000"){
					alert("시간을 선택해주세요.");
					return false;
				}else if(fishTimeType == "1" && fishTimes.length < 1){
					alert("생활낚시 시간을 입력해주세요.");
					return false;
				}
				
				//추천숙박정보
				var house1_rec = _self.$updateForm.find("#house1_rec").val();
				if(house1_rec == 'dir'){
					house1_rec = _self.$updateForm.find("#house1_rec_dir").val();
				}
				
				var house2_rec = _self.$updateForm.find("#house2_rec").val();
				if(house2_rec == 'dir'){
					house2_rec = _self.$updateForm.find("#house2_rec_dir").val();
				}
				
				var house3_rec = _self.$updateForm.find("#house3_rec").val();
				if(house3_rec == 'dir'){
					house3_rec = _self.$updateForm.find("#house3_rec_dir").val();
				}
				
				var updateParam = {
						'CONF_SEQ': _self.selectScheduleId
						, 'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()
						, 'SCHD_FR' : schdDateFr
						, 'SCHD_TO' : schdDateTo
						, 'SCHD_TIME_TYPE' : fishTimeType
						, 'SCHD_TIME' : fishTime
						, 'SCHD_TIMES' : JSON.stringify(fishTimes)
						, 'OLD_CONF_SEQS' : JSON.stringify(fishOldConf)
						, 'SUB_TITLE' : $updateForm.find('[data-key=SUB_TITLE]').val()
						, 'PREPARE_FISH_SEQ1' : $updateForm.find('[data-key=PREPARE_FISH_SEQ3]').val()
						, 'PREPARE_FISH_SEQ2' : $updateForm.find('[data-key=PREPARE_FISH_SEQ4]').val()
						, 'PREPARE_TITLE1' : $updateForm.find('[data-key=PREPARE_TITLE1]').val()
						, 'PREPARE_TITLE2' : $updateForm.find('[data-key=PREPARE_TITLE2]').val()
						, 'FISHING_TITLE1' : $updateForm.find('[data-key=FISHING_TITLE1]').val()
						, 'FISHING_TITLE2' : $updateForm.find('[data-key=FISHING_TITLE2]').val()
						, 'PSGR_CNT' : $updateForm.find('[data-type=PSGR_CNT] option:selected').val()
						, 'REG_FEE' : $updateForm.find('[data-key=REG_FEE]').val()
						, 'HOL_FEE' : $updateForm.find('[data-key=HOL_FEE]').val()
						, 'REG_PNT_RATE' : $updateForm.find('[data-key=REG_PNT_RATE]').val()
						, 'HOL_PNT_RATE' : $updateForm.find('[data-key=HOL_PNT_RATE]').val()
						, 'REG_DSC_FEE' : $updateForm.find('[data-key=REG_DSC_FEE]').val()
						, 'HOL_DSC_FEE' : $updateForm.find('[data-key=HOL_DSC_FEE]').val()
						, 'LOC_DESC' : $updateForm.find('[data-key=LOC_DESC]').val()
						, 'SERVICE_INFO' : $updateForm.find('[data-key=SERVICE_INFO]').val()
						, 'FISH_KIND' : $updateForm.find('[data-key=FISH_KIND]').val()
						, 'DESCR' : $updateForm.find('[data-key=DESCR]').val()
						, 'PREPARE' : $updateForm.find('[data-key=PREPARE]').val()
						, 'TOOL_TYPE1' : $updateForm.find('[data-key=TOOL_TYPE1]').val()
						, 'TOOL_TYPE2' : $updateForm.find('[data-key=TOOL_TYPE2]').val()
						, 'TOOL_TYPE3' : $updateForm.find('[data-key=TOOL_TYPE3]').val()
						, 'TOOL_TYPE4' : $updateForm.find('[data-key=TOOL_TYPE4]').val()
						, 'TOOL_TYPE1_STATUS' : ($updateForm.find('[data-key=TOOL_TYPE1_STATUS]').is(":checked") == true ) ? "Y":"N"
						, 'TOOL_TYPE2_STATUS'  : ($updateForm.find('[data-key=TOOL_TYPE2_STATUS]').is(":checked") == true ) ? "Y":"N"
						, 'TOOL_TYPE3_STATUS'  :  ($updateForm.find('[data-key=TOOL_TYPE3_STATUS]').is(":checked") == true ) ? "Y":"N"
						, 'TOOL_TYPE4_STATUS'  : ($updateForm.find('[data-key=TOOL_TYPE4_STATUS]').is(":checked") == true ) ? "Y":"N"
						, 'REMAIN_FILE' : JSON.stringify(remainFiles)
						, 'PENSION1' : ( house1_rec == "dir")? "":house1_rec
						, 'PENSION2' : ( house2_rec == "dir")? "":house2_rec
						, 'PENSION3' :( house3_rec == "dir")? "":house3_rec
						, 'SAT_REG_FEE' : $updateForm.find('[data-key=SAT_REG_FEE]').val()
						, 'SUN_REG_FEE' : $updateForm.find('[data-key=SUN_REG_FEE]').val()
						, 'SAT_HOL_FEE' : $updateForm.find('[data-key=SAT_HOL_FEE]').val()
						, 'SUN_HOL_FEE' : $updateForm.find('[data-key=SUN_HOL_FEE]').val()
						, 'SAT_REG_PNT_RATE': $updateForm.find('[data-key=SAT_REG_PNT_RATE]').val()
						, 'SUN_REG_PNT_RATE' : $updateForm.find('[data-key=SUN_REG_PNT_RATE]').val()
						, 'SAT_HOL_PNT_RATE' : $updateForm.find('[data-key=SAT_HOL_PNT_RATE]').val()
						, 'SUN_HOL_PNT_RATE': $updateForm.find('[data-key=SUN_HOL_PNT_RATE]').val()
						, 'SAT_REG_DSC_FEE': $updateForm.find('[data-key=SAT_REG_DSC_FEE]').val()
						, 'SAT_HOL_DSC_FEE' :$updateForm.find('[data-key=SAT_HOL_DSC_FEE]').val()
						, 'SUN_REG_DSC_FEE': $updateForm.find('[data-key=SUN_REG_DSC_FEE]').val()
						, 'SUN_HOL_DSC_FEE': $updateForm.find('[data-key=SUN_HOL_DSC_FEE]').val()
						, 'HOL_TEL_YN': $updateForm.find('[data-key=HOL_TEL_YN] option:selected').val()
						, 'SHOW_YN' : $updateForm.find("[data-key='SHOW_YN'] option:selected").val()
				};
				
				if(updateParam.PREPARE_TITLE1 != ""){
					oEditors.getById["PREPARE_UPDATE_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.PREPARE_CONTENT1 = $('#PREPARE_UPDATE_CONTENT1').val().replace(/\u8203/g,'');
				}else{
					if($('#PREPARE_UPDATE_CONTENT1').val() != ""){
						alert("채비법1 제목을 입력해주세요.");
						return;
					}
				}
				
				if(updateParam.PREPARE_TITLE2 != ""){
					oEditors.getById["PREPARE_UPDATE_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.PREPARE_CONTENT2 = $('#PREPARE_UPDATE_CONTENT2').val().replace(/\u8203/g,'');
				}else{
					if($('#PREPARE_UPDATE_CONTENT2').val() != ""){
						alert("채비법2 제목을 입력해주세요.");
						return;
					}
				}
				if(updateParam.FISHING_TITLE1 != ""){
					oEditors.getById["FISHING_UPDATE_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.FISHING_CONTENT1 = $('#FISHING_UPDATE_CONTENT1').val().replace(/\u8203/g,'');
				}else{
					if($('#FISHING_UPDATE_CONTENT1').val() != ""){
						alert("낚시법1 제목을 입력해주세요.");
						return;
					}
				}
				if(updateParam.FISHING_TITLE2 != ""){
					oEditors.getById["FISHING_UPDATE_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.FISHING_CONTENT2 = $('#FISHING_UPDATE_CONTENT2').val().replace(/\u8203/g,'');
				}else{
					if($('#FISHING_UPDATE_CONTENT2').val() != ""){
						alert("낚시법2 제목을 입력해주세요.");
						return;
					}
				}
						
				
				$.ajax({
					 url : "/sc/schedule/updateConf"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		location.href="/sc/schedule/conf?PAGE="+_self.selectPage+"&SHIP_ID="+_self.$srhSel.find('option:selected').val()+"&CONF_SEQ="+_self.selectScheduleId
				    		return;
				    	}else{
				    		if( data.hasOwnProperty('error') ) {
					    		alert(data.error);
					    		return;
					    	}
					    	
					    	alert("오류가 발생하였습니다.");
					    	return;
				    	}
				    }
				});
			},
			// 장르 삭제
			'deleteSchedule' : function() {
				var _self = this;
				if(_self.selectScheduleId == ""){
					alert("삭제하실 장르를 목록에서 선택해주세요.");
					return;
				}
				
				$.ajax({
					 url : "/sc/schedule/deleteConf"
					,type : 'POST'
					,data : {
						 'CONF_SEQ' : _self.selectScheduleId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				var $scheduleConfUpdateForRegisterForm = _self.$scheduleConfUpdateForRegisterForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					//시간 세팅
					if(data.SCHD_TIME_TYPE == "1"){
						var schdTimes = data.SCHD_TIMES;
						var txt = "";
						for(var i = 0 ; i < schdTimes.length ;i++){
							console.log(schdTimes[i]);
							txt += "생활낚시 "+ (i+1) +" [ "+ schdTimes[i].substring(0,2) +":"+ schdTimes[i].substring(2,4) +" ]</br>";
						}
						$detailForm.find('[data-type=SCHD_TIME]').html(txt);
					}else{
						var schdTime = data.SCHD_TIME;
						if(schdTime != "" && schdTime != undefined)
							$detailForm.find('[data-type=SCHD_TIME]').text(schdTime.substring(0,2) +":"+ schdTime.substring(2,4));
					}
					if(data.PREPARE != "" && data.PREPARE != undefined)
						$detailForm.find("[data-type=PREPARE]").html(data.PREPARE.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=PREPARE]").html("");
					
					if(data.DESCR != "" && data.DESCR != undefined)
						$detailForm.find("[data-type=DESCR]").html(data.DESCR.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=DESCR]").html("");
					
					if(data.SERVICE_INFO != "" && data.SERVICE_INFO != undefined)
						$detailForm.find("[data-type=SERVICE_INFO]").html(data.SERVICE_INFO.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=SERVICE_INFO]").html("");
					
					if(data.PREPARE_CONTENT1 != "" && data.PREPARE_CONTENT1 != undefined){
						$detailForm.find("[data-type=PREPARE_CONTENT_1]").html(data.PREPARE_CONTENT1);
					}else{
						$detailForm.find("[data-type=PREPARE_CONTENT_1]").html("");
					}
					
					if(data.PREPARE_CONTENT2 != "" && data.PREPARE_CONTENT2 != undefined){
						$detailForm.find("[data-type=PREPARE_CONTENT_2]").html(data.PREPARE_CONTENT2);
					}else{
						$detailForm.find("[data-type=PREPARE_CONTENT_2]").html("");
					}
					
					if(data.FISHING_CONTENT1 != "" && data.FISHING_CONTENT1 != undefined){
						$detailForm.find("[data-type=FISHING_CONTENT_1]").html(data.FISHING_CONTENT1);
					}else{
						$detailForm.find("[data-type=FISHING_CONTENT_1]").html("");
					}
					
					if(data.FISHING_CONTENT2 != "" && data.FISHING_CONTENT2 != undefined){
						$detailForm.find("[data-type=FISHING_CONTENT_2]").html(data.FISHING_CONTENT2);
					}else{
						$detailForm.find("[data-type=FISHING_CONTENT_2]").html("");
					}
					
					if(data.hasOwnProperty('mainImg')){
							jdg.util.createImgList( data.mainImg, $detailForm.find('[data-type=IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('prepare1Img')){
						jdg.util.createImgList( data.prepare1Img, $detailForm.find('[data-type=PREPARE1_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=PREPARE1_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('prepare2Img')){
						jdg.util.createImgList( data.prepare2Img, $detailForm.find('[data-type=PREPARE2_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=PREPARE2_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('fishing1Img')){
						jdg.util.createImgList( data.fishing1Img, $detailForm.find('[data-type=FISHING1_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=FISHING1_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('fishing2Img')){
						jdg.util.createImgList( data.fishing2Img, $detailForm.find('[data-type=FISHING2_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=FISHING2_IMAGE_LIST]').html("");
					}
						
					$detailForm.show();
				}
				// 신규등록
				else if('insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
										
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					
					// 출조일 셋팅
					var $schdDateFr = $insertForm.find('[data-type=SCHD_FR]');
					var $schdDateTo = $insertForm.find('[data-type=SCHD_TO]');
					$schdDateFr.val('');
					$schdDateTo.val('');
					
					$insertForm.find('.hour').val('00');
					$insertForm.find('.minute').val('00');
					$insertForm.show();
					
					//내부선박사진
					_self.fileList = new component.File({
						 'id' : "fileImageDiv"
						,'container' : $insertForm.find('[data-type=IMAGE_LIST]')
					});
					_self.fileList.init();
					

					var shipId = $("#searchShipSel").val();					
					if(shipId != "" && shipId != undefined){
						$insertForm.find("select[name='regShipId'] option:eq(0)").attr("selected", false);
						$insertForm.find("select[name='regShipId'] option[value='"+shipId+"']").attr("selected", true);
					}
					
					//승선인원 체크
					_self.createOptionSelect( $insertForm.find('[data-type=PSGR_CNT]'), $insertForm.find('[data-key=SHIP_ID] option:selected').attr('psgrcnt') );
					
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					if(data.INSERT_FROM == "L"){
						$("#showYnDiv").hide();
					}else{
						$("#showYnDiv").show();
					}
					
					$updateForm.find("[data-key='SHIP_ID'] option[value='"+data.SHIP_ID+"']").attr("checked","checked");
					_self.createOptionSelect( $updateForm.find('[data-type=PSGR_CNT]'), data.SHIP_PSGR_CNT );					
					$updateForm.find('[data-type=PSGR_CNT]').val(data.PSGR_CNT );
					
					if(data.TOOL_TYPE1_STATUS == 'Y')
						$updateForm.find("[data-key=TOOL_TYPE1_STATUS]").attr("checked", "checked");
					else
						$updateForm.find("[data-key=TOOL_TYPE1_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE2_STATUS == 'Y')
						$updateForm.find("[data-key=TOOL_TYPE2_STATUS]").attr("checked", "checked");
					else
						$updateForm.find("[data-key=TOOL_TYPE2_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE3_STATUS == 'Y')
						$updateForm.find("[data-key=TOOL_TYPE3_STATUS]").attr("checked", "checked");
					else
						$updateForm.find("[data-key=TOOL_TYPE3_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE4_STATUS == 'Y')
						$updateForm.find("[data-key=TOOL_TYPE4_STATUS]").attr("checked", "checked");
					else
						$updateForm.find("[data-key=TOOL_TYPE4_STATUS]").removeAttr("checked");
					
					var schdFr = data.SCHD_FR;
					var schdTo = data.SCHD_TO;
					if(schdFr != null){
						var from = schdFr.substring(0,4)+"-"+ schdFr.substring(4,6)+"-"+ schdFr.substring(6,8);
						$updateForm.find("[data-key=SCHD_FR]").val(from);
					}else{
						$updateForm.find("[data-key=SCHD_FR]").val("");
					}
					
					if(schdTo != null){
						var to = schdTo.substring(0,4)+"-"+ schdTo.substring(4,6)+"-"+ schdTo.substring(6,8);
						$updateForm.find("[data-key=SCHD_TO]").val(to);
					}else{
						$updateForm.find("[data-key=SCHD_TO]").val("");
					}
					
					// 시간 세팅
					if(data.SCHD_TIME_TYPE == "1"){
						var schdTimeType = data.SCHD_TIME_TYPE;
						$updateForm.find("input:checkbox[name='fishTimeType']").attr("checked", true);
						$updateForm.find("input:checkbox[name='fishTimeType']").on("click", function(e){ e.stopPropagation(); return false;});
						$updateForm.find('select.hour').removeAttr("disabled");
						$updateForm.find('select.minute').removeAttr("disabled");
						$("#lifeTd2").attr("style", "display:;");
						$("#lifeTd1").attr("style", "display:;");
						
						$("#generalTd").attr("style", "display:none;");
						var schdTimes = data.SCHD_TIMES;
						for(var i = 0 ;i < schdTimes.length ;i++){
							$updateForm.find("select[name='fishHour"+(i+1)+"']").val( schdTimes[i].substring(0,2) );
							$updateForm.find("select[name='fishMinute"+(i+1)+"']").val(schdTimes[i].substring(2,4) );
							$updateForm.find("input[name='fishConf"+(i+1)+"']").val( schdTimes[i].substring(5) );
						}
						
					}else{
						var schdTime = data.SCHD_TIME;
						$updateForm.find("input:checkbox[name='fishTimeType']").removeAttr("checked");
						$("#generalTd").attr("style", "display:;");
						if(schdTime != "" && schdTime != undefined){
							$updateForm.find("select[name='fishHour']").val( schdTime.substring(0,2) );
							$updateForm.find("select[name='fishMinute']").val( schdTime.substring(2,4) );
						}
						$("#lifeTd2").attr("style", "display:none;");
						$("#lifeTd1").attr("style", "display:none;");
					}
					
					if(data.PREPARE_FISH_SEQ1 != null && data.PREPARE_FISH_SEQ1 != undefined){
						$updateForm.find('#PREPARE_FISH_SEQ3').val(data.PREPARE_FISH_SEQ1);
						$updateForm.find('#PREPARE_SEQ_TEXT3').val(data.PREPARE_TITLE1);
						$("tr.update_show_prepare").hide();
					}else{
						$updateForm.find("textarea[name='PREPARE_UPDATE_CONTENT1']").text("");
						$updateForm.find("textarea[name='PREPARE_UPDATE_CONTENT2']").text("");
						oEditors.getById["PREPARE_UPDATE_CONTENT1"].exec("LOAD_CONTENTS_FIELD");
						oEditors.getById["PREPARE_UPDATE_CONTENT2"].exec("LOAD_CONTENTS_FIELD");
						if(data.PREPARE_CONTENT1 != null && data.PREPARE_CONTENT1 != undefined)
							oEditors.getById['PREPARE_UPDATE_CONTENT1'].exec("PASTE_HTML", [data.PREPARE_CONTENT1]);
											
						if(data.PREPARE_CONTENT2 != null && data.PREPARE_CONTENT2 != undefined)
							oEditors.getById['PREPARE_UPDATE_CONTENT2'].exec("PASTE_HTML", [data.PREPARE_CONTENT2]);

						//채비법 1
						_self.prepare1FileList = new component.FileList({
							 'id' : "prepare1ImageDiv"
							,'container' : $updateForm.find('[data-type=PREPARE1_IMAGE_LIST]')
						});
						
						_self.prepare1FileList.initWithoutTextArea(data.prepare1Img);
						
						//채비법 2
						_self.prepare2FileList = new component.FileList({
							 'id' : "prepare2ImageDiv"
							,'container' : $updateForm.find('[data-type=PREPARE2_IMAGE_LIST]')
						});
						
						_self.prepare2FileList.initWithoutTextArea(data.prepare2Img);
						
						$("tr.update_show_prepare").show();
					}
					
					console.log(data.PREPARE_FISH_SEQ2)
					if(data.PREPARE_FISH_SEQ2 != null && data.PREPARE_FISH_SEQ2 != undefined){
						console.log(data.PREPARE_FISH_SEQ2+",등ㄹ어놀다");
						$updateForm.find('#PREPARE_FISH_SEQ4').val(data.PREPARE_FISH_SEQ2);
						$updateForm.find('#PREPARE_SEQ_TEXT4').val(data.FISHING_TITLE1);
						$("tr.update_show_fishing").hide();
					}else{
						$("tr.update_show_fishing").show();
						$updateForm.find("textarea[name='FISHING_UPDATE_CONTENT1']").text("");
						$updateForm.find("textarea[name='FISHING_UPDATE_CONTENT2']").text("");
						oEditors.getById["FISHING_UPDATE_CONTENT1"].exec("LOAD_CONTENTS_FIELD");
						oEditors.getById["FISHING_UPDATE_CONTENT2"].exec("LOAD_CONTENTS_FIELD");
						
						if(data.FISHING_CONTENT1 != null && data.FISHING_CONTENT1 != undefined)
							oEditors.getById['FISHING_UPDATE_CONTENT1'].exec("PASTE_HTML", [data.FISHING_CONTENT1]);
						
						if(data.FISHING_CONTENT2 != null && data.FISHING_CONTENT2 != undefined)
							oEditors.getById['FISHING_UPDATE_CONTENT2'].exec("PASTE_HTML", [data.FISHING_CONTENT2]);
						
						//낚시법 1
						_self.fishing1FileList = new component.FileList({
							 'id' : "fishing1ImageDiv"
							,'container' : $updateForm.find('[data-type=FISHING1_IMAGE_LIST]')
						});
						
						_self.fishing1FileList.initWithoutTextArea(data.fishing1Img);
						
						//낚시법 2
						_self.fishing2FileList = new component.FileList({
							 'id' : "fishing2ImageDiv"
							,'container' : $updateForm.find('[data-type=FISHING2_IMAGE_LIST]')
						});
						
						_self.fishing2FileList.initWithoutTextArea(data.fishing2Img);
					}						
					
					
					//내부선박사진
					_self.fileList = new component.File({
						 'id' : "fileImageDiv"
						,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
					});
					_self.fileList.init(data.mainImg[0]);
					
					$updateForm.show();
				}
				//복제
				else if( 'duplicate' === mode){
					$detailForm.hide();
					$insertForm.hide();
					$updateForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $scheduleConfUpdateForRegisterForm, data );
					console.log(data);
					
					if(data.PREPARE_FISH_SEQ1 != null){
						$scheduleConfUpdateForRegisterForm.find('#PREPARE_FISH_SEQ5').val(data.PREPARE_FISH_SEQ1);
						$scheduleConfUpdateForRegisterForm.find('#PREPARE_SEQ_TEXT5').val(data.PREPARE_TITLE1);
					}
					
					if(data.PREPARE_FISH_SEQ2 != null){
						$scheduleConfUpdateForRegisterForm.find('#PREPARE_FISH_SEQ6').val(data.PREPARE_FISH_SEQ2);
						$scheduleConfUpdateForRegisterForm.find('#PREPARE_SEQ_TEXT6').val(data.FISHING_TITLE1);
					}
					
					_self.createOptionSelect( $scheduleConfUpdateForRegisterForm.find('[data-type=PSGR_CNT]'), data.SHIP_PSGR_CNT );					
					$scheduleConfUpdateForRegisterForm.find('[data-type=PSGR_CNT]').val(data.PSGR_CNT );
					
					var schdFr = data.SCHD_FR;
					var schdTo = data.SCHD_TO;
					var from = schdFr.substring(0,4)+"-"+ schdFr.substring(4,6)+"-"+ schdFr.substring(6,8);
					var to = schdTo.substring(0,4)+"-"+ schdTo.substring(4,6)+"-"+ schdTo.substring(6,8);
					$scheduleConfUpdateForRegisterForm.find("[data-key=SCHD_FR]").val(from);
					$scheduleConfUpdateForRegisterForm.find("[data-key=SCHD_TO]").val(to);
					
					if(data.TOOL_TYPE1_STATUS == 'Y')
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE1_STATUS]").attr("checked", "checked");
					else
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE1_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE2_STATUS == 'Y')
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE2_STATUS]").attr("checked", "checked");
					else
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE2_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE3_STATUS == 'Y')
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE3_STATUS]").attr("checked", "checked");
					else
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE3_STATUS]").removeAttr("checked");
					
					if(data.TOOL_TYPE4_STATUS == 'Y')
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE4_STATUS]").attr("checked", "checked");
					else
						$scheduleConfUpdateForRegisterForm.find("[data-key=TOOL_TYPE4_STATUS]").removeAttr("checked");
					
					
					// 시간 세팅
					if(data.SCHD_TIME_TYPE == "1"){
						var schdTimeType = data.SCHD_TIME_TYPE;
						$scheduleConfUpdateForRegisterForm.find("input:checkbox[name='fishTimeType']").attr("checked", true);
						$scheduleConfUpdateForRegisterForm.find("input:checkbox[name='fishTimeType']").on("click", function(e){ e.stopPropagation(); return false;});
						$scheduleConfUpdateForRegisterForm.find('select.hour').removeAttr("disabled");
						$scheduleConfUpdateForRegisterForm.find('select.minute').removeAttr("disabled");
						$("#lifeTd2").attr("style", "display:;");
						$("#lifeTd1").attr("style", "display:;");
						
						$("#generalTd").attr("style", "display:none;");
						var schdTimes = data.SCHD_TIMES;
						for(var i = 0 ;i < schdTimes.length ;i++){
							$scheduleConfUpdateForRegisterForm.find("select[name='fishHour"+(i+1)+"']").val( schdTimes[i].substring(0,2) );
							$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute"+(i+1)+"']").val(schdTimes[i].substring(2,4) );
							$scheduleConfUpdateForRegisterForm.find("input[name='fishConf"+(i+1)+"']").val( schdTimes[i].substring(5) );
						}
						
					}else{
						var schdTime = data.SCHD_TIME;
						$scheduleConfUpdateForRegisterForm.find("input:checkbox[name='fishTimeType']").removeAttr("checked");
						$("#generalTd").attr("style", "display:;");
						if(schdTime != "" && schdTime != undefined){
							$scheduleConfUpdateForRegisterForm.find("select[name='fishHour']").val( schdTime.substring(0,2) );
							$scheduleConfUpdateForRegisterForm.find("select[name='fishMinute']").val( schdTime.substring(2,4) );
						}
						$("#lifeTd2").attr("style", "display:none;");
						$("#lifeTd1").attr("style", "display:none;");
					}				
					
					
					//내부선박사진
					_self.fileList = new component.File({
						 'id' : "fileImageDiv"
						,'container' : $scheduleConfUpdateForRegisterForm.find('[data-type=IMAGE_LIST]')
					});
					_self.fileList.init();
					
					$scheduleConfUpdateForRegisterForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('CONF_SEQ') ) {
					var confSeq = p_param.CONF_SEQ;
					var shipId = p_param.SHIP_ID;
					var page = p_param.PAGE;
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == shipId){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					// 출조스케쥴 목록 조회
					this.getScheduleList(page, {SHIP_ID : shipId} , confSeq);
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getScheduleList(1, {SHIP_ID : p_param.SHIP_ID});
				} else {
					// 출조스케쥴 목록 조회
					this.getScheduleList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
