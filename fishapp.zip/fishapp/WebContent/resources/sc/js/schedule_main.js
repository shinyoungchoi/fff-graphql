defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveURL = $('#reserveURL').val();
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleInsertURL = $('#scheduleInsertURL').val();
				this._scheduleUpdateURL = $('#scheduleUpdateURL').val();
				this._scheduleDeleteURL = $('#scheduleDeleteURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				this.$detailForm = $('#scheduleDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				// form
				this.$srchForm = $('#scheduleSearchForm');
				this.$insertForm = $('#scheduleInsertForm');
				this.$updateForm = $('#scheduleUpdateForm');
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// datePicker 이벤트선언
				_self.$insertForm.find('.datepicker').datepick({dateFormat:'yyyy-mm-dd'});
				_self.$updateForm.find('.datepicker').datepick({dateFormat:'yyyy-mm-dd'});
				
				// 보조 select box 변경
				$('.helpSel').change( function() {
					var $this = $( this );
					var val = $this.val();
					if( '' !== val ) {
						var prevVal = $this.prev().val();
						if( '' === prevVal ) $this.prev().val( $this.find('option:selected').text() );
						else $this.prev().val(prevVal + ', ' + $this.find('option:selected').text() );
					}
				});
				
				// 승선인원 변경(등록)
				_self.$insertForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.createOptionSelect( _self.$insertForm.find('[data-type=PSGR_CNT]'), $this.attr('psgrCnt'));
				});
				// 승선인원 변경(수정)
				_self.$updateForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.createOptionSelect( _self.$updateForm.find('[data-type=PSGR_CNT]'), $this.attr('psgrCnt'));
				});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertSchedule();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectScheduleId, 'SCHD_ID') );
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateSchedule();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteSchedule();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'SCHD_ID'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( page, param, showDetailId ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.scheduleList, 'SCHD_ID',  function( data, $row ) {
				    			// 등록/수정
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			// 날짜
				    			if( data.SCHD_DATE ) $row.find('[data-key=SCHD_DATE]').text( jdg.util.replaceDate(data.SCHD_DATE+data.SCHD_TIME) );
				    			// 예약관리로 이동
				    			$row.find('.reverseLink').click( function( e ) {
				    				Bplat.view.loadPage( _self._reserveURL, {
				    					'SCHD_ID' : data.SCHD_ID
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getScheduleList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.scheduleList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 출조스케줄 등록
			'insertSchedule' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				// 출조일 가공
				var $schdDate = $insertForm.find('[data-type=SCHD_DATE]');
				var schdDate = $schdDate.find('.datepicker').val().replaceAll('-','');
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_DATE' : schdDate
					, 'SCHD_TIME' : $schdDate.find('.hour option:selected').val() + $schdDate.find('.minute option:selected').val()
					, 'SUB_TITLE' : $insertForm.find('[data-key=SUB_TITLE]').val()
					, 'DESCR' : $insertForm.find('[data-key=DESCR]').val()
					, 'PSGR_CNT' : $insertForm.find('[data-type=PSGR_CNT] option:selected').val()
					, 'FEE' : $insertForm.find('[data-key=FEE]').val()
					, 'FEE_WHOLE' : $insertForm.find('[data-key=FEE_WHOLE]').val()
					, 'STATUS_CD' : $insertForm.find('[data-key=STATUS_CD] option:selected').val()
					, 'LOC_DESC' : $insertForm.find('[data-key=LOC_DESC]').val()
					, 'FISH_KIND' : $insertForm.find('[data-key=FISH_KIND]').val()
					, 'PREPARE' : $insertForm.find('[data-key=PREPARE]').val()
				};
				$.ajax({
					 url : _self._scheduleInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 출조스케줄 수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 출조일 가공
				var $schdDate = $updateForm.find('[data-type=SCHD_DATE]');
				var schdDate = $schdDate.find('.datepicker').val().replaceAll('-','');
				var updateParam = {
					  'SCHD_ID' : _self.selectScheduleId
					, 'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_DATE' : schdDate
					, 'SCHD_TIME' : $schdDate.find('.hour option:selected').val() + $schdDate.find('.minute option:selected').val()
					, 'SUB_TITLE' : $updateForm.find('[data-key=SUB_TITLE]').val()
					, 'DESCR' : $updateForm.find('[data-key=DESCR]').val()
					, 'PSGR_CNT' : $updateForm.find('[data-type=PSGR_CNT] option:selected').val()
					, 'FEE' : $updateForm.find('[data-key=FEE]').val()
					, 'FEE_WHOLE' : $updateForm.find('[data-key=FEE_WHOLE]').val()
					, 'STATUS_CD' : $updateForm.find('[data-key=STATUS_CD] option:selected').val()
					, 'LOC_DESC' : $updateForm.find('[data-key=LOC_DESC]').val()
					, 'FISH_KIND' : $updateForm.find('[data-key=FISH_KIND]').val()
					, 'PREPARE' : $updateForm.find('[data-key=PREPARE]').val()
				};
				$.ajax({
					 url : _self._scheduleUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getScheduleList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, _self.selectScheduleId);
				    	}
				    }
				});
			},
			// 출조스케줄 삭제
			'deleteSchedule' : function() {
				var _self = this;
				$.ajax({
					 url : _self._scheduleDeleteURL
					,type : 'POST'
					,data : {
						 'SCHD_ID' : _self.selectScheduleId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 출조일 셋팅
					var schdDate = data.SCHD_DATE+data.SCHD_TIME;
					if( schdDate ) {
						$detailForm.find('[data-key=SCHD_DATE]').text(jdg.util.replaceDate(schdDate));
					}
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					_self.createOptionSelect( $insertForm.find('[data-type=PSGR_CNT]'), $insertForm.find('[data-key=SHIP_ID] option:eq(0)').attr('psgrCnt') );
					// 출조일 셋팅
					var $schdDate = $insertForm.find('[data-type=SCHD_DATE]');
					$schdDate.find('.datepicker').val('');
					$schdDate.find('.hour').val('00');
					$schdDate.find('.minute').val('00');
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					_self.createOptionSelect( $updateForm.find('[data-type=PSGR_CNT]'), data.SHIP_PSGR_CNT );					
					$updateForm.find('[data-type=PSGR_CNT]').val(data.PSGR_CNT );
					
					// 출조일 셋팅
					var $schdDate = $updateForm.find('[data-type=SCHD_DATE]');
					var schdDate = data.SCHD_DATE+data.SCHD_TIME;
					if( schdDate ) {
						$schdDate.find('.datepicker').val( jdg.util.replaceDate(schdDate.substring(0,8)) );
						$schdDate.find('.hour').val( schdDate.substring(8,10) );
						$schdDate.find('.minute').val( schdDate.substring(10,12) );
					} else {
						$schdDate.find('.datepicker').val('');
						$schdDate.find('.hour').val('00');
						$schdDate.find('.minute').val('00');
					}
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('SCHD_ID') ) {
					var schdId = p_param.SCHD_ID;
					// 출조스케쥴 목록 조회
					this.getScheduleList('1', {'SCHD_ID' : schdId});
				} else {
					// 출조스케쥴 목록 조회
					this.getScheduleList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
