defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = $('#memberListURL').val();
				this._memberDetailURL = $('#memberDetailURL').val();
				this._memberInsertURL = $('#memberInsertURL').val();
				this._memberUpdateURL = $('#memberUpdateURL').val();
				this._memberDeleteURL = $('#memberDeleteURL').val();
				this._memberNickCheckURL = $('#memberNickCheckURL').val();
				this._shipSearchURL = $('#shipSearchURL').val();
				this._shipSundanSearchURL = $('#shipSundanSearchURL').val();
				this._shipSundanSearchURL = $('#shipSundanSearchURL').val();
				
				//memberPointListURL
				
				// element
				this.$listContainer = $('#memberListContainer');
				this.$listTemplate = $('#memberListTemplate');
				this.$detailForm = $('#memberDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$showPointBtn = $('#showPointBtn');
				this.$addPointBtn = $('#addPointBtn');
				
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$regChkBtn = $('#regNickCheckBtn');
				this.$mfyChkBtn = $('#mfyNickCheckBtn');
				this.$mGradeSel = $('#memberGradeSel');
				this.$mSrhKeyRadio = $('[name=memberSearchTerms]');
				this.$mSrhVal = $('#memberSearchVal');
				
				this.$addShipBtn = $('#addShipMemberBtn');
				this.$delShipBtn = $('#delShipMemberBtn');
				
				this.$addShipSundanBtn = $('#addSoMemberBtn');
				this.$delShipSundanBtn = $('#delSoMemberBtn');
				
				this.$selectShip = $('#selectShip');
				
				// form
				this.$srchForm = $('#memberSearchForm');
				this.$insertForm = $('#memberInsertForm');
				this.$updateForm = $('#memberUpdateForm');
				// static variable
				this.ShipMemberList = [];
				this.selectMemberId = '';
				this.selectDetailData = {};
				this.updateShipMemberList = [];
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.$selectedSortOption = "";
				this.$portalYn = "N";
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$srchForm.submit(function() {
					// 회원목록조회
					var param = {
						'GRADE_CD' : _self.$mGradeSel.find('option:selected').val()
					};
					var key = _self.$mSrhKeyRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$mSrhVal.val());
					}
					_self.getMemberList('1',param);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규 등록시 닉네임 중복 체크 클릭
				_self.$regChkBtn.click( function() {
					_self.checkNickName( _self.$insertForm.find('[data-key=NICK_NAME]') );
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertMember();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectDetailData);
				});
				
				// 회원 정보 수정시 닉네임 중복 체크 클릭
				_self.$mfyChkBtn.click( function() {
					_self.checkNickName( _self.$updateForm.find('[data-key=NICK_NAME]') );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateMember();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteMember();
				});
				
				// 가입선박 추가
				_self.$addShipBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_insert_popup' );
					
					return false;
				});
				
				// 삭제선박추가
				_self.$delShipBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_delete_popup' );
					
					return false;
				});

				
				// 가입출조점 추가
				_self.$addShipSundanBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSundanSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'so_insert_popup' );
					
					return false;
				});
				
				// 삭제출조점 추가
				_self.$delShipSundanBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSundanSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'so_delete_popup' );
					
					return false;
				});
				
				_self.$selectedSortOption = $(".btnSort:first");
				_self.$selectedTypeOption = $(".btnType:first");
				_self.$selectShip
				
				$(".btnSort").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedSortOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedSortOption = newSel;
						
						_self.$srchForm.submit();
					}
					
					return false;
				});				

				$(".btnType").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedTypeOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedTypeOption = newSel;
						
						var typeValue = newSel.val();
						
						if (typeValue == "_A" || typeValue == "_P")
							{
								_self.$selectShip.val("");
								_self.$selectShip.hide();
							}
						else
							{
								_self.$selectShip.show();
							}
						
						_self.$srchForm.submit();
					}
					
					return false;
				});	
				
				
				_self.$showPointBtn.click( function(event) {
					
					var _self = this;					
					
					_self.$listContainer.find('tr').removeClass('jdg-selected');
					$tr.addClass('jdg-selected');
					$.ajax({
						 url : _self._memberDetailURL
						,type : 'POST'
						,data : {'MEM_ID' : _self.selectMemberId}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	if( data.hasOwnProperty('memberList') ) {
					    		// 리스트 초기화
					    		_self.list.createList( data.memberList, 'MEM_ID' , function( data, $row ) {

					    		});

					    	}
					    }
					});
					
				});
				
				
				_self.$selectShip.change(function() {
				
					if (_self.$selectShip.css("display") != "none")
					{
						_self.$srchForm.submit();					 	
					}
					
					return false;
										
				});
				
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectMemberId = $tr.attr('rowKey');
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				$.ajax({
					 url : _self._memberDetailURL
					,type : 'POST'
					,data : {'MEM_ID' : _self.selectMemberId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		_self.selectDetailData = detail;
				    		_self.selectFormShow('search', detail);
				    	}
				    }
				});
			},
			// 회원 목록 조회
			'getMemberList' : function( page, param, showDetailId ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				    ,'SORT': _self.$selectedSortOption.val()
				    ,'TYPE': _self.$selectedTypeOption.val()
				    ,'SHIP_ID': _self.$selectShip.val()
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('memberList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.memberList, 'MEM_ID' , function( data, $row ) {

				    		});
				    		// 페이징 초기화
				    		$('#memberListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getMemberList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.memberList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 회원 등록
			'insertMember' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				// 닉네임 등록 여부 확인
				var $nickName = $insertForm.find('[data-key=NICK_NAME]');
				var checkFlag =$nickName.attr('checkFlag');
				if( '' === $nickName.val() || checkFlag === 'true' ) {
					var insertParam = {
						   'USER_ID' : $insertForm.find('[data-key=USER_ID]').val()
						,  'EMAIL' : $insertForm.find('[data-key=EMAIL]').val()
						, 'TEL' : $insertForm.find('[data-key=TEL_1]').val() + '-' + $insertForm.find('[data-key=TEL_2]').val() + '-' + $insertForm.find('[data-key=TEL_3]').val()
						, 'MEM_NAME' : $insertForm.find('[data-key=MEM_NAME]').val()
						, 'NICK_NAME' : $nickName.val()
						, 'PWD' : $insertForm.find('[data-key=PWD]').val()
						, 'EMAIL_AUTH_KEY' : $insertForm.find('[data-key=EMAIL_AUTH_KEY]').val()
						, 'GRADE_CD' : $insertForm.find('[data-type=GRADE_CD] option:selected').val()
					};
					$.ajax({
						 url : _self._memberInsertURL
						,type : 'POST'
						,data : insertParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('등록 되었습니다');
					    		location.reload();
					    	}
					    	
					    	if(data.hasOwnProperty('error')){
					    		alert(data.error.userMessage);
					    		
					    	}
					    }
					});
				} else {
					alert('닉네임 중복체크를 해주세요');
				}
			},
			// 회원 수정
			'updateMember' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateData = _self.list.getListRowData(_self.selectMemberId, 'MEM_ID');
				// 닉네임 등록 여부 확인
				var $nickName = $updateForm.find('[data-key=NICK_NAME]');
				var checkFlag =$nickName.attr('checkFlag');
				var nickName = $nickName.val();
				var beforeNickName = updateData.NICK_NAME;
				if( '' === nickName || beforeNickName === nickName || checkFlag === 'true' ) {
					var updateParam = {
						  'MEM_ID' : _self.selectMemberId
					    , 'EMAIL' : $updateForm.find('[data-key=EMAIL]').val()
						, 'TEL' : $updateForm.find('[data-key=TEL_1]').val() + '-' + $updateForm.find('[data-key=TEL_2]').val() + '-' + $updateForm.find('[data-key=TEL_3]').val()
						, 'MEM_NAME' : $updateForm.find('[data-key=MEM_NAME]').val()
						, 'NICK_NAME' : nickName
						, 'PWD' : $updateForm.find('[data-key=PWD]').val()
						, 'EMAIL_AUTH_KEY' : $updateForm.find('[data-key=EMAIL_AUTH_KEY]').val()
						, 'GRADE_CD' : $updateForm.find('[data-type=GRADE_CD] option:selected').val()
						, 'STATUS_CD' : $updateForm.find('[data-type=STATUS_CD] option:selected').val()
						, 'SHIP_MEMBER_LIST' : JSON.stringify(_self.ShipMemberList)
					};
					if( '107_170' === updateData.GRADE_CD ) updateParam.GRADE_CD = '107_170';
					$.ajax({
						 url : _self._memberUpdateURL
						,type : 'POST'
						,data : updateParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		alert('수정 되었습니다');
					    		_self.selectFormShow('none');
					    	}
					    }
					});
				} else {
					alert('닉네임 중복체크를 해주세요');
				}
			},
			// 회원 삭제
			'deleteMember' : function() {
				var _self = this;
				$.ajax({
					 url : _self._memberDeleteURL
					,type : 'POST'
					,data : {
						 'MEM_ID' : _self.selectMemberId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	} else if ( data.hasOwnProperty( 'error' ) ){
				    		alert( data.error.userMessage );
				    		return false;
				    	}
				    }
				});
			},
			// 닉네임 체크
			'checkNickName' : function( $nickName ) {
				var _self = this;
				var nickName = $.trim( $nickName.val() );
				if( '' === nickName ) {
					alert('닉네임을 등록해주세요');
					return false;
				}
				$.ajax({
					 url : _self._memberNickCheckURL
					,type : 'POST'
					,data : {
						 'NICK_NAME' : nickName
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('count') ) {
				    		if( data.count == 0 ) {
				    			alert('등록 가능한 닉네임 입니다');
				    			// 닉네임창 비활성화
				    			$nickName.addClass('jdg-disabled');
				    			$nickName.attr('readonly', true);
				    			$nickName.attr('checkFlag', 'true');
				    		} else {
				    			alert('사용중인 닉네임 입니다');
				    			$nickName.attr('checkFlag', 'false');
				    		}
				    	}
				    }
				});
			},
			
			//가입선박,가입출조점,포털가입여부를 화면에 setting
			setShipList: function($form)
			{
				var _self = this;
				
				var h_count = 0;
				var c_count = 0;				

				var $shipMember = $form.find('[data-type=SHIP_MEMBER_LIST]');
				var $soMember = $form.find('[data-type=SO_MEMBER_LIST]');
				var $pMember = $form.find('[data-type=PORTAL_MEMBER_YN]');		
		
				$shipMember.empty();
				$soMember.empty();
				$pMember.empty();
				
				var shipList = _self.ShipMemberList;
				
				var shipNm = "";
				var shipType;
				$.each(shipList, function( idx,ship ) {
					shipNm = ship.SHIP_NAME;
					
					shipType = ship.SHIP_ID.substr(0,1);
					
					if(shipType == "H")
					{
						if(h_count != 0) shipNm = ', ' + shipNm;
						$shipMember.append( $('<em>').attr('shipId',ship.SHIP_ID).text(shipNm) );
						h_count ++;
					}
					else if(shipType == "C")
					{
						if(c_count != 0)  shipNm = ', ' + shipNm;
						$soMember.append( $('<em>').attr('shipId',ship.SHIP_ID).text(shipNm) );
						c_count ++;
					}
					else
					{
						$portalYn = shipNm;
						
						if (shipNm == "Y")
							{
								$pMember.append( $('<em>').attr('portalYn','Y').text('회원') );
							}
						else
							{
								$pMember.append( $('<em>').attr('portalYn','N').text('비회원') );
							}
					}

				});
				
			},
			
			
			// 가입 선박,가입 출조점, 포털가입여부
			'createShipList' : function( $form, data ) {
				var _self = this;
				_self.ShipMemberList = [];
				
				if( undefined != data.shipList || null != data.shipList ) {
					_self.ShipMemberList = jdg.util.toArray(data.shipList);
				}
				
				_self.setShipList($form);
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 가입선박
					_self.createShipList( $detailForm, data );
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=GRADE_CD] option:eq(0)').attr('selected',true);
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_1]'), $updateForm.find('[data-key=TEL_2]'), $updateForm.find('[data-key=TEL_3]'), data.TEL );
					
					var $userId = $updateForm.find('[data-type=USER_ID]');
					$userId.text(data.USER_ID); 
					
					
					// 등급
					var $gradeSel = $updateForm.find('[data-type=GRADE_CD]');
					var $gradeNm = $updateForm.find('[data-type=GRADE_NAME]');
					if( '107_170' === data.GRADE_CD ) {
						$gradeSel.hide();
						$gradeNm.text( data.GRADE_NAME ); 
					} else {
						$gradeNm.text(''); 
						$gradeSel.show();
						$gradeSel.val(data['GRADE_CD']);
					}
					
					$updateForm.find('[data-type=STATUS_CD] option[value="'+data.STATUS_CD+'"]').attr("selected","selected");
					if(data.STATUS_CD != '118_130'){
						$updateForm.find('[data-type=STATUS_CD]').attr('disabled','disabled');
					}else{
						$updateForm.find('[data-type=STATUS_CD]').removeAttr('disabled');
					}
					
					var $pMember = $updateForm.find('[data-type=PORTAL_MEMBER_YN]');
					
					if ($portalYn == "Y")
					{
						$pMember.append( "<a id='addPortalMemberBtn' href ='#' class='jdg-btn-check'>탈퇴</a>" );
					}
					else
					{
						$pMember.append( "<a id='addPortalMemberBtn' href ='#' class='jdg-btn-check'>가입</a>" );
					}
					
					$pMember.html("sv");

					
					// 가입선박
					_self.createShipList( $updateForm, data );
					
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 회원목록조회
				this.getMemberList('1', p_param);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				// 가입선박 팝업 close
				if(data){
					if( 'ship_insert_popup' === p_param.id ) {
						var shipId = data.SHIP_ID;
						var shipNm = '';
						var isNotRegistered = true;
						var $shipMember = _self.$updateForm.find('[data-type=SHIP_MEMBER_LIST]');
							$.each( $shipMember.find('em'), function(){
								var $this = $( this );
								if( shipId == $this.attr('shipId') ) {
									alert('이미 등록된 선박 입니다.');
									isNotRegistered = false;
								}
							});
	
						if( isNotRegistered ) {
							
							_self.ShipMemberList[_self.ShipMemberList.length] = {
								'SHIP_ID' : 	data.SHIP_ID
								,'SHIP_NAME' : data.SHIP_NAME
							};
							
							_self.setShipList(_self.$updateForm);
						}
					}
					if('ship_delete_popup' == p_param.id){
						var shipId = data.SHIP_ID;
						var shipNm = '';
						var isRegistered = false;
						var $shipMember = _self.$updateForm.find('[data-type=SHIP_MEMBER_LIST]');
							$.each( $shipMember.find('em'), function(){
								var $this = $( this );
								if( shipId == $this.attr('shipId') ) {

									isRegistered = true;
								}
							});
						
						if( isRegistered ) {
							
							var tempList = [];
							var i= 0;
							
							$.each(_self.ShipMemberList, function(idx, ship){
								console.info("idx", idx);
								console.info("_self.ShipMemberList[]", ship);
								if(ship.SHIP_ID != data.SHIP_ID){
									tempList[i] = ship;
									i++;
								}
							});							
							
							_self.ShipMemberList = tempList;
							_self.setShipList(_self.$updateForm);

						}else{
							alert("등록되지 않은 선박입니다.");
						}
					}

				
					if( 'so_insert_popup' === p_param.id ) {
						var shipId = data.SHIP_ID;
						var shipNm = '';
						var isNotRegistered = true;
						var $shipMember = _self.$updateForm.find('[data-type=SO_MEMBER_LIST]');
							$.each( $shipMember.find('em'), function(){
								var $this = $( this );
								if( shipId == $this.attr('shipId') ) {
									alert('이미 등록된 출조점 입니다.');
									isNotRegistered = false;
								}
							});
	
						if( isNotRegistered ) {
							
							_self.ShipMemberList[_self.ShipMemberList.length] = {
								'SHIP_ID' : 	data.SHIP_ID
								,'SHIP_NAME' : data.SHIP_NAME
							};
							
							_self.setShipList(_self.$updateForm);
						}
					}
					if('so_delete_popup' == p_param.id){
						var shipId = data.SHIP_ID;
						var shipNm = '';
						var isRegistered = false;
						var $shipMember = _self.$updateForm.find('[data-type=SO_MEMBER_LIST]');
							$.each( $shipMember.find('em'), function(){
								var $this = $( this );
								if( shipId == $this.attr('shipId') ) {

									isRegistered = true;
								}
							});
						
						if( isRegistered ) {
							
							var tempList = [];
							var i= 0;
							
							$.each(_self.ShipMemberList, function(idx, ship){
								console.info("idx", idx);
								console.info("_self.ShipMemberList[]", ship);
								if(ship.SHIP_ID != data.SHIP_ID){
									tempList[i] = ship;
									i++;
								}
							});							
							
							_self.ShipMemberList = tempList;
							_self.setShipList(_self.$updateForm);

						}else{
							alert("등록되지 않은 출조점입니다.");
						}
					}
					
					
				
				}
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
