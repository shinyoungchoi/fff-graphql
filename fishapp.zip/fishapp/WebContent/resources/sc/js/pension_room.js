defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveURL = $('#reserveURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				
				//신규 등록시
				this.$regBtn = $('#regBtn');
				//장르 등록 버튼
				this.$regSubmitBtn = $('#regSubmitBtn');
				//상세 -> 수정시
				this.$updateSubmitBtn = $('#updateSubmitBtn');
				this.$mfyBtn = $('#modifyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				this.$detailForm = $('#scheduleConfDetailForm');
				this.$insertForm = $('#scheduleConfInsertForm');
				this.$updateForm = $('#scheduleConfUpdateForm');
				
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				
				this.fileList = null;
				this.mainImgList= null;
				
			},
			'setEvent'		: function() {
				var _self = this;
								
				
				// 조회
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getRoomList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					var shipId = _self.$srhSel.find('option:selected').val();	
					if(shipId == '' || shipId == undefined){
						alert("업체를 먼저 선택해주세요!");
						return;
					}
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$regSubmitBtn.click( function() {
					_self.insertRoom();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				//수정 취소
				_self.$mfyCancelBtn.click(function(){
					_self.selectFormShow('none');
				});
								
				// 수정화면 보이기
				_self.$updateSubmitBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectScheduleId, 'ROOM_ID') );
				});
				
				//수정하기
				_self.$mfyBtn.click(function(){
					_self.updateSchedule();
				});
				
				//삭제하기
				_self.$delBtn.click(function(){
					if(!confirm("삭제하시겠습니까?")){
						return false;
					}
					_self.deleteSchedule();
					
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
				
				
				$(".jdg-ui-inner").delegate('.fileUpBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});

				$(".jdg-ui-inner").delegate('.fileDownBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, +1); //다운버튼을 눌렀을때는 해당 이미지를 한칸아래로 이동
				});
				
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'ROOM_ID'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			
			// 객실정보 목록 조회
			'getRoomList' : function( page, param, showDetailId ) {
				var _self = this;
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/pension/roomList"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('roomList') ) {
				    		
				    		var shipName =  _self.$srhSel.find("option:selected").text();
				    		if (shipName == '*선박선택')
				    		{
				    			shipName = "전체 선박";
				    		}
				    		
							$('#span_ship_nm').text(shipName + '의 장르');
							$('#span_ship_nm').show();
							
				    		// 리스트 초기화
				    		_self.list.createList( data.roomList, 'ROOM_ID');
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getRoomList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.roomList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 객실정보 등록
			'insertRoom' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var filesParam = {};
				var files = _self.fileList.getFileList(); //FILEID 반환.
				if(files != null && files != ""){
					filesParam.mainFile = { IMG_ID : files , type :"MAIN_IMG"};
				}
				
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;				
				
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'ROOM_NM' : $insertForm.find('[data-key=ROOM_NM]').val()
					, 'STD_MAN' : $insertForm.find('[data-key=STD_MAN]').val()
					, 'ADD_MAN' : $insertForm.find('[data-key=ADD_MAN]').val()
					, 'ADD_FEE_DESC' : $insertForm.find('[data-key=ADD_FEE_DESC]').val()
					, 'ROOM_EQP' : $insertForm.find('[data-key=ROOM_EQP]').val()
					, 'ROOM_DESC' : $insertForm.find('[data-key=ROOM_DESC]').val()
					, 'ROOM_TYPE' : $insertForm.find('[data-type=ROOM_TYPE] option:selected').val()
					, 'ROOM_SIZE' : $insertForm.find('[data-key=ROOM_SIZE]').val()
					, 'ROOM_STYLE' : $insertForm.find('[data-key=ROOM_STYLE]').val()
					, 'ROOM_SEQ': $insertForm.find('[data-type=ROOM_SEQ] option:selected').val()
					, 'MAIN_FILE' : ( filesParam.mainFile != undefined )? JSON.stringify(filesParam.mainFile): null
				};
				
				if(insertParam.ADD_MAN == '' || insertParam.ADD_MAN == undefined){
					insertParam.ADD_MAN = "0";
				} 
		
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/pension/insertRoom"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/pension/room?SHIP_ID="+ $("#searchShipSel").val();
				    		return;
				    	}else{
				    		if( data.hasOwnProperty('error') ) {
					    		alert(data.error);
					    		return;
					    	}
					    	
					    	alert("오류가 발생하였습니다.");
					    	return;
				    	}
				    }
				});
				
			},
			
			// 객실 수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				var filesParam = {};
				var remainFiles= [];
				
				$updateForm.find("[data-type=IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"MAIN_IMG", SEQ : index + 1});
				});
				
				
				console.log(remainFiles);
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				
				var updateParam = {
						'ROOM_ID': _self.selectScheduleId
						 ,'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()
						, 'ROOM_NM' : $updateForm.find('[data-key=ROOM_NM]').val()
						, 'STD_MAN' : $updateForm.find('[data-key=STD_MAN]').val()
						, 'ADD_FEE_DESC' : $updateForm.find('[data-key=ADD_FEE_DESC]').val()
						, 'ROOM_EQP' : $updateForm.find('[data-key=ROOM_EQP]').val()
						, 'ROOM_DESC' : $updateForm.find('[data-key=ROOM_DESC]').val()
						, 'ROOM_TYPE' : $updateForm.find('[data-type=ROOM_TYPE] option:selected').val()
						,  'ADD_MAN' : $updateForm.find('[data-key=ADD_MAN]').val()
						, 'ROOM_SIZE' : $updateForm.find('[data-key=ROOM_SIZE]').val()
						, 'ROOM_STYLE' : $updateForm.find('[data-key=ROOM_STYLE]').val()
						, 'ROOM_SEQ': $updateForm.find('[data-type=ROOM_SEQ] option:selected').val()
						, 'REMAIN_FILE' : ( remainFiles != undefined )? JSON.stringify(remainFiles): null
				};
				
				if(updateParam.ADD_MAN == '' || updateParam.ADD_MAN == undefined){
					updateParam.ADD_MAN = "0";
				} 
				
				$.ajax({
					 url : "/sc/pension/updateRoom"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		location.href="/sc/pension/room?PAGE="+_self.selectPage+"&SHIP_ID="+_self.$srhSel.find('option:selected').val()+"&ROOM_ID="+_self.selectScheduleId
				    		return;
				    	}else{
				    		if( data.hasOwnProperty('error') ) {
					    		alert(data.error);
					    		return;
					    	}
					    	
					    	alert("오류가 발생하였습니다.");
					    	return;
				    	}
				    }
				});
			},
			// 장르 삭제
			'deleteSchedule' : function() {
				var _self = this;
				if(_self.selectScheduleId == ""){
					alert("삭제하실 객실을 목록에서 선택해주세요.");
					return;
				}
				
				$.ajax({
					 url : "/sc/pension/deleteRoom"
					,type : 'POST'
					,data : {
						 'ROOM_ID' : _self.selectScheduleId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					console.log(data);
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
			
					if(data.ROOM_DESC != "" && data.ROOM_DESC != undefined)
						$detailForm.find("[data-type=ROOM_DESC]").html(data.ROOM_DESC.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=ROOM_DESC]").html("");
										
					if(data.hasOwnProperty('mainImg')){
						_self.mainImgList = _self.setImageContainer("IMAGE_LIST", data.mainImg);
					}else{
						$detailForm.find('[data-type=IMAGE_LIST]').html("");
					}
						
					$detailForm.show();
				}
				// 신규등록
				else if('insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
										
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
										
					//객실이미지사진
					_self.fileList = new component.FileList({
						 'id' : 'fileImageDiv'
						,'container' :$insertForm.find('[data-type=IMAGE_LIST]')
					});
					
					_self.fileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
					_self.fileList.init([]);
					
					var shipId = $("#searchShipSel").val();					
					if(shipId != "" && shipId != undefined){
						$insertForm.find("select[name='regShipId'] option:eq(0)").attr("selected", false);
						$insertForm.find("select[name='regShipId'] option[value='"+shipId+"']").attr("selected", "selected");
						var supply = $insertForm.find("select[name='regShipId'] option:selected").attr("psupply");
						$insertForm.find("[data-key='ADD_FEE_DESC']").attr("value", supply);
					}
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					//객실순번 세팅
					$updateForm.find("select[data-type='ROOM_SEQ'] option[value='"+data.ROOM_SEQ+"']").attr("selected", "selected");
					//객실타입 세팅
					$updateForm.find("select[data-type='ROOM_TYPE'] option[value='"+data.ROOM_TYPE+"']").attr("selected", "selected");
					
					//선박이미지 셋팅
					_self.fileList = new component.FileList({
						 'id' : 'fileImageDiv'
						,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
					});
					
			        _self.fileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
					_self.fileList.init(_self.mainImgList);

					$updateForm.show();
				}
				
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},	//이미지 컨테이너에 이미지들을 셋팅
			'setImageContainer' : function( fieldName,data) {
				console.log(data);
				var _self = this;
				
				var imgContainer = _self.$detailForm.find('[data-type="' + fieldName + '"]');	
				var images = data;		
				var imgList = [];
									
				if (images == null)
				{
					imgContainer.empty();						
				}
				else
				{
					$.each(images, function(index, item)
							{
								imgList.push({"IMG_ID":item.IMG_ID});						
							});	
					jdg.util.createImgList( imgList, imgContainer );
					
				}	
				
				return imgList;
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('ROOM_ID') ) {
					var roomId = p_param.ROOM_ID;
					var shipId = p_param.SHIP_ID;
					var page = p_param.PAGE;
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == shipId){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					// 방리스트 조회
					this.getRoomList(page, {SHIP_ID : shipId} , roomId);
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getRoomList(1, {SHIP_ID : p_param.SHIP_ID});
				} else {
					// 출조스케쥴 목록 조회
					this.getRoomList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
