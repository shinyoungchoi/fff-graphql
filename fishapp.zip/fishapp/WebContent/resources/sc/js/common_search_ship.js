var arrylen = arryShip.length;
var area1 = "";
var area2 = "";

var area1_map = {};
var area2_map = {};

var item;
var area1_item;
var area2_item;
var prev_stext = "";

var $area1Sel = $('#area1Sel');
var $area2Sel = $('#area2Sel');
var $shipSel = $('#searchShipSel');
var $searchText = $('#searchText');
var $span_ship_nm = $('#span_ship_nm');

for (var i=1; i < arrylen; i++)
	{
		item = arryShip[i];
		if (area1 != item.area1)
			{
				$area1Sel.append('<option>' + item.area1 + "</option>" );
				area1 = item.area1;
			}
		
		if (area2 != item.port_nm)
		{
			area1_item = area1_map[item.area1];
			if (area1_item == null)
			{
				area1_item = [];
			}	
			
			area1_item.push({area2: item.area2, port_cd: item.port_cd, port_nm: item.port_nm});			
			area1_map[item.area1] = area1_item;
			area2= item.port_nm;
		}
		
		area2_item = area2_map[item.port_cd];
		if (area2_item == null)
		{
			area2_item = [];
		}
		area2_item.push(item);	
		area2_map[item.port_cd] = area2_item;
	}
	
$area1Sel.change(function(){
	
	$searchText.val("");
	
	$area2Sel.empty();
	$area2Sel.append('<option value=""> * 항구선택 </option>' );
	
	$shipSel.empty();
	$shipSel.append('<option  value=""> * 선박선택 </option>' );
	
	$.each( area1_map[$area1Sel.val()], function( key, value ) {
			$area2Sel.append('<option value=' + value.port_cd + '>' + value.area2 + ' (' +  value.port_nm + ')' + "</option>" );
		});
});

$area2Sel.change(function(){
	
	$searchText.val("");
	
	$shipSel.empty();
	$shipSel.append('<option  value=""> * 선박선택 </option>' );
	
	$.each( area2_map[$area2Sel.val()], function( key, value ) {
			$shipSel.append('<option value="' + value.ship_id   + '">' + value.ship_nm + '</option>' );
		});

});

$searchText.focusout(function(){
	
	var stext = $searchText.val().trim();
	if (stext == '' && prev_stext != stext)
	{
		return;
	}
	
	prev_stext = stext;
	
	$shipSel.empty();
	$shipSel.append('<option  value=""> * 선박선택 </option>' );

	for (var i=1; i < arrylen; i++)
	{
		item = arryShip[i];
		if (item.ship_nm.indexOf(stext) >= 0 )
			{
				$shipSel.append('<option value="' + item.ship_id   + '">' + item.ship_nm + '</option>' );
			}
	}
	
	//배 정보가 있는 경우 자동세팅
	var query = window.location.search.substring(1);
	if(query != '' && query != undefined){
		var vars = query.split("&");
		for (var i=0;i<vars.length;i++) {
			    var pair = vars[i].split("=");
			    if(pair[0] == 'SHIP_ID'){
			    	var shipId = decodeURIComponent(pair[1]);
			    	$shipSel.val(shipId);
			}
		}
	}
});
