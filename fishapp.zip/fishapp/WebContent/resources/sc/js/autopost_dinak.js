defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$detailForm = $('#shipDetailForm');
				this.$shipCateSel = $('#searchShipCategorySel');

				this.$regBtn = $('#regBtn');
				this.$dinakBtn = $('#dinakBtn');
				this.$refreshBtn = $('#refreshBtn');
				
				// form
				this.$srchForm = $('#shipSearchForm');
				this.$insertForm = $('#shipInsertForm');
				this.$updateForm = $('#shipUpdateForm');
				
				this.$selRegdays = $('#select_regdays');
				this.$selRegship = $('#select_regship');
				
				
				// static variable
				this.selectShipId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.page = 1;
				this.param = null;
				this.total_rows = 1;
				
				this.alllist = null;
				
				opener = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
				// 코드 목록 조회
				_self.$srchForm.submit(function() {
					
					var param = {};
					
					var key = $('[name="shipSearchTerms"]').filter(':checked').val();
					var searchText = $("#searchText").val().trim();
					
					if( '' !== key && searchText != '') {
						param[key] = '%' + searchText + '%';
					}
					
					_self.getShipList( '1', param);
					return false;
				});
				
				// logindo
				$("#shipListContainer").on("click", ".loginBtn",function(){
					var pid = $(this).attr("pid");
					var alllist = _self.alllist;
					let dinak_id;
					let dinak_pwd;
					for(var i = 0 ;i < alllist.length ;i++){
						var item = alllist[i];
						if(item.GALR_ID == pid){
							$("#login-id").val(item.DINAK_ID);
							$("#login-password").val(item.DINAK_PWD);
							console.log(item.DINAK_ID);
							console.log(item.DINAK_PWD);
						}
					}
					opener = window.open("", "openTab"); 
					var df = document.formname1;

					df.target = "openTab";
					df.action = "https://ssl.dinak.co.kr:8129/proxy/mypage/exec/member-login.dnak";
					df.method = "post";
					df.submit();
					
				});
				
				// logindo
				$("#shipListContainer").on("click", ".contentBtn",function(){
					var pid = $(this).attr("pid");
					var alllist = _self.alllist;
					
					var newForm = document.createElement('form');
					document.body.appendChild(newForm);
					
					newForm.action="http://jowhang.dinak.co.kr/%EC%A0%90%EC%A3%BC%EC%84%A0%EC%9E%A5%EC%A1%B0%ED%99%A9/exec/write/0";
					newForm.method = "post";
					newForm.target = "openTab";
					
					for(var i = 0 ;i < alllist.length ;i++){
						var item = alllist[i];
						if(item.GALR_ID == pid){
							// 에디터 선택	
							var inputEditType = document.createElement("input");
							inputEditType.setAttribute("type","hidden");
							inputEditType.setAttribute("name","editType");
							inputEditType.setAttribute("value","editor");
							newForm.appendChild(inputEditType);
							
							// 지역 선택
							var inputRegion1 = document.createElement("input");
							inputRegion1.setAttribute("type","hidden");
							inputRegion1.setAttribute("name","region1");
							inputRegion1.setAttribute("value",item.DINAK_P1);
							newForm.appendChild(inputRegion1);
							
							var inputRegion2 = document.createElement("input");
							inputRegion2.setAttribute("type","hidden");
							inputRegion2.setAttribute("name","region2");
							inputRegion2.setAttribute("value",item.DINAK_P2);
							newForm.appendChild(inputRegion2);
							
							// 낚시 구분
		        			let genre = "선상";
		        	      	if (item.DINAK_BBS_CD == "좌대")
		        	      		genre = "유료/좌대";
		        	      	else if (item.DINAK_BBS_CD == "갯바위")
		        	      		genre = "갯바위";
		        	      	else if (item.DINAK_BBS_CD == "방파제")
		        	      		genre = "방파제";
		        	      	else 
		        	      		genre = "선상";
		        	      	
		        	      	var inputType = document.createElement("input");
							inputType.setAttribute("type","hidden");
							inputType.setAttribute("name","type");
							inputType.setAttribute("value",genre);
							newForm.appendChild(inputType);
							
							if (genre == "선상") {
								
		        	        	let fishes = item.FISH_NAME;
		        	        	if(fishes.indexOf("갈치") != -1) 
		        	        		fishes ="갈치선상/갈치지깅";
		        	        	else if(fishes.indexOf("오징어") != -1 || fishes.indexOf("문어") != -1 || fishes.indexOf("쭈꾸미") != -1) 
		        	        		fishes = "오징어/문어/주꾸미";
		        	        	else if(fishes.indexOf("삼치") != -1 || fishes.indexOf("부시리") != -1 || fishes.indexOf("방어") != -1 || fishes.indexOf("대구") != -1 || fishes.indexOf("고등어") != -1 || fishes.indexOf("명태") != -1 ) 
		        	        		fishes = "삼치/부시리/방어/대구";
		        	        	else if(fishes.indexOf("참돔") != -1 || fishes.indexOf("광어") != -1 || fishes.indexOf("농어") != -1 || fishes.indexOf("민어") != -1 || fishes.indexOf("도다리") != -1 || fishes.indexOf("양태") != -1 ) 
		        	        		fishes = "참돔/광어/농어";
		        	        	else if(fishes.indexOf("열기") != -1 || fishes.indexOf("볼락") != -1 || fishes.indexOf("우럭") != -1 || fishes.indexOf("백조기") != -1 || fishes.indexOf("쥐노래미") != -1 ) 
		        	        		fishes = "열기/볼락/우럭";
		        	        	else 
		        	        		fishes = "감/참/부/방 선상낚시";		        	        	
		        	        	
		        	        	var inputFishes = document.createElement("input");
		    					inputFishes.setAttribute("type","hidden");
		    					inputFishes.setAttribute("name","fishes");
		    					inputFishes.setAttribute("value",fishes);
		    					newForm.appendChild(inputFishes);
		    					
		    					var inputUsingextend = document.createElement("input");
		    					inputUsingextend.setAttribute("type","hidden");
		    					inputUsingextend.setAttribute("name","usingextend");
		    					inputUsingextend.setAttribute("value","1"); //어종별 선상 조황 함께 등록 체크 값
		    					newForm.appendChild(inputUsingextend);
							}
							
							var inputSubject = document.createElement("input");
							inputSubject.setAttribute("type","hidden");
							inputSubject.setAttribute("name","subject");
							inputSubject.setAttribute("value",item.TITLE);
							newForm.appendChild(inputSubject);
							
							var inputContents = document.createElement("input");
							inputContents.setAttribute("type","hidden");
							inputContents.setAttribute("name","contents");
							inputContents.setAttribute("value",item.REAL_CONTENT);
							newForm.appendChild(inputContents);
							
						}
					}
					
					
					
					/*
					var newForm = document.createElement('form');
					document.body.appendChild(newForm);
					
					newForm.action="http://jowhang.dinak.co.kr/%EC%A0%90%EC%A3%BC%EC%84%A0%EC%9E%A5%EC%A1%B0%ED%99%A9/exec/write/0";
					newForm.method = "post";
					newForm.target = "openTab";
					
					var inputEditType = document.createElement("input");
					inputEditType.setAttribute("type","hidden");
					inputEditType.setAttribute("name","editType");
					inputEditType.setAttribute("value","editor");
					newForm.appendChild(inputEditType);
					
					var inputRegion1 = document.createElement("input");
					inputRegion1.setAttribute("type","hidden");
					inputRegion1.setAttribute("name","region1");
					inputRegion1.setAttribute("value","경남");
					newForm.appendChild(inputRegion1);
					
					var inputRegion2 = document.createElement("input");
					inputRegion2.setAttribute("type","hidden");
					inputRegion2.setAttribute("name","region2");
					inputRegion2.setAttribute("value","통영");
					newForm.appendChild(inputRegion2);
					
					var inputType = document.createElement("input");
					inputType.setAttribute("type","hidden");
					inputType.setAttribute("name","type");
					inputType.setAttribute("value","선상");
					newForm.appendChild(inputType);
					
					var inputUsingextend = document.createElement("input");
					inputUsingextend.setAttribute("type","hidden");
					inputUsingextend.setAttribute("name","usingextend");
					inputUsingextend.setAttribute("value","1");
					newForm.appendChild(inputUsingextend);
					
					var inputFishes = document.createElement("input");
					inputFishes.setAttribute("type","hidden");
					inputFishes.setAttribute("name","fishes");
					inputFishes.setAttribute("value","갈치선상/갈치지깅");
					newForm.appendChild(inputFishes);
					
					var inputSubject = document.createElement("input");
					inputSubject.setAttribute("type","hidden");
					inputSubject.setAttribute("name","subject");
					inputSubject.setAttribute("value","111우~와,내만갈치,우~와/돌문어!!말이 필요없습니다!!오늘 예약가능");
					newForm.appendChild(inputSubject);
					
					var inputContents = document.createElement("input");
					inputContents.setAttribute("type","hidden");
					inputContents.setAttribute("name","contents");
					inputContents.setAttribute("value","내용");
					newForm.appendChild(inputContents);
					
					*/
					newForm.submit();
					
					/*
					
					document.formname2.editType = "editor";
					document.formname2.region1 = "경남";
					document.formname2.region2 = "통영";
					document.formname2.type = "선상";
					document.formname2.usingextend = "1";
					document.formname2.fishes = "갈치선상/갈치지깅";
					document.formname2.subject = "갈치 post";
					document.formname2.contents = "갈치 post cont";

					document.formname2.target="openTab";
					document.formname2.submit();
					*/
				}); 
				
				//디낚등록정보 
				_self.$dinakBtn.click(function(){
					location.href="/sc/autopost/dinak";
				});
								
				_self.$refreshBtn.click(function(){
					location.reload();
				});
				
			},
			// 코드 카테고리 목록 조회
			'getShipList' : function( page, param ) {
				
				var _self = this;
				
				_self.page = page;
				_self.param = param;
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : 'dinak_list'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('dinakList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.dinakList, 'GALR_ID', function( data, $row ) {
//				    				console.log(data.REAL_CONTENT);
				    				if(data.DINAK_STATUS != 'S'){
				    					$row.find("[class=data_status]").html(data.DINAK_STATUS);
				    				}else{
				    					$row.find("[class=data_status]").html(data.DINAK_STATUS_STR);
				    				}				    			
				    				
				    				$row.find("[class=button-area] button").each(function(){
				    					$(this).attr("pid", data.GALR_ID);
				    				});
				    		});

				    		_self.alllist = data.dinakList;
				    		_self.total_rows = data.total;
				    		
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: Math.ceil(data.total / 10)
								,onclick:function(e,page){
									_self.getShipList(page,param);
								}
			    				,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');

				    	}
				    }
				});
			},

			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[autopost_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				this.getShipList('1');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[autopost_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[autopost_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[autopost_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[autopost_main] onDestroy Method' );
			}		
	  }
});