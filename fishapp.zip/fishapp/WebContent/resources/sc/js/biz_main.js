defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberURL = $('#memberURL').val();
				this._memberSearchURL = $('#memberSearchURL').val();
				this._bizListURL = $('#bizListURL').val();
				this._bizDetailURL = $('#bizDetailURL').val();
				this._bizInsertURL = $('#bizInsertURL').val();
				this._bizUpdateURL = $('#bizUpdateURL').val();
				this._bizDeleteURL = $('#bizDeleteURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				// element
				this.$listContainer = $('#bizListContainer');
				this.$listTemplate = $('#bizListTemplate');
				this.$detailForm = $('#bizDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				// form
				this.$srchForm = $('#bizSearchForm');
				this.$insertForm = $('#bizInsertForm');
				this.$updateForm = $('#bizUpdateForm');
				// static variable
				this.selectBizId = '';
				this.selectedRowData = {};
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				// 파일 리스트 초기화
				this.addrFileList = null;
				this.shopFileList = null;
				
				//FileListRow 에서 radio, textarea 삭제
				var _flstRow = $(".fileListRow");
				_flstRow.find(".jdg-checkbox").remove();
				_flstRow.find("textarea").remove();
				
				this._mapUrl = "https://openapi.naver.com/map/getStaticMap?version=1.0&crs=EPSG:4326&center=-&level=12&w=810&h=400&maptype=default&markers=-&key=2cb6075ee7f3874aa19c564d792b8b62&uri=www.fishapp.co.kr";
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$srchForm.submit(function() {
					var $this = $(this);
					var param = {};
					var searchText = $.trim($this.find('#searchText').val());
					var checkedTerm = $(this).find(':radio[name=bizSearchTerms]:checked').attr('id');
					param = (checkedTerm == 'bizName' ? {'BIZ_NAME' : searchText} : {'BIZ_ID' : searchText} );
					// 사업체목록조회
					_self.getBizList('1', param);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertBiz();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.addrFileList.removeFile();
					_self.shopFileList.removeFileList();
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectedRowData.biz );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateBiz();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.addrFileList.removeFile();
					_self.shopFileList.removeFileList();
					_self.selectFormShow('search', _self.selectedRowData.biz);
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteBiz();
					return false;
				});
			
				// 회원 조회 팝업 오픈 (등록)
				_self.$insertForm.find('#searchMgr').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_insert_popup');
				});
				
				// 회원 조회 팝업 오픈 (수정)
				_self.$updateForm.find('#searchMgr').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_update_popup');
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
					return false;
				});
			},
			
			// 회원정보
			'getUserInfo' : function( memId ) {
				var _self = this;

				$.ajax({
					 url : '/sc/member/getLoginInfo.json'
					,type : 'POST'
					,data : {'MEM_ID' : memId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var divCaptain = $('#div_captain')
				    	
				    	if( data.info) {
				    		var info = data.info;
				    		
				    		if (info.QUIT_YN == 'Y')
				    			divCaptain.text(info.MEM_NAME + "\t ☎  " + info.TEL + "\t ***** 탈퇴한 아이디 입니다. 탈퇴한 아이디는 접속이 불가능합니다.");
				    		else				    		
				    			divCaptain.text(info.MEM_NAME + "\t ☎  " + info.TEL + "\t" + info.USER_ID + "\t" + info.PWD );
				    	}
				    }
				});
			},			
			
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				var $addrImgContainer = _self.$detailForm.find('[data-type=ADDR_IMG_ID]').parent();
				var $shopImgContainer = _self.$detailForm.find('[data-type=SHOP_IMG_ID]').parent();
				_self.selectBizId = $tr.attr('rowKey');
				$.ajax({
					 url : _self._bizDetailURL
					,type : 'POST'
					,data : {'BIZ_ID': _self.selectBizId}
					,dataType : 'json'
					,success : function(data){
						
						// 데이터 초기화
						_self.selectedRowData = {};
						
						if(data.hasOwnProperty('biz')){
							// style
							_self.selectFormShow('search', data.biz );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							$tr.addClass('jdg-selected');
							if(data.biz.ADDR_IMG_ID != undefined){
								jdg.util.createImgList( [{"IMG_ID" : data.biz.ADDR_IMG_ID, 
									                      "IMG_WIDTH" : data.biz.ADDR_IMG_WIDTH, 
									                      "IMG_HEIGHT" : data.biz.ADDR_IMG_HEIGHT}], $addrImgContainer.find('[data-type=ADDR_IMG_ID]') );
							} else {
								jdg.util.createImgList([], $addrImgContainer.find('[data-type=ADDR_IMG_ID]'));
							}
						}
						
						_self.selectedRowData = data;
					}
				});
			},
			// 사업체 목록 조회
			'getBizList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._bizListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('bizList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.bizList, 'BIZ_ID', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			var bizRegNo = $row.find('[data-key=BIZ_REG_NO]').text();
				    			if( bizRegNo.indexOf() < 0 )
				    				$row.find('[data-key=BIZ_REG_NO]').text( bizRegNo.replace(/([0-9]{3})([0-9]{2})([0-9]{5})/, "$1-$2-$3") );
				    			else 
				    				$row.find('[data-key=BIZ_REG_NO]').text( bizRegNo );
				    			$row.find('.memberLink').click( function( e ) {
				    				e.stopPropagation();
				    				_self.getUserInfo(data.MGR_MEM_ID);
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#bizListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getBizList(page,param);
								}
				    			,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.bizList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 사업체 등록
			'insertBiz' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var mapUrl = $insertForm.find('[data-key=MAP_URL]').val();
				// 지도 url을 입력하지 않아도 되지만, 입력했다면 urlX , x, lat 셋중에 하나는 반드시 있어야 유효하다. 없으면 주소가 틀렸으므로 경고메시지 출력
				if (mapUrl !='' && mapUrl.indexOf('urlX=') < 0 &&  mapUrl.indexOf('x=') < 0 && mapUrl.indexOf('lat=') < 0)
				{
					alert('위치지도URL 맞지 않습니다. 짧은 url은 입력하실수 없습니다. 입력란에 있는 설명문을 잘 읽어보십시오.');
					return false;
				}
				
				// IMG_ID
				var addrImgId = _self.addrFileList.getFile();
				//var shopImgId = _self.shopFileList.getFile();
				var shopImgId = _self.shopFileList.getFileList();

				var shopImgIdStr = "";
				
				for (var i=0; i < shopImgId.length; i++)
				{
					if (shopImgIdStr == "")
					{
						shopImgIdStr = shopImgId[i].IMG_ID;
					}
					else
					{
						shopImgIdStr += "," + shopImgId[i].IMG_ID;
					}					
				}				
				
				$insertForm.find('[data-key=BIZ_REG_NO_START]').val() + '-' + $insertForm.find('[data-key=BIZ_REG_NO_END]').val()
				// 사업체 등록
				var insertParam = {
					  'BIZ_NAME' : $insertForm.find('[data-key=BIZ_NAME]').val()
					, 'MGR_MEM_ID' : $insertForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId')
					, 'BIZ_REG_NO' : $insertForm.find('[data-key=BIZ_REG_NO_1]').val() + '-' + $insertForm.find('[data-key=BIZ_REG_NO_2]').val() + '-' + $insertForm.find('[data-key=BIZ_REG_NO_3]').val()
					, 'TEL_MOBILE' : $insertForm.find('[data-key=TEL_MOBILE_1]').val() + '-' + $insertForm.find('[data-key=TEL_MOBILE_2]').val() + '-' + $insertForm.find('[data-key=TEL_MOBILE_3]').val()
					, 'TEL_ETC' : $insertForm.find('[data-key=TEL_ETC_1]').val() + '-' + $insertForm.find('[data-key=TEL_ETC_2]').val() + '-' + $insertForm.find('[data-key=TEL_ETC_3]').val()
					, 'ADDR' : $insertForm.find('[data-key=ADDR]').val()
					, 'ADDR_DESC' : $insertForm.find('[data-key=ADDR_DESC]').val()
					, 'ADDR_IMG_ID' : (addrImgId ?  addrImgId : '')
					, 'SHOP_NM' : $insertForm.find('[data-key=SHOP_NM]').val()
					, 'SHOP_DESC' : $insertForm.find('[data-key=SHOP_DESC]').val()
					, 'SHOP_TEL' : $insertForm.find('[data-key=SHOP_TEL_1]').val() + '-' + $insertForm.find('[data-key=SHOP_TEL_2]').val() + '-' + $insertForm.find('[data-key=SHOP_TEL_3]').val()
					, 'SHOP_TEL_ETC' : $insertForm.find('[data-key=SHOP_TEL_ETC_1]').val() + '-' + $insertForm.find('[data-key=SHOP_TEL_ETC_2]').val() + '-' + $insertForm.find('[data-key=SHOP_TEL_ETC_3]').val()
					, 'SHOP_IMG_ID' : shopImgIdStr
					, 'MAP_URL' : $insertForm.find('[data-key=MAP_URL]').val()
					, 'BANK_CD' : $insertForm.find('[data-key=BANK_CD]').val()
					, 'BANK_ACCN' : $insertForm.find('[data-key=BANK_ACCN]').val()
					, 'BANK_HOLDER' : $insertForm.find('[data-key=BANK_HOLDER]').val()
					, 'VR_BANKING_YN' : $insertForm.find('[data-key=VR_BANKING_YN]').val()
					, 'PORT_CD' : $insertForm.find('[data-key=PORT_CD]').val()
					, 'CEO_NAME' : $insertForm.find('[data-key=CEO_NAME]').val()
					, 'SHOW_050_YN' : $insertForm.find('[data-key=SHOW_050_YN]').val()
				};
				
				//050번호를 입력했을때만 등록되게 함
				var tel050 = $insertForm.find('[data-key=TEL_050_2]').val().trim() + '-' + $insertForm.find('[data-key=TEL_050_3]').val().trim();
				if (tel050 != '-')
				{
					insertParam.TEL_050 = '050-' + tel050;
				}
				
				$.ajax({
					 url : _self._bizInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');

				    		if( data.result.BIZ_ID != null && 
			    				data.result.BIZ_ID != undefined && 
			    				data.result.BIZ_ID != '' ){
				    			_self.getBizList('1', {'BIZ_ID' : data.result.BIZ_ID});
				    		}
				    	}
				    }
				});
			},
			// 사업체 수정
			'updateBiz' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				var mapUrl = $updateForm.find('[data-key=MAP_URL]').val();
				// 지도 url을 입력하지 않아도 되지만, 입력했다면 urlX , x, lat 셋중에 하나는 반드시 있어야 유효하다. 없으면 주소가 틀렸으므로 경고메시지 출력
				if (mapUrl !='' && mapUrl.indexOf('urlX=') < 0 &&  mapUrl.indexOf('x=') < 0 && mapUrl.indexOf('lat=') < 0)
				{
					alert('위치지도URL 맞지 않습니다. 짧은 url은 입력하실수 없습니다. 입력란에 있는 설명문을 잘 읽어보십시오.');
					return false;
				}
				
				var updateData = _self.list.getListRowData(_self.selectBizId, 'BIZ_ID');
				// 관리자
				var mgrMemId = $updateForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId');
				var beforeMgrMemId = updateData.MGR_MEM_ID;
				// IMG_ID
				var addrImgId = _self.addrFileList.getFile();
				//var shopImgId = _self.shopFileList.getFile();
				var shopImgId = _self.shopFileList.getFileList();

				var shopImgIdStr = "";
				
				for (var i=0; i < shopImgId.length; i++)
				{
					if (shopImgIdStr == "")
					{
						shopImgIdStr = shopImgId[i].IMG_ID;
					}
					else
					{
						shopImgIdStr += "," + shopImgId[i].IMG_ID;
					}					
				}	
				
				var beforeAddrImgId = updateData.ADDR_IMG_ID ? updateData.ADDR_IMG_ID : '';
				var beforeShopImgId = updateData.SHOP_IMG_ID ? updateData.SHOP_IMG_ID : '';
				// 사업체 수정
				var updateParam = {
					  'BIZ_ID' : _self.selectBizId
					, 'BIZ_NAME' : $updateForm.find('[data-key=BIZ_NAME]').val()
					, 'MGR_MEM_ID' : mgrMemId
					, 'BEFORE_MGR_MEM_ID' : (beforeMgrMemId === mgrMemId || !beforeMgrMemId) ? "" : beforeMgrMemId
					, 'BIZ_REG_NO' : $updateForm.find('[data-key=BIZ_REG_NO_1]').val() + '-' + $updateForm.find('[data-key=BIZ_REG_NO_2]').val() + '-' + $updateForm.find('[data-key=BIZ_REG_NO_3]').val()
					, 'TEL_MOBILE' : $updateForm.find('[data-key=TEL_MOBILE_1]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_2]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_3]').val()
					, 'TEL_ETC' : $updateForm.find('[data-key=TEL_ETC_1]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_2]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_3]').val()
					, 'ADDR' : $updateForm.find('[data-key=ADDR]').val()
					, 'ADDR_DESC' : $updateForm.find('[data-key=ADDR_DESC]').val()
					, 'ADDR_IMG_ID' : (addrImgId ?  addrImgId : '')
					, 'BEFORE_ADDR_IMG_ID' : beforeAddrImgId
					, 'SHOP_NM' : $updateForm.find('[data-key=SHOP_NM]').val()
					, 'SHOP_DESC' : $updateForm.find('[data-key=SHOP_DESC]').val()
					, 'SHOP_TEL' : $updateForm.find('[data-key=SHOP_TEL_1]').val() + '-' + $updateForm.find('[data-key=SHOP_TEL_2]').val() + '-' + $updateForm.find('[data-key=SHOP_TEL_3]').val()
					, 'SHOP_TEL_ETC' : $updateForm.find('[data-key=SHOP_TEL_ETC_1]').val() + '-' + $updateForm.find('[data-key=SHOP_TEL_ETC_2]').val() + '-' + $updateForm.find('[data-key=SHOP_TEL_ETC_3]').val()
					, 'SHOP_IMG_ID' : shopImgIdStr
					, 'BEFORE_SHOP_IMG_ID' : beforeShopImgId
					, 'MAP_URL' : $updateForm.find('[data-key=MAP_URL]').val()
					, 'BANK_CD' : $updateForm.find('[data-key=BANK_CD]').val()
					, 'BANK_ACCN' : $updateForm.find('[data-key=BANK_ACCN]').val()
					, 'BANK_HOLDER' : $updateForm.find('[data-key=BANK_HOLDER]').val()
					, 'VR_BANKING_YN' : $updateForm.find('[data-key=VR_BANKING_YN]').val()
					, 'PORT_CD' : $updateForm.find('[data-key=PORT_CD]').val()
					, 'CEO_NAME' : $updateForm.find('[data-key=CEO_NAME]').val()
					, 'SHOW_050_YN' : $updateForm.find('[data-key=SHOW_050_YN]').val()
				};
				
				//050번호를 입력했을때만 변경되게 함
				var tel050 = $updateForm.find('[data-key=TEL_050_2]').val().trim() + '-' + $updateForm.find('[data-key=TEL_050_3]').val().trim();
				if (tel050 != '-')
				{
					updateParam.TEL_050 = '050-' + tel050;
				}
				else
				{
					updateParam.TEL_050 = ''; //입력을 안했으면 050번호를 지우도록 한다.
				}
				
				$.ajax({
					 url : _self._bizUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getBizList('1', {'BIZ_ID' : _self.selectBizId});
				    	}
				    }
				});
			},
			// 사업체 삭제
			'deleteBiz' : function() {
				var _self = this;
				var selectData = _self.list.getListRowData(_self.selectBizId, 'BIZ_ID');
				$.ajax({
					 url : _self._bizDeleteURL
					,type : 'POST'
					,data : {
						  'BIZ_ID' : _self.selectBizId
						, 'ADDR_IMG_ID' : selectData.ADDR_IMG_ID
						, 'SHOP_IMG_ID' : selectData.SHOP_IMG_ID
						, 'MGR_MEM_ID' : selectData.MGR_MEM_ID
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		_self.getBizList('1');
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			} ,
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					
					//출조점이미지 멀티이미지 처리
					var imgContainer = _self.$detailForm.find('[data-type="SHOP_IMG_ID"]');	
					var shops = data.SHOP_IMGS_ID ? data.SHOP_IMGS_ID.split(",") : null;		
					var imgList = [];
										
					if (shops == null)
					{
						imgContainer.empty();						
					}
					else
					{
						$.each(shops, function(index, value)
								{
									imgList.push({"IMG_ID":value, "SHOP_IMG_ID":value});						
								});						
						jdg.util.createImgList( imgList, imgContainer );
						
					}					
					_self.shopImageList = imgList;
					
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					var replaceRegNo = jdg.util.replaceRegNo( data.BIZ_REG_NO );
					$detailForm.find('[data-key=BIZ_REG_NO]').text(replaceRegNo);		
					
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					// 관리자
					$insertForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId','');
					$insertForm.find('[data-type=MGR_MEM_ID]').text('');
					$insertForm.find('[data-type=GRADE_NAME]').text('');
					$insertForm.find('[data-type=MEM_NAME]').text('');
					$insertForm.find('[data-type=EMAIL]').text('');
					$insertForm.find('[data-type=TEL]').text('');
										
					// 파일리스트 초기화
					_self.addrFileList = new component.File({
						 'id' : 'INSERT_ADDR_IMG_ID'
						,'container' : $('#INSERT_ADDR_IMG_ID')
					});
					_self.addrFileList.init();

					//출조점이미지는 멀티로
					_self.shopFileList = new component.FileList({
						 'id' : $updateForm.attr('id')
						,'container' : $('#INSERT_SHOP_IMG_ID')
					});
					_self.shopFileList.init([]);					
					
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					jdg.util.setRegNo( $updateForm.find('[data-key=BIZ_REG_NO_1]'), $updateForm.find('[data-key=BIZ_REG_NO_2]'), $updateForm.find('[data-key=BIZ_REG_NO_3]'), data.BIZ_REG_NO );
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_MOBILE_1]'), $updateForm.find('[data-key=TEL_MOBILE_2]'), $updateForm.find('[data-key=TEL_MOBILE_3]'), data.TEL_MOBILE );
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_ETC_1]'), $updateForm.find('[data-key=TEL_ETC_2]'), $updateForm.find('[data-key=TEL_ETC_3]'), data.TEL_ETC );
					jdg.util.setTelNum( $updateForm.find('[data-key=SHOP_TEL_1]'), $updateForm.find('[data-key=SHOP_TEL_2]'), $updateForm.find('[data-key=SHOP_TEL_3]'), data.SHOP_TEL );
					jdg.util.setTelNum( $updateForm.find('[data-key=SHOP_TEL_ETC_1]'), $updateForm.find('[data-key=SHOP_TEL_ETC_2]'), $updateForm.find('[data-key=SHOP_TEL_ETC_3]'), data.SHOP_TEL_ETC );
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_050_1]'), $updateForm.find('[data-key=TEL_050_2]'), $updateForm.find('[data-key=TEL_050_3]'), data.TEL_050 );
					
					$insertForm.find('[data-type=GRADE_NAME]').text('');
					$insertForm.find('[data-type=MEM_NAME]').text('');
					$insertForm.find('[data-type=EMAIL]').text('');
					$insertForm.find('[data-type=TEL]').text('');
					
					// 파일리스트 초기화
					_self.addrFileList = new component.File({
						 'id' : 'UPDATE_ADDR_IMG_ID'
						,'container' : $('#UPDATE_ADDR_IMG_ID')
					});
					_self.addrFileList.init( data.ADDR_IMG_ID ? data : null );
					
					
					_self.shopFileList = new component.FileList({
						 'id' : 'UPDATE_SHOP_IMG_ID'
						,'container' : $('#UPDATE_SHOP_IMG_ID')
					});
					_self.shopFileList.init(_self.shopImageList );
					
					_self.$updateForm.find('[data-type=MGR_MEM_ID]').text(data.MGR_MEM_ID);
					_self.$updateForm.find('[data-type=GRADE_NAME]').parent().hide();
					_self.$updateForm.find('[data-type=MEM_NAME]').text(data.MGR_MEM_NAME);
					_self.$updateForm.find('[data-type=EMAIL]').parent().hide();
					_self.$updateForm.find('[data-type=TEL]').parent().hide();
					
					// 관리자
					$updateForm.find('[data-type=MGR_MEM_ID]').attr( 'mgrMemId', data.MGR_MEM_ID ? data.MGR_MEM_ID : '' );
					
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[biz_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 사업체목록조회
				this.getBizList('1' , p_param );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[biz_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				// 관리자 팝업 close
				if( 'member_insert_popup' === p_param.id ) {
					var $mgrMemId = _self.$insertForm.find('[data-type=MGR_MEM_ID]');
					var $gradeName = _self.$insertForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$insertForm.find('[data-type=MEM_NAME]');
					var $email = _self.$insertForm.find('[data-type=EMAIL]');
					var $tel = _self.$insertForm.find('[data-type=TEL]');
					if( data ) {
						$mgrMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME );
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL );
						$tel.text( data.TEL );
						$mgrMemId.attr('mgrMemId', data.MEM_ID );
					} 
				} else if( 'member_update_popup' === p_param.id ) {
					var $mgrMemId = _self.$updateForm.find('[data-type=MGR_MEM_ID]');
					var $gradeName = _self.$updateForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$updateForm.find('[data-type=MEM_NAME]');
					var $email = _self.$updateForm.find('[data-type=EMAIL]');
					var $tel = _self.$updateForm.find('[data-type=TEL]');
					if( data ) {
						$mgrMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME ).parent().show();
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL ).parent().show();
						$tel.text( data.TEL ).parent().show();
						$mgrMemId.attr('mgrMemId', data.MEM_ID );
					}
				}
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[biz_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[biz_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[biz_main] onDestroy Method' );
			}		
	  }
});
