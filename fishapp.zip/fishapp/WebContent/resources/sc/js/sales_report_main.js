defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipId = $('#shipId').val();
				this._statListURL = $('#statListURL').val();
				this._excelExportURL = $('#excelExportURL').val();
				// element
				
				this.$selectArea = $('#selectArea');
				this.$selectPort = $('#selectPort');
				this.$selectShip = $('#selectShip');
				this.$selectSundan = $('#selectSundan');
				this.$rdoSiteCd = $(':radio[name="rdoSiteCd"]');
				
				this.$startDate = $('#startDate');
				this.$endDate = $('#endDate');
				this.$executeBtn = $('#executeBtn');
				this.$executeExcelBtn = $('#executeExcelBtn');
				this.$listContainer = $('#statListContainer');
				this.$listTemplate = $('#statListTemplate');
				this.$searchType = $(':radio[name="searchRdo"]');
				this.$radioCustomDate = $("#radioCustomDate");
				this.$startDate = $('#startDate');
				this.$endDate = $('#endDate');
				
				this.$thisWeek = $('#thisWeek');
				this.$lastWeek = $('#lastWeek');
				this.$thisMonth = $('#thisMonth');
				this.$lastMonth = $('#lastMonth');
				this.$lastSixMonth = $('#lastSixMonth');
				this.$thisYear = $('#thisYear');
				this.$lastYear = $('#lastYear');
				
				
				// form
				this.$srchForm = $('#codeSearchForm');
				
				//static variable
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});

				this.list2 = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.jdg-tr-total')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
		
				
				//header fix
				$(window).scroll(function(){
			        if ($(this).scrollTop() > 100) {
			        	$('.jdg-ui-table-thead').hide();
			        	$('.jdg-ui-table-thead-fix').show();
			        } else {
			        	$('.jdg-ui-table-thead-fix').hide();
			        	$('.jdg-ui-table-thead').show();
			        };
			    });
				
			},
			'setEvent'		: function() {
				var _self = this;

				
				//datepicker set
				_self.$startDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				_self.$endDate.datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd',
				    showTrigger: '<a href="#" class="jdg-btn-calendar"title="달력"></a>'});
				
				
				// 검색 라디오버튼 변경시
				_self.$searchType.change(function(){
					
					var rdo = $(':radio[name="searchRdo"]:checked').attr('data-key');
					
					if (rdo == "custom")
					{
						$("#spanPeriod").show();
					}
					else
					{
						$("#spanPeriod").hide();
					}
					
					
				});
				
				
				// 해역콤보박스 변경시				
				_self.$selectArea.change(function(){
					
					var pvalue = $(':radio[name="rdoSiteCd"]:checked').val();					
					
					var code = $("#selectArea option:selected").val();
					$('#selectPort option[value!=""]').remove();
					$('#selectSundan option[value!=""]').remove();
					
				    var options = $('#selectPort_options option[data-pcode=' + code +']').clone();
				    $('#selectPort').append(options);					

				});			
				
				// 항구콤보박스 변경시				
				_self.$selectPort.change(function(){
					
					var pvalue = $(':radio[name="rdoSiteCd"]:checked').val();	

					var code = $("#selectPort option:selected").val();
					$('#selectShip option[value!=""]').remove();
					$('#selectSundan option[value!=""]').remove();
				
					if (pvalue == "S")
					{
					    var options = $('#selectSundan_options option[data-pcode=' + code +']').clone();
					    $('#selectSundan').append(options);							
		
					}
					else
					{
					    var options = $('#selectShip_options option[data-pcode=' + code +']').clone();
					    $('#selectShip').append(options);
					}
				
				});	

				
				_self.$rdoSiteCd.bind( "change", function(event, ui) {
					
					var pvalue = event.currentTarget.value;
					
					if (pvalue == "S")
					{
						_self.$selectShip.hide();
						_self.$selectSundan.show();
						
						_self.$selectPort.trigger("change");
					}
					else
					{
						if (_self.$selectShip.is(':hidden'))
							{
								_self.$selectShip.show();
								_self.$selectSundan.hide();	
	
								_self.$selectPort.trigger("change");
							}
					}

				});	
				
				
				
				_self.$executeBtn.click(function() {
					
					var param = {};
				
					_self.getStatList(1, param);
					
					return false;
				});
				
				_self.$executeExcelBtn.click(function(){
					
					_self.excelExport();					
					return false;
					
				});
				
			},
			
			'excelExport' : function(){	
				
				var param = {};	
				
				var _self = this;
				
				var now = new Date();
				var nowDayOfWeek = now.getDay();
				var nowMonth = now.getMonth(); 
				var nowDay = now.getDate(); 
				var nowYear = now.getFullYear(); 
				
				var rdo = $(':radio[name="searchRdo"]:checked').attr('data-key');
				
				if( rdo == 'day'){
					
				    param.FROM_DATE = _self.converDateString(now);
				    param.TO_DATE = _self.converDateString(now);
					
				}else if (rdo== 'week'){
					
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));	
				    
				    param.FROM_DATE = _self.converDateString(weekStartDate);
				    param.TO_DATE = _self.converDateString(weekEndDate);					
					
				}else if (rdo == 'month'){

					var monthStartDate = new Date(nowYear, nowMonth, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);	
				    
				    param.FROM_DATE = _self.converDateString(monthStartDate);
				    param.TO_DATE = _self.converDateString(monthEndDate);		
					
				}else{
					param.FROM_DATE = $("#startDate").val();
					param.TO_DATE = $("#endDate").val();
					
					if (param.FROM_DATE == "" || param.TO_DATE == "" )
					{
						alert('기간을 입력해주세요.');
						return false;
					}
					
					
				}				
							
				param.SITE_CD =  $(":input:radio[name=rdoSiteCd]:checked").val();
				param.AREA_CD = $("#selectArea").val();
				param.PORT_CD = $("#selectPort").val();
				param.SHIP_ID = $("#selectShip").val();
				param.SHIP_ID = $("#selectSundan").val();
				
				if (param.AREA_CD != "")
					param.AREA_NAME = $("#selectArea option:selected").text();
				
				if (param.PORT_CD != "")
					param.PORT_NAME = $("#selectPort option:selected").text();
				
				if (param.SHIP_ID != "")
					param.SHIP_NAME = $("#selectShip option:selected").text();
				
				if (param.SHIP_ID != "")
					param.SHIP_NAME = $("#selectSundan option:selected").text();
				
				
				$.download(_self._excelExportURL, param, 'POST');
			},
			
			
			'getStatList' : function(page, param){

				var _self = this;
				
				var now = new Date();
				var nowDayOfWeek = now.getDay();
				var nowMonth = now.getMonth(); 
				var nowDay = now.getDate(); 
				var nowYear = now.getFullYear(); 
				
				var rdo = $(':radio[name="searchRdo"]:checked').attr('data-key');
				
				if( rdo == 'day'){
					
				    param.FROM_DATE = _self.converDateString(now);
				    param.TO_DATE = _self.converDateString(now);
					
				}else if (rdo== 'week'){
					
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));	
				    
				    param.FROM_DATE = _self.converDateString(weekStartDate);
				    param.TO_DATE = _self.converDateString(weekEndDate);					
					
				}else if (rdo == 'month'){

					var monthStartDate = new Date(nowYear, nowMonth, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);	
				    
				    param.FROM_DATE = _self.converDateString(monthStartDate);
				    param.TO_DATE = _self.converDateString(monthEndDate);		
					
				}else{
					param.FROM_DATE = $("#startDate").val();
					param.TO_DATE = $("#endDate").val();
					
					if (param.FROM_DATE == "" || param.TO_DATE == "" )
					{
						alert('기간을 입력해주세요.');
						return false;
					}
					
					
				}				
							
				param.PAGE = page;	
				param.SITE_CD =  $(":input:radio[name=rdoSiteCd]:checked").val();
				param.AREA_CD = $("#selectArea").val();
				param.PORT_CD = $("#selectPort").val();
				param.SHIP_ID = $("#selectShip").val();
				param.SHIP_ID = $("#selectSundan").val();
				
				if (param.AREA_CD != "")
					param.AREA_NAME = $("#selectArea option:selected").text();
				
				if (param.PORT_CD != "")
					param.PORT_NAME = $("#selectPort option:selected").text();
				
				if (param.SHIP_ID != "")
					param.SHIP_NAME = $("#selectShip option:selected").text();
				
				if (param.SHIP_ID != "")
					param.SHIP_NAME = $("#selectSundan option:selected").text();
				
				var title;
				
				if (param.SITE_CD == "P")
					{
						title = "(피쉬앱 포털 매출)";
					}
				else if (param.SITE_CD == "L")
					{
						title = "(로컬 선박 매출)";
					}
				else
					{
						title = "(출조점 매출)";
					}

				if (param.SHIP_NAME != null)
				{
					title += param.SHIP_NAME;
				}
				if (param.SHIP_NAME != null)
				{
					title += param.SHIP_NAME;
				}
				else if (param.PORT_NAME != null)
				{
					title += param.PORT_NAME;
				}
				else if (param.AREA_NAME != null)
				{
					title += param.AREA_NAME;
				}
				else
				{
					title += "전체";
				}
				
				title += "  " + param.FROM_DATE + " ~ " + param.TO_DATE;
					
				$("#spanlabel").text(title);
				
				$.ajax({
					 url : _self._statListURL
					,type : 'POST'
					,data : param
				    ,success : function( data ) {
				    	
				    	var total;
				    	
				    	//리스트
				    	_self.list.createList( data.statList, 'ROW_NUMBER' , function( data, $row ) {				    		
				    		
				    		var rsvid = data.RSV_ID;

				    		if(rsvid == '소계')
				    		{
				    			$row.find('[data-key=ROW_NUMBER]').text(rsvid);
				    			$row.find('[data-key=RSV_ID]').text("");				    			
				    			$row.addClass('jdg-tr-total');				    			
				    		}	
				    		else if(rsvid == '총계')
			    			{
				    			$row.find('[data-key=ROW_NUMBER]').text(rsvid);
				    			$row.find('[data-key=RSV_ID]').text("");				    			
				    			$row.addClass('jdg-tr-grandtotal');	
				    			total = data.TOTAL;
			    			}

				    		//금액 comma
				    		$row.find('[data-key=MAN_CNT]').text(_self.stringFilter($row.find('[data-key=MAN_CNT]').text(), 'money'));
				    		$row.find('[data-key=TOT_COST]').text(_self.stringFilter($row.find('[data-key=TOT_COST]').text(), 'money'));
				    		

			    		});
				    	

				    	if (total && total > 0)
			    		{
				    		$("#executeExcelBtn").show();
				    		$('#salesListPaging').show();
			    		}
				    	else
				    	{
				    		$("#executeExcelBtn").hide();
				    		$('#salesListPaging').hide();
				    	}
				    	
			    		// 페이징 초기화
			    		$('#salesListPaging').paging({
							 current: page
							,max: (Math.ceil(total / 10))
							,onclick:function(e,page){
								_self.getStatList(page,param);
							}
		    				,prev : '이전'
			    			,next : '다음'
						});				    	
				    	
				    	
				    }
				});
			},

			
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length == 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(-?[0-9]+)([0-9]{3})/;
					while(pattern.test(str)) {
						str = str.replace(pattern,"$1,$2");
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},

			
			//버튼 클릭시 날짜 셋팅
			'clickTypeButton' : function( $button ){
				var _self = this;
				var now = new Date();
				var nowDayOfWeek = now.getDay();
				var nowMonth = now.getMonth(); 
				var nowDay = now.getDate(); 
				var nowYear = now.getYear(); 
				nowYear += (nowYear < 2000) ? 1900 : 0; 
				 
				if($button == _self.$thisWeek){
					//이번주
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));
					_self.$startDate.val(_self.converDateString(weekStartDate));
					_self.$endDate.val(_self.converDateString(weekEndDate));
				}
				if($button == _self.$lastWeek){
					//지난주
					nowDay += -7;
					var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek +1); 
				    var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));
					_self.$startDate.val(_self.converDateString(weekStartDate));
					_self.$endDate.val(_self.converDateString(weekEndDate));
				}
				if($button == _self.$thisMonth){
					//이번달
					var monthStartDate = new Date(nowYear, nowMonth, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$lastMonth){
					//지난달
					var monthStartDate = new Date(nowYear, nowMonth-1, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$lastSixMonth){
					//최근6개월
					var monthStartDate = new Date(nowYear, nowMonth-5, 1); 
				    var monthEndDate = new Date(nowYear, nowMonth+1, 0);
					_self.$startDate.val(_self.converDateString(monthStartDate));
					_self.$endDate.val(_self.converDateString(monthEndDate));
				}
				if($button == _self.$thisYear){
					//이번해
					var yearStartDate = new Date(nowYear, 0, 1); 
				    var yearEndDate = new Date(nowYear, 12, 0);
					_self.$startDate.val(_self.converDateString(yearStartDate));
					_self.$endDate.val(_self.converDateString(yearEndDate));
				}
				if($button == _self.$lastYear){
					//지난해
					var yearStartDate = new Date(nowYear-1, 0, 1); 
				    var yearEndDate = new Date(nowYear-1, 12, 0);
					_self.$startDate.val(_self.converDateString(yearStartDate));
					_self.$endDate.val(_self.converDateString(yearEndDate));
				}
			},
			
			//date를 String으로 변경.
			'converDateString' : function(dt){
				function addZero(i){
					var rtn = i + 100;
					return rtn.toString().substring(1,3);
				}
				return dt.getFullYear() + "-" + addZero(eval(dt.getMonth()+1)) + "-" + addZero(dt.getDate());
			},
			
			//쿠키 set
			'setSearchCookie' : function(){
				var _self = this;
				$.cookie('stat.startDate', _self.$startDate.val());
				$.cookie('stat.endDate', _self.$endDate.val());
				$.cookie('stat.type', $(':radio[name="searchRdo"]:checked').attr('data-key'));
				
			},
			
			//쿠키 get
			'getSerchCookie' : function(cookieName){
				return $.cookie(cookieName);
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
