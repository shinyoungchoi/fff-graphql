defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleURL = $('#scheduleURL').val();
				this._reserveManURL = $('#reserveManURL').val();
				this._reserveListURL = $('#reserveListURL').val();
				this._reserveDetailURL = $('#reserveDetailURL').val();
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._reserveUpdateURL = $('#reserveUpdateURL').val();
				this._reserveDeleteURL = $('#reserveDeleteURL').val();
				this._reserveManCntURL = $('#reserveManCntURL').val();
				this._reserveUpdateStatusURL = $('#reserveUpdateStatusURL').val();
				// element
				this.$srhShipName = $('#searchShipName');
				this.$srhScheduleSel = $('#searchScheduleSel');
				this.$listContainer = $('#reserveListContainer');
				this.$listTemplate = $('#reserveListTemplate');
				this.$detailForm = $('#reserveDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$updateStatusBtn300 = $('#updateStatusBtn300');
				this.$updateStatusBtn310 = $('#updateStatusBtn310');		
				this.$updateStatusBtn320 = $('#updateStatusBtn320');
				this.$updateStatusBtn340 = $('#updateStatusBtn340');
				this.$updateStatusBtn410 = $('#updateStatusBtn410');
				this.$updateStatusBtn420 = $('#updateStatusBtn420');
				this.$updateStatusBtn430 = $('#updateStatusBtn430');
				// form
				this.$srchForm = $('#reserveSearchForm');
				this.$insertForm = $('#reserveInsertForm');
				this.$updateForm = $('#reserveUpdateForm');
				
				//메시지전송
				this.$sendMsgBtn = $("#sendMsgBtn");
				this.$schdDate = $('#schdDate');
				this._currentPage = 1;
				
				// static variable
				this.selectReserveId = '';
				this.selectDetailData = {};
				this.selectPage = '';
				this.searchParam = {};
				
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;	
				
				//메시지 전송을 위한 팝업 열기
				_self.$sendMsgBtn.on("click", function(){
					showPop('.notice_pop_wrap', '.popup_common_con');
				});
				
				$('#schdDate,#schdDate2').datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd'
				    ,showTrigger: '<a href="#" class="jdg-btn-calendar" title="달력"></a>'
					,onSelect: function(dateText)	 {_self.searchReserveList(); }				    	
				});
				
				$('#siteCd,#sortBy,#chkMethod,#chkTest,#statusCd').change(function()	{_self.searchReserveList();});
				
				$('#rsvId,#shipName,#rsvName,#rsvTel').keypress(function(e) {if (e.which == 13) _self.searchReserveList();});
				
				// 독선예약 체크박스 선택
				_self.$insertForm.find('[data-type=WHOLE_YN]').click( function(e) {
					var $this = $( this );
					var $manCnt = _self.$insertForm.find('[data-type=MAN_CNT]');
					var $totCost = _self.$insertForm.find('[data-key=TOT_COST]');
					if( $this.is(':checked') ) {
						// 비활성화
						$manCnt.find('option:last').attr('selected', true);
						$manCnt.attr('disabled', true);
						$totCost.addClass('jdg-disabled');
						$totCost.attr('readonly', true);
						// 독선요금 셋팅
						var feeWhole = _self.$insertForm.find('[data-type=SCHD_ID] option:selected').attr('feeWhole');
						if( '' != feeWhole ) $totCost.val( feeWhole );
						else _self.totalCost();
					} else {
						// 활성화
						$manCnt.attr('disabled', false);
						$totCost.removeClass('jdg-disabled');
						$totCost.attr('readonly', false);
						_self.totalCost();
					}
				});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 예약목록조회
					_self.searchReserveList();
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertReserve();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectDetailData );
				});
				
				// 수정(수정화면에서 저장버튼 눌렀을때(
				_self.$updateForm.submit( function() {
					_self.updateReserve(); // 예약상태는 바뀌지 않고, 나머지 입력내용만 반영
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 예약상태수정
				// 2017.5.18. 원래는 예약상태만 수정되었는데 예약상태 + 다른 입력값들까지 다 수정되도록 변경함
				_self.$updateStatusBtn300.click( function() {
					if( confirm('예약확정(입금완료) 상태로 수정하시겠습니까?') ){
						_self.updateReserve('104_300'); //예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn320.click( function() {
					if( confirm('부분입금 상태로 수정하시겠습니까?') ){
						_self.updateReserve('104_320');//예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn340.click( function() {
					if( confirm('예약확정(미입금) 상태로 수정하시겠습니까?') ){
						_self.updateReserve('104_340');//예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn410.click( function() {
					if( confirm('예약취소 하시겠습니까?') ){
						_self.updateReserve('104_410');//예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn420.click( function() {
					if( confirm('예약취소 하시겠습니까?') ){
						_self.updateReserve('104_420');//예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn430.click( function() {
					if( confirm('환불완료 상태로 수정하시겠습니까?') ){
						_self.updateReserve('104_430');//예약내용 및 예약상태 모두 수정
					}
				});
				_self.$updateStatusBtn310.click( function() {
					if( confirm('미입금 상태로 수정하시겠습니까?') ){
						_self.updateReserve('104_310');//예약내용 및 예약상태 모두 수정
					}
				});				
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}					
					_self.deleteReserve();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			
			//
			'searchReserveList': function() {
				
				var _self = this;
				var param;
				
				var rsvId = $('#rsvId').val().trim();
				var rsvTel = $('#rsvTel').val().trim();
				
				if (rsvTel != "")
				{
					var len = rsvTel.length;
					
					if (len == 4)
					{
						if (isNaN(rsvTel))
							{alert('전화번호 4자리중에 숫자가 아닌 글자가 있습니다!'); return;}
			
						param = {RSV_TEL: '%' + rsvTel};
					}
					else if (len >= 7 && len <= 13)
					{
						var telnum = rsvTel.replace('-','');
						
						if (isNaN(telnum)) 
							{alert('전화번호에 숫자나 -가 아닌 문자가 있습니다!'); return;}
						
						var len2 = telnum.length;
						
						if (len2 < 7 || len2 > 11) 
							{alert('전화번호 자리수가 유효하지 않습니다.'); return;}
						
						var telnum2;
						
						if (len2 == 7 || len2 == 8)
							{
								telnum2 = telnum.substr(0,len2 - 4) + '-' + telnum.substr(len2 - 4,4);
							}
						else if (telnum.substr(0,2) == '02')
						    {
								telnum2 = '02-' + telnum.substr(2, len2 - 6) + '-' + telnum.substr(len2 - 4,4);
						    }
						else if (len2 == 10 || len2 == 11)
						    {
								telnum2 = telnum.substr(0,3) + '-' + telnum.substr(3,len2 - 7) + '-' + telnum.substr(len2 - 4,4);
						    }
						else 
							{
								alert('전화번호 자리수가 유효하지 않습니다!'); return;
							}
						
						if (len2 >= 10)
						{
							param = {RSV_TEL: telnum, RSV_TEL2: telnum2};
						}
						else
						{
							param = {RSV_TEL: '%' + telnum, RSV_TEL2: '%' + telnum2};
						}
						
					}
					else
					{
						alert('전화번호 자리수가 유효하지 않습니다! (최소 4자리, 최대 11자리)'); return;
					}
					
					
				}				
				else if (rsvId != "")
				{
					param = {RSV_ID:rsvId};
				}
				else
				{
					param = 
						{
						SHIP_NAME : $('#shipName').val().trim()	
						,RSV_NAME : $('#rsvName').val().trim()
						, SITE_CD : $('#siteCd').val()
						};
					
					if ($('#chkTest').is(':checked'))
					{
						param.TEST_YN = "N";
					}
					
					if ($('#chkMethod').is(':checked'))
					{
						param.PAY_METHOD = "BC"; //가상계좌(B) + 신용카드(C)
					}					
				
					var schdDate1 = $('#schdDate').val().replace(/-/g,'').trim();
					var schdDate2 = $('#schdDate2').val().replace(/-/g,'').trim();
					
					if (schdDate1 != '')
					{
						param.SCHD_DATE = schdDate1;
					}
					
					if (schdDate2 != '')
					{
						param.SCHD_DATE2 = schdDate2;
					}
					
					var statusCd = $('#statusCd').val();
					
					if (statusCd != '')
					{
						param.STATUS_CD = statusCd;
					}					
				}
				
				_self.searchParam = param;				
				_self.getReserveList('1',param);
				
			},
			
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectReserveId = $tr.attr('rowKey');
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				// 예약 상세 조회
				$.ajax({
					 url : _self._reserveDetailURL
					,type : 'POST'
					,data : {'RSV_ID' : _self.selectReserveId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		console.log(detail);
				    		if (detail.VR_PAID_AT)
				    		{
				    			var obj = detail.VR_PAID_AT;				    			
				    			detail.VR_PAID_AT = (obj.year + 1900) + "-" + format00(obj.month + 1) + "-" + format00(obj.date) + " " + format00(obj.hours) + ":" + format00(obj.minutes);
				    		}
				    		
				    		if (detail.PAY_METHOD && detail.PAY_METHOD == 'C')
				    		{
				    			detail.BNK_TYPE = '신용카드 결제';
				    		}
				    		
				    		_self.selectDetailData = detail;
							_self.selectFormShow('search', detail);
							
				    	}
				    }
				});
			},
			// 예약 인원 셋팅
			'reserveManSetting' : function( $schdOption ) {
				var _self = this;
				var $wholeYn = _self.$insertForm.find('[data-type=WHOLE_YN]');
				$wholeYn.attr('checked', false);
				// 출조 선택
				if( '' !== $schdOption.val() ) {
					// 현재 스케줄의 예약인원 체크
					$.ajax({
						 url : _self._reserveManCntURL
						,type : 'POST'
						,data : {'SCHD_ID' : $schdOption.val()}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('count') ){
					    		if( data.count == 0 )  $wholeYn.attr('disabled', false);
					    		else $wholeYn.attr('disabled', true);
					    	}
					    }
					});
					// 예약인원 설정
					_self.createOptionSelect( _self.$insertForm.find('[data-type=MAN_CNT]'), $schdOption.attr('psgrCnt') );
				} else {
					$wholeYn.attr('disabled', true);
					// 예약인원 설정
					_self.createOptionSelect( _self.$insertForm.find('[data-type=MAN_CNT]'), $schdOption.attr('psgrCnt'), true );
				}
			},
			// 예약가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt, _flag ) {
				var _self = this;
				$sel.empty();
				if( _flag ) $sel.append( $('<option value="">선택해주세요</option>') );
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
				// 예약금액 변경
				_self.totalCost();
			},
			// 예약인원 * 1인당 금액을 계산하여 예약금액을 자동셋팅
			'totalCost' : function() {
				var $form = this.$insertForm;
				var man = $form.find('[data-type=MAN_CNT] option:selected').val();
				var money = $form.find('[data-type=SCHD_ID] option:selected').attr('feeMan');
				var sum = man * money;
				if( !sum ) sum = 0;
				$form.find('[data-key=TOT_COST]').val( sum );
			},
			// 예약 목록 조회
			'getReserveList' : function( page, param, showDetailId ) {
				var _self = this;
				
				var sortBy = $('#sortBy').val();
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'SORT_BY' : sortBy
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._reserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('reserveList') ) {
				    		var reserveList = data.reserveList;
				    		$.each( reserveList, function(idx, data) {
				    			data.SCHD_DATE = jdg.util.replaceDate(data.SCHD_DATE);
				    			data.PAY_METHOD_NAME = (data.PAY_METHOD == 'B')? '가상계좌' : (data.PAY_METHOD == 'C')? '카드' : '-';
				    		});
				    		// 리스트 초기화
				    		_self.list.createList( reserveList, 'RSV_ID', function( data, $row ) {
				    		
				    			$row.find('.scheduleLink').click( function( e ) {
				    				// 출조관리로 이동
				    				Bplat.view.loadPage( "/sc/schedule/main", {
				    					'SCHD_ID' : data.SCHD_ID
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#reserveListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getReserveList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.reserveList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 예약등록
			'insertReserve' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var $schdIdOption = $insertForm.find('[data-type=SCHD_ID] option:selected');
				// 과거 출조일에 대한 체크
				var today = jdg.util.today().replaceAll('-','');
				var schdData = $schdIdOption.attr('schdDate').replaceAll('-','');
				if( today >= schdData ) {
					if(!confirm('과거 또는 오늘에 대한 예약 시도입니다. 계속하시겠습니까?')) {
						return false;
					}
				}
				var insertParam = {
					  'SCHD_ID' : $schdIdOption.val()
					, 'MEM_ID' : $insertForm.find('[data-type=MEM_ID]').text()
					, 'RSV_NAME' : $insertForm.find('[data-type=RSV_NAME]').val()
					, 'RSV_TEL' : $insertForm.find('[data-type=RSV_TEL]').val()
					, 'RSV_EMAIL' : $insertForm.find('[data-type=RSV_EMAIL]').val()
					, 'MAN_CNT' : $insertForm.find('[data-type=MAN_CNT] option:selected').val()
					, 'TOT_COST' : $insertForm.find('[data-key=TOT_COST]').val()
					, 'DEPOSIT_NAME' : $insertForm.find('[data-key=DEPOSIT_NAME]').val()
					, 'MEMO' : $insertForm.find('[data-key=MEMO]').val()
					, 'PSGR_CNT' : $schdIdOption.attr('psgrCnt')
					, 'WHOLE_YN' : 'N'
				};
				// 독선예약 여부 체크 
				if( $insertForm.find('[data-type=WHOLE_YN]').is(':checked') ) {
					insertParam.WHOLE_YN = 'Y';
				}
				$.ajax({
					 url : _self._reserveInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    	alert(data.error.userMessage);
				    }
				});
			},
			// 예약수정
			'updateReserve' : function(statusCd) {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateParam = {
					  'RSV_ID' : _self.selectReserveId
					, 'RSV_NAME' : $updateForm.find('[data-key=RSV_NAME]').val().trim()
					, 'RSV_TEL' : $updateForm.find('[data-key=RSV_TEL]').val().trim()
					, 'RSV_EMAIL' : $updateForm.find('[data-key=RSV_EMAIL]').val().trim()
					, 'DEPOSIT_NAME' : $updateForm.find('[data-key=DEPOSIT_NAME]').val()
					, 'MAN_CNT' : $updateForm.find('[data-type=MAN_CNT] option:selected').val()
					, 'MEMO' : $updateForm.find('[data-key=MEMO]').val()
					, 'DISP_CD' : $updateForm.find('[data-key=DISP_CD]').val()
					, 'SEAT_TXT' : $updateForm.find('[data-key=SEAT_TXT]').val().trim()
				};
				
				if (statusCd) //상태코드값이 있으면 상태코드 필드 추가
				{
					updateParam.STATUS_CD = statusCd;
				}				
				
				$.ajax({
					 url : _self._reserveUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getReserveList( _self.selectPage
				    							, _self.searchParam
				    							, _self.selectReserveId);
				    	}
				    }
				});
			},
//			//예약상태 수정
//			'updateReserveStatus' : function( statusCd ) {
//				var _self = this;
//				var updateParam = {
//					  'RSV_ID' : _self.selectReserveId
//					, 'STATUS_CD' : statusCd
//				};
//				$.ajax({
//					 url : _self._reserveUpdateStatusURL
//					,type : 'POST'
//					,data : updateParam
//					,dataType : 'json'
//					,success : function( data ){
//						if( data.hasOwnProperty('success') ){
//							if( data.success === false ){
//								alert( data.error.userMessage );
//								location.reload();
//								return false;
//							}
//						}
//						if( data.hasOwnProperty('result') && data.result > 0 ){
//							alert( '수정 되었습니다.' );
//				    		_self.getReserveList( _self.selectPage
//	    							, _self.searchParam
//	    							, _self.selectReserveId);
//							return false;
//						}
//						alert('수정에 실패하였습니다.');
//					}
//				});
//			},
			// 예약 삭제
			'deleteReserve' : function() {
				var _self = this;
				$.ajax({
					 url : _self._reserveDeleteURL
					,type : 'POST'
					,data : {
						 'RSV_ID' : _self.selectReserveId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		if( data.result > 0 ) {
					    		alert('삭제 되었습니다');
					    		location.reload();
				    		} else {
				    			alert('해당 예약은 삭제할 수 없습니다.');
				    		}
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 승선명부관리로 이동
					$detailForm.find('.reserveManLink').click( function() {
						Bplat.view.openPopup({
							 'url' : _self._reserveManURL + '?RSV_ID=' + _self.selectReserveId
							,'width' : 800
							,'height' : 600
						}, 'reserve_man_popup');
	    			});
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=SCHD_ID] option:eq(0)').attr('selected',true);
					_self.createOptionSelect( $insertForm.find('[data-type=MAN_CNT]'), $insertForm.find('[data-type=SCHD_ID] option:eq(0)').attr('psgrCnt'), true );
					$insertForm.show(); 
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.find('[data-type=SCHD_ID]').val( data.SCHD_ID );
					$updateForm.find('[data-type=STATUS_NAME]').val( data.STATUS_NAME );
					_self.createOptionSelect( $updateForm.find('[data-type=MAN_CNT]'), data.MAN_CNT, true );
					
					// 일단 모든 상태버튼 보여주고 예약상태가 자기랑 같은거만 감춤
					$('a.jdg-btn-check').show();
					
					// 예약상태별 버튼 노출.
					if( data.STATUS_CD == '104_300' ){
						_self.$updateStatusBtn300.hide();
					}else if( data.STATUS_CD == '104_310' ){					
						_self.$updateStatusBtn310.hide();
					}else if( data.STATUS_CD == '104_310' ){					
						_self.$updateStatusBtn320.hide();
					}else if( data.STATUS_CD == '104_320' ){
						_self.$updateStatusBtn340.hide();
					}else if( data.STATUS_CD == '104_340' ){					
						_self.$updateStatusBtn410.hide();					
					}else if( data.STATUS_CD == '104_410' ){					
						_self.$updateStatusBtn420.hide();
					}else if( data.STATUS_CD == '104_420' ){					
						_self.$updateStatusBtn430.hide();
					}else if( data.STATUS_CD == '104_430' ){
						_self.$updateStatusBtn310.hide();
					}
					
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},

			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[reserve_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				var today = jdg.util.today();
				
				$('#schdDate').val(today);
				$('#schdDate2').val(jdg.util.addDay(today, 30));
				
				this.searchReserveList();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[reserve_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[reserve_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[reserve_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[reserve_main] onDestroy Method' );
			}		
	  }
});