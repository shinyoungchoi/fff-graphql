defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = "/sc/point/list";
				this._memberDetailURL = "/sc/point/mem_detail";
				this._historyListURL = "/sc/point/history";
				this._memberInsertURL = $('#memberInsertURL').val();
				this._memberUpdateURL = $('#memberUpdateURL').val();
				this._memberDeleteURL = $('#memberDeleteURL').val();
				this._memberNickCheckURL = $('#memberNickCheckURL').val();
				this._shipSearchURL = $('#shipSearchURL').val();
				this._shipSundanSearchURL = $('#shipSundanSearchURL').val();
				this._shipSundanSearchURL = $('#shipSundanSearchURL').val();
				this._page = 1;
				
				// element
				this.$listContainer = $('#memberListContainer');
				this.$listTemplate = $('#memberListTemplate');
				this.$detailForm = $('#memberDetailForm');
				this.$historyListContainer = $("#historyListContainer");
				this.$historyListTemplate = $("#historyListTemplate");
				
				this.$showPointBtn = $('#showPointBtn');
				this.$addPointBtn = $('#addPointBtn');
				
				this.$regChkBtn = $('#regNickCheckBtn');
				this.$mfyChkBtn = $('#mfyNickCheckBtn');
				this.$mGradeSel = $('#memberGradeSel');
				this.$mSrhKeyRadio = $('[name=memberSearchTerms]');
				this.$mSrhVal = $('#memberSearchVal');
				
				this.$addShipBtn = $('#addShipMemberBtn');
				this.$delShipBtn = $('#delShipMemberBtn');
				
				this.$addShipSundanBtn = $('#addSoMemberBtn');
				this.$delShipSundanBtn = $('#delSoMemberBtn');
				
				this.$selectShip = $('#selectShip');
				
				// form
				this.$srchForm = $('#memberSearchForm');
				this.$perPageSel = $('#perPage'); //포인트 내역 검색 박스
				
				// static variable
				this.ShipMemberList = [];
				this.selectMemberId = '';
				this.selectDetailData = {};
				this.updateShipMemberList = [];
				this.selectPage = ''; // 회원 목록 페이지
				this.selectSubPage = ''; //포인트 내역 목록 페이징
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.history_list = new component.List({
					 'container' : this.$historyListContainer
					,'template' : this.$historyListTemplate.find('.searchRow')
					,'nodata' : this.$historyListTemplate.find('.nodataRow')
				});
				
				this.$selectedSortOption = "";
				this.$portalYn = "N";
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 회원 조회
				_self.$srchForm.submit(function() {
					// 회원목록조회
					var param = {
						'GRADE_CD' : _self.$mGradeSel.find('option:selected').val()
					};
					var key = _self.$mSrhKeyRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$mSrhVal.val());
					}
					_self.getMemberList('1',param);
					return false;
				});
				
				// 포인트 조회
				_self.$perPageSel.change(function() {
					// 회원목록조회
					var param = {
						'PERPAGE' : $("#perPage").val()
					};
					
					_self.getPointHistoryList('1',param);
					return false;
				});
				
			
				// 포인트 내역 추가
				_self.$addPointBtn.click( function() {
					var selectMemId = $("#selectMemId").val();
					Bplat.view.openPopup({
						  'url' : "/sc/point/popup?MEM_ID="+selectMemId
						 ,'width' : 800
						 ,'height' : 600
					}, 'add_point_popup', {MEM_ID : selectMemId});
					
					return false;
				});
				
				_self.$selectedSortOption = $(".btnSort:first");
				
				$(".btnSort").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedSortOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedSortOption = newSel;
						
						_self.$srchForm.submit();
					}
					
					return false;
				});				

			
				
				
				_self.$showPointBtn.click( function(event) {
					
					var _self = this;					
					
					_self.$listContainer.find('tr').removeClass('jdg-selected');
					$tr.addClass('jdg-selected');
					$.ajax({
						 url : _self._memberDetailURL
						,type : 'POST'
						,data : {'MEM_ID' : _self.selectMemberId}
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	if( data.hasOwnProperty('memberList') ) {
					    		// 리스트 초기화
					    		_self.list.createList( data.memberList, 'MEM_ID' , function( data, $row ) {

					    		});

					    	}
					    }
					});
					
				});
				
				
				_self.$selectShip.change(function() {
				
					if (_self.$selectShip.css("display") != "none")
					{
						_self.$srchForm.submit();					 	
					}
					
					return false;
										
				});
				
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectMemberId = $tr.attr('rowKey');
				this._selectMemId  = _self.selectMemberId;
				$("#selectMemId").val(_self.selectMemberId);
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				$.ajax({
					 url : _self._memberDetailURL
					,type : 'POST'
					,data : {'MEM_ID' : _self.selectMemberId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('mem_detail') ) {
				    		var detail = data.mem_detail;
				    		_self.selectDetailData = detail;
				    		_self.selectFormShow('search', detail);
				    	}
				    	
				    	//포인트 히스토리 내역 조회
						var param = {
							'PERPAGE' : $("#perPage").val()
						};
				    	_self.getPointHistoryList(1, param);
				    }
				});
			},
			// 회원 목록 조회
			'getMemberList' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				    ,'SORT': _self.$selectedSortOption.val()
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('pointList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.pointList, 'MEM_ID' , function( data, $row ) {

				    		});
				    		
				    		var max_ = 0;
				    		if(data.pointList != null && data.pointList.length > 0){
				    			max_ = Math.ceil(data.pointList[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memberListPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getMemberList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.pointList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 회원별 적립금 내역 조회
			'getPointHistoryList' : function( page, param ) {
				var _self = this;
				var memberId = $("#selectMemId").val();
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : 10
				    ,'MEM_ID': memberId
				};
				console.log(defaultParam);
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectSubPage = page;
				$.ajax({
					 url : _self._historyListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('historyList') ) {
				    		// 리스트 초기화
				    		_self.history_list.createList( data.historyList, 'PAY_DATE' , function( data, $row ) {

				    		});
				    		
				    		var max_ = 0;
				    		if(data.historyList != null && data.historyList.length > 0){
				    			max_ = Math.ceil(data.historyList[0].TOTAL / defaultParam.PERPAGE);
				    		}
				    		// 페이징 초기화
				    		$('#historyListPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getPointHistoryList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$detailForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 회원목록조회
				this.getMemberList('1', p_param);
				
				var today = jdg.util.today();
				
				$('#schdDate2').val(today);
				
				var nextDay = jdg.util.addYear(-2);
				$('#schdDate').val(nextDay);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			
				var _self = this;
				var data = p_param.value;
				if(data == undefined || data == ""){
					return; //취소인 경우 값이 없음.
				}
				var memberId = $("#selectMemId").val();
				if(memberId != data){
					alert("시스템 오류가 발생하였습니다.");
					location.reload();
				}
				// 포인트 지급 팝업 close
				if (data) {
					//회원정보 재검색
					var param = {
							'GRADE_CD' : _self.$mGradeSel.find('option:selected').val()
					};
					var key = _self.$mSrhKeyRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$mSrhVal.val());
					}
					_self.getMemberList(_self._page, param, memberId);
				}
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
