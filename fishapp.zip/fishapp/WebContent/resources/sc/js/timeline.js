/* ******************************************************************************
 * 
 * 타임 라인 :
 * 해당 월의 데이터를 사진+텍스트+서브이미지의 형태로 화면에 나타낼 수 있다.
 * 웹브라우저 크기에 따라 좌우 분할이나 분할 되지 않는 모습으로 배치 될 수 있으며
 * 좌우 분할 시 좌우 레이어의 높이 값에 따라 해당 아이템이 어디에 붙어야 될지 정해진다.
 * 
 * 사용법 : 
 * timeline.minItemWidth : 좌우 분할 일 때 아이템의 최저 너비(기본값 100)
 * timeline.maxItemWidth : 좌우 분할 일 때 아이템의 최대 너비(기본값 600)
 * timeline.devideWidth : 좌우 분할 되는 최소 너비 값(기본값 320)
 * 
 * timeline.setData(배열) : 배열의 데이터를 받아서 화면에 뿌려진다.
 * timeline.changeMonth = 콜백함수(y, m) : 월이 변경 될 때 호출 되는 함수
 * timeline.clickMore = 콜백함수(y, m, itemNum) : 더 보기 버튼을 클릭 했을 때 호출 되는 함수
 * 
 *******************************************************************************/
var timeline = {
		
	/**
	 * 년, 월 표시
	 * 
	 * @param year : 년
	 * @param month : 월
	 */
	setDate : function(year, month) {
		if (this.changeMonth && typeof(this.changeMonth) == "function")
			this.changeMonth(year, month);
		
		this.$timelineYear.text(year);
		this.$timelineMonth.text(month);
	},
	
	/**
	 * 이미지 로드가 완료/실패 됐을 때 호출
	 * setData 후 layout을 잡아주기 위해 이미지 로드 카운트
	 */
	onImgLoad : function() {
		this.loadedImgNum++;
		if (this.loadedImgNum >= this.loadImgNum)
		{
			this.isLoading = false;
			this.layout();
		}
	},
	
	/**
	 * 타임라인에 표시될 데이터를 넣어줌
	 * 
	 * @param data : [{
	 * 					"src" : "이미지 주소", 
	 * 					"text" : "설명", 
	 * 					"date" : "날짜", 
	 * 					"subImages" : [ "이미지 주소", "이미지 주소"]
	 * 				}]
	 * @param isReset : true면 초기화
	 */
	setData : function(data, isReset) {
		if (this.isLoading)
			return;
			
		this.isLoading = true;
		
		if (isReset)
		{
			this.$timelineLeftContainer.empty();
			this.$timelineRightContainer.empty();
			this.$timelineCenterContainer.empty();
			this.items = [];
		}
		
		this.loadedImgNum = 0;
		this.loadImgNum = data.length;
		
		for( var i = 0; i < data.length; i++)
		{
			this.createItem(data[i]);
		}
		
	},
	
	/**
	 * 일 단위 아이템(사진 + 설명)을 생성
	 * 
	 * @param data : {
	 * 					"src" : "이미지 주소", 
	 * 					"text" : "설명", 
	 * 					"date" : "날짜", 
	 * 					"subImages" : [ "이미지 주소", "이미지 주소"]
	 * 				}
	 */
	createItem : function(data) {
		var _self = this;
		
		var $item = this.$timelineItem.clone();
		var $img = $item.find("img");
		
		$img.attr("src", data.src);
		$img.load(function() {
			_self.onImgLoad();
		});
		$img.error(function() {
			_self.onImgLoad();
		});
		$item.find("p").text(data.text);
		$item.attr("date", data.date);
		
		var $subContainer = $item.find( "#timelineItemSubContainer" );
		this.createSubItem(data.subImages, $subContainer);
		
		this.items.push( $item );
		
		this.$tempContainer.append($item);
	},
	
	/**
	 * 일 단위 아이템에서 서브 이미지 생성
	 * 
	 * @param subData : ["이미지 주소", "이미지 주소"]
	 * @param $subContainer : 서브이미지가 붙을 부모 컨테이너
	 */
	createSubItem : function(subData, $subContainer) {
		if (!subData)
			return;
		
		var $subItem;
		for (var i = 0; i < subData.length; i++)
		{
			$subItem = this.$timelineItemSubItem.clone();
			$subItem.find("img").attr("src", subData[i]);
			
			$subContainer.append($subItem);
		}
	},
	
	/**
	 * 각 아이템의 크기를 itemWidth에 맞게 재조정
	 * 
	 * @param item
	 */
	resizeItem : function($item) {
		if (!this.isMobile)
		{
			if (this.itemWidth > this.maxItemWidth)
				this.itemWidth = this.maxItemWidth;
			else if (this.itemWidth < this.minItemWidth)
				this.itemWidth = this.minItemWidth;
		}
		
		$item.width(this.itemWidth);
	},
	
	/**
	 * 아이템들을 배치
	 */
	layout : function() {
		if (this.isLoading)
			return;
		
		for (var i = 0; i < this.items.length; i++)
		{
			this.resizeItem(this.items[i]);
			
			if (this.items[i].parent().attr("id") == "tempContainer" || 
				(this.items[i].parent().length && String(this.isMobile) != this.items[i].attr("isMobile")) )
			{
				var $addContainer = this.nextAddContainer();
				$addContainer.append(this.items[i]);
				
				this.items[i].attr("isMobile", this.isMobile);
			}
		}
		
	},
	
	/**
	 * 아이템이 붙을 부모 컨테이너 구하기
	 * 
	 * @param month
	 * @param isMobile
	 * @returns
	 */
	nextAddContainer : function() {
		
		if (!this.isMobile)
		{
			var leftHeight = this.$timelineLeftContainer.height();
			var rightHeight = this.$timelineRightContainer.height();
			
			if (leftHeight > rightHeight)
				return this.$timelineRightContainer;
			else
				return this.$timelineLeftContainer;
		}
		else
			return this.$timelineCenterContainer;
	},
	
	/**
	 * 전역 속성 정의
	 */
	setProperties : function() {
		this.minItemWidth = 100;	// 분할 일 때 아이템의 최저 너비
		this.maxItemWidth = 600;	// 분할 일 때 아이템의 최대 너비
		this.devideWidth = 320;		// 분할 되는 시점(너비)
		
		this.itemWidth = this.$timelineContainer.width() / 2 - 50;	// 분할 일 때 각 아이템의 너비
		
		this.items = [];			// 현재 보여지는 아이템들 모음
		
		this.loadImgNum = 0;		// 로드 될 이미지 갯 수
		this.loadedImgNum = 0;		// 로드 된 이미지 갯 수
		
		this.isMobile = false;		// 모바일 인지 판단(devideWidth 이하일 때)
		
		this.changeMonth = null;	// 월 변경이 있을 때 호출 될 콜백 함수(사용자가 지정해 줘야 함)
		this.clickMore = null;		// 더보기 버튼 클릭 시 호출 될 콜백 함수(사용자가 지정해 줘야 함)
		
		this.isLoading = false;		// 이미지 로딩이 완료 되야 다음 데이터를 받아올 수 있다.
	},
	
	/**
	 * 엘리멘트 정의
	 */
	setElements : function() {
		this.$timelineContainer = $( "#timelineContainer" );			// 전체 
		
		this.$timelineMonthContainer = $( "#timelineMonthContainer" );	// left, right, center 컨테이너의 부모
		this.$timelineLeftContainer = $( "#timelineLeftContainer" );	// 왼쪽 컨테이너
		this.$timelineRightContainer = $( "#timelineRightContainer" );	// 오른쪽 컨테이너
		this.$timelineCenterContainer = $( "#timelineCenterContainer" );// 가운데 컨테이너
		
		this.$timelineItem = $( "#timelineItem" ).clone();				// 아이템(이미지 + 설명)
		this.$timelineItemSubItem = $( "#timelineItemSubItem" ).clone();// 서브 아이템(이미지)
		
		this.$tempContainer = $( "#tempContainer" );					// 이미지가 로드 되기 전까지 append 되어 있는 곳(실제 부모가 없으면 사이즈를 구할 수 없음)
		
		$( "#timelineItem" ).remove();
		$( "#timelineItemSubItem" ).remove();
		
		this.$timelineYear = $( "#timelineYear" );						// 년
		this.$timelineMonth = $( "#timelineMonth" );					// 월
	},
	
	/**
	 * 이벤트 정의
	 */
	setEvents : function() {
		var _self = this;
		
		/*
		 * 리사이징 이벤트
		 */
		$(window).resize(function() {
			_self.isMobile = false;
			
			if (_self.$timelineContainer.width() < _self.devideWidth)
				_self.isMobile = true;
			
			if (!_self.isMobile)
				_self.itemWidth = _self.$timelineContainer.width() / 2 - 50;
			else
				_self.itemWidth = _self.$timelineContainer.width();
			
			_self.layout();
		});
		
		/*
		 * 이전달/다음달 클릭
		 */
		$( ".plusMinusBtn" ).click(function(event) {
			var y = _self.$timelineYear.text();
			var m = _self.$timelineMonth.text();

			// 이전달 클릭
			if ($(event.target).attr("id") == "timelineMonthMinus")
				m = Number(m) - 2;
			
			var date = new Date(y, m);
			
			_self.setDate(date.getFullYear(), date.getMonth() + 1);
		});
		
		/*
		 * 더 보기 클릭
		 */
		$( "#moreBtn" ).click(function(event) {
			if (_self.clickMore && typeof(_self.clickMore) == "function")
			{
				var y = _self.$timelineYear.text();
				var m = _self.$timelineMonth.text();
				var num = _self.items.length;
				
				_self.clickMore(y, m, num);
			}
		});
	},
	
	/**
	 * 초기화
	 */
	init : function() {
		this.setElements();
		this.setEvents();
		this.setProperties();
		
		var d = new Date();
		this.setDate(d.getFullYear(), d.getMonth() + 1);
		
		$( "#timelineItem" ).width(this.itemWidth);
		
	}
};

timeline.init();