defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipURL = $('#shipURL').val();
				this._postListURL = $('#postListURL').val();
				this._portalPostListURL = $('#portalPostListURL').val();
				this._detailPostURL = $('#detailPostURL').val();
				this._portalDetailPostURL = $('#portalDetailPostURL').val();
				this._postInsertURL = $('#postInsertURL').val();
				this._postUpdateURL = $('#postUpdateURL').val();
				this._postDeleteURL = $('#postDeleteURL').val();
				this._postReserveNotiURL = $('#postReserveNotiURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				// element
				this.$listContainer = $('#postListContainer');
				this.$postThreadContainer = $('#postThreadContainer');
				this.$listTemplate = $('#postListTemplate');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				
				this.$mfyShipBtn = $('#mfyShipBtn'); //추천선박수정버튼
				
				
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$searchTypeSel = $('#searchPostSel');
				this.$searchShipSel = $('#searchShipSel');
				this.$sortArrow = $('.sortArrow');
				this.$typeCdEm = $('#TYPE_CD');
				this.$typeNameEm = $('#TYPE_NAME');
				this.$shipIdEm = $('#SHIP_ID');
				this.$shipNameEm = $('#SHIP_NAME');
				this.$postDetailTbl = $('#postDetailTbl');
				// form
				this.$srchForm = $('#postSearchForm');
				this.$insertForm = $('#postInsertForm');
				this.$updateForm = $('#postUpdateForm');
				this.$detailForm = $('#postDetailForm');
				
				this.$movieListRow = $('.movieListRow');

				// static variable
				this.selectPostId = '';
				this.selectedRowData = {};
				this.selectFileList = null;
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					/*,'nodata' : this.$listTemplate.find('.nodataRow')*/
				});
				// 파일 리스트 초기화
				this.fileList = null;
				// 예약 알림 사항에 대한 전역 설정
				this.RESERVE_ALARM = '108_120';
				
				
				/// 추천선박 ////////				
				this.$shipDelBtn = $('#shipDelBtn');
				this.$shipAddBtn = $('#shipAddBtn');
				
				this.$shipUpBtn = $('#shipUpBtn');
				this.$shipDnBtn = $('#shipDnBtn');
				
				//추천선박저장버튼
				this.$mfyShipBtn = $('#mfyShipBtn');

				// 추천선박 변경여부
				this.$shipUpdated = false;
				
				// 추천선박 선택된 행
				this.selectedRow = null;

			},
			'setEvent'		: function() {
				var _self = this;

				
				// 추천선박 위로 버튼클릭
				_self.$shipUpBtn.click( function() {
					
					_self.$shipUpdated = true;
					
					var sr = _self.selectedRow;						
					if (sr == null) return false;					
					sr.insertBefore(sr.prev());
					return false;
				});
				
				
				// 추천선박 아래로 버튼 클릭
				_self.$shipDnBtn.click( function() {
					
					_self.$shipUpdated = true;
					
					var sr = _self.selectedRow;
					if (sr == null) return false;
					sr.insertAfter(sr.next());
					return false;
				});
				
				
				// 추천선박 추가
				_self.$shipAddBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : '/sc/ship/search'
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_insert_popup' );
					
					return false;
				});
	

				// 추천선박 삭제(선택된 선박 1개 삭제)
				_self.$shipDelBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.$shipUpdated = true;
					
					_self.selectedRow.remove();	
					return false;
				});
				
				// 추천 선박 테이블 ROW 선택시 선택상태 표시
				$('#shipListContainer').delegate('tr','click', function() {
					var $this = $( this );

					$('#shipListContainer').find('tr').removeClass('jdg-selected');				
					_self.selectedRow = $this;				
					$this.addClass('jdg-selected');
					
					
				});
				
				// 추천선박 변경버튼
				_self.$mfyShipBtn.click( function() {
					_self.insertRecommShip();
				});
				
				
				
				
				
				_self.$sortArrow.click(function(){
					var sort = $(this).attr('data-key');
					if($(this).is(':visible')){
						sort = $(this).siblings('span').attr('data-key');
						$(this).siblings('span').show();
						$(this).hide();
					}
					_self.getPostList('1', 
							{
								 'TYPE_CD' : _self.$searchTypeSel.find('option:selected').val()
								,'SHIP_ID' : _self.$searchShipSel.find('option:selected').val()
								
							}
							, sort
					);
					return false;
				});

				// 조회
				_self.$srchForm.submit(function() {
					// 사업체목록조회
					_self.getPostList('1', 
							{
								 'TYPE_CD' : _self.$searchTypeSel.find('option:selected').val()
								,'SHIP_ID' : _self.$searchShipSel.find('option:selected').val()
							}
					);
					return false;
				});				
				
		

				
				function ImageExist(url) 
				{
					var img = new Image();
					$(img).load(url, function(response, status, xhr) {
					    if (status == "error") 
					       return false;
					    else
					       return true;
					    });
				}
				
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertPost();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow('none');
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					// 현재 셀렉트된 아이템을 수정화면에 셋팅
					_self.selectFormShow('update', _self.selectedRowData );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updatePost();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow( 'search', _self.selectedRowData.detailPost );
					return false;
				});

				
				_self.$insertForm.delegate("#movieAddBtn","click",function(event)
						{
							event.preventDefault();
							addMovieUrl(_self);
						});
				
				
				_self.$updateForm.delegate("#movieAddBtn","click",function(event)
						{
							event.preventDefault();
							addMovieUrl(_self);
						});
				
				
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					var defaultParam = {
							 'POST_ID': _self.selectPostId
   							 //선박명 : 선박 페이지 , portal : 포탈 페이지
							,'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val() 
					   };
					$.ajax({
						 url : _self._postDeleteURL
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		if( data.result > 0 ) {
						    		alert('삭제 되었습니다');
						    		location.reload();
					    		} else {
					    			alert('해당 사업체는 삭제할 수 없습니다.');
					    		}
					    	}
					    }
					});
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
	
				
				
			},

			// 추천 선박 저장
			'insertRecommShip' : function() {
				var _self = this;
				
//				if (_self.$updated == false)
//				{
//					alert('변경된 추천선박이 없습니다.');
//					return;
//				}
//				
				if(!confirm("저장하시겠습니까?")) {return;}
				
				var insertParam = {};
				var ships = [];
			
				$('#shipListContainer').find('td.ship').each(function (index) {
	            	
	            	var shipId = this.innerText;
	            	
	            	for (var i=0; i < ships.length; i++)
	            	{
	            		if (ships[i].SHIP_ID == shipId)
            			{
	            			alert("중복된 선박이 있습니다.(" + index + "번째)" );
	            			return false;
            			}
	            	}
	            	
	            	var item = {SHIP_ID: shipId, SORT_KEY: "" + index};
	            	ships.push(item);
	            });				
				
				insertParam.POST_ID = _self.selectPostId;
	            insertParam.ships = JSON.stringify(ships);

				$.ajax({
					 url : '/sc/ship/insertThemeShip'
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	_self.$updated = false;
				    	
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});

			},
			
			
			// 게시물 등록
			'insertPost' : function(){
				var _self = this;
				var $insertForm = _self.$insertForm;
				var typeCd = _self.$typeCdEm.text();
				var $insertForm = _self.$insertForm;

				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var insertParam = {
						  'TYPE_CD' : typeCd
						, 'TITLE' : $insertForm.find('[data-key=TITLE]').val()
						, 'CONTENT' : $insertForm.find('[data-key=CONTENT]').val()
						, 'FILE_NAME' : $insertForm.find('[data-key=FILE_NAME]').val()
						, 'IMG_ID' : JSON.stringify( _self.fileList.getFileList() )
						//선박명 : 선박 페이지 , portal : 포탈 페이지
						, 'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val()
				};
				
				if (typeCd >= '122_050')
				{
					var tds = $('#shipListContainer td.ship');
					
//					if (tds == null||tds.length == 0)
//					{
//						alert('추천선박을 추가해주십시오.');
//						return false;
//					}
					
					var ships = null;
					
					for (var i =0 ; i < tds.length; i++ )
					{
						var shipId = $(tds[i]).text();
						ships = (i == 0)? shipId : ships + "," + shipId;
					}
					
					if (ships)	insertParam.SHIPS = ships;
				}
				
				$.ajax({
					 url : _self._postInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		if( data.result.POST_ID != null && 
			    				data.result.POST_ID != undefined && 
			    				data.result.POST_ID != '' ){
				    			_self.getPostList('1', {'POST_ID' : data.result.POST_ID});
				    		}
				    	}
				    }
				});
				return false;
			},
			// 게시물 수정
			'updatePost' : function(){
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 파일등록
		    	// set update parameters
				var updateParam = {
						  'POST_ID'   : _self.selectPostId
						, 'TYPE_CD'   : $updateForm.find('[data-key=TYPE_CD]').text()
						, 'SHIP_ID'   : $updateForm.find('[data-key=SHIP_ID]').text()
						, 'TITLE'     : $updateForm.find('[data-key=TITLE]').val()
						, 'CONTENT'   : $updateForm.find('[data-key=CONTENT]').val()
						, 'IMG_ID'    : JSON.stringify( _self.fileList.getFileList() )
						//선박명 : 선박 페이지 , portal : 포탈 페이지
						, 'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val()
				};
				$.ajax({
					 url : _self._postUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getPostList('1', {'POST_ID' : _self.selectPostId});
				    	}
				    }
				});
				return false;
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				var $imgContainer = _self.$detailForm.find('[data-type=IMAGE]').parent();
				_self.selectPostId = $tr.attr('rowKey');
				var postType = _self.$searchTypeSel.find('option:selected').val();

				var detailPostURL = '';
				var defaultParam = {
										 'POST_ID': _self.selectPostId
									     ,'TYPE_CD' : postType
								   };
				
				detailPostURL = _self._detailPostURL;

				$.ajax({
					 url : _self._detailPostURL
					,type : 'POST'
					,data : defaultParam
					,dataType : 'json'
					,success : function(data){
						// 데이터 초기화
						_self.selectedRowData = {};
						if(data.hasOwnProperty('detailPost')){

							_self.selectFormShow('search', data.detailPost );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							$tr.addClass('jdg-selected');

						}
						if( 1 == 2 ){
							$imgContainer.hide();
						} else {
							$imgContainer.show();
							if(data.hasOwnProperty('postImage'))
								jdg.util.createImgList( data.postImage, $imgContainer.find('[data-type=IMAGE]') );
						}
						_self.selectedRowData = data;
					}
				});
			},
			// 게시물 목록 조회
			'getPostList' : function( page, param, sort ) {
				var _self = this;
				var typeCd = _self.$searchTypeSel.find('option:selected').val();
				var defaultParam = {};
				var paramURL = ''; 
				var postTblThCnt = 0 ;
				var nodata ='';

				 paramURL = _self._postListURL;
				 defaultParam = {
						 'PAGE' : page
						,'PERPAGE' : '10'
						,'SORT_BY' : sort
						,'TYPE_CD' : typeCd
					};

				$.extend( defaultParam, param );
				$.ajax({
				 url : paramURL
				,type : 'POST'
				,data : defaultParam
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	if( data.hasOwnProperty('postList') ) {
			    		// 리스트 초기화
			    		if(data.postList.length > 0 ){
			    			_self.list.createList( data.postList, 'POST_ID', function( data, $row) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    				$row.find('[data-key=UPDATED_NICK]').text( data.UPDATED_NICK );
				    			}

				    		});
			    		}else{

			    			nodata = "<tr class='nodataRow'><td colspan='3' style='text-align: center;'>조회된 데이터가 없습니다.</td></tr>";

			    			_self.$listContainer.empty();
			    			_self.$listContainer.append( nodata );
			    		}
			    		
			    		// 페이징 초기화
			    		$('#postListPaging').paging({
							 current: page
							,max: (Math.ceil(data.total / 10))
							,onclick:function(e,page){
								_self.getPostList(page);
							}
	    					,prev : '이전'
			    			,next : '다음'
						});
			    		_self.selectFormShow('none');
			    		// 데이터1개일 경우 자동 펼침
			    		if( data.postList.length == 1 )
			    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
			    		
			    		// 현재의 조회 조건이 예약 알림 사항일 경우 안드로이드에서 보여지는 예약 알림 사항내역을 가져온다.
			    		if( typeCd == _self.RESERVE_ALARM )
			    			_self.getReserveNoties( shipId );
			    	}
			    }
			});
				
				
				
			},

			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;

				var typeCd = (data == null)? $('#searchPostSel').val() : data.TYPE_CD;
				
				if (typeCd < '122_050')
				{
					$('#recomShipForm').hide();
					$('#msg').hide();
				}
				else
				{
					$('#recomShipForm').show();
					$('#msg').show();
					
					if (mode == 'insert')
					{
						$('#mfyShipBtn').hide();
						$('#shipListContainer').empty();
					}
					else
					{
						$('#mfyShipBtn').show();
					}
				}
				
				
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					
					$detailForm.show();
					
					_self.getShipList(data.POST_ID);
				}
				// 신규등록
				else if( 'insert' === mode ) {
					// span Elements
					var $typeCdEm = _self.$typeCdEm;
					var $typeNameEm = _self.$typeNameEm;
					var $shipIdEm = _self.$shipIdEm;
					var $shipNameEm = _self.$shipNameEm;
					
					// select Box
					var $searchTypeSel = _self.$searchTypeSel;
					var $searchShipSel = _self.$searchShipSel;
					
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $insertForm.attr('id')
						,'container' : $insertForm.find('[data-type=IMAGE_LIST]')
					});
					
					// 선박명과 게시종류를 게시물 등록 텍스트에 보여줌.
					$typeCdEm.text($searchTypeSel.find("option:selected").val());
					$typeNameEm.text($searchTypeSel.find("option:selected").text());
					
					$shipIdEm.text($searchShipSel.find("option:selected").val());
					$shipNameEm.text($searchShipSel.find("option:selected").text());
					
					// 예약 알림 설정은 이미지를 등록하지 않으므로 이미지 컨테이너를 보이지 않는다.
					var $typeCd = _self.$searchTypeSel.find('option:selected');
					if( $typeCd.val() == _self.RESERVE_ALARM ){
						_self.$insertForm.find('[data-type=IMAGE_LIST]').parent().hide();
					} else {
						_self.$insertForm.find('[data-type=IMAGE_LIST]').parent().show();
					}
					
					_self.fileList.init();
					$insertForm.find(".movieListRow").remove();
					$insertForm.show();
					
//					$insertForm.delegate("#movieAddBtn","click",function(event)
//							{
//								event.preventDefault();
//								addMovieUrl(_self);
//							})
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					
					// 컨텐츠 내용중 <br> 에 대한 문자열은 \n 으로 변환
					var content = data.detailPost.CONTENT;
					if( content && content.indexOf('<br>') ){
						content = content.replace(/<br>/gi, '\n');
						data.detailPost.CONTENT = content;
					}
			
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data.detailPost );
					
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $updateForm.attr('id')
						,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
					});
					
					_self.fileList.init(data.postImage);
					
					// 게시종류가 예약알림사항일 경우 이미지 컨테이너를 숨김.
					if( data.detailPost['TYPE_CD'] == _self.RESERVE_ALARM ){
						$updateForm.find('[data-type=IMAGE_LIST]').parent().hide();
					} else {
						$updateForm.find('[data-type=IMAGE_LIST]').parent().show();
					}
					
					$updateForm.find(".movieListRow").remove();
					$updateForm.show();
					
//					$updateForm.delegate("#movieAddBtn","click",function(event)
//							{
//								event.preventDefault();
//								addMovieUrl(_self);
//							});
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
				
				return false;
			},
			
			
			// 테마별 선박 목록 조회
			'getShipList' : function(postId) {
				var _self = this;
				
				$('#shipListContainer').empty();
				
				 var param = {'POST_ID' : postId	};

				$.ajax({
					 url : '/sc/ship/themeShipList'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		
				    		_self.$shipUpdated = false; //추천선박 변경여부 false
				    		var rowcount = 0;
				    		var list = data.shipList;
				    		
				    		var $cont =$('#shipListContainer');
				    		var $templ = $('#shipListTemplate tr.searchRow');
				    		
				    		for (var i=0; i < list.length; i++ )
				    		{
				    			var item = list[i];
				    			var $row = $templ.clone();
				    			var tds = $row.find('td');
				    			
				    			$(tds[0]).text(i + 1);
				    			$(tds[1]).text(item.SHIP_ID);
				    			$(tds[2]).text(item.SHIP_NAME);
				    			$(tds[3]).text(item.PORT_NM);
				    			
				    			$cont.append($row);
				    		}
				    	}
				    }
				});
			},
			
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 사업체목록조회
				this.getPostList('1' , p_param );
				$("a[href='#']").attr('href','javascript:void(0);');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[post_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[post_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var item = p_param.value;
				// 관리자 팝업 close
				if( 'ship_insert_popup' === p_param.id ) {
					
					_self.$updated = true;
					
		    		var $cont =$('#shipListContainer');
		    		var $templ = $('#shipListTemplate tr.searchRow');
	    			var $row = $templ.clone();
	    			var tds = $row.find('td');
	    			
	    			$(tds[0]).text('new');
	    			$(tds[1]).text(item.SHIP_ID);
	    			$(tds[2]).text(item.SHIP_NAME);
	    			$(tds[3]).text(item.PORT_NAME);
		    			
	    			$cont.append($row);
					
				} 
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[post_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[post_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[post_main] onDestroy Method' );
			}		
	  }
});
