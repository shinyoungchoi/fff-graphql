defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// element
				this.$srhSel = $('#searchShipSel');
				this.$chkYear = $('#checkYear');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				this.$detailForm = $('#scheduleDetailForm');

				//출조 당월 등록
				this.$registerMonthBtn = $("#register_month");
				this.$updateScheduleBtn = $("#updateScheduleBtn");
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$deleteScheduleBtn = $('#deleteScheduleBtn');
				//해당 월 스케쥴 전체 보이기, 감추기
				this.$showAll = $("#show_all");
				this.$hideAll = $("#hide_all");
				
				this.$useAll = $("#use_all");
				this.$removeAll = $("#remove_all");
				
				this.$btnDelete = $("input.btn_delete");
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				//수정 form
				this.$updateForm = $('#scheduleUpdateForm');
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				var date = new Date();
				
				$("#checkYear").val(date.getFullYear());
				$("#selectYear").val(date.getFullYear());
				
				//모든 스케쥴 삭제를 위한 클릭
				$("#allselected").click(function(){
					if(!confirm("화면에 보이는 모든 스케쥴을 선택하시겠습니까?"))
						return;
					
					$("input:checkbox[name=delCheck]").each(function(){
						if($(this).attr("ptype") == '0')
							$(this).trigger("click");
					})
				});
				
				//년도에 따라 월별 등록 여부 표가 바뀜.
				$("#checkYear").change(function(){
					var year = $(this).val();
					if(_self.$srhSel.find('option:selected').val() == ""){
						alert("선박을 선택해주세요.");
						return;
					}
					_self.getScheduleByMonth({SCHD_DATE : year, SHIP_ID : _self.$srhSel.find('option:selected').val()});
				});
					
				//스케쥴 삭제
				_self.$btnDelete.click(function(){
					if(!confirm("선택하신 스케쥴 및 장르를 삭제하시겠습니까? \n (장르 삭제를 원하시면 스케쥴 삭제 후 낚시장르에서도 삭제해주세요.)")){
						 return;
					}
					var params = [];
					$("input:checkbox[name='delCheck']").each(function(index, item){
						var checkYn = $(this).is(":checked");
						
						if(checkYn){
							var pType = $(this).attr("ptype");
							var pSchdId = $(this).attr("pschdid");
							var pGenre = $(this).attr("pgenre");
							
							var param = { TYPE : pType, SCHD_ID : pSchdId, GENRE : pGenre};
							params.push(param);
						}
					});
				
					if(params == null || params.length < 1){
						alert("삭제하실 스케쥴을 선택해주세요.");
						return;
					}
					_self.deleteScheduleGenre(params);
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 조회만 하기
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val(),
						'DOTYPE' : 'SELECT'
					});
					//월별 등록 여부
					_self.getScheduleByMonth({ 'SHIP_ID' : _self.$srhSel.find('option:selected').val(), 'SCHD_DATE' : _self.$chkYear.find('option:selected').val()});
					
					return false;
				});
				
				//년, 월에 등록
				_self.$registerMonthBtn.click(function(){
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val(),
						'DOTYPE' : 'REGISTER'
					});
				});
				
				//체크한 장르 사용함으로 변경.
				_self.$useAll.click(function(){

					var params = [];
					$("table.jdg-cmpt-list").find("input:checkbox[name='genreUse']").each(function(index, item){
						var schdId = $(this).attr("pschdid");
						var genreId = $(this).attr("pgenre");
						var type = $(this).attr("ptype");
						var checked = $(this).is(":checked");
						console.log(schdId, genreId, checked);
						
						if(checked){
							var param = { SCHD_ID : schdId, GENRE : genreId, USE_YN : 'Y', TYPE : type};
							params.push(param);
						}
						
					});

					
					_self.updateGenre(params);
				});
				
				//체크한 장르 사용안함으로 변경
				_self.$removeAll.click(function(){
					
					var params = [];
					$("table.jdg-cmpt-list").find("input:checkbox[name='genreUse']").each(function(index, item){
						var schdId = $(this).attr("pschdid");
						var genreId = $(this).attr("pgenre");
						var type = $(this).attr("ptype");
						var checked = $(this).is(":checked");
						console.log(schdId, genreId, checked);
						
						if(checked){
							var param = { SCHD_ID : schdId, GENRE : genreId, USE_YN : 'N', TYPE : type};
							params.push(param);
						}
					});
					_self.updateGenre(params);
				})
				
				//해당 월의 스케쥴 전체 보이기
				_self.$showAll.click(function(){
					var shipId =  _self.$srhSel.find('option:selected').val();
					var year =  $("#selectYear option:selected").val();
					var month = $("#selectMonth option:selected").val();
					_self.updateAllShow('show', shipId, year, month);
				});
				
				//해당 월의 스케쥴 전체 감추기
				_self.$hideAll.click(function(){
					var shipId =  _self.$srhSel.find('option:selected').val();
					var year =  $("#selectYear option:selected").val();
					var month = $("#selectMonth option:selected").val();
					_self.updateAllShow('hide', shipId, year, month);
				});
				
				//리스트에서 스케쥴 별 노출 여부 변경
				$("#scheduleListContainer").on("change", "select[name=delFlagsBy]" , function(){
					var value= $(this).val();
					var pid = $(this).attr("pid");
					_self.changeDelFlag(value, pid);
				});
				
				//수정
				_self.$updateScheduleBtn.click(function(){
					_self.updateSchedule();
					return false;
				});
				
				//삭제
				_self.$deleteScheduleBtn.click(function(){
					_self.deleteSchedule("Y");
					return false;
				});
				
				//출조 취소시 사유쓰는 input 보임
				_self.$updateForm.find("[data-key=STATUS_CD]").change(function(){
					$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").val("");
					if($(this).val() == '113_210'){
						$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").show();
					}else
						$("#scheduleUpdateForm").find("[data-key=CANCEL_DESC]").hide();
				});
				
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					if($(this).attr("rowkey") != undefined)
						_self.openDetailForm( $this );
				});
			},
			//체크박스 선택된 장르, 스케쥴 삭제
			'deleteScheduleGenre' : function(param){
				var _self = this;
				$.ajax({
					 url : "/sc/schedule/deleteScheduleGenre"
					,type : 'POST'
					,data : { param : JSON.stringify(param)}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}else if( data.hasOwnProperty('error') ){
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			'updateGenre' : function(param){
				var _self = this;
				$.ajax({
					 url : "/sc/schedule/updateGenreStatus"
					,type : 'POST'
					,data : { param : JSON.stringify(param)}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			'updateAllShow' : function(type, shipId, year, month){
				var _self = this;
				if(shipId == ''){
					alert("배를 선택해주세요.");
					return;
				}
				month = ("0" + month).slice(-2);
				var param = { TYPE : type, SHIP_ID :shipId ,SCHD_COMPARE_DATE: year+month};
				
				if(type == 'show'){
					type = "전체 보임";
				}else{
					type = "전체 숨김";
				}
				
				if(!confirm( _self.$srhSel.find('option:selected').text() +"의 "+ year+"년도 "+ month +"월의 스케쥴을 "+type+"으로 변경하시겠습니까?"))
					return;
				$.ajax({
					 url : "/sc/schedule/changeShowStatus"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		_self.getScheduleList( '1', {'SHIP_ID' : shipId});
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
				
			},
			'changeDelFlag' : function(value, pid){
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				var param = { SCHD_ID : pid, DEL_FLAG : value};
				$.ajax({
					 url : "/sc/schedule/changeDelFlag"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert("변경되었습니다.");
				    		$updateForm.hide();
				    		_self.getScheduleList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, pid);
				    		return;
				    	}
				    	
				    	alert("변경도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'SCHD_ID'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option value="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			// 년도 월별 등록 여부 조회 
			'getScheduleByMonth' : function(param){
				$.ajax({
					 url : "/sc/schedule/selectScheduleByMonth"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('monthList') ) {
				    		for(var i = 1 ;i < 13 ; i++){
				    			$("#monthTr").find("[tdkey='m_"+ i +"']").html("-");
				    		}
				    		
				    		for(var i =0 ;i < data.monthList.length ; i++){
				    			var item = data.monthList[i];
				    			if(item != null && item != undefined){
				    				var registerYn = item.REGISTER_YN;
					    			var month = item.MONTH;
				    				$("#monthTr").find("[tdkey='m_"+ month +"']").text(registerYn+"("+item.CNT+"개)");
				    			}
				    		}
				    	}
				    }
				});
			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( page, param, showDetailId ) {
				var _self = this;
				
				var shipId = _self.$srhSel.val();
				
				if (shipId == '')
				{
					alert('선택된 선박이 없습니다!');
					return false;
				}
				
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : $("#selectPerPage").val()
					,'YEAR' : $("#selectYear").val()
					,'MONTH' : $("#selectMonth").val()
					,'STATUS_CD' : $("#selectReserve").val()
					,'SHIP_ID' : _self.$srhSel.find('option:selected').val()
				};

				$.extend( defaultParam, param );
				
				if(defaultParam.SCHD_ID != undefined && defaultParam.SCHD_ID != ''){
					//예약화면에서 넘어온 경우.
					defaultParam.YEAR = null;
					defaultParam.MONTH = null;
					defaultParam.STATUS_CD = null;
					defaultParam.SHIP_ID = null;
				}
				
				//전체선택시 조회 안되도록.
				if(_self.$srhSel.find('option:selected').val() == "" && (defaultParam.SCHD_ID == '' || defaultParam.SCHD_ID == undefined)){
					alert("선박을 선택해주세요.");
					return;
				}
				
				$('#span_ship_nm').text(_self.$srhSel.find("option:selected").text() + '의 스케쥴');
				$('#span_ship_nm').show();
				
				$('#loadingbar').attr("style", "display:;");
				
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/pension/scheduleList"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.scheduleList, 'SCHD_ID',  function( data, $row ) {
				    			$row.find("[data-key=SCHD_DATE]").attr("style", "font-weight:600;");
				    			var selectGenreYn ="";
				    			if(data.CHOICE_GENRE != undefined && data.CHOICE_GENRE != ''){
				    				selectGenreYn = "◆ ";
				    			}
				    			
				    			if(data.ROOM_TYPE == "P"){
				    				$row.find('[data-key=SCHD_ROOM_TYPE]').html("펜션형");
				    			}else{
				    				$row.find('[data-key=SCHD_ROOM_TYPE]').html("게스트하우스형");
				    			}
				    			
				    			// 날짜
				    			var selectDate = new Date(data.SCHD_DATE_STR);
				    			if(selectDate.getDay() == '0'){
				    				selectDate = "일";
				    			}else if(selectDate.getDay() == '1'){
				    				selectDate = "월";
				    			}else if(selectDate.getDay() == '2'){
				    				selectDate = "화";
				    			}else if(selectDate.getDay() == '3'){
				    				selectDate = "수";
				    			}else if(selectDate.getDay() == '4'){
				    				selectDate = "목";
				    			}else if(selectDate.getDay() == '5'){
				    				selectDate = "금";
				    			}else if(selectDate.getDay() == '6'){
				    				selectDate = "토";
				    			}
				    			
				    			if( data.SCHD_DATE ) $row.find('[data-key=SCHD_DATE]').text( selectGenreYn + data.SCHD_DATE_STR + "("+ selectDate +")" );
				    			if( data.STATUS_CD == '113_110'){
				    				$row.find('[data-key=STATUS_NAME]').attr("style", "color:blue;");
				    			}else{
				    				$row.find('[data-key=STATUS_NAME]').attr("style", "color:red;");
				    			}
				    			
				    			if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined){
				    				$row.find('[data-key=SUB_SHIPNM]').html("<br/>("+data.SUB_SHIPNM+")");
				    			}
				    			var delCheck ="&nbsp;<input type='checkbox' name='delCheck' pType='0' pSchdId='"+data.SCHD_ID+"'>";				    					
				    			$row.find("[data-type=SCHD_DELETE]").html(delCheck);
		    					
				    			$row.find('[data-type=DEL_FLAG]').val(data.DEL_FLAG);
				    			$row.find('[data-type=DEL_FLAG]').attr("pId", data.SCHD_ID);
				    			
				    		}, function(data, $row){
				    			
				    			if($row.prev().find("[data-key=SCHD_DATE]").text().substring(0,10) != data.SCHD_DATE_STR){
				    				$row.css({"border-top-style": "double", "border-top-color":"#a7a7a7"});
				    			}
				    			
				    		
				    		});
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total /  $("#selectPerPage").val()))
								,onclick:function(e,page){
									_self.getScheduleList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.scheduleList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    	
				    	$('#loadingbar').attr("style", "display:none;");
				    }
				});
			},
			// 출조스케줄 수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				// 출조일 가공
				var updateParam = {
					  'SCHD_ID' : _self.selectScheduleId
					, 'CHOICE_GENRE' : $updateForm.find('[data-key=CHOICE_GENRE]').text()
					, 'CANCEL_DESC' : $updateForm.find('[data-key=CANCEL_DESC]').val() //취소사유
					, 'STATUS_CD' : $updateForm.find('[data-key=STATUS_CD] option:selected').val()
					, 'DEL_FLAG' :$updateForm.find("input:radio[name='delFlag']:checked").val()
					, 'FISH_KIND' : $updateForm.find('[data-key=FISH_KIND]').val()
					, 'RESERVE_CONFIRM_CNT' : $updateForm.find('[data-key=RESERVE_CONFIRM_CNT]').text()
					, 'RESERVE_WAIT_CNT' : $updateForm.find('[data-key=RESERVE_WAIT_CNT]').text()
				};
				
				if(updateParam.STATUS_CD == "113_210" && updateParam.DESC == ""){
					alert("출조스케쥴 출조 취소사유를 입력해주세요.");
					return;
				}
				
				//선택된 장르가 있는 경우 위의 서머리 정보가 수정가능해짐.
				updateParam.PSGR_CNT = $updateForm.find('[data-key=PSGR_CNT]').val();
				updateParam.PREPARE = $updateForm.find('[data-key=PREPARE]').val();
				updateParam.SUB_TITLE = $updateForm.find('[data-key=SUB_TITLE]').val();
				updateParam.LOC_DESC = $updateForm.find('[data-key=LOC_DESC]').val();
				updateParam.REWARD_RATE = $updateForm.find('[data-key=REWARD_RATE]').val();
				updateParam.REWARD_WHOLE_RATE = $updateForm.find('[data-key=REWARD_WHOLE_RATE]').val();
				updateParam.FEE = $updateForm.find('[data-key=FEE]').val();
				updateParam.FEE_WHOLE = $updateForm.find('[data-key=FEE_WHOLE]').val();
				updateParam.DESCR = $updateForm.find('[data-key=DESCR]').val();
				if(updateParam.RESERVE_CONFIRM_CNT == '0' && updateParam.RESERVE_WAIT_CNT == '0'){
					updateParam.DISCOUNT_FEE = $updateForm.find('[data-key=DISCOUNT_FEE]').val();
					updateParam.DISCOUNT_WHOLE_FEE =  $updateForm.find('[data-key=DISCOUNT_WHOLE_FEE]').val();
				}
								
				$.ajax({
					 url : "/sc/pension/updateScheduleList"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		$updateForm.hide();
				    		_self.getScheduleList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, _self.selectScheduleId);
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 출조스케줄 삭제
			'deleteSchedule' : function(type) {
				var _self = this;
				var $updateForm = _self.$updateForm;
			
				if(!confirm("스케쥴을 삭제하시겠습니까?")){
					return false;
				}
				
				$.ajax({
					 url : "/sc/schedule/deleteScheduleList"
					,type : 'POST'
					,data : {
						 'SCHD_ID' : _self.selectScheduleId,
						 'DEL_TYPE' : type
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		$updateForm.hide();
				    		_self.getScheduleList( "1", {'SHIP_ID' : _self.$srhSel.find('option:selected').val()});
				    		return;
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 수정하기
				if('search' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					console.log(data);
					
					if(data.PREPARE == '' || data.PREPARE == undefined){
						data.PREPARE = '';
					}
					
					if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined){
						$updateForm.find("[data-key=SUB_SHIPNM]").text("("+ data.SUB_SHIPNM +")");
					}
					
					if(data.STATUS_CD == '113_210'){
						$updateForm.find("[data-key=CANCEL_DESC]").show();
					}else{
						$updateForm.find("[data-key=CANCEL_DESC]").hide();
					}
					
					$updateForm.find("input:radio[name=delFlag]:input[value='"+ data.DEL_FLAG +"']").attr("checked","checked");
					
					var roomHtml = "";
					if(data.SCHD_ROOM_TYPE == "P"){
						roomHtml += "펜션형";
					}else{
						roomHtml += "게스트하우스형";
					}
					roomHtml += "<br/>[ 기본 인원 :  "+data.STD_MAN+"명 , 추가 인원 : "+ data.ADD_MAN +"명 ]";
					$updateForm.find("[data-key='SCHD_ROOM_TYPE']").html(roomHtml);
					
					// 출조일 셋팅
					var schdDate = data.SCHD_DATE;
					if( schdDate ) {
						$updateForm.find('[data-type=SCHD_DATE]').text(jdg.util.replaceDate(schdDate));
					}
					
					var schdTime = data.SCHD_TIME_STR;
					$updateForm.find('[data-type=SCHD_TIME]').text(schdTime);
					
					//승선인원 세팅
					if(data.PSGR_CNT){
						$updateForm.find('[data-type=PSGR_CNT]').val(data.PSGR_CNT);
					}
					
					//예약자가 있는 경우 삭제 못하도록 막음.
					if(data.RESERVE_CONFIRM_CNT > 0 && data.RESERVE_WAIT_CNT > 0){
						$('#deleteScheduleBtn').attr("style", "display:none;");
					}
					
					$updateForm.find("[data-key=PSGR_CNT]").parent().html("<input class='jdg-input-text' type=text data-key='PSGR_CNT' value='"+data.PSGR_CNT+"' style='width:91%'/>명");
					if(data.REWARD_WHOLE_RATE == undefined){
						data.REAWRD_WHOLE_RATE = "";
					}
					$updateForm.find("[data-key=REWARD_WHOLE_RATE]").parent().html("<input class='jdg-input-text' type=text data-key='REWARD_WHOLE_RATE' value='"+data.REWARD_WHOLE_RATE+"' style='width:91%'>%");
					if(data.DISCOUNT_WHOLE_FEE == undefined){
						data.DISCOUNT_WHOLE_FEE = "";
					}
					$updateForm.find("[data-key=DISCOUNT_WHOLE_FEE]").parent().html("<input class='jdg-input-text' type=text data-key='DISCOUNT_WHOLE_FEE' value='"+data.DISCOUNT_WHOLE_FEE+"' style='width:91%'>원");
					$updateForm.find("[data-key=SUB_TITLE]").parent().html("<input class='jdg-input-text' type=text data-key='SUB_TITLE' value='"+data.SUB_TITLE+"'>");
					$updateForm.find("[data-key=LOC_DESC]").parent().html("<input class='jdg-input-text' type=text data-key='LOC_DESC' value='"+( data.LOC_DESC != undefined ? data.LOC_DESC : '' )+"'>");
					$updateForm.find("[data-key=REWARD_RATE]").parent().html("<input class='jdg-input-text' type=text data-key='REWARD_RATE' value='"+data.REWARD_RATE+"' style='width:91%'>%");
					$updateForm.find("[data-key=PREPARE]").parent().html("<input class='jdg-input-text' type=text data-key='PREPARE' value='"+data.PREPARE+"'>");
					$updateForm.find("[data-key=FEE]").parent().html("<input class='jdg-input-text' type=text data-key='FEE' value='"+data.FEE+"' style='width:91%'/>원");
					if(data.FEE_WHOLE == undefined){
						data.FEE_WHOLE = "";
					}
					$updateForm.find("[data-key=FEE_WHOLE]").parent().html("<input  class='jdg-input-text' type=text data-key='FEE_WHOLE' value='"+data.FEE_WHOLE+"' style='width:91%'/>원");
											
					if(data.RESERVE_CONFIRM_CNT <= 0 && data.RESERVE_WAIT_CNT <= 0){
						if(data.DISCOUNT_FEE == undefined){
							data.DISCOUNT_FEE = "";
						}
						$updateForm.find("[data-key=DISCOUNT_FEE]").parent().html("<input  class='jdg-input-text' type=text data-key='DISCOUNT_FEE' value='"+data.DISCOUNT_FEE+"'style='width:91%'/>원");
					}
					
									
					$updateForm.show();
				}
				
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				if( p_param.hasOwnProperty('SCHD_ID') ) {
					var schdId = p_param.SCHD_ID;
					// 출조스케쥴 목록 조회
					this.getScheduleList('1', {'SCHD_ID' : schdId});
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getScheduleList('1', {'SHIP_ID' : p_param.SHIP_ID});
				}
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
