defClass({
	name		: 'BplatBody',
	pkg			: 'Bplat.viewPkg',
	implement	: Bplat.viewPkg.ViewInterface,
	construct : function() {},
	methods :{
		'setElement' : function(){
			// url
			this._statListURL = $('#statListURL').val();
			this._statGroupByListURL = $('#statGroupByListURL').val();
			
			//element
			this.$listContainer = $('#statListContainer');
			this.$listTemplate = $('#statListTemplate');
			this.$todayBtn = $('#todayBtn');
			this.$thisWeekBtn = $('#thisWeekBtn');
			this.$lastWeekBtn = $('#lastWeekBtn');
			this.$thisMonthBtn = $('#thisMonthBtn');
			this.$lastMonthBtn  = $('#lastMonthBtn');
			this.$datepicker = $('.datepicker');
			this.$startDate = $('.datepicker').eq(0);
			this.$endDate = $('.datepicker').eq(1);
			this.$searchBtn  = $('.jdg-btn-search');
			this.$groupByChecked = $('#groupByChecked');
			this.$listTable = $('.jdg-cmpt-list');
			this.$sendEmailTd = $('.sendEmailTd');
			
			//form
			this.$srchForm = $('#statSearchForm');
			
			
			// static variable
			this.selectPage = '';
			this.list = new component.List({
				 'container' : this.$listContainer
				,'template' : this.$listTemplate.find('.searchRow')
				,'nodata' : this.$listTemplate.find('.nodataRow')
			});
			
		}, //end of setElement
		'setEvent' : function() {
			var _self = this;
			
			_self.$searchBtn.click(function(){
				if(! _self.checkData() ){
					
					return false;
				}else {
					
					if(_self.$groupByChecked.is(":checked")==true ){
						_self.getSendMailStatListGroupBy("1"); // 바꿔
					}else{
						_self.getSendMailStatList("1");
					}
					
				}
			});
			
			_self.$datepicker.datepick({dateFormat:'yyyy-mm-dd'});
			
			//오늘 버튼 클릭
			_self.$todayBtn.click(function(){
				_self.$startDate.val( _self.dateCalc("today") );
				_self.$endDate.val( _self.dateCalc("today"));
			}); //end of $todayBtn click
			
			//이번주 버튼 클릭
			_self.$thisWeekBtn.click(function(){ 
				_self.$startDate.val(_self.dateCalc( "thisWeekSt" ));
				_self.$endDate.val(_self.dateCalc("today")); 

			}); // end of $thisWeekBtn click
			
			//저번주 버튼 클릭
			_self.$lastWeekBtn.click(function(){ 
				_self.$startDate.val(_self.dateCalc("lastWeekSt"));
				_self.$endDate.val(_self.dateCalc("lastWeekEnd"));
			});
			
			//이번달 버튼 클릭
			_self.$thisMonthBtn.click(function(){
				_self.$startDate.val(_self.dateCalc("thisMonthSt"));
				_self.$endDate.val(_self.dateCalc("thisMonthEnd"));
			}); // end of $thisMonthBtn click
			
			//저번달 버튼 클릭 
			_self.$lastMonthBtn.click(function(){
				_self.$startDate.val(_self.dateCalc("lastMonthSt"));
				_self.$endDate.val(_self.dateCalc("lastMonthEnd"));
			});//end of $lastMonthBtn click event
			
		}, //end of setEvent
		
		//GroupBy 보낸주소 체크시에 메일 발송 통계 List를 가져온다. 
		'getSendMailStatListGroupBy':function(page){
			var _self = this;
			var insertParam = {
					'START_DATE' :  new String(_self.$startDate.val()).replaceAll("-","")
				   ,'END_DATE'	:  new String(_self.$endDate.val()).replaceAll("-","")
				   ,'PAGE' : page
			};
			//페이지 저장
			_self.selectPage = page;
			$.ajax({  
				 url : _self._statGroupByListURL
				,type : 'POST'
				,data : insertParam
				,dataType : 'json'
				,success : function( data ) {
					
				   if(data.hasOwnProperty('statPagingList')){
						if(_self.$groupByChecked.is(":checked")==true ){
							_self.$listTable.find('tr').eq(0).find('th').eq(1).show();
							_self.$listTemplate.find('.nodataRow').find('td').attr("colspan",5);
						    _self.$listTemplate.find('.searchRow').find('.sendEmailTd').show();
							_self.list.createList( data.statPagingList, 'SEND_DATE',function( data, $row ){
							    _self.$listTemplate.find('.searchRow').find('.sendEmailTd').show();
					    	});
							
						}
				    	
				       // 페이징 초기화
				    	$('#statListPaging').paging({
							 current: page
							,max: (data.total)
							,onclick:function(e,page){
								_self.getSendMailStatListGroupBy(page);
							}
	    					,prev : '이전'
			    			,next : '다음'
						});
				    }
				 }
			});
				
		},
		
		//메일 발송 통계 List를 가져온다. 
		'getSendMailStatList' : function(page){
			var _self = this;
			var insertParam = {
					'START_DATE' :  new String(_self.$startDate.val()).replaceAll("-","")
				   ,'END_DATE'	:  new String(_self.$endDate.val()).replaceAll("-","")
				   ,'PAGE' : page
			};
			//페이지 저장
			_self.selectPage = page;
			$.ajax({  
				 url : _self._statListURL
				,type : 'POST'
				,data : insertParam
				,dataType : 'json'
				,success : function( data ) {
					
				   if(data.hasOwnProperty('statPagingList')){
					   if(_self.$groupByChecked.is(":checked")==false ){
							_self.$listTable.find('tr').eq(0).find('th').eq(1).hide();
							_self.$listTemplate.find('.nodataRow').find('td').attr("colspan",4);
						    _self.$listTemplate.find('.searchRow').find('.sendEmailTd').hide();
							_self.list.createList( data.statPagingList, 'SEND_DATE' , function( data, $row ) {
							    _self.$listTemplate.find('.searchRow').find('.sendEmailTd').hide();
							});
					   }
				       // 페이징 초기화
				    	$('#statListPaging').paging({
							 current: page
							,max: (data.total)
							,onclick:function(e,page){
								_self.getSendMailStatList(page);
							}
	    					,prev : '이전'
			    			,next : '다음'
						});
				    	 
				    }
				 }
			});
			
		},
		//조회버튼을 누르기전에 데이터를 확인한다. 
		'checkData': function(){
			if( ! this.checkInput( this.$startDate ,'날짜를 입력하세요') ) return false;
			if( ! this.checkInput( this.$endDate ,'날짜를 입력하세요') ) return false;
			if( ! this.dateCheck(this.$startDate, this.$endDate)){
				alert("앞칸의 날짜가 더 큽니다.");
				return false;
			}
			return true;
		},
		'checkInput' : function($input,str){
			if($input.val() == "") {
				alert(str);
				return false;
			}
			return true;
		},
		'dateCheck' : function($startDate,$endDate){
			var startDate = new String( $startDate.val() );
			var endDate = new String( $endDate.val() );
			var firstYear =  parseInt(startDate.substring(0, 4));
			var lastYear = parseInt( endDate.substring(0, 4));
 			var firstMonth = parseInt( startDate.substring(5,7 ) );
 			var lastMonth = parseInt( endDate.substring(5,7) );
 			var firstDay = parseInt( startDate.substring(8,10) );
 			var lastDay = parseInt( endDate.substring(8, 10) );
 			
		    if(firstYear == lastYear ){
		    	
			  if(firstMonth == lastMonth){
				  
 				 if(firstDay <= lastDay ){
 					 return true;
 				 }
 			  }
			  else if(firstMonth < lastMonth  ){
 				return true;
 			  }
			return false;
		  }
		    if(firstYear < lastYear ){
			 return true;
		  }
		
		},
		//날짜 계산 함수
		'dateCalc' : function( str ){ 
			var nowDate  = new Date();
		    var nowYear  = nowDate.getFullYear(); 
		    var nowMonth = nowDate.getMonth() + 1; 
		    var nowDay  = nowDate.getDate();
		    var date = nowDate.getDay(); 
		    var day = (nowDay - date)+1; //현재 날짜와 요일을 뺀 값.
		    var thisDate = nowYear + "-" + nowMonth + "-" + nowDay;
		    if(nowMonth < 10 ){nowMonth = "0" + nowMonth;}
		    if(nowDay < 10 ){nowDay = "0" + nowDay;}
		    
		    switch(str){
		    case "today" 	   : nowDate = nowYear + "-" + nowMonth + "-" + nowDay; return nowDate; break;
		    case "thisWeekSt"  : return this.findWeek(day,nowYear,nowMonth); break;
		    case "lastWeekSt"  : day = day-7; return this.findWeek(day, nowYear, nowMonth); break;
		    case "lastWeekEnd" : day = day-1; return this.findWeek(day, nowYear, nowMonth); break;
		    case "thisMonthSt" : nowDate.setDate(1);return this.converDateString(nowDate);break;
		    case "thisMonthEnd": nowDate.setMonth( nowDate.getMonth()+1 );nowDate.setDate(0);
	    						 return this.converDateString(nowDate); break;
		    case "lastMonthSt" : nowDate.setMonth( nowDate.getMonth() - 1 ); nowDate.setDate(1);
		    					 return this.converDateString(nowDate); break;
		    case "lastMonthEnd": nowDate.setMonth( nowDate.getMonth() ); nowDate.setDate(0);
		    					 return this.converDateString(nowDate);break;
		    }
		},
		// 주에 첫번째 날짜와 , 마지막 날짜를 가지고 오는 메소드
		'findWeek' : function(day,nowYear,nowMonth){ 
			if(day<=0){ // ex) 2013년 01월 01일때, 전년도 12월로 처리
	    		if(nowMonth-1 <= 0){
	    			nowYear = nowYear -1;
	    			nowMonth = 12;
	    			date = this.getLastDay(nowMonth-1,nowYear) + (day);
	    		    thisWeek = nowYear+"-"+nowMonth+"-"+date;
	    		}else { //ex) 2013년 08월 01일 일때 , 지난달로 처리
	    		 date = this.getLastDay(nowMonth-2,nowYear) + (day);
	    		 nowMonth = nowMonth-1;
	    		 if(nowMonth < 10 ){nowMonth = "0" + nowMonth;}
				 if(date < 10 ){date = "0" + date;}
	    		 thisWeek = nowYear+"-"+nowMonth+"-"+date;
	    	}
	       }else{ // 일반적인 경우
			 if(day < 10 ){day = "0" + day;}
	    	 thisWeek = nowYear+"-"+nowMonth+"-"+day;
	       }
	    	return thisWeek;
		},
		'getLastDay': function(month,year){ //해당 월에 마지막 날짜를 가져오는 메소드
			var nDays;
	    	 var nMonthDay = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
	    	 if (this.isLeapYear(year)){
	    	   nMonthDay[1]=29;
	    	 }
	    	 nDays=nMonthDay[month];
	    	 return nDays;
		},
		'converDateString' : function(dt){ // date를 String으로 바꾸는 메소드
	    	return dt.getFullYear() + "-" + this.addZero(eval(dt.getMonth()+1)) + "-" + this.addZero(dt.getDate());
		},
		'addZero' : function(i){
			var rtn = i + 100;
	    	return rtn.toString().substring(1,3);
		},
		'isLeapYear': function(year){ // 윤년을 체크하는 메소드
			
	    	return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
		},
		'onCreate'  : function( p_param, _viewClass ) {
			Bplat.log.debug( '[ship_main] onCreate Method' );
			// 초기화
			this.setElement();
			this.setEvent();
			this.$startDate.val( this.dateCalc("thisMonthSt")  );
			this.$endDate.val(   this.dateCalc("thisMonthEnd"));
			
		},
		'onRestart' : function( p_param ) {
			Bplat.log.debug( '[ship_main] onRestart Method' );
		},
		'onStart' : function( p_param ) {			
			Bplat.log.debug( '[ship_main] onStart Method' );
		},
		'onHidePopup' : function( p_param ) {
			Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
			
		},
		'onShowPopup' : function( p_param ) {
			Bplat.log.debug( '[ship_main] onShowPopup Method' );
		},
		'onStop'	: function() {
			Bplat.log.debug( '[ship_main] onStop Method' );			
		},
		'onDestroy' : function() {
			Bplat.log.debug( '[ship_main] onDestroy Method' );
		}
	} //end of methods
	
});
