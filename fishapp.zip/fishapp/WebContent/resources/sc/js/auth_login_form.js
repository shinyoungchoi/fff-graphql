defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._context = $('#context').val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$loginForm = $('#loginForm');
				this.$pwdInitBtn = $('#pwdInitBtn');
				this.$loginBtn = $("#loginBtn");
			},
			'setEvent'		: function() {
				var _self = this;
				
				var secret = "58A318A21396B2ECA0B8671D48E4A556";
				
				// 로그인 폼 전송
				
				_self.$loginBtn.click(function(){				
			    	var encrypt_id = CryptoJS.AES.encrypt($("#loginForm #jdg-id").val(), secret).toString();
			    	var encrypt_pwd = CryptoJS.AES.encrypt($("#loginForm #jdg-pw").val(), secret).toString();
    	
					$.ajax({
						type : 'POST'
						,url : _self._loginURL
					    ,dataType : 'json'
					    , data: {    LOGIN_ID :encrypt_id,
		          				 PWD: encrypt_pwd }
					     ,success : function( data ) {
					    	if( data.msg || null != data.msg ) {
					    		alert( data.msg );
					    		return false;
					    	}
					    	var url = _self._context + data.redirectUrl;
					    	Bplat.view.loadPage( url );
				    	}
					});
				});
				
				//비번초기화 버튼.
				this.$pwdInitBtn.click(function(){
					Bplat.view.loadPage( './pwd_init_form' );
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[login] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[login] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[login] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[login] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[login] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[login] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[login] onDestroy Method' );
			}		
	  }
});
