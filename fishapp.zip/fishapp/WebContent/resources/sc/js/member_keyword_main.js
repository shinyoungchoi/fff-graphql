defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = "/sc/member/keyword/list";
				this._recommnedListURL = "/sc/member/recommend/list";
				this._chartListUrl = "/sc/member/keyword/chart";
				this._recommendSaveUrl = "/sc/member/recommend/save";
				this._recommendUpdateUrl = "/sc/member/recommend/update";
				this._memSearchUrl = "/sc/member/keyword/memSearchList";
				this._page = 1;
				this._btnType="register";
			
			
				// element
				this.$listContainer = $('#memberList1Container');
				this.$listContainer2 = $('#memberList2Container');
				this.$listContainer3 = $('#memberList3Container');
				this.$listTemplate = $('#keywordHistoryTemplate');
				
				this.$recContainer = $('#recommentContainer');
				this.$recTemplate = $('#keywordRecommendTemplate');
				
				this.$memSearchContainer = $("#memSearchListContainer");
				this.$memSearchTemplate = $("#memSearchListTemplate");
				
				
			
				this.selectSubPage = ''; //포인트 내역 목록 페이징
				this.list_rec = new component.List({
					 'container' : this.$recContainer
					,'template' : this.$recTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.list2 = new component.List({
					 'container' : this.$listContainer2
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.list3 = new component.List({
					 'container' : this.$listContainer3
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this.list_mem = new component.List({
					 'container' : this.$memSearchContainer
					,'template' : this.$memSearchTemplate.find('.searchRow')
					,'nodata' : this.$memSearchTemplate.find('.nodataRow')
				});
				
				
				this.$selectedSortOption = "";
				this.$selectedChartOption = "";
				this.$selectedMemOption = "";
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$selectedSortOption = $(".btnSort:first");
				_self.$selectedChartOption = $(".chartSort:first");
				_self.$selectedMemOption = $(".memSort:first");
				
				$(".memSort").click(function(event){
					clicked = event.target.value;
					
					var oldSel = _self.$selectedMemOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedMemOption = newSel;
						
						_self.getSearchMemList(1);
					}
					
					return false;
				});
				
				$(".btnSort").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedSortOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedSortOption = newSel;
						
						_self.getHistoryList(1);
					}
					
					return false;
				});		
				
				$(".chartSort").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedChartOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedChartOption = newSel;
						
						_self.createChart();
					}
					
					return false;
				});	
				
				//검색어 조회
				$(".search_text_button").click(function(){
					_self.getSearchMemList(1);
					
				});

				//추천 검색어 등록
				$("#regBtn").click(function(){
					
					if($("#rec_word").val() == ""){
						alert("추천 검색어를 입력해주세요.");
						return;
					}
					
					var param = {
							KEYWORD : $("#rec_word").val()
							, USE_YN : $("#rec_useyn").val()
							, KEY_ORDER : $("#rec_order").val() 
					}
					
					var url = _self._recommendSaveUrl;
					if(_self._btnType == "update"){
						url = _self._recommendUpdateUrl;
					}
					
					$.ajax({
						 url : url
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if(data.result == "success"){
					    		alert("추천 키워드가 저장되었습니다.");
					    		$("#rec_word").val("");
					    		$("#rec_order").val("0"); 
					    		$("#rec_useyn").val("N");
					    		_self._btnType="register";
					    		_self.getRecommendList(1, null);
					    	}else{
					    		if(data.message != undefined && data.message != "")
					    			alert(data.message);
					    		else
					    			alert("저장도중 오류가 발생하였습니다.");
					    		return;
					    	}
					    	
					    }
					});
				});
				
				//답변 입력 취소시
				$("#cancleBtn").click(function(){
					$("#rec_word").val("");
					$("#rec_order").val("0"); 
					$("#rec_useyn").val("N");
					_self._btnType="register";
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$recContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.showDetail( $this );
				});
			},
			
			'showDetail' : function($tr){
				var _self = this;
				
				$('#recommentContainer tr').each(function(){
					$(this).attr("style", "background:#fff;");
				});
				
				var selectMemberId = $tr.attr('rowKey');
				$tr.attr("style", "background:#fce711;");
				
				var useYn = $tr.find("td:eq(1)").text();
				var keyOrder = $tr.find("td:eq(2)").text();
				var keyWord = $tr.attr("rowkey");
				
				$("#rec_word").val(keyWord);
				$("#rec_useyn").val(useYn);
				$("#rec_order").val(keyOrder);
				_self._btnType="update";
			},
			// 검색 히스토리 조회
			'getHistoryList' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'SORT': "DAYS"
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('keyword_list') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.keyword_list, 'SEQ' , function( data, $row ) {
				    		});
				    		
				    		var max_ = 0;
				    		if(data.keyword_list != null && data.keyword_list.length > 0){
				    			max_ = Math.ceil(data.keyword_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memberList1Paging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getHistoryList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			'getHistoryList2' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'SORT': "WEEKS"
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('keyword_list') ) {
				    		// 리스트 초기화
				    		_self.list2.createList( data.keyword_list, 'SEQ' , function( data, $row ) {
				    		});
				    		
				    		var max_ = 0;
				    		if(data.keyword_list != null && data.keyword_list.length > 0){
				    			max_ = Math.ceil(data.keyword_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memberList2Paging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getHistoryList2(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			'getHistoryList3' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'SORT': "MONTHS"
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('keyword_list') ) {
				    		// 리스트 초기화
				    		_self.list3.createList( data.keyword_list, 'SEQ' , function( data, $row ) {
				    		});
				    		
				    		var max_ = 0;
				    		if(data.keyword_list != null && data.keyword_list.length > 0){
				    			max_ = Math.ceil(data.keyword_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memberList3Paging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getHistoryList3(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			// 추천 검색어 리스트 반환
			'getRecommendList' : function( page, param ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._recommnedListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('recommend_list') ) {
				    		// 리스트 초기화
				    		_self.list_rec.createList( data.recommend_list, 'KEYWORD' , function( data, $row ) {

				    		});
				    		
				    		var max_ = 0;
				    		if(data.recommend_list != null && data.recommend_list.length > 0){
				    			max_ = Math.ceil(data.recommend_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#recommentContainerPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getRecommendList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			//검색어 별 회원 누적 검색 조회
			'getSearchMemList' : function( page, param, showDetailId ) {
				var _self = this;
				if($("#search_text").val() == ""){
					alert("검색어를 입력해주세요.");
					return;
				}
				
				var param = {
						KEYWORD : $("#search_text").val(),
						SORT: _self.$selectedMemOption.val(),
						PERPAGE : 10,
						PAGE : page
				}
				
				$.ajax({
					 url : _self._memSearchUrl
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('search_list') ) {
				    		// 리스트 초기화
				    		_self.list_mem.createList( data.search_list, 'MEM_ID' , function( data, $row ) {
				    		});
				    		
				    		var max_ = 0;
				    		if(data.search_list != null && data.search_list.length > 0){
				    			max_ = Math.ceil(data.search_list[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memSearchListPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getSearchMemList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	}
				    }
				});
			},
			'createChart': function(){
				var _self = this;
				var today  = new Date();
				
				 var options = {
				        chart: {
				            plotBackgroundColor: null,
				            plotBorderWidth: null,
				            plotShadow: false,
				            type: 'pie',
				            renderTo : 'container',
				        },
				        title: {
				            text: '전체 누적 검색어'
				        },
				        tooltip: {
				            pointFormat: '{series.name}: <b>  {point.y}</b>({point.percentage:.1f}%)'
				        },
				        plotOptions: {
				            pie: {
				                allowPointSelect: true,
				                cursor: 'pointer',
				                dataLabels: {
				                    enabled: true,
				                    format: '<b>{point.name}</b>: {point.y}회',
				                    style: {
				                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
				                    }
				                }
				            }
				        },
				        series: [{
				            name: '키워드 누적횟수',
				            colorByPoint: true,
				            data: []
				        }]
				    };
				
				 var options_guest = {
					        chart: {
					            plotBackgroundColor: null,
					            plotBorderWidth: null,
					            plotShadow: false,
					            type: 'pie',
					            renderTo : 'container_guest',
					        },
					        title: {
					            text: '방문회원 누적 검색어'
					        },
					        tooltip: {
					            pointFormat: '{series.name}: <b>  {point.y}</b>({point.percentage:.1f}%)'
					        },
					        plotOptions: {
					            pie: {
					                allowPointSelect: true,
					                cursor: 'pointer',
					                dataLabels: {
					                    enabled: true,
					                    format: '<b>{point.name}</b>: {point.y}회',
					                    style: {
					                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
					                    }
					                }
					            }
					        },
					        series: [{
					            name: '키워드 누적횟수',
					            colorByPoint: true,
					            data: []
					        }]
					    };
				 
				 var options_users = {
					        chart: {
					            plotBackgroundColor: null,
					            plotBorderWidth: null,
					            plotShadow: false,
					            type: 'pie',
					            renderTo : 'container_users',
					        },
					        title: {
					            text: '포탈회원 누적 검색어'
					        },
					        tooltip: {
					            pointFormat: '{series.name}: <b>  {point.y}</b>({point.percentage:.1f}%)'
					        },
					        plotOptions: {
					            pie: {
					                allowPointSelect: true,
					                cursor: 'pointer',
					                dataLabels: {
					                    enabled: true,
					                    format: '<b>{point.name}</b>: {point.y}회',
					                    style: {
					                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
					                    }
					                }
					            }
					        },
					        series: [{
					            name: '키워드 누적횟수',
					            colorByPoint: true,
					            data: []
					        }]
					    };
				$.ajax({
					 url : _self._chartListUrl
					,type : 'POST'
					, data : { SORT: _self.$selectedChartOption.val()}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		options.series[0].data = data.result.all;
				    		 var chart = new Highcharts.chart(options);
				    		 options_guest.series[0].data = data.result.guest;
				    		 var chart_guest = new Highcharts.chart(options_guest);
				    		 
				    		 options_users.series[0].data = data.result.users;
				    		 var chart_users = new Highcharts.chart(options_users);
				    	}
				    }
				});
			  
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 검색 히스토리내역 조회
				this.getHistoryList('1', p_param);
				this.getHistoryList2('1', p_param);
				this.getHistoryList3('1', p_param);
				
				// 관리자 추천 검색어 조회
				this.getRecommendList('1', p_param);
				//차트 생성
				this.createChart();
			
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
