defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveURL = $('#reserveURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				
				//신규 등록시
				this.$regBtn = $('#regBtn');
				//장르 등록 버튼
				this.$regSubmitBtn = $('#regSubmitBtn');
				//상세 -> 수정시
				this.$updateSubmitBtn = $('#updateSubmitBtn');
				this.$mfyBtn = $('#modifyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				//장르 복제
				this.$dupConfBtn = $("#dupConf");
				this.$dupBtn = $('#dupBtn');
				this.$dupCancelBtn = $('#dupCancelBtn');
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				this.$detailForm = $('#scheduleConfDetailForm');
				this.$insertForm = $('#scheduleConfInsertForm');
				this.$updateForm = $('#scheduleConfUpdateForm');
				this.$scheduleConfUpdateForRegisterForm = $("#scheduleConfUpdateForRegisterForm");
				
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				
				this.fileList = null;
				this.prepare1FileList= null;
				this.prepare2FileList= null;
				this.fishing1FileList= null;
				this.fishing2FileList= null;
				
			},
			'setEvent'		: function() {
				var _self = this;
							
				// datePicker 이벤트선언
				_self.$insertForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$updateForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$scheduleConfUpdateForRegisterForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
			
								
				//복제하기(수정폼처럼 보이는 등록 폼)
				_self.$dupConfBtn.click(function(){
					_self.selectFormShow('duplicate', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ') );
				});
				
				//복제된 장르 등록
				_self.$dupBtn.click(function(){
					_self.duplicateConf();
					return false;
				});				
				
				// 신규등록 취소
				_self.$dupCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				
				
				// 보조 select box 변경
				$('.helpSel').change( function() {
					var $this = $( this );
					var val = $this.val();
					if( '' !== val ) {
						var prevVal = $this.prev().val();
						if( '' === prevVal ) $this.prev().val( $this.find('option:selected').text() );
						else $this.prev().val(prevVal + ', ' + $this.find('option:selected').text() );
					}
				});
				
				
				// 업체 변경 시 객실 ID 리스트 반환.(등록)
				_self.$insertForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.getRoomList("register", $(this).val());
				});
				
				// 객실변경 시 숙박가능인원 변경(등록)
				_self.$insertForm.find('[data-key=ROOM_IDS]').change( function() {
					var $this = $( this ).find('option:selected');
					var psgrCnt = $this.attr("pcnt");
					var pstdman = $this.attr("pstdman");
					var ptype = ( $this.attr("ptype") == 'P' ) ? "펜션" : "게스트하우스";					
					_self.$insertForm.find("[data-key=SUB_TITLE]").val($this.text());
					_self.$insertForm.find("[id=regAddInfo]").html("[ 숙박타입 : "+ ptype+" ]");
					_self.$insertForm.find("[id=regPsgrInfo]").html("[ 기본인원 : "+pstdman+"명 , 총 숙박가능인원 : "+ psgrCnt +"명 ]");
				});
				
							
				// 업체 변경 시 객실 ID 리스트 반환.(수정)
				_self.$updateForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.getRoomList("update", $(this).val());
				});
				
				// 객실변경 시 숙박가능인원 변경(수정)
				_self.$updateForm.find('[data-key=ROOM_IDS]').change( function() {
					var $this = $( this ).find('option:selected');
					var psgrCnt = $this.attr("pcnt");
					var pstdman = $this.attr("pstdman");
					var ptype = ( $this.attr("ptype") == 'P' ) ? "펜션" : "게스트하우스";					
					_self.$updateForm.find("[data-key=SUB_TITLE]").val($this.text());
					_self.$updateForm.find("[id=updateAddInfo]").html("[ 숙박타입 : "+ ptype+" ]");
					_self.$updateForm.find("[id=updatePsgrInfo]").html("[ 기본인원 : "+pstdman+"명, 총 숙박가능인원 : "+ psgrCnt +"명 ]");					
				});
								
				// 업체 변경 시 객실 ID 리스트 반환.(복제)
				_self.$scheduleConfUpdateForRegisterForm.find('[data-key=SHIP_ID]').change( function() {
					var $this = $( this ).find('option:selected');
					_self.getRoomList("duplicate", $(this).val());
				});
				
				// 객실변경 시 숙박가능인원 변경(복제)
				_self.$scheduleConfUpdateForRegisterForm.find('[data-key=ROOM_IDS]').change( function() {
					var $this = $( this ).find('option:selected');
					var psgrCnt = $this.attr("pcnt");
					var pstdman = $this.attr("pstdman");
					var ptype = ( $this.attr("ptype") == 'P' ) ? "펜션" : "게스트하우스";					
					_self.$scheduleConfUpdateForRegisterForm.find("[data-key=SUB_TITLE]").val($this.text());
					_self.$scheduleConfUpdateForRegisterForm.find("[id=updateAddInfo]").html("[ 숙박타입 : "+ ptype+" ]");
					_self.$scheduleConfUpdateForRegisterForm.find("[id=updatePsgrInfo]").html("[ 기본인원 : "+pstdman+"명, 총 숙박가능인원 : "+ psgrCnt +"명 ]");					
				});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getScheduleList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					var shipId = _self.$srhSel.find('option:selected').val();
					if(shipId == ''){
						alert("업체 선택을 먼저 해주세요");
						return;
					}
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$regSubmitBtn.click( function() {
					_self.insertSchedule();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				//수정 취소
				_self.$mfyCancelBtn.click(function(){
					_self.selectFormShow('none');
				});
								
				// 수정화면 보이기
				_self.$updateSubmitBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ') );
				});
				
				//수정하기
				_self.$mfyBtn.click(function(){
					_self.updateSchedule();
				});
				
				//삭제하기
				_self.$delBtn.click(function(){
					if(!confirm("삭제하시겠습니까?")){
						return false;
					}
					_self.deleteSchedule();
					
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
				
				
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'CONF_SEQ'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			
			// 승선가능인원 동적 변경
			'createOptionSelect' : function( $sel, cnt ) {
				$sel.empty();
				for( var i=0 ; i < cnt ; i++ ) {
					$sel.append( $('<option val="'+(i+1)+'">'+(i+1)+'</option>') );
				}
				$sel.val( cnt );
			},
			'getRoomList': function(type, shipId, roomId, psgrCnt){
				var _self = this;
				var param = {};
				param.SHIP_ID = shipId
				$.ajax({
					 url : "/sc/pension/search_room"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('search_room') ) {
				    		var list = data.search_room;
				    		if(type == "register"){
				    			var html = "<option value=''>선택해주세요.</option>";
				    			for(var i = 0 ;i < list.length ;i ++){
				    				var item = list[i];
				    				html += "<option value='"+item.ROOM_ID+"' pcnt='"+item.PSGR_CNT+"' pstdman='"+item.STD_MAN+"' ptype='"+item.ROOM_TYPE+"'>"+item.ROOM_NM+"</option>";
				    			}
				    			_self.$insertForm.find("[data-key='ROOM_IDS']").html(html);
				    		}else if(type == "update"){
				    			var html = "<option value=''>선택해주세요.</option>";
				    			for(var i = 0 ;i < list.length ;i ++){
				    				var item = list[i];				    			
				    				html += "<option value='"+item.ROOM_ID+"' pcnt='"+item.PSGR_CNT+"' pstdman='"+item.STD_MAN+"' ptype='"+item.ROOM_TYPE+"'>"+item.ROOM_NM+"</option>";
				    			}
				    			_self.$updateForm.find("[data-key='ROOM_IDS']").html(html);
				    			if(roomId != '' && roomId != null && roomId != undefined){
				    				_self.$updateForm.find("[data-key='ROOM_IDS'] option[value='"+roomId+"']").attr("selected","selected");
				    				//선택된 방에 해당되는 숙박가능인원 정보 설정.
				    				var pcnt = _self.$updateForm.find("[data-key='ROOM_IDS'] option:selected").attr("pcnt");
				    				var ptype = _self.$updateForm.find("[data-key='ROOM_IDS'] option:selected").attr("ptype");
				    				ptype = ( ptype== 'P' ) ? "펜션" : "게스트하우스";		
				    				var pstdman = _self.$updateForm.find("[data-key='ROOM_IDS'] option:selected").attr("pstdman");
				    				var pcnt = _self.$updateForm.find("[data-key='ROOM_IDS'] option:selected").attr("pcnt");
				    				_self.$updateForm.find("[id=updateAddInfo]").html("[ 숙박타입 : "+ ptype+" ]");
									_self.$updateForm.find("[id=updatePsgrInfo]").html("[ 기본인원 : "+pstdman+"명, 총 숙박가능인원 : "+ pcnt +"명 ]");
				    			}
				    			
				    		}else if(type == "duplicate"){
				    			var html = "<option value=''>선택해주세요.</option>";
				    			for(var i = 0 ;i < list.length ;i ++){
				    				var item = list[i];				    			
				    				html += "<option value='"+item.ROOM_ID+"' pcnt='"+item.PSGR_CNT+"' pstdman='"+item.STD_MAN+"' ptype='"+item.ROOM_TYPE+"'>"+item.ROOM_NM+"</option>";
				    			}
				    			_self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS']").html(html);
				    			if(roomId != '' && roomId != null && roomId != undefined){
				    				_self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS'] option[value='"+roomId+"']").attr("selected","selected");
				    				//선택된 방에 해당되는 숙박가능인원 정보 설정.
				    				var pcnt = _self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS'] option:selected").attr("pcnt");
				    				var ptype = _self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS'] option:selected").attr("ptype");
				    				ptype = ( ptype== 'P' ) ? "펜션" : "게스트하우스";		
				    				var pstdman = _self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS'] option:selected").attr("pstdman");
				    				var pcnt = _self.$scheduleConfUpdateForRegisterForm.find("[data-key='ROOM_IDS'] option:selected").attr("pcnt");
				    				_self.$scheduleConfUpdateForRegisterForm.find("[id=duplicateAddInfo]").html("[ 숙박타입 : "+ ptype+" ]");
									_self.$scheduleConfUpdateForRegisterForm.find("[id=duplicatePsgrInfo]").html("[ 기본인원 : "+pstdman+"명, 총 숙박가능인원 : "+ pcnt +"명 ]");
				    			}
				    			
				    		}
				    	}
				    }
				});
			},
			// 장르  목록 조회
			'getScheduleList' : function( page, param, showDetailId ) {
				var _self = this;
				console.log(param);
				console.log(showDetailId);
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/pension/genreList"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('scheduleList') ) {
				    		
				    		var shipName =  _self.$srhSel.find("option:selected").text();
				    		if (shipName == '*선박선택')
				    		{
				    			shipName = "전체 선박";
				    		}
				    		
							$('#span_ship_nm').text(shipName + '의 장르');
							$('#span_ship_nm').show();
							
				    		// 리스트 초기화
				    		_self.list.createList( data.scheduleList, 'CONF_SEQ');
				    						    		
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getScheduleList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.scheduleList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 장르 등록
			'insertSchedule' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
			
				// 출조일 가공
				var schdDateFr = $insertForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $insertForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = "1";
				var roomType = $insertForm.find("[data-key=ROOM_TYPE]").val();
				var psgrCnt =  $insertForm.find('[data-key=ROOM_IDS] option:selected').attr("pcnt");
				
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_FR' : schdDateFr
					, 'SCHD_TO' : schdDateTo
					, 'SCHD_TIME_TYPE' : fishTimeType
					, 'PSGR_CNT': psgrCnt
					, 'ROOM_ID' : $insertForm.find('[data-key=ROOM_IDS] option:selected').val()
					, 'SCHD_TIME' : '0000'
					, 'SUB_TITLE' : $insertForm.find('[data-key=SUB_TITLE]').val()
					, 'REG_FEE' : $insertForm.find('[data-key=REG_FEE]').val()
					, 'HOL_FEE' : $insertForm.find('[data-key=HOL_FEE]').val()
					, 'REG_PNT_RATE' : $insertForm.find('[data-key=REG_PNT_RATE]').val()
					, 'HOL_PNT_RATE' : $insertForm.find('[data-key=HOL_PNT_RATE]').val()
					, 'REG_DSC_FEE' : $insertForm.find('[data-key=REG_DSC_FEE]').val()
					, 'HOL_DSC_FEE' : $insertForm.find('[data-key=HOL_DSC_FEE]').val()
					, 'LOC_DESC' : $insertForm.find('[data-key=LOC_DESC]').val()
					, 'SERVICE_INFO' : $insertForm.find('[data-key=SERVICE_INFO]').val()
					, 'DESCR' : $insertForm.find('[data-key=DESCR]').val()
					, 'PREPARE' : $insertForm.find('[data-key=PREPARE]').val()
				};
				
				if(roomType == 'P'){
					if(insertParam.HOL_FEE == '' || insertParam.HOL_FEE == undefined){
						alert("1박당 요금을 입력해주세요.");
						return;
					}
				}
				
				if(insertParam.HOL_FEE == '' || insertParam.HOL_FEE == undefined){
					insertParam.HOL_FEE = "0";
				}
		
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/pension/insertGenre"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/pension/genre?SHIP_ID="+ insertParam.SHIP_ID;
				    		return;
				    	}
				    	
				    	if( data.hasOwnProperty('error') ) {
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("오류가 발생하였습니다.");
				    	return;
				    }
				});
				
			},
			'duplicateConf' : function(){
				//복제한 장르 저장.
				var _self = this;
				var $scheduleConfUpdateForRegisterForm = _self.$scheduleConfUpdateForRegisterForm;
				
				// validation
				if( !jdg.util.validator( $scheduleConfUpdateForRegisterForm, true ) ) return false;
				// 출조일 가공
				var schdDateFr = $scheduleConfUpdateForRegisterForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $scheduleConfUpdateForRegisterForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = "1";
				var roomType = $scheduleConfUpdateForRegisterForm.find("[data-key=ROOM_TYPE]").val();
				var psgrCnt =  $scheduleConfUpdateForRegisterForm.find('[data-key=ROOM_IDS] option:selected').attr("pcnt");
				
				var insertParam = {
					  'SHIP_ID' : $scheduleConfUpdateForRegisterForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'SCHD_FR' : schdDateFr
					, 'SCHD_TO' : schdDateTo
					, 'SCHD_TIME_TYPE' : fishTimeType
					, 'ROOM_ID' : $scheduleConfUpdateForRegisterForm.find('[data-key=ROOM_IDS] option:selected').val()
					, 'SCHD_TIME' : '0000'
					, 'SUB_TITLE' : $scheduleConfUpdateForRegisterForm.find('[data-key=SUB_TITLE]').val()					
					, 'PSGR_CNT' : psgrCnt
					, 'REG_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_FEE]').val()
					, 'HOL_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_FEE]').val()
					, 'REG_PNT_RATE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_PNT_RATE]').val()
					, 'HOL_PNT_RATE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_PNT_RATE]').val()
					, 'REG_DSC_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=REG_DSC_FEE]').val()
					, 'HOL_DSC_FEE' : $scheduleConfUpdateForRegisterForm.find('[data-key=HOL_DSC_FEE]').val()
					, 'LOC_DESC' : $scheduleConfUpdateForRegisterForm.find('[data-key=LOC_DESC]').val()
					, 'SERVICE_INFO' : $scheduleConfUpdateForRegisterForm.find('[data-key=SERVICE_INFO]').val()
					, 'FISH_KIND' : $scheduleConfUpdateForRegisterForm.find('[data-key=FISH_KIND]').val()
					, 'DESCR' : $scheduleConfUpdateForRegisterForm.find('[data-key=DESCR]').val()
					, 'PREPARE' : $scheduleConfUpdateForRegisterForm.find('[data-key=PREPARE]').val()
				};
					
				if(roomType == 'P'){
					if(insertParam.HOL_FEE == '' || insertParam.HOL_FEE == undefined){
						alert("1박당 요금을 입력해주세요.");
						return;
					}
				}	
				
				
				if(insertParam.HOL_FEE == '' || insertParam.HOL_FEE == undefined){
					insertParam.HOL_FEE = "0";
				}
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/pension/insertGenre"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/schedule/conf?SHIP_ID="+ insertParam.SHIP_ID;
				    		return;
				    	}
				    	
				    	if( data.hasOwnProperty('error') ) {
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("오류가 발생하였습니다.");
				    	return;
				    }
				});
			},
			// 장르  수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 출조일 가공
				var schdDateFr = $updateForm.find('[data-key=SCHD_FR]').val();
				schdDateFr = schdDateFr.replaceAll('-','');
				var schdDateTo = $updateForm.find('[data-key=SCHD_TO]').val();
				schdDateTo = schdDateTo.replaceAll('-','');
				var fishTimeType = "1";
				var roomType = $updateForm.find("[data-key=ROOM_TYPE]").val();
				var psgrCnt =  $updateForm.find('[data-key=ROOM_IDS] option:selected').attr("pcnt");
				
				var updateParam = {
						'CONF_SEQ': _self.selectScheduleId
						, 'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()
						, 'SCHD_FR' : schdDateFr
						, 'SCHD_TO' : schdDateTo
						, 'SCHD_TIME_TYPE' : fishTimeType
						, 'ROOM_ID' : $updateForm.find('[data-key=ROOM_IDS] option:selected').val()
						, 'SCHD_TIME' : '0000'
						, 'SUB_TITLE' : $updateForm.find('[data-key=SUB_TITLE]').val()
						, 'PSGR_CNT' : psgrCnt
						, 'REG_FEE' : $updateForm.find('[data-key=REG_FEE]').val()
						, 'HOL_FEE' : $updateForm.find('[data-key=HOL_FEE]').val()
						, 'REG_PNT_RATE' : $updateForm.find('[data-key=REG_PNT_RATE]').val()
						, 'HOL_PNT_RATE' : $updateForm.find('[data-key=HOL_PNT_RATE]').val()
						, 'REG_DSC_FEE' : $updateForm.find('[data-key=REG_DSC_FEE]').val()
						, 'HOL_DSC_FEE' : $updateForm.find('[data-key=HOL_DSC_FEE]').val()
						, 'LOC_DESC' : $updateForm.find('[data-key=LOC_DESC]').val()
						, 'SERVICE_INFO' : $updateForm.find('[data-key=SERVICE_INFO]').val()
						, 'DESCR' : $updateForm.find('[data-key=DESCR]').val()
						, 'PREPARE' : $updateForm.find('[data-key=PREPARE]').val()					
				};
				
				if(roomType == 'P'){
					if(updateParam.HOL_FEE == '' || updateParam.HOL_FEE == undefined){
						alert("1박당 요금을 입력해주세요.");
						return;
					}
				}			
				
				
				if(updateParam.HOL_FEE == '' || updateParam.HOL_FEE == undefined){
					updateParam.HOL_FEE = "0";
				}
				
				$.ajax({
					 url : "/sc/pension/updateGenre"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		location.href="/sc/pension/genre?PAGE="+_self.selectPage+"&SHIP_ID="+updateParam.SHIP_ID+"&CONF_SEQ="+_self.selectScheduleId
				    		return;
				    	}else{
				    		if( data.hasOwnProperty('error') ) {
					    		alert(data.error);
					    		return;
					    	}
					    	
					    	alert("오류가 발생하였습니다.");
					    	return;
				    	}
				    }
				});
			},
			// 장르 삭제
			'deleteSchedule' : function() {
				var _self = this;
				if(_self.selectScheduleId == ""){
					alert("삭제하실 장르를 목록에서 선택해주세요.");
					return;
				}
				
				$.ajax({
					 url : "/sc/schedule/deleteConf"
					,type : 'POST'
					,data : {
						 'CONF_SEQ' : _self.selectScheduleId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				var $scheduleConfUpdateForRegisterForm = _self.$scheduleConfUpdateForRegisterForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					
					if(data.ROOM_TYPE == 'P'){
						$detailForm.find("[data-key=ROOM_TYPE_STR]").html("펜션형");
					}else if(data.ROOM_TYPE == 'G'){
						$detailForm.find("[data-key=ROOM_TYPE_STR]").html("게스트하우스형");
					}
					
					if(data.DESCR != "" && data.DESCR != undefined)
						$detailForm.find("[data-type=DESCR]").html(data.DESCR.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=DESCR]").html("");
					
					if(data.SERVICE_INFO != "" && data.SERVICE_INFO != undefined)
						$detailForm.find("[data-type=SERVICE_INFO]").html(data.SERVICE_INFO.replaceAll("\n","<br>"));
					else
						$detailForm.find("[data-type=SERVICE_INFO]").html("");
									
						
					$detailForm.show();
				}
				// 신규등록
				else if('insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
										
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					
					// 출조일 셋팅
					var $schdDateFr = $insertForm.find('[data-type=SCHD_FR]');
					var $schdDateTo = $insertForm.find('[data-type=SCHD_TO]');
					$schdDateFr.val('');
					$schdDateTo.val('');
					
					$insertForm.show();
							

					var shipId = $("#searchShipSel").val();					
					if(shipId != "" && shipId != undefined){
						$("select[name='regShipId']").val(shipId).trigger("change");
					}
					
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					//객실 ID부분 생성.
					_self.getRoomList("update", data.SHIP_ID, data.ROOM_ID, data.PSGR_CNT);
				
					var schdFr = data.SCHD_FR;
					var schdTo = data.SCHD_TO;
					var from = schdFr.substring(0,4)+"-"+ schdFr.substring(4,6)+"-"+ schdFr.substring(6,8);
					var to = schdTo.substring(0,4)+"-"+ schdTo.substring(4,6)+"-"+ schdTo.substring(6,8);
					$updateForm.find("[data-key=SCHD_FR]").val(from);
					$updateForm.find("[data-key=SCHD_TO]").val(to);									
					
					$updateForm.show();
				}
				//복제
				else if( 'duplicate' === mode){
					$detailForm.hide();
					$insertForm.hide();
					$updateForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $scheduleConfUpdateForRegisterForm, data );
					
					//객실 ID부분 생성.
					_self.getRoomList("duplicate", data.SHIP_ID, data.ROOM_ID, data.PSGR_CNT);
					
					var schdFr = data.SCHD_FR;
					var schdTo = data.SCHD_TO;
					var from = schdFr.substring(0,4)+"-"+ schdFr.substring(4,6)+"-"+ schdFr.substring(6,8);
					var to = schdTo.substring(0,4)+"-"+ schdTo.substring(4,6)+"-"+ schdTo.substring(6,8);
					$scheduleConfUpdateForRegisterForm.find("[data-key=SCHD_FR]").val(from);
					$scheduleConfUpdateForRegisterForm.find("[data-key=SCHD_TO]").val(to);
					
					
					$scheduleConfUpdateForRegisterForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('CONF_SEQ') ) {
					var confSeq = p_param.CONF_SEQ;
					var shipId = p_param.SHIP_ID;
					var page = p_param.PAGE;
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == shipId){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					// 출조스케쥴 목록 조회
					this.getScheduleList(page, {SHIP_ID : shipId} , confSeq);
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getScheduleList(1, {SHIP_ID : p_param.SHIP_ID});
				} else {
					// 출조스케쥴 목록 조회
					this.getScheduleList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
