defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishListURL = $('#fishListURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishUpdateURL = $('#fishUpdateURL').val();
				this._fishDeleteURL = $('#fishDeleteURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#fishListContainer');
				this.$listTemplate = $('#fishListTemplate');
				this.$detailForm = $('#fishDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				// form
				this.$srchForm = $('#fishSearchForm');
				this.$insertForm = $('#fishInsertForm');
				this.$updateForm = $('#fishUpdateForm');
				// static variable
				this.selectFishId = '';
				this.selectDetailData = {};
				this.selectFileList = null;
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				this.fileList = null;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// datePicker 이벤트선언
				_self.$insertForm.find('[data-key=FISH_DATE]').datepick({dateFormat:'yyyy-mm-dd'});
				_self.$updateForm.find('[data-key=FISH_DATE]').datepick({dateFormat:'yyyy-mm-dd'});
				
				// 조회
				_self.$srchForm.submit(function() {
					// 조과목록조회
					_self.getFishList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertFish();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectDetailData );
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateFish();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow('none');
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteFish();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectFishId = $tr.attr('rowKey');
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				// 조과 상세 조회
				$.ajax({
					 url : _self._fishDetailURL
					,type : 'POST'
					,data : {'GALR_ID' : _self.selectFishId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		detail.FISH_DATE = jdg.util.replaceDate(detail.FISH_DATE);
				    		_self.selectDetailData = detail;
							_self.selectFormShow('search', detail);
				    	}
				    }
				});
			},
			// 조과 목록 조회
			'getFishList' : function( page, param, showDetailId ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('fishList') ) {
				    		var fishList = data.fishList;
				    		$.each( fishList, function(idx, data) {
				    			data.FISH_DATE = jdg.util.replaceDate(data.FISH_DATE);
				    		});
				    		// 리스트 초기화
				    		_self.list.createList( fishList, 'GALR_ID', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    				$row.find('[data-key=CREATED_NICK]').text( data.UPDATED_NICK ? '/' + data.UPDATED_NICK : '' );
				    			}
				    		});
				    		// 페이징 초기화
				    		$('#fishListPaging').paging({
								current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getFishList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.fishList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 조과 등록
			'insertFish' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
			
				var fishName = $insertForm.find('[data-key=FISH_NAME]').val();
				if(fishName != '')
					fishName = fishName.replace(/(\s*)/g, '');
				
				// 조과 등록
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'TYPE_CD' : $insertForm.find('[data-key=TYPE_CD] option:selected').val()
					, 'FISH_DATE' : $insertForm.find('[data-key=FISH_DATE]').val().replaceAll('-','')
					, 'TITLE' : $insertForm.find('[data-key=TITLE]').val()
					, 'FISH_NAME' :  fishName
					, 'PEOPLE_ONBOARD' :  $insertForm.find('[data-key=PEOPLE_ONBOARD]').val()
					, 'LOC_DESC' : $insertForm.find('[data-key=LOC_DESC]').val()
					, 'CONTENT' : $insertForm.find('[data-key=CONTENT]').val()
					, 'IMG_ID' : JSON.stringify( _self.fileList.getFileList() )
					, 'HEADER_TEXT': $insertForm.find('[data-key=HEADER_TEXT]').val().replace(/\n/g, "<br>")
					, 'FOOTER_TEXT': $insertForm.find('[data-key=FOOTER_TEXT]').val().replace(/\n/g, "<br>")
				};
				$.ajax({
					 url : _self._fishInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});
				return false;
			},
			// 조과수정
			'updateFish' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				var fishName = $updateForm.find('[data-key=FISH_NAME]').val();
				if(fishName != '')
					fishName = fishName.replace(/(\s*)/g, '');
				
				var updateParam = {
					  'GALR_ID' : _self.selectFishId
					, 'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'TYPE_CD' : $updateForm.find('[data-key=TYPE_CD] option:selected').val()
					, 'FISH_DATE' : $updateForm.find('[data-key=FISH_DATE]').val().replaceAll('-','')
					, 'TITLE' : $updateForm.find('[data-key=TITLE]').val()
					, 'FISH_NAME' :  fishName
					, 'PEOPLE_ONBOARD' :  $updateForm.find('[data-key=PEOPLE_ONBOARD]').val()
					, 'LOC_DESC' : $updateForm.find('[data-key=LOC_DESC]').val()
					, 'CONTENT' : $updateForm.find('[data-key=CONTENT]').val()
					, 'IMG_ID' : JSON.stringify( _self.fileList.getFileList() )
					, 'HEADER_TEXT': $updateForm.find('[data-key=HEADER_TEXT]').val().replace(/\n/g, "<br>")
					, 'FOOTER_TEXT': $updateForm.find('[data-key=FOOTER_TEXT]').val().replace(/\n/g, "<br>")
				};
				
				$.ajax({
					 url : _self._fishUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getFishList( _self.selectPage, {'SHIP_ID' : _self.$srhSel.find('option:selected').val()}, _self.selectFishId);
				    	}
				    }
				});
			},
			// 조과삭제
			'deleteFish' : function() {
				var _self = this;
				$.ajax({
					 url : _self._fishDeleteURL
					,type : 'POST'
					,data : {
						 'GALR_ID' : _self.selectFishId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					console.log(data);
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					// 디테일이미지리스트
		    		var imgList = jdg.util.toArray( data.imageList );
		    		var $imgContainer = _self.$detailForm.find('[data-type=IMAGE]');
		    		jdg.util.createImgList( imgList, $imgContainer );
					_self.selectFileList = imgList;

					_self.$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $insertForm.attr('id')
						,'container' : $insertForm.find('[data-type=IMAGE_LIST]')
					});
					_self.fileList.init();

					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					
					if (data.HEADER_TEXT)
						data.HEADER_TEXT = data.HEADER_TEXT.replace(/<br>/g, "<br>");
					
					if (data.FOOTER_TEXT)
						data.FOOTER_TEXT = data.FOOTER_TEXT.replace(/<br>/g, "<br>");
					
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $updateForm.attr('id')
						,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
					});
					_self.fileList.init(_self.selectFileList);

					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 조과목록조회
				this.getFishList('1');
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});