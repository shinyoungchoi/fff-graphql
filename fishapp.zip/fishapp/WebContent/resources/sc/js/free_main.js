defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizURL = $('#bizURL').val();
				this._shipListURL = $('#shipListURL').val();
				this._registerCompleteURL = $("#registerCompleteURL").val();
				this._deleteFreeURL = $("#deleteFreeURL").val();
			
				this._excelURL = $('#memberSearchURL').val();
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$detailForm = $('#shipDetailForm');
				
				this.$prepaidlistContainer = $("#msgHistoryListContainer");
				this.$prepaidlistTemplate = $("#prepaidlistTemplate");
				
				
				//기본이미지 추가(파일업로드가 아닌 서버에 있는 이미지 선택)
				this.$basicfileAddBtn = $('.basicfileAddBtn');		
				
				this.$popupSelectBasicImage = $('#popupSelectBasicImage');	
				
				// form
				this.$srchForm = $('#shipSearchForm');
				this.$insertForm = $('#shipInsertForm');
				this.$updateForm = $('#shipUpdateForm');
				
				// static variable
				this.selectShipId = '';
				this.selectedRowData = {};
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
		
				this.redirectNameTemp = "";
				
				// 배경이미지 선택용
				var _flstRow = $(".fileListRow2");
				
				this._bgImgloaded = false;
				
				this._isSaving = false;				
			},
			'setEvent'		: function() {
				var _self = this;
				// 조회
				_self.$srchForm.submit(function() {
					var $this = $(this);
					var param = {};
					var searchText = $.trim($this.find('#searchText').val());
					var checkedTerm = $(this).find(':radio[name=shipSearchTerms]:checked').attr('id');
					param = (checkedTerm == 'shipName' ? {'SHIP_NAME' : searchText} : {'SHIP_ID' : searchText} );
					// 회원목록조회
					_self.getShipList('1', param);
					return false;
				});
				
				$("#searchType").on("change", function(){
					var value = $(this).val();
					var param = {};
					_self.getShipList('1', param);
				});
				
				$("#shipListContainer").on("change",".comp_btn", function(){
					var seq = $(this).attr("seq");
					var value = $(this).val();
					if(value == 'Y'){
						if(confirm("무료홈피 등록 완료 처리하시겠습니까? \n무료홈피 등록 완료 시 문자가 함께 발송됩니다.")){
							$.ajax({
								 url : _self._registerCompleteURL
								,type : 'POST'
								,data : { SEQ : seq , COMP_YN : 'Y'}
								,dataType : 'json'
								,success : function(data){
									if(data.result == "fail"){
										alert("처리상태 수정도중 오류가 발생하였습니다.");
										return;
									}									
									alert("수정되었습니다.");
									location.reload();								
								}
							});
						}
					}					
					return false;
				});
				
			
				$("#shipListContainer").on("click",".delete_btn", function(){
					var seq = $(this).attr("seq");
					if(confirm("신청된 내역을 삭제하시시겠습니까? \n선박 및 사업체 , 사업자 정보가 모두 삭제됩니다.")){
						$.ajax({
							 url : _self._deleteFreeURL
							,type : 'POST'
							,data : { SEQ : seq }
							,dataType : 'json'
							,success : function(data){
								console.log(data);
								if(data.result == "fail"){
									alert("삭제도중 오류가 발생하였습니다.");
									return;
								}								
								alert("삭제되었습니다");
								location.reload();
							}
						});
					}
				});
				
			},
	
			'closePopup' :function(){
				var _self = this;
				_self.$popupSelectBasicImage.hide();
		        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
		        	$(this).attr("checked", false);
		        });
			},		
					
			// 선박 목록 조회
			'getShipList' : function( page, param ) {
				var _self = this;
				var defaultParam = {'PAGE' : page, 'PERPAGE' : '10', 'SEARCH_TYPE' : $("#searchType").val()};
				$.extend(defaultParam, param);
				$.ajax({
					 url : _self._shipListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.shipList, 'SHIP_ID', function( data, $row ) {
				    			
				    			console.log(data);
				    			
				    			$row.find("SELECT[name='comp_btn']").val(data.COMP_YN).attr("selected","selected");
				    			$row.find(".comp_btn").attr("seq", data.SEQ);
				    			if(data.QUIT_YN == 'N'){
				    				$row.find(".delete_btn").attr("seq", data.SEQ);
				    			}else{
				    				//$row.find(".delete_btn").attr("style", "display:none");
				    				$row.find(".delete_btn").parent().html("삭제처리");
				    			}
				    			
				    			$row.find(".redirectLink").attr("href", "/"+data.REDIRECT_NAME+".ho");			    			
				    		});
				    		
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getShipList(page, param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	
				    	}
				    }
				});
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선박목록조회
				this.getShipList('1');
				
				$('.jdg-ui-inner').prop('disabled',true);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_main] onDestroy Method' );
			}
	  }
});
