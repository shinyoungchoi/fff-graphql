defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._reserveURL = $('#reserveURL').val();
				// element
				this.$srhSel = $('#searchShipSel');
				this.$listContainer = $('#scheduleListContainer');
				this.$listTemplate = $('#scheduleListTemplate');
				
				//신규 등록시
				this.$regBtn = $('#regBtn');
				//장르 등록 버튼
				this.$regSubmitBtn = $('#regSubmitBtn');
				//상세 -> 수정시
				this.$updateSubmitBtn = $('#updateSubmitBtn');
				this.$mfyBtn = $('#modifyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				//장르 복제
				this.$dupConfBtn = $("#dupConf");
				this.$dupBtn = $('#dupBtn');
				this.$dupCancelBtn = $('#dupCancelBtn');
				
				// form
				this.$srchForm = $('#scheduleSearchForm');
				this.$detailForm = $('#scheduleConfDetailForm');
				this.$insertForm = $('#scheduleConfInsertForm');
				this.$updateForm = $('#scheduleConfUpdateForm');
				this.$scheduleConfUpdateForRegisterForm = $("#scheduleConfUpdateForRegisterForm");
				
				// static variable
				this.selectScheduleId = '';
				this.selectPage = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				
				this.fileList = null;
				this.prepare1FileList= null;
				this.prepare2FileList= null;
				this.fishing1FileList= null;
				this.fishing2FileList= null;
				
			},
			'setEvent'		: function() {
				var _self = this;
							
				// datePicker 이벤트선언
				_self.$insertForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$updateForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				_self.$scheduleConfUpdateForRegisterForm.find(".datepicker").datepick({showOnFocus: true, dateFormat: 'yyyy-mm-dd'});
				
				
				// 신규등록 취소
				_self.$dupCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 보조 select box 변경
				$('.helpSel').change( function() {
					var $this = $( this );
					var val = $this.val();
					if( '' !== val ) {
						var prevVal = $this.prev().val();
						if( '' === prevVal ) $this.prev().val( $this.find('option:selected').text() );
						else $this.prev().val(prevVal + ', ' + $this.find('option:selected').text() );
					}
				});
								
				// 조회
				_self.$srchForm.submit(function() {
					// 출조스케쥴목록조회
					_self.getPrepareFishingList('1',{
						'SHIP_ID' : _self.$srhSel.find('option:selected').val()
					});
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$regSubmitBtn.click( function() {
					_self.insertSchedule();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				//수정 취소
				_self.$mfyCancelBtn.click(function(){
					_self.selectFormShow('none');
				});
								
				// 수정화면 보이기
				_self.$updateSubmitBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData(_self.selectScheduleId, 'SEQ') );
				});
				
				//수정하기
				_self.$mfyBtn.click(function(){
					_self.updateSchedule();
				});
				
				//삭제하기
				_self.$delBtn.click(function(){
					if(!confirm("삭제하시겠습니까?")){
						return false;
					}
					_self.deleteSchedule();
					
				});
				
				//등록시 채비법/ 낚시법 입력 창 보이기
				_self.$insertForm.find("[data-key='PREPARE_FISHING_TYPE']").on("change", function(){
					var value = $(this).val();
					if(value == "PREPARE"){
						$("tr.prepare_div").show();
						$("tr.fishing_div").hide();
					}else{
						$("tr.prepare_div").hide();
						$("tr.fishing_div").show();
					}
				});			
			
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});										
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectScheduleId = $tr.attr('rowKey');
				console.log(_self.selectScheduleId);
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectScheduleId, 'SEQ'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			
			// 채비법/낚시법 조회
			'getPrepareFishingList' : function( page, param, showDetailId ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : "/sc/schedule/prepareFishingList"
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('list') ) {
				    		console.log(data.list);
				    									
				    		// 리스트 초기화
				    		_self.list.createList(data.list, 'SEQ', function(data, template){
				    			if(data.FISHING_YN == "Y"){
				    				template.find("[data-key='TITLE1']").html(data.FISHING_TITLE1);
				    				template.find("[data-key='TITLE2']").html(data.FISHING_TITLE2);
				    				template.find("[data-key='CONTENT1']").html(data.FISHING_CONTENT1);
				    				template.find("[data-key='CONTENT2']").html(data.FISHING_CONTENT2);
				    			}else{
				    				template.find("[data-key='TITLE1']").html(data.PREPARE_TITLE1);
				    				template.find("[data-key='TITLE2']").html(data.PREPARE_TITLE2);
				    				template.find("[data-key='CONTENT1']").html(data.PREPARE_CONTENT1);
				    				template.find("[data-key='CONTENT2']").html(data.PREPARE_CONTENT2);
				    			}
				    		});
				    		
				    		// 페이징 초기화
				    		$('#scheduleListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getPrepareFishingList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.list.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			// 장르 등록
			'insertSchedule' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var filesParam = {};
				
				var prepareFiles1 = _self.prepare1FileList.getFileList();
				if(prepareFiles1 != null && prepareFiles1 != ""){
					filesParam.prepareFile1 = { IMG_ID : prepareFiles1 , type :"PREPARE1"};
				}
				
				var prepareFiles2 = _self.prepare2FileList.getFileList();
				if(prepareFiles2 != null && prepareFiles2 != ""){
					filesParam.prepareFile2 = { IMG_ID : prepareFiles2, type :"PREPARE2"};
				}
				
				var fishingFiles1 = _self.fishing1FileList.getFileList();
				if(fishingFiles1 != null && fishingFiles1 != ""){
					filesParam.fishingFiles1 = { IMG_ID : fishingFiles1 , type :"FISHING1"};
				}
				
				var fishingFiles2 = _self.fishing2FileList.getFileList();
				if(fishingFiles2 != null && fishingFiles2 != ""){
					filesParam.fishingFiles2 = { IMG_ID : fishingFiles2 , type :"FISHING2"};
				}
				
				var PREPARE_YN = "N";
				var FISHING_YN = "Y";
				
				if($insertForm.find("[data-key='PREPARE_FISHING_TYPE'] option:selected").val() == "PREPARE"){
					PREPARE_YN = "Y";
					FISHING_YN = "N";
				}
			
				var insertParam = {
					  'SHIP_ID' : $insertForm.find('[data-key=SHIP_ID] option:selected').val()
					, 'PREPARE_YN' : PREPARE_YN			
					, 'FISHING_YN' : FISHING_YN
					, 'PREPARE_TITLE1' : $insertForm.find('[data-key=PREPARE_TITLE1]').val()
					, 'PREPARE_TITLE2' : $insertForm.find('[data-key=PREPARE_TITLE2]').val()
					, 'PREPARE_FILE1' : ( filesParam.prepareFile1 != undefined )? JSON.stringify(filesParam.prepareFile1): null
					, 'PREPARE_FILE2' : ( filesParam.prepareFile2 != undefined )? JSON.stringify(filesParam.prepareFile2): null
					, 'FISHING_TITLE1' : $insertForm.find('[data-key=FISHING_TITLE1]').val()
					, 'FISHING_TITLE2' : $insertForm.find('[data-key=FISHING_TITLE2]').val()
					, 'FISHING_FILE1' : ( filesParam.fishingFiles1 != undefined )? JSON.stringify(filesParam.fishingFiles1): null
					, 'FISHING_FILE2' : ( filesParam.fishingFiles2 != undefined )? JSON.stringify(filesParam.fishingFiles2): null
				};		
				
				if(insertParam.PREPARE_TITLE1 != ""){
					oEditors.getById["PREPARE_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					insertParam.PREPARE_CONTENT1 = $('#PREPARE_CONTENT1').val().replace(/\u8203/g,'');
				}
				
				if(insertParam.PREPARE_TITLE2 != ""){
					oEditors.getById["PREPARE_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					insertParam.PREPARE_CONTENT2 = $('#PREPARE_CONTENT2').val().replace(/\u8203/g,'');
				}
				
				if(insertParam.FISHING_TITLE1 != ""){
					oEditors.getById["FISHING_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					insertParam.FISHING_CONTENT1 = $('#FISHING_CONTENT1').val().replace(/\u8203/g,'');
				}
				
				if(insertParam.FISHING_TITLE2 != ""){
					oEditors.getById["FISHING_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					insertParam.FISHING_CONTENT2 = $('#FISHING_CONTENT2').val().replace(/\u8203/g,'');
				}
			
				console.log(insertParam);
				
				$.ajax({
					 url : "/sc/schedule/insert_preparefishing"
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('등록 되었습니다');
				    		location.href="/sc/schedule/fishing_conf?PAGE="+_self.selectPage+"&SHIP_ID="+_self.$srhSel.find('option:selected').val()+"&CONF_SEQ="+_self.selectScheduleId
				    		return;
				    	}
				    	
				    	if( data.hasOwnProperty('error') ) {
				    		alert(data.error);
				    		return;
				    	}
				    	
				    	alert("오류가 발생하였습니다.");
				    	return;
				    }
				});
				
			},
			// 장르  수정
			'updateSchedule' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				var remainFiles= [];
				
				$updateForm.find("[data-type=PREPARE1_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"PREPARE_FILE1", SEQ : index + 1});
				});
				
				$updateForm.find("[data-type=PREPARE2_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"PREPARE_FILE2", SEQ : index + 1});
				});
				$updateForm.find("[data-type=FISHING1_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"FISHING_FILE1", SEQ : index + 1});
				});
				
				$updateForm.find("[data-type=FISHING2_IMAGE_LIST] ul.fileList li").each(function(index, item){
					var imgId = $(this).attr("img_id");
					remainFiles.push({IMG_ID : imgId, TYPE_CD :"FISHING_FILE2", SEQ : index + 1});
				});
				
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
			
				var updateParam = {
						'SEQ': _self.selectScheduleId
						, 'SHIP_ID' : $updateForm.find('[data-key=SHIP_ID] option:selected').val()					
						, 'PREPARE_TITLE1' : $updateForm.find('[data-key=PREPARE_TITLE1]').val()
						, 'PREPARE_TITLE2' : $updateForm.find('[data-key=PREPARE_TITLE2]').val()
						, 'FISHING_TITLE1' : $updateForm.find('[data-key=FISHING_TITLE1]').val()
						, 'FISHING_TITLE2' : $updateForm.find('[data-key=FISHING_TITLE2]').val()
						, 'REMAIN_FILE' : JSON.stringify(remainFiles)					
				};
				
				if($updateForm.find("[data-key='PREPARE_FISHING_TYPE'] option:selected").val() == "PREPARE"){
					updateParam.PREPARE_YN = "Y";
					updateParam.FISHING_YN = "N"; 
				}else{
					updateParam.PREPARE_YN = "N";
					updateParam.FISHING_YN = "Y";
				}

				if(updateParam.PREPARE_TITLE1 != ""){
					oEditors.getById["PREPARE_UPDATE_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.PREPARE_CONTENT1 = $('#PREPARE_UPDATE_CONTENT1').val().replace(/\u8203/g,'');
				}else{
					if($('#PREPARE_UPDATE_CONTENT1').val() != ""){
						alert("채비법1 제목을 입력해주세요.");
						return;
					}
				}
				
				if(updateParam.PREPARE_TITLE2 != ""){
					oEditors.getById["PREPARE_UPDATE_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.PREPARE_CONTENT2 = $('#PREPARE_UPDATE_CONTENT2').val().replace(/\u8203/g,'');
				}else{
					if($('#PREPARE_UPDATE_CONTENT2').val() != ""){
						alert("채비법2 제목을 입력해주세요.");
						return;
					}
				}
				if(updateParam.FISHING_TITLE1 != ""){
					oEditors.getById["FISHING_UPDATE_CONTENT1"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.FISHING_CONTENT1 = $('#FISHING_UPDATE_CONTENT1').val().replace(/\u8203/g,'');
				}else{
					if($('#FISHING_UPDATE_CONTENT1').val() != ""){
						alert("낚시법1 제목을 입력해주세요.");
						return;
					}
				}
				if(updateParam.FISHING_TITLE2 != ""){
					oEditors.getById["FISHING_UPDATE_CONTENT2"].exec("UPDATE_CONTENTS_FIELD", []);
					updateParam.FISHING_CONTENT2 = $('#FISHING_UPDATE_CONTENT2').val().replace(/\u8203/g,'');
				}else{
					if($('#FISHING_UPDATE_CONTENT2').val() != ""){
						alert("낚시법2 제목을 입력해주세요.");
						return;
					}
				}
						
				
				$.ajax({
					 url : "/sc/schedule/update_preparefishing"
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	console.log(data);
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		location.href="/sc/schedule/fishing_conf?PAGE="+_self.selectPage+"&SHIP_ID="+_self.$srhSel.find('option:selected').val()+"&CONF_SEQ="+_self.selectScheduleId
				    		return;
				    	}else{
				    		if( data.hasOwnProperty('error') ) {
					    		alert(data.error);
					    		return;
					    	}
					    	
					    	alert("오류가 발생하였습니다.");
					    	return;
				    	}
				    }
				});
			},
			// 장르 삭제
			'deleteSchedule' : function() {
				var _self = this;
				if(_self.selectScheduleId == ""){
					alert("삭제하실 장르를 목록에서 선택해주세요.");
					return;
				}
				
				$.ajax({
					 url : "/sc/schedule/deleteConf"
					,type : 'POST'
					,data : {
						 'CONF_SEQ' : _self.selectScheduleId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}else{
				    		if(data.hasOwnProperty('error') ){
				    			alert(data.error);
				    			return;
				    		}
				    		
				    		alert("오류가 발생하였습니다.");
				    		return;
				    	}
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
			
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				var $scheduleConfUpdateForRegisterForm = _self.$scheduleConfUpdateForRegisterForm;
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
				
					if(data.PREPARE_CONTENT1 != "" && data.PREPARE_CONTENT1 != undefined){
						$detailForm.find("[data-type=PREPARE_CONTENT_1]").html(data.PREPARE_CONTENT1);
					}else{
						$detailForm.find("[data-type=PREPARE_CONTENT_1]").html("");
					}
					
					if(data.PREPARE_CONTENT2 != "" && data.PREPARE_CONTENT2 != undefined){
						$detailForm.find("[data-type=PREPARE_CONTENT_2]").html(data.PREPARE_CONTENT2);
					}else{
						$detailForm.find("[data-type=PREPARE_CONTENT_2]").html("");
					}
					
					if(data.FISHING_CONTENT1 != "" && data.FISHING_CONTENT1 != undefined){
						$detailForm.find("[data-type=FISHING_CONTENT_1]").html(data.FISHING_CONTENT1);
					}else{
						$detailForm.find("[data-type=FISHING_CONTENT_1]").html("");
					}
					
					if(data.FISHING_CONTENT2 != "" && data.FISHING_CONTENT2 != undefined){
						$detailForm.find("[data-type=FISHING_CONTENT_2]").html(data.FISHING_CONTENT2);
					}else{
						$detailForm.find("[data-type=FISHING_CONTENT_2]").html("");
					}
					
					if(data.hasOwnProperty('PREPARE1_IMAGE_LIST')){
						jdg.util.createImgList( data.PREPARE1_IMAGE_LIST, $detailForm.find('[data-type=PREPARE1_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=PREPARE1_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('PREPARE2_IMAGE_LIST')){
						jdg.util.createImgList( data.PREPARE2_IMAGE_LIST, $detailForm.find('[data-type=PREPARE2_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=PREPARE2_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('FISHING1_IMAGE_LIST')){
						jdg.util.createImgList( data.FISHING1_IMAGE_LIST, $detailForm.find('[data-type=FISHING1_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=FISHING1_IMAGE_LIST]').html("");
					}
					
					if(data.hasOwnProperty('FISHING2_IMAGE_LIST')){
						jdg.util.createImgList( data.FISHING2_IMAGE_LIST, $detailForm.find('[data-type=FISHING2_IMAGE_LIST]') );
					}else{
						$detailForm.find('[data-type=FISHING2_IMAGE_LIST]').html("");
					}
						
					$detailForm.show();
				}
				// 신규등록
				else if('insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.show();
					$scheduleConfUpdateForRegisterForm.hide();
										
					// 초기화
					jdg.util.detailDataSetting( $insertForm, {} );

					//채비법 1
					_self.prepare1FileList = new component.FileList({
						 'id' : "prepare1ImageDiv"
						,'container' : $insertForm.find('[data-type=PREPARE1_IMAGE_LIST]')
					});					
					_self.prepare1FileList.initWithoutTextArea();
			
					
					//채비법 2
					_self.prepare2FileList = new component.FileList({
						 'id' : "prepare2ImageDiv"
						,'container' : $insertForm.find('[data-type=PREPARE2_IMAGE_LIST]')
					});					
					_self.prepare2FileList.initWithoutTextArea();
					
					//낚시법 1
					_self.fishing1FileList = new component.FileList({
						 'id' : "fishing1ImageDiv"
						,'container' : $insertForm.find('[data-type=FISHING1_IMAGE_LIST]')
					});
					
					_self.fishing1FileList.initWithoutTextArea();
					
					//낚시법 2
					_self.fishing2FileList = new component.FileList({
						 'id' : "fishing2ImageDiv"
						,'container' : $insertForm.find('[data-type=FISHING2_IMAGE_LIST]')
					});
					
					_self.fishing2FileList.initWithoutTextArea();
					

					var shipId = $("#searchShipSel").val();					
					if(shipId != "" && shipId != undefined){
						$insertForm.find("select[name='regShipId'] option:eq(0)").attr("selected", false);
						$insertForm.find("select[name='regShipId'] option[value='"+shipId+"']").attr("selected", true);
					}
			
					
					//에디터 내용 초기화시킴.
					$insertForm.find("textarea[name='PREPARE_CONTENT1']").text("");
					$insertForm.find("textarea[name='PREPARE_CONTENT2']").text("");
					$insertForm.find("textarea[name='FISHING_CONTENT1']").text("");
					$insertForm.find("textarea[name='FISHING_CONTENT2']").text("");
					
					
					loadbbsEditor("PREPARE_CONTENT1", "");
					loadbbsEditor("PREPARE_CONTENT2", "");
					loadbbsEditor("FISHING_CONTENT1", "");
					loadbbsEditor("FISHING_CONTENT2", "");
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
										
					$updateForm.find("[data-key='SHIP_ID'] option[value='"+data.SHIP_ID+"']").attr("selected","selected");
					
					//채비법인경우
					if(data.PREPARE_YN == "Y"){
						$("tr.update_prepare_div").show();
				
						//낚시법인경우
					}else{
						$("tr.update_fishing_div").show();
					}
					
					
					//에디터 내용 초기화시킴.
					$updateForm.find("textarea[name='PREPARE_UPDATE_CONTENT1']").text("");
					$updateForm.find("textarea[name='PREPARE_UPDATE_CONTENT2']").text("");
					$updateForm.find("textarea[name='FISHING_UPDATE_CONTENT1']").text("");
					$updateForm.find("textarea[name='FISHING_UPDATE_CONTENT2']").text("");
					
					loadbbsEditor("PREPARE_UPDATE_CONTENT1", data.PREPARE_CONTENT1);
					loadbbsEditor("PREPARE_UPDATE_CONTENT2", data.PREPARE_CONTENT2);
					loadbbsEditor("FISHING_UPDATE_CONTENT1", data.FISHING_CONTENT1);
					loadbbsEditor("FISHING_UPDATE_CONTENT2", data.FISHING_CONTENT2);

					//채비법 1
					_self.prepare1FileList = new component.FileList({
						 'id' : "prepare1ImageDiv"
						,'container' : $updateForm.find('[data-type=PREPARE1_IMAGE_LIST]')
					});
					
					_self.prepare1FileList.initWithoutTextArea(data.PREPARE1_IMAGE_LIST);
					
					//채비법 2
					_self.prepare2FileList = new component.FileList({
						 'id' : "prepare2ImageDiv"
						,'container' : $updateForm.find('[data-type=PREPARE2_IMAGE_LIST]')
					});
					
					_self.prepare2FileList.initWithoutTextArea(data.PREPARE2_IMAGE_LIST);
					
					//낚시법 1
					_self.fishing1FileList = new component.FileList({
						 'id' : "fishing1ImageDiv"
						,'container' : $updateForm.find('[data-type=FISHING1_IMAGE_LIST]')
					});
					
					_self.fishing1FileList.initWithoutTextArea(data.FISHING1_IMAGE_LIST);
					
					//낚시법 2
					_self.fishing2FileList = new component.FileList({
						 'id' : "fishing2ImageDiv"
						,'container' : $updateForm.find('[data-type=FISHING2_IMAGE_LIST]')
					});
					
					_self.fishing2FileList.initWithoutTextArea(data.FISHING2_IMAGE_LIST);
					
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
					$scheduleConfUpdateForRegisterForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('SEQ') ) {
					var seq = p_param.SEQ;
					var shipId = p_param.SHIP_ID;
					var page = p_param.PAGE;
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == shipId){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					// 출조스케쥴 목록 조회
					this.getPrepareFishingList(page, {SHIP_ID : shipId} , seq);
				}else if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getPrepareFishingList(1, {SHIP_ID : p_param.SHIP_ID});
				} else {
					// 낚시법&채비법 조회
					this.getPrepareFishingList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
