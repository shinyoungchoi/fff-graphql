defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberURL = $('#memberURL').val();
				this._memberSearchURL = $('#memberSearchURL').val();
				this._sundanListURL = $('#sundanListURL').val();
				this._sundanDetailURL = $('#sundanDetailURL').val();
				this._sundanInsertURL = $('#sundanInsertURL').val();
				this._sundanUpdateURL = $('#sundanUpdateURL').val();
				this._sundanDeleteURL = $('#sundanDeleteURL').val();
				this._redirectNameCheckURL = $('#redirectNameCheckURL').val();		
				this._shipSearchURL = $('#shipSearchURL').val();
				this._addShipURL = $('#addShipURL').val();
				this._delShipURL = $('#delShipURL').val();
				
				this._msgPrepaidHistoryURL = $("#msgPrepaidHistoryURL").val();
				this._msgBudgetHistoryURL = $("#msgBudgetHistoryURL").val();
				
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				// element
				this.$listContainer = $('#sundanListContainer');
				this.$listTemplate = $('#sundanListTemplate');
				this.$detailForm = $('#sundanDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$regCheckBtn = $('#regCheckBtn');
				this.$mfyCheckBtn = $('#mfyCheckBtn');
				
				this.$prepaidlistContainer = $("#msgHistoryListContainer");
				this.$prepaidlistTemplate = $("#prepaidlistTemplate");
				
				this.$budgetlistContainer = $("#budgetlistContainer");
				this.$budgetlistTemplate = $("#budgetlistTemplate");
				
				this.$addShipBtn = $('#addShipBtn');
				this.$delShipBtn = $('#delShipBtn');

				//기본이미지 추가(파일업로드가 아닌 서버에 있는 이미지 선택)
				this.$basicfileAddBtn = $('.basicfileAddBtn');		
				
				this.$popupSelectBasicImage = $('#popupSelectBasicImage');	
				
				// form
				this.$srchForm = $('#sundanSearchForm');
				this.$insertForm = $('#sundanInsertForm');
				this.$updateForm = $('#sundanUpdateForm');
				
				this.ShipList = [];
				
				// static variable
				this.selectSundanId = '';
				this.selectedRowData = {};
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				this.prepaidlist = new component.List({
					 'container' : this.$prepaidlistContainer
					,'template' : this.$prepaidlistTemplate.find('.searchRow')
					,'nodata' : this.$prepaidlistTemplate.find('.nodataRow')
				});
				this.budgetlist = new component.List({
					 'container' : this.$budgetlistContainer
					,'template' : this.$budgetlistTemplate.find('.searchRow')
					,'nodata' : this.$budgetlistTemplate.find('.nodataRow')
				});
				// 파일 리스트 초기화
				this.homeImageList = null; //홈이미지 리스트
				
				// 배경이미지 선택용
				var _flstRow = $(".fileListRow2");
				
				this._bgImgloaded = false;
				
				this._isSaving = false;
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회_isSaving
				_self.$srchForm.submit(function() {
					var $this = $(this);
					var param = {};
					var searchText = $.trim($this.find('#searchText').val());
					var checkedTerm = $(this).find(':radio[name=sundanSearchTerms]:checked').attr('id');
					param = (checkedTerm == 'sundanName' ? {'SUNDAN_NAME' : searchText} : {'SUNDAN_ID' : searchText} );
					// 선단목록조회
					_self.getSundanList('1', param);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertSundan();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.addrFileList.removeFile();
					//_self.shopFileList.removeFile();
					_self.selectFormShow('none');
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectedRowData.sundan );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateSundan();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					//_self.addrFileList.removeFile();
					//_self.shopFileList.removeFile();
					_self.selectFormShow('search', _self.selectedRowData.sundan);
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteSundan();
					return false;
				});
				
				// 회원 조회 팝업 오픈 (등록)
				_self.$insertForm.find('#searchMgr').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_insert_popup');
				});
				
				// 회원 조회 팝업 오픈 (수정)
				_self.$updateForm.find('#searchMgr').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_update_popup');
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
					return false;
				});
				
				
				// REDIRECT_NAME 중복 체크 클릭
				_self.$regCheckBtn.click( function() {
					_self.redirectNameCheck( _self.$insertForm.find('[data-key=REDIRECT_NAME]') );
					return false;
				});
				
				// REDIRECT_NAME 중복 체크 클릭
				_self.$mfyCheckBtn.click( function() {
					_self.redirectNameCheck( _self.$updateForm.find('[data-key=REDIRECT_NAME]') );
					return false;
				});
				
				// 가입선박 추가
				_self.$addShipBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_insert_popup' );
					
					return false;
				});
				
				// 삭제선박추가
				_self.$delShipBtn.click( function() {
					Bplat.view.openPopup({
						  'url' : _self._shipSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'ship_delete_popup' );
					
					return false;
				});

				$(".jdg-ui-inner").delegate('.fileUpBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});

				$(".jdg-ui-inner").delegate('.fileDownBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, +1); //다운버튼을 눌렀을때는 해당 이미지를 한칸아래로 이동
				});
				
				
				_self.$popupSelectBasicImage.delegate('.close_btn','click', function() {
					_self.closePopup();
				});
				
				_self.$popupSelectBasicImage.delegate('.popCloseBtn','click', function() {
					_self.closePopup();
				});
				
				_self.$popupSelectBasicImage.delegate('.popConfirmBtn','click', function() {
					
			        var selectedImages = [];
			        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
			        	selectedImages[i] = {'IMG_ID': $(this).val()};
			        });
			        
			        var fileList = _self.homeFileList.getFileList();
			        		
			        $.merge(fileList,selectedImages);
			        
			        //_self.homeFileList.find(".fileAddBtn").attr('id', "homeAddFile");			        
					_self.homeFileList.init(fileList );	
					
					
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();							
							_self.loadBgImage();

							return false;
						});
					};
					
					_self.closePopup();					

				});	
				
				//문자 서비스 선불 충전내역 결제결과값 수정
				$("#resultStatus").on("change", function(){
					_self.getMsgPrepaidList(1,{SUNDAN_ID : _self.selectSundanId});
				});
				
				//문자 서비스 내역 조회
				$("#budgetStatus").on("change", function(){
					_self.getMsgBudgetList(1,{SUNDAN_ID : _self.selectSundanId});
				});
				
				//후불 결제 처리
				$("#msgAfterPayment").on("click", function(){
					//후불 결제를 받은 후에 시스템 처리
					_self.setMsgAfterPayment();
				});
				
				//선불 결제 처리( 카드가 아닌 통장으로 선불지급한 경우 )
				$("#msgPrePayment").on("click", function(){
					//후불 결제를 받은 후에 시스템 처리
					_self.setMsgPrePayment();
				});
			},
			//선불 결제처리 창 팝업
			'setMsgPrePayment': function(){
				var _self = this;
				window.open("/sc/sundan/budget/prepay?SUNDAN_ID="+_self.selectSundanId,"prepay","width=500,height=400");
			},	
			//후불 결제처리 창 팝업
			'setMsgAfterPayment': function(){
				var _self = this;
				window.open("/sc/sundan/budget/afterpay?SUNDAN_ID="+_self.selectSundanId,"afterpay","width=500,height=400");
			},					
			'closePopup' :function(){
				var _self = this;
				_self.$popupSelectBasicImage.hide();
		        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
		        	$(this).attr("checked", false);
		        });
			},	

			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				var $addrImgContainer = _self.$detailForm.find('[data-type=ADDR_IMG_ID]').parent();
				var $shopImgContainer = _self.$detailForm.find('[data-type=SUNDAN_IMG_ID]').parent();
				_self.selectSundanId = $tr.attr('rowKey');
				$.ajax({
					 url : _self._sundanDetailURL
					,type : 'POST'
					,data : {'SUNDAN_ID': _self.selectSundanId}
					,dataType : 'json'
					,success : function(data){
						
						// 데이터 초기화
						_self.selectedRowData = {};
						
						if(data.hasOwnProperty('sundan')){
							_self.selectedRowData = data;							

							_self.ShipList = data.shipList;
							_self.setShipList();
							
							// style
							_self.selectFormShow('search', data.sundan );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							$tr.addClass('jdg-selected');
							if(data.sundan.ADDR_IMG_ID != undefined){
								jdg.util.createImgList( [{"IMG_ID" : data.sundan.ADDR_IMG_ID, 
									                      "IMG_WIDTH" : data.sundan.ADDR_IMG_WIDTH, 
									                      "IMG_HEIGHT" : data.sundan.ADDR_IMG_HEIGHT}], $addrImgContainer.find('[data-type=ADDR_IMG_ID]') );
							} else {
								jdg.util.createImgList([], $addrImgContainer.find('[data-type=ADDR_IMG_ID]'));
							}
							if(data.sundan.SUNDAN_IMG_ID != undefined){
								
								jdg.util.createImgList( [{"IMG_ID" : data.sundan.SUNDAN_IMG_ID, 
									                      "IMG_WIDTH" : data.sundan.SUNDAN_IMG_HEIGHT, 
									                      "IMG_HEIGHT" : data.sundan.SUNDAN_IMG_HEIGHT}], $shopImgContainer.find('[data-type=SUNDAN_IMG_ID]') );
							} else {
								jdg.util.createImgList([], $shopImgContainer.find('[data-type=SUNDAN_IMG_ID]'));
							}
							
							
							if(data.sundan.SEND_MSG_BUDGET_TYPE == 'P'){
								$("#msgAfterPayment").css("display","none");
								//문자메시지 총 사용 금액
				    			$("#budgetTotalPrice").html("잔여금액 : 총 "+ data.MSG_TOTAL_PRICE);
							}else{
								//문자메시지 총 사용 금액
				    			$("#budgetTotalPrice").html("결제금액 : 총 "+ data.MSG_TOTAL_PRICE);
								$("#msgAfterPayment").css("display","inline-block");
							}
						}
												

					}
				});
			},			
			//가입선박,가입출조점,포털가입여부를 화면에 setting
			setShipList: function()
			{
				var _self = this;
				var $shipList = $('[data-type=SHIP_LIST]');
				var list = _self.ShipList;
				$shipList.empty();
				
				for (var i = 0; i < list.length; i++)
				{							
					if (i == 0)
					{
						$shipList.append( $('<em>').attr('shipId',list[i].SHIP_ID).text(list[i].SHIP_NAME) );
					}
					else
					{
						$shipList.append( $('<em>').attr('shipId',list[i].SHIP_ID).text("," + list[i].SHIP_NAME) );
					}							
				}				
			},
			
			// 회원정보
			'getUserInfo' : function( memId ) {
				var _self = this;

				$.ajax({
					 url : '/sc/member/getLoginInfo.json'
					,type : 'POST'
					,data : {'MEM_ID' : memId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var divCaptain = $('#div_captain')
				    	
				    	if( data.info) {
				    		var info = data.info;
				    		divCaptain.text(info.MEM_NAME + "\t ☎  " + info.TEL + "\t" + info.USER_ID + "\t" + info.PWD );
				    	}
				    }
				});
			},
			//카드 결제환불처리
			'cancleCard' : function(prepaidSeq, lgdTid){
				var _self = this;
				$.ajax({
					 url : '/sc/sundan/prepaid/refund'
					,type : 'POST'
					,data : {'LGD_TID' : lgdTid, PREPAID_SEQ : prepaidSeq}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if(data.result == "success"){
				    		alert("환불처리되었습니다.");
				    		var param = {};
							var searchText = $.trim($this.find('#searchText').val());
							var checkedTerm = $(this).find(':radio[name=sundanSearchTerms]:checked').attr('id');
							param = (checkedTerm == 'sundanName' ? {'SUNDAN_NAME' : searchText} : {'SUNDAN_ID' : searchText} );
							// 선단목록조회
							_self.getSundanList('1', param);
							return;
				    	}
				    	
				    	alert("환불처리도중 오류가 발생하였습니다. [상세 :"+ data.msg +"]");
				    	return;
				    }
				});
			},
			// 문자 사용 내역 조회
			'getMsgBudgetList' : function( page, param ) {
				var _self = this;
				var status = $("#budgetStatus").val();
				var defaultParam = {'PAGE' : page, 'PERPAGE' : $("#budgetPerPage").val()};
				if(status != ''){
					defaultParam.STATUS = status;
				}
				$.extend(defaultParam, param);
				$.ajax({
					 url : _self._msgBudgetHistoryURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msgBudgetList') ) {
				    		// 리스트 초기화
				    		var index =0;
				    		_self.budgetlist.createList( data.msgBudgetList, 'BUDGET_SEQ', function( data, $row ) {
				    					    	
				    			var html = "<br/>";
				    			//이미지 확인
				    			if(data.images != null && data.images.length > 0){
				    				for(var i = 0 ;i < data.images.length ; i++){
				    					var image = data.images[i];
				    					console.log(image);
				    					html += "<img src='"+image.HOSTING_URL+"' width='100px'>";
				    					
				    				}
				    			}
				    			
				    			//상세 로그 확인
				    			if(data.logs != null && data.logs.length > 0){
				    				var subhtml = "<div><span style='font-weight:700;'>발송결과</span><table width='100%'><tr><td>메시지 타입</td><td>발송결과</td><td>메시지</td><td>발신번호</td><td>수신번호</td>";
				    				subhtml += "</tr>";
				    				for(var i = 0 ; i < data.logs.length ; i++){
				    					var log = data.logs[i];
				    					console.log(log);
				    					if(log.TYPE == 'SMS'){
				    						subhtml += "<tr><td>SMS</td>";
				    						subhtml += "<td>"+ log.RSLT_STR+"</td>";
				    						subhtml += "<td width='320px'>"+log.MSG+"</td>";
				    						subhtml += "<td>"+log.CALLBACK+"</td>";
				    						subhtml += "<td>"+log.PHONE+"</td>";
				    						subhtml += "</tr>"
				    					}else{
				    						if(log.FILE_CNT != '0'){
				    							subhtml += "<tr><td>MMS</td>";
				    						}else{
				    							subhtml += "<tr><td>LMS</td>";
				    						}
				    						subhtml += "<td>"+ log.RSLT_STR+"</td>";
				    						subhtml += "<td  width='320px'>"+ log.MSG+"</td>";
				    						subhtml += "<td>"+log.CALLBACK+"</td>";
				    						subhtml += "<td>"+log.PHONE+"</td>";
				    						subhtml += "</tr>"
				     					}
				    						
				    				}
				    				subhtml += "</table></div>";
				    				html += subhtml;
				    			}
				    			

				    			$row.find("[data-key='CONTENT']").append(html);
				    			
				    			
				    			//충전(결재) 상태인 경우
				    			if(data.MSG_TOTAL > 0){
				    				if(data.SEND_MSG_BUDGET_TYPE == 'A'){
				    					if(data.SUMMARY != null)
				    						$row.find("[data-key='CONTENT']").html(data.SUMMARY);
				    					else
				    						$row.find("[data-key='CONTENT']").html("후불제 결제처리");
					    				$row.find("[data-key='SEND_DATE_STR']").html(data.CREATED_AT_STR);
				    				}else{
				    					if(data.SUMMARY != null)
				    						$row.find("[data-key='CONTENT']").html(data.SUMMARY);
				    					else
				    						$row.find("[data-key='CONTENT']").html("선불 결제처리");
					    				$row.find("[data-key='SEND_DATE_STR']").html(data.CREATED_AT_STR);
				    				}				    			
				    				$row.css("background","rgba(0, 26, 173, 0.25)");
				    			}
				    			
				    			index++;
				    							    					    			
				    		});
				    		
				    		// 페이징 초기화
				    		$('#budgetlistPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getMsgBudgetList(page, param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	
				    		$("#msgBudgetForm").show();
				    	}else{
				    		$("#msgBudgetForm").hide();
				    	}
				    }
				});
			},
			// 선박 충전 히스토리 조회(선불 충전 내역)
			'getMsgPrepaidList' : function( page, param ) {
				var _self = this;
				var resultStatus = $("#resultStatus").val();
				var defaultParam = {'PAGE' : page, 'PERPAGE' : '10'};
				if(resultStatus != null && resultStatus != ''){
					defaultParam.STATUS = resultStatus;
				}
				$.extend(defaultParam, param);
				$.ajax({
					 url : _self._msgPrepaidHistoryURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msgHistoryList') ) {
				    		// 리스트 초기화
				    		_self.prepaidlist.createList( data.msgHistoryList, 'PREPAID_SEQ', function( data, $row ) {
				    			
				    			//결제성공인 경우
				    			if(data.PREPAID_RESULT == '1'){
				    				$row.css("background","rgba(76, 175, 80, 0.35)");
				    				$row.find('.cancleCard').css("display","inline-block");
				    			}
				    			
				    			$row.find('.cancleCard').click( function( e ) {
				    				e.stopPropagation();
				    				if(confirm("환불처리하시겠습니까?")){
				    					_self.cancleCard(data[$(e.target).data('id')], data.LGD_TID);
				    				}
				    				return false;
				    			});
				    			
				    			if(data.details != null && data.details.length > 0){
				    				var html = "";
				    				for(var i = 0 ; i < data.details.length ;i++){
				    					var detail = data.details[i];
				    					html += "<tr style='color:#666;text-align:right;'><td colspan=7> 결제금액 : "+detail.LGD_AMOUNT+"원/ ";
				    					html += "결제 일시 : "+detail.LGD_PAYDATE +"/ 결제결과 : "+ detail.LGD_RESPMSG;
				    					html += "</td></tr>";
				    					
				    				}
				    				$row.after(html);
				    			}
				    							    					    			
				    		});
				    		
				    		// 페이징 초기화
				    		$('#msgHistoryListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getMsgPrepaidList(page, param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	
				    		if(param.SEND_MSG_BUDGET_TYPE != 'A')
				    			$("#msgHistoryForm").show();
				    		else
				    			$("#msgHistoryForm").hide();
				    	}
				    }
				});
			},
			
			// 선단 목록 조회
			'getSundanList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._sundanListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('sundanList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.sundanList, 'SUNDAN_ID', function( data, $row ) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			var sundanRegNo = $row.find('[data-key=SUNDAN_REG_NO]').text();
				    			$row.find('[data-key=SUNDAN_REG_NO]').text( sundanRegNo.replace(/([0-9]{3})([0-9]{2})([0-9]{5})/, "$1-$2-$3") );
				    			
				    			$row.find('.memberLink').click( function( e ) {
				    				e.stopPropagation();
				    				_self.getUserInfo(data.MGR_MEM_ID);
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#sundanListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getSundanList(page,param);
								}
				    			,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.sundanList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 선단 등록
			'insertSundan' : function() {
				var _self = this;
				
				if (_self._isSaving)
				{
					alert('저장중입니다. 잠시만 기다려주세요.');
					return;
				}
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return;
				
				var homeimageIdStr = _self.homeFileList.getFileIdString();

				// 선단 등록
				var insertParam = {
					  'SUNDAN_NAME' : $insertForm.find('[data-key=SUNDAN_NAME]').val()
					, 'MGR_MEM_ID' : $insertForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId')
					, 'SUNDAN_REG_NO' : $insertForm.find('[data-key=SUNDAN_REG_NO_1]').val() + '-' +$insertForm.find('[data-key=SUNDAN_REG_NO_2]').val() + '-' +$insertForm.find('[data-key=SUNDAN_REG_NO_3]').val() 
					, 'BANK_CD' : $insertForm.find('[data-key=BANK_CD]').val()
					, 'BANK_ACCN' : $insertForm.find('[data-key=BANK_ACCN]').val()
					, 'BANK_HOLDER' : $insertForm.find('[data-key=BANK_HOLDER]').val()
					, 'VR_BANKING_YN' : $insertForm.find('[data-key=VR_BANKING_YN]').val()
					, 'REDIRECT_NAME' : $insertForm.find('[data-key=REDIRECT_NAME]').val()
					, 'DOM_ADDR' : $insertForm.find('[data-key=DOM_ADDR]').val()
					, 'CEO_NAME' : $insertForm.find('[data-key=CEO_NAME]').val()
					, 'BIZ_ID' : $insertForm.find('[data-key=BIZ_ID]').val()
					, 'NAVIGATION' : $insertForm.find('[data-key=NAVIGATION]').val()
					, 'PORT_CD' : $insertForm.find('[data-key=PORT_CD]').val()
					, 'TEST_YN' : $insertForm.find('[data-key=TEST_YN]').val()
					, 'CAFE_YN' : $insertForm.find('[data-key=CAFE_YN]').val()
					, 'CAFE_URL' : $insertForm.find('[data-key=CAFE_URL]').val()
					, 'PENSION_URL' : $insertForm.find('[data-key=PENSION_URL]').val()
					, 'HOUSE_TYPE' :  $insertForm.find('[data-key=HOUSE_TYPE]').val()
					, 'BBS_YN' : $insertForm.find('[data-key=BBS_YN]').val()
					, 'HOME_IMGS_ID' : homeimageIdStr
					, 'SD_ACCN_YN' : $insertForm.find('[data-key=SD_ACCN_YN]').val()
					, 'META_DESC' :	$insertForm.find('[data-key=META_DESC]').val()
					, 'TEL_MOBILE' : $insertForm.find('[data-key=TEL_MOBILE_1]').val() + '-' + $insertForm.find('[data-key=TEL_MOBILE_2]').val() + '-' + $insertForm.find('[data-key=TEL_MOBILE_3]').val()
					, 'TEL_ETC' : $insertForm.find('[data-key=TEL_ETC_1]').val() + '-' + $insertForm.find('[data-key=TEL_ETC_2]').val() + '-' + $insertForm.find('[data-key=TEL_ETC_3]').val()
					, 'ADDR' : $insertForm.find('[data-key=ADDR]').val()
					, 'ADDR_DESC' : $insertForm.find('[data-key=ADDR_DESC]').val()
					, 'SEND_MSG_YN' : $insertForm.find('[data-key=SEND_MSG_YN]').val()
					, 'SEND_MSG_BUDGET_TYPE' : $insertForm.find('[data-key=SEND_MSG_BUDGET_TYPE]').val()
					, 'SEND_MSG_BATCH_YN' : $insertForm.find('[data-key=SEND_MSG_BATCH_YN]').val()
					, 'SUB_SUNDAN_NM' : $insertForm.find('[data-key=SUB_SUNDAN_NM]').val()
					, 'FREE_YN' : $insertForm.find('[data-key=FREE_YN] option:selected').val()
					, 'AUTOPOST_NEW' : $insertForm.find('[data-key=AUTOPOST_NEW] option:selected').val()
					, 'CLOSE_YN' : $insertForm.find('[data-key=CLOSE_YN] option:selected').val()
				};
				
				_self._isSaving = true;
				
				$.ajax({
					 url : _self._sundanInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
					    	_self._isSaving = false;
				    		alert('등록 되었습니다');

				    		if( data.result.SUNDAN_ID != null && 
			    				data.result.SUNDAN_ID != undefined && 
			    				data.result.SUNDAN_ID != '' ){
				    			_self.getSundanList('1', {'SUNDAN_ID' : data.result.SUNDAN_ID});
				    		}
				    	}
				    }
	             	,error: function(result) {
	                    alert("수정실패!!!");
				    	_self._isSaving = false;
	                }				
				
				});
			},
			// 선단 수정
			'updateSundan' : function() {
				var _self = this;
				
				if (_self._isSaving)
				{
					alert('저장중입니다. 잠시만 기다려주세요.');
					return;
				}				
				
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateData = _self.list.getListRowData(_self.selectSundanId, 'SUNDAN_ID');
				// 관리자
				var mgrMemId = $updateForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId');
				var beforeMgrMemId = updateData.MGR_MEM_ID;
				
				var homeimageIdStr = _self.homeFileList.getFileIdString();	

				// 선단 수정
				var updateParam = {
					  'SUNDAN_ID' : _self.selectSundanId
					, 'SUNDAN_NAME' : $updateForm.find('[data-key=SUNDAN_NAME]').val()
					, 'MGR_MEM_ID' : mgrMemId
					, 'HOME_IMGS_ID' : homeimageIdStr
					, 'BEFORE_MGR_MEM_ID' : (beforeMgrMemId === mgrMemId || !beforeMgrMemId) ? "" : beforeMgrMemId
					, 'SUNDAN_REG_NO' : $updateForm.find('[data-key=SUNDAN_REG_NO_1]').val() + '-' +$updateForm.find('[data-key=SUNDAN_REG_NO_2]').val() + '-' +$updateForm.find('[data-key=SUNDAN_REG_NO_3]').val()
					, 'MAP_URL' : $updateForm.find('[data-key=MAP_URL]').val()
					, 'BANK_CD' : $updateForm.find('[data-key=BANK_CD]').val()
					, 'BANK_ACCN' : $updateForm.find('[data-key=BANK_ACCN]').val()
					, 'BANK_HOLDER' : $updateForm.find('[data-key=BANK_HOLDER]').val()
					, 'VR_BANKING_YN' : $updateForm.find('[data-key=VR_BANKING_YN]').val()
					, 'REDIRECT_NAME' : $updateForm.find('[data-key=REDIRECT_NAME]').val()
					, 'DOM_ADDR' : $updateForm.find('[data-key=DOM_ADDR]').val()
					, 'CEO_NAME' : $updateForm.find('[data-key=CEO_NAME]').val()
					, 'BIZ_ID' : $updateForm.find('[data-key=BIZ_ID]').val()
					, 'NAVIGATION' : $updateForm.find('[data-key=NAVIGATION]').val()
					, 'PORT_CD' : $updateForm.find('[data-key=PORT_CD]').val()
					, 'TEST_YN' : $updateForm.find('[data-key=TEST_YN]').val()
					, 'CAFE_YN' : $updateForm.find('[data-key=CAFE_YN]').val()
					, 'CAFE_URL' : $updateForm.find('[data-key=CAFE_URL]').val()
					, 'PENSION_URL' : $updateForm.find('[data-key=PENSION_URL]').val()
					, 'HOUSE_TYPE' :  $updateForm.find('[data-key=HOUSE_TYPE]').val()
					, 'BBS_YN' : $updateForm.find('[data-key=BBS_YN]').val()
					, 'SD_ACCN_YN' : $updateForm.find('[data-key=SD_ACCN_YN]').val()
					, 'META_DESC' :	$updateForm.find('[data-key=META_DESC]').val()
					, 'TEL_MOBILE' : $updateForm.find('[data-key=TEL_MOBILE_1]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_2]').val() + '-' + $updateForm.find('[data-key=TEL_MOBILE_3]').val()
					, 'TEL_ETC' : $updateForm.find('[data-key=TEL_ETC_1]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_2]').val() + '-' + $updateForm.find('[data-key=TEL_ETC_3]').val()
					, 'ADDR' : $updateForm.find('[data-key=ADDR]').val()
					, 'ADDR_DESC' : $updateForm.find('[data-key=ADDR_DESC]').val()					
					, 'SEND_MSG_YN' : $updateForm.find('[data-key=SEND_MSG_YN]').val()
					, 'SEND_MSG_BUDGET_TYPE' : $updateForm.find('[data-key=SEND_MSG_BUDGET_TYPE]').val()
					, 'SEND_MSG_BATCH_YN' : $updateForm.find('[data-key=SEND_MSG_BATCH_YN]').val()
					, 'SUB_SUNDAN_NM' : $updateForm.find('[data-key=SUB_SUNDAN_NM]').val()
					, 'FREE_YN' : $updateForm.find('[data-key=FREE_YN] option:selected').val()
					, 'AUTOPOST_NEW' : $updateForm.find('[data-key=AUTOPOST_NEW] option:selected').val()
					, 'CLOSE_YN' : $updateForm.find('[data-key=CLOSE_YN] option:selected').val()
				};
				
				_self._isSaving = true;
				
				$.ajax({
					 url : _self._sundanUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	_self._isSaving = false;
				    	
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getSundanList('1', {'SUNDAN_ID' : _self.selectSundanId});
				    	}
				    }
	             	,error: function(result) {
	                    alert("수정실패!!!");
	                    _self._isSaving = false;
	                }
				
				});
			},
			// 선단 삭제
			'deleteSundan' : function() {
				var _self = this;
				var selectData = _self.list.getListRowData(_self.selectSundanId, 'SUNDAN_ID');
				$.ajax({
					 url : _self._sundanDeleteURL
					,type : 'POST'
					,data : {
						  'SUNDAN_ID' : _self.selectSundanId
						, 'ADDR_IMG_ID' : selectData.ADDR_IMG_ID
						, 'SUNDAN_IMG_ID' : selectData.SUNDAN_IMG_ID
						, 'MGR_MEM_ID' : selectData.MGR_MEM_ID
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		_self.getSundanList('1');
				    	}

				    }
				});
			} ,
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					
					//홈이미지 멀티이미지 처리
					_self.homeImageList = _self.setImageContainer("HOME_IMGS_ID", data);
					
					jdg.util.detailDataSetting( $detailForm, data );
					var replaceRegNo = jdg.util.replaceRegNo( data.SUNDAN_REG_NO );
					$detailForm.find('[data-key=SUNDAN_REG_NO]').text(replaceRegNo);

					if(data.SEND_MSG_BUDGET_TYPE == 'A'){
						_self.$detailForm.find("[data-key=SEND_MSG_BUDGET_TYPE]").text('후불제');
					}else{
						_self.$detailForm.find("[data-key=SEND_MSG_BUDGET_TYPE]").text('선불제');
					}
					
					_self.getMsgPrepaidList('1', {SUNDAN_ID: data.SUNDAN_ID, SEND_MSG_BUDGET_TYPE : data.SEND_MSG_BUDGET_TYPE});
					_self.getMsgBudgetList('1', {SUNDAN_ID : data.SUNDAN_ID});
									
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					// 관리자
					$insertForm.find('[data-type=MGR_MEM_ID]').attr('mgrMemId','');
					$insertForm.find('[data-type=MGR_MEM_ID]').text('');
					$insertForm.find('[data-type=GRADE_NAME]').text('');
					$insertForm.find('[data-type=MEM_NAME]').text('');
					$insertForm.find('[data-type=EMAIL]').text('');
					$insertForm.find('[data-type=TEL]').text('');
					$insertForm.find('[data-type=NAVIGATION]').text('');

					
					// 홈화면 배경 이미지 셋팅
					_self.homeFileList = new component.FileList({
						 'id' : 'INSERT_HOME_IMGS_ID'
						,'container' : $('#INSERT_HOME_IMGS_ID')
					});
					
			        _self.homeFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
					_self.homeFileList.init([]);	
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();
							_self.loadBgImage();
							return false;
						});
					}
					
					
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );

					jdg.util.setRegNo( $updateForm.find('[data-key=SUNDAN_REG_NO_1]'), $updateForm.find('[data-key=SUNDAN_REG_NO_2]'), $updateForm.find('[data-key=SUNDAN_REG_NO_3]'), data.SUNDAN_REG_NO );
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_MOBILE_1]'), $updateForm.find('[data-key=TEL_MOBILE_2]'), $updateForm.find('[data-key=TEL_MOBILE_3]'), data.TEL_MOBILE );
					jdg.util.setTelNum( $updateForm.find('[data-key=TEL_ETC_1]'), $updateForm.find('[data-key=TEL_ETC_2]'), $updateForm.find('[data-key=TEL_ETC_3]'), data.TEL_ETC );
					
					$insertForm.find('[data-type=GRADE_NAME]').text('');
					$insertForm.find('[data-type=MEM_NAME]').text('');
					$insertForm.find('[data-type=EMAIL]').text('');
					$insertForm.find('[data-type=TEL]').text('');
					$insertForm.find('[data-type=NAVIGATION]').text('');
					
					// 홈화면 배경 이미지 셋팅
					_self.homeFileList = new component.FileList({
						 'id' : 'UPDATE_HOME_IMGS_ID'
						,'container' : $('#UPDATE_HOME_IMGS_ID')
					});
					
			        _self.homeFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
			        //_self.homeFileList.find(".fileAddBtn").attr('id', "homeAddFile");
					_self.homeFileList.init(_self.homeImageList );	
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();
							_self.loadBgImage();
							return false;
						});
					};
					
					_self.$updateForm.find('[data-type=MGR_MEM_ID]').text(data.MGR_MEM_ID);
					_self.$updateForm.find('[data-type=GRADE_NAME]').parent().hide();
					_self.$updateForm.find('[data-type=MEM_NAME]').text(data.MGR_MEM_NAME);
					_self.$updateForm.find('[data-type=EMAIL]').parent().hide();
					_self.$updateForm.find('[data-type=TEL]').parent().hide();
					
					// 관리자
					$updateForm.find('[data-type=MGR_MEM_ID]').attr( 'mgrMemId', data.MGR_MEM_ID ? data.MGR_MEM_ID : '' );
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
	
			// REDIRECT_NAME 중복체크
			'redirectNameCheck' : function( $redirectName ) {
				var _self = this;
				var redirectName = $.trim( $redirectName.val() );
				if( '' === redirectName ) {
					alert('리다이렉트 명칭을 입력해주세요');
					return false;
				}
				$.ajax({
					 url : _self._redirectNameCheckURL
					,type : 'POST'
					,data : {
						 'REDIRECT_NAME' : redirectName
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('count') ) {
				    		if( data.count == 0 ) {
				    			alert('등록 가능한 리다이렉트 명칭 입니다');
				    			// 닉네임창 비활성화
				    			$redirectName.addClass('jdg-disabled');
				    			$redirectName.attr('readonly', true);
				    			$redirectName.attr('checkFlag', 'true');
				    		} else {
				    			alert('사용중인 리다이렉트 명칭 입니다');
				    			$redirectName.attr('checkFlag', 'false');
				    		}
				    	}
				    }
				});
			},			

			
			//이미지 컨테이너에 이미지들을 셋팅
			'setImageContainer' : function( fieldName,data) {				
				var _self = this;
				
				var imgContainer = _self.$detailForm.find('[data-type="' + fieldName + '"]');	
				var images = data[fieldName] ? data[fieldName].split(",") : null;		
				var imgList = [];
									
				if (images == null)
				{
					imgContainer.empty();						
				}
				else
				{
					$.each(images, function(index, value)
							{
								imgList.push({"IMG_ID":value});						
							});						
					jdg.util.createImgList( imgList, imgContainer );
					
				}					
				return imgList;				
			},
			// 배경이미지 로딩
			'loadBgImage' : function() {
				var _self = this;
				
				if (_self._bgImgloaded) return;
				_self._bgImgloaded = true;
				
				var bgCon = $('#bgCon');
				var imgitem;
				var imgNum;
				
	    		for(var i=1; i <= 609; i++)
	    		{
	    			imgNum = "HOMEBG" + (("000" + i).slice(-4));

	    			imgitem = 				    			
						'<li class="basicImgRow" style="float:left; padding: 10px;">' +	
							'<input type="checkbox" class="chkImgs" value="' + imgNum + '">' +	
							'<img style="width:240px;height:120px;" src="https://img.fishapp.co.kr/legacy/b0/' + imgNum +'.jpg">' +						
						'</li>';	
	    			bgCon.append(imgitem);
	    			
	    		} 
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[sundan_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선단목록조회
				this.getSundanList('1' , p_param );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[sundan_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[sundan_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[sundan_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				// 관리자 팝업 close
				if( 'member_insert_popup' === p_param.id ) {
					var $mgrMemId = _self.$insertForm.find('[data-type=MGR_MEM_ID]');
					var $gradeName = _self.$insertForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$insertForm.find('[data-type=MEM_NAME]');
					var $email = _self.$insertForm.find('[data-type=EMAIL]');
					var $tel = _self.$insertForm.find('[data-type=TEL]');
					if( data ) {
						$mgrMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME );
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL );
						$tel.text( data.TEL );
						$mgrMemId.attr('mgrMemId', data.MEM_ID );
					} 
				} else if( 'member_update_popup' === p_param.id ) {
					var $mgrMemId = _self.$updateForm.find('[data-type=MGR_MEM_ID]');
					var $gradeName = _self.$updateForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$updateForm.find('[data-type=MEM_NAME]');
					var $email = _self.$updateForm.find('[data-type=EMAIL]');
					var $tel = _self.$updateForm.find('[data-type=TEL]');
					if( data ) {
						$mgrMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME ).parent().show();
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL ).parent().show();
						$tel.text( data.TEL ).parent().show();
						$mgrMemId.attr('mgrMemId', data.MEM_ID );
					}
				}
				
				
				if( 'ship_insert_popup' === p_param.id ) {
					var shipId = data.SUNDAN_ID;
					var shipNm = '';
					var isNotRegistered = true;
					var $shiplist = _self.$updateForm.find('[data-type=SHIP_LIST]');
						$.each( $shiplist.find('em'), function(){
							var $this = $( this );
							if( shipId == $this.attr('shipId') ) {
								alert('이미 등록된 선박 입니다.');
								isNotRegistered = false;
							}
						});

					if( isNotRegistered ) {
						
						_self.ShipList[_self.ShipList.length] = {
							'SHIP_ID' : 	data.SHIP_ID
							,'SHIP_NAME' : data.SHIP_NAME
						};
						
						_self.setShipList();
						
						// 출조점 관리선박 추가
						var updateParam = {
							  'SUNDAN_ID' : _self.selectSundanId
							, 'SHIP_ID' : data.SHIP_ID
						};
						$.ajax({
							 url : _self._addShipURL
							,type : 'POST'
							,data : updateParam
						    ,dataType : 'json'
						    ,success : function( data ) {
						    	console.info('success','_addShipURL')
						    }
						});
						
					}
				}
				if('ship_delete_popup' == p_param.id){
					var shipId = data.SHIP_ID;
					var shipNm = data.SHIP_NAME;
					var isRegistered = false;
					var $shipMember = _self.$updateForm.find('[data-type=SHIP_LIST]');
						$.each( $shipMember.find('em'), function(){
							var $this = $( this );
							if( shipId == $this.attr('shipId') ) {

								isRegistered = true;
							}
						});
					
					if( isRegistered ) {
						
						var tempList = [];
						var i= 0;
						
						$.each(_self.ShipList, function(idx, ship){
							console.info("idx", idx);
							console.info("_self.ShipList[]", ship);
							if(ship.SHIP_ID != data.SHIP_ID){
								tempList[i] = ship;
								i++;
							}
						});							
						
						_self.ShipList = tempList;
						_self.setShipList();
						
						// 출조점 관리선박 삭제
						var updateParam = {
							  'SUNDAN_ID' : _self.selectSundanId
							, 'SHIP_ID' : shipId
						};
						$.ajax({
							 url : _self._delShipURL
							,type : 'POST'
							,data : updateParam
						    ,dataType : 'json'
						    ,success : function( data ) {
						    	console.info('success','_delShipURL')
						    }
						});

					}else{
						alert("등록되지 않은 선박입니다.");
					}
				}
				
				
				
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[sundan_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[sundan_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[sundan_main] onDestroy Method' );
			}		
	  }
});
