defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._shipURL = $('#shipURL').val();
				this._postListURL = $('#postListURL').val();
				this._portalPostListURL = $('#portalPostListURL').val();
				this._detailPostURL = $('#detailPostURL').val();
				this._portalDetailPostURL = $('#portalDetailPostURL').val();
				this._postInsertURL = $('#postInsertURL').val();
				this._postUpdateURL = $('#postUpdateURL').val();
				this._postDeleteURL = $('#postDeleteURL').val();
				this._postReserveNotiURL = $('#postReserveNotiURL').val();
				this._imgUploadMultiURL = $('#imgUploadMultiURL').val();
				// element
				this.$listContainer = $('#postListContainer');
				this.$postThreadContainer = $('#postThreadContainer');
				this.$listTemplate = $('#postListTemplate');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$searchTypeSel = $('#searchPostSel');
				this.$searchShipSel = $('#searchShipSel');
				this.$sortArrow = $('.sortArrow');
				this.$typeCdEm = $('#TYPE_CD');
				this.$typeNameEm = $('#TYPE_NAME');
				this.$shipIdEm = $('#SHIP_ID');
				this.$shipNameEm = $('#SHIP_NAME');
				this.$postDetailTbl = $('#postDetailTbl');
				// form
				this.$srchForm = $('#postSearchForm');
				this.$insertForm = $('#postInsertForm');
				this.$updateForm = $('#postUpdateForm');
				this.$detailForm = $('#postDetailForm');
				// file 관련
				this.$fileAddBtn = $('[data-type=fileAddBtn]');
				this.$fileDeleteBtn = $('.fileDeleteBtn');
				this.$fileContainer = $('.fileContainer');
				this.$fileComponent = $('.fileComponent');
				// static variable
				this.selectPostId = '';
				this.selectedRowData = {};
				this.selectFileList = null;
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					/*,'nodata' : this.$listTemplate.find('.nodataRow')*/
				});
				// 파일 리스트 초기화
				this.fileList = null;
				// 예약 알림 사항에 대한 전역 설정
				this.RESERVE_ALARM = '108_120';
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$sortArrow.click(function(){
					var sort = $(this).attr('data-key');
					if($(this).is(':visible')){
						sort = $(this).siblings('span').attr('data-key');
						$(this).siblings('span').show();
						$(this).hide();
					}
					_self.getPostList('1', 
							{
								 'TYPE_CD' : _self.$searchTypeSel.find('option:selected').val()
								,'SHIP_ID' : _self.$searchShipSel.find('option:selected').val()
								
							}
							, sort
					);
					return false;
				});
				// 조회
				_self.$srchForm.submit(function() {
					// 사업체목록조회
					_self.getPostList('1', 
							{
								 'TYPE_CD' : _self.$searchTypeSel.find('option:selected').val()
								,'SHIP_ID' : _self.$searchShipSel.find('option:selected').val()
							}
					);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
					return false;
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertPost();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow('none');
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					// 현재 셀렉트된 아이템을 수정화면에 셋팅
					_self.selectFormShow('update', _self.selectedRowData );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updatePost();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.fileList.removeFileList();
					_self.selectFormShow( 'search', _self.selectedRowData.detailPost );
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					var defaultParam = {
							 'POST_ID': _self.selectPostId
   							 //선박명 : 선박 페이지 , portal : 포탈 페이지
							,'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val() 
					   };
					$.ajax({
						 url : _self._postDeleteURL
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	if( data.hasOwnProperty('result') ) {
					    		if( data.result > 0 ) {
						    		alert('삭제 되었습니다');
						    		location.reload();
					    		} else {
					    			alert('해당 사업체는 삭제할 수 없습니다.');
					    		}
					    	}
					    }
					});
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 게시물 등록
			'insertPost' : function(){
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $typeCd = _self.$typeCdEm.text();
				var $shipId = _self.$shipIdEm.text();
				var $insertForm = _self.$insertForm;

				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var insertParam = {
						  'TYPE_CD' : $typeCd
						, 'SHIP_ID' : $shipId
						, 'TITLE' : $insertForm.find('[data-key=TITLE]').val()
						, 'CONTENT' : $insertForm.find('[data-key=CONTENT]').val()
						, 'FILE_NAME' : $insertForm.find('[data-key=FILE_NAME]').val()
						, 'IMG_ID' : JSON.stringify( _self.fileList.getFileList() )
						//선박명 : 선박 페이지 , portal : 포탈 페이지
						, 'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val()
				};
				$.ajax({
					 url : _self._postInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		if( data.result.POST_ID != null && 
			    				data.result.POST_ID != undefined && 
			    				data.result.POST_ID != '' ){
				    			_self.getPostList('1', {'POST_ID' : data.result.POST_ID});
				    		}
				    	}
				    }
				});
				return false;
			},
			// 게시물 수정
			'updatePost' : function(){
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				// 파일등록
		    	// set update parameters
				var updateParam = {
						  'POST_ID'   : _self.selectPostId
						, 'TYPE_CD'   : $updateForm.find('[data-key=TYPE_CD]').text()
						, 'SHIP_ID'   : $updateForm.find('[data-key=SHIP_ID]').text()
						, 'TITLE'     : $updateForm.find('[data-key=TITLE]').val()
						, 'CONTENT'   : $updateForm.find('[data-key=CONTENT]').val()
						, 'IMG_ID'    : JSON.stringify( _self.fileList.getFileList() )
						//선박명 : 선박 페이지 , portal : 포탈 페이지
						, 'PAGE_TYPE' : _self.$searchShipSel.find('option:selected').val()
				};
				$.ajax({
					 url : _self._postUpdateURL
					,type : 'POST'
					,data : updateParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		_self.getPostList('1', {'POST_ID' : _self.selectPostId});
				    	}
				    }
				});
				return false;
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				var $imgContainer = _self.$detailForm.find('[data-type=IMAGE]').parent();
				_self.selectPostId = $tr.attr('rowKey');
				//선박명 : 선박 페이지 , portal : 포탈 페이지
				var pageType = _self.$searchShipSel.find('option:selected').val();
				var detailPostURL = '';
				var defaultParam = {
										 'POST_ID': _self.selectPostId
										,'PAGE_TYPE' : pageType
								   };
				
				if(pageType == "portal"){
					detailPostURL = _self._portalDetailPostURL;
				}else{
					detailPostURL = _self._detailPostURL;
				}
				
				$.ajax({
					 url : _self._detailPostURL
					,type : 'POST'
					,data : defaultParam
					,dataType : 'json'
					,success : function(data){
						// 데이터 초기화
						_self.selectedRowData = {};
						if(data.hasOwnProperty('detailPost')){
							// style
							if(pageType == "portal"){
								_self.$postDetailTbl.find('tbody').find('tr').eq(0).hide();
							}else{
								_self.$postDetailTbl.find('tbody').find('tr').eq(0).show();
							}
							_self.selectFormShow('search', data.detailPost );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							$tr.addClass('jdg-selected');
						}
						if( data.detailPost['TYPE_CD']== _self.RESERVE_ALARM ){
							$imgContainer.hide();
						} else {
							$imgContainer.show();
							if(data.hasOwnProperty('postImage'))
								jdg.util.createImgList( data.postImage, $imgContainer.find('[data-type=IMAGE]') );
						}
						_self.selectedRowData = data;
					}
				});
			},
			// 공지사항 목록 조회
			'getPostList' : function( page, param, sort ) {
				var _self = this;
				var typeCd = _self.$searchTypeSel.find('option:selected').val();
				var shipId = _self.$searchShipSel.find('option:selected').val();
				var defaultParam = {};
				var paramURL = ''; 
				var postTblThCnt = 0 ;
				var nodata ='';
				
				if(shipId == 'portal'){
					 paramURL = _self._portalPostListURL;
					 defaultParam = {
						 'PAGE' : page
						 ,'PERPAGE' : '10'
						 ,'SORT_BY' : sort
						,'TYPE_CD' : typeCd
					};
				}else{
					 paramURL = _self._postListURL;
					 defaultParam = {
							 'PAGE' : page
							,'PERPAGE' : '10'
							,'SORT_BY' : sort
							,'TYPE_CD' : typeCd
							,'SHIP_ID' : shipId
						};
				}
				$.extend( defaultParam, param );
				$.ajax({
				 url : paramURL
				,type : 'POST'
				,data : defaultParam
			    ,dataType : 'json'
			    ,success : function( data ) {
			    	if( data.hasOwnProperty('postList') ) {
			    		// 리스트 초기화
			    		if(data.postList.length > 0 ){
			    			_self.list.createList( data.postList, 'POST_ID', function( data, $row) {
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    				$row.find('[data-key=UPDATED_NICK]').text( data.UPDATED_NICK );
				    			}
				    			if(shipId == 'portal'){
				    				postTblThCnt =  _self.$postThreadContainer.find('thead').find('tr').find('th').length;
				    				
				    				if(postTblThCnt == 4 ){
				    					_self.$postThreadContainer.find('col').eq(0).remove();
				    					_self.$postThreadContainer.find('thead').find('tr').find('th').eq(0).remove();
				    				}
				    				$row.each(function(i){
				    					$(this).find('td').eq(1).remove();
				    				});
				    			}else{
				    				postTblThCnt =  _self.$postThreadContainer.find('thead').find('tr').find('th').length;
				    				var td ="<td></td>";
				    				if(postTblThCnt == 3){
				    					_self.$postThreadContainer.find('colgroup').prepend("<col width='100' />");
				    					_self.$postThreadContainer.find('thead').find('tr').prepend('<th>선박명</th>');
				    				}
				    				
				    				$row.find('.postClass').click( function( e ) {
					    				// 선박관리로 이동
					    				Bplat.view.loadPage( _self._shipURL, {
					    					'SHIP_ID' : data.SHIP_ID
					    				});
					    				e.stopPropagation();
					    				return false;
					    			});
				    			}
				    		});
			    		}else{
			    			if(shipId == 'portal'){
			    				nodata = "<tr class='nodataRow'><td colspan='3' style='text-align: center;'>조회된 데이터가 없습니다.</td></tr>";
			    			}else{
			    				 nodata = "<tr class='nodataRow'><td colspan='4' style='text-align: center;'>조회된 데이터가 없습니다.</td></tr>";
				    			 postTblThCnt =  _self.$postThreadContainer.find('thead').find('tr').find('th').length;
				    			 if( postTblThCnt == 3 ){
				    				 _self.$postThreadContainer.find('colgroup').prepend("<col width='100' />");
				    					_self.$postThreadContainer.find('thead').find('tr').prepend('<th>선박명</th>');
				    			 }
			    			}
			    			_self.$listContainer.empty();
			    			_self.$listContainer.append( nodata );
			    		}
			    		
			    		// 페이징 초기화
			    		$('#postListPaging').paging({
							 current: page
							,max: (Math.ceil(data.total / 10))
							,onclick:function(e,page){
								_self.getPostList(page);
							}
	    					,prev : '이전'
			    			,next : '다음'
						});
			    		_self.selectFormShow('none');
			    		// 데이터1개일 경우 자동 펼침
			    		if( data.postList.length == 1 )
			    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
			    		
			    		// 현재의 조회 조건이 예약 알림 사항일 경우 안드로이드에서 보여지는 예약 알림 사항내역을 가져온다.
			    		if( typeCd == _self.RESERVE_ALARM )
			    			_self.getReserveNoties( shipId );
			    	}
			    }
			});
				
				
				
			},
			// 예약 알림 사항 조회
			'getReserveNoties' : function( shipId ){
				var _self = this;
				$.ajax({
					 url : _self._postReserveNotiURL
					,type : 'POST'
					,data : { 'SHIP_ID' : shipId }
			        ,dataType : 'json'
			        ,success : function( data ){
			        	var returnData = data.result;
			        	if( returnData == undefined )
			        		return false;
			        	if( returnData.hasOwnProperty( 'POST_ID' ) ){
			        		var $postIdEm = _self.$listContainer.find( '[data-key=POST_ID]' );
			        		var i = 0;
			        		while( i < $postIdEm.length ){
			        			var $em = $($postIdEm[i]);
			        			if( returnData['POST_ID'] == $em.text() ){
			        				$($postIdEm[i]).siblings('[data-key=TITLE]').css('color','blue').append(' <span style="color:red;">(화면 표시중)</span>'); 
			        			}
			        			i++;
			        		}
			        	}
			        }
			        ,error : function( e ){
			        	console.info( e );
			        }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					// span Elements
					var $typeCdEm = _self.$typeCdEm;
					var $typeNameEm = _self.$typeNameEm;
					var $shipIdEm = _self.$shipIdEm;
					var $shipNameEm = _self.$shipNameEm;
					
					// select Box
					var $searchTypeSel = _self.$searchTypeSel;
					var $searchShipSel = _self.$searchShipSel;
					
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $insertForm.attr('id')
						,'container' : $insertForm.find('[data-type=IMAGE_LIST]')
					});
					
					// 선박명과 게시종류를 게시물 등록 텍스트에 보여줌.
					$typeCdEm.text($searchTypeSel.find("option:selected").val());
					$typeNameEm.text($searchTypeSel.find("option:selected").text());
					
					$shipIdEm.text($searchShipSel.find("option:selected").val());
					$shipNameEm.text($searchShipSel.find("option:selected").text());
					
					// 예약 알림 설정은 이미지를 등록하지 않으므로 이미지 컨테이너를 보이지 않는다.
					var $typeCd = _self.$searchTypeSel.find('option:selected');
					if( $typeCd.val() == _self.RESERVE_ALARM ){
						_self.$insertForm.find('[data-type=IMAGE_LIST]').parent().hide();
					} else {
						_self.$insertForm.find('[data-type=IMAGE_LIST]').parent().show();
					}
					
					_self.fileList.init();
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					
					// 컨텐츠 내용중 <br> 에 대한 문자열은 \n 으로 변환
					var content = data.detailPost.CONTENT;
					if( content.indexOf('<br>') ){
						content = content.replace(/<br>/gi, '\n');
						data.detailPost.CONTENT = content;
					}
					
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data.detailPost );
					
					// 파일리스트 초기화
					_self.fileList = new component.FileList({
						 'id' : $updateForm.attr('id')
						,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
					});
					
					_self.fileList.init(data.postImage);
					
					// 게시종류가 예약알림사항일 경우 이미지 컨테이너를 숨김.
					if( data.detailPost['TYPE_CD'] == _self.RESERVE_ALARM ){
						$updateForm.find('[data-type=IMAGE_LIST]').parent().hide();
					} else {
						$updateForm.find('[data-type=IMAGE_LIST]').parent().show();
					}
					
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[post_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 사업체목록조회
				this.getPostList('1' , p_param );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[post_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[post_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[post_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[post_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[post_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[post_main] onDestroy Method' );
			}		
	  }
});
