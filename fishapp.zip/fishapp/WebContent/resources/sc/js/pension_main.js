defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizURL = $('#bizURL').val();
				this._shipListURL = $('#shipListURL').val();
				this._shipDetailURL = $('#shipDetailURL').val();
				this._shipInsertURL = $('#shipInsertURL').val();
				this._shipUpdateURL = $('#shipUpdateURL').val();
				this._shipDeleteURL = $('#shipDeleteURL').val();
				this._memberSearchURL = $('#memberSearchURL').val();
				this._redirectNameCheckURL = $('#redirectNameCheckURL').val();
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$detailForm = $('#shipDetailForm');

				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				this.$regCheckBtn = $('#regCheckBtn');
				this.$mfyCheckBtn = $('#mfyCheckBtn');
				
				//기본이미지 추가(파일업로드가 아닌 서버에 있는 이미지 선택)
				this.$basicfileAddBtn = $('.basicfileAddBtn');		
				
				this.$popupSelectBasicImage = $('#popupSelectBasicImage');	
				
				// form
				this.$srchForm = $('#shipSearchForm');
				this.$insertForm = $('#shipInsertForm');
				this.$updateForm = $('#shipUpdateForm');
				
				// static variable
				this.selectShipId = '';
				this.selectedRowData = {};
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				// 파일 리스트 초기화
				this.mainFileList = null;	//선박이미지 리스트
				this.homeImageList = null; //홈이미지 리스트
				this.cptnFileList = null;
				
				this.redirectNameTemp = "";
				
				// 배경이미지 선택용
				var _flstRow = $(".fileListRow2");
				
				this._bgImgloaded = false;
				
				this._isSaving = false;				
			},
			'setEvent'		: function() {
				var _self = this;
				// 조회
				_self.$srchForm.submit(function() {
					var $this = $(this);
					var param = {};
					var searchText = $.trim($this.find('#searchText').val());
					var checkedTerm = $(this).find(':radio[name=shipSearchTerms]:checked').attr('id');
					param = (checkedTerm == 'shipName' ? {'SHIP_NAME' : searchText} : {'SHIP_ID' : searchText} );
					// 회원목록조회
					_self.getShipList('1', param);
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertShip();
					return false;
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.homeFileList.removeFileList(); //다건 이미지는 removeFileList()
					_self.mainFileList.removeFileList(); //다건 이미지는 removeFileList()
					_self.cptnFileList.removeFile();	 //단건 이미지는 removeFile()
					_self.selectFormShow('none');
				});
				
				// REDIRECT_NAME 중복 체크 클릭
				_self.$regCheckBtn.click( function() {
					_self.redirectNameCheck( _self.$insertForm.find('[data-key=REDIRECT_NAME]') );
					return false;
				});
				
				// REDIRECT_NAME 중복 체크 클릭
				_self.$mfyCheckBtn.click( function() {
					_self.redirectNameCheck( _self.$updateForm.find('[data-key=REDIRECT_NAME]') );
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.selectedRowData.ship );
					return false;
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateShip();
					return false;
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.homeFileList.removeFileList(); //다건 이미지는 removeFileList()
					_self.mainFileList.removeFileList(); //다건 이미지는 removeFileList()
					_self.cptnFileList.removeFile();	 //단건 이미지는 removeFile()
					_self.selectFormShow('search', _self.selectedRowData.ship);
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteShip();
				});
				
				// 회원 조회 팝업 오픈 (등록)
				_self.$insertForm.find('.searchCPTN').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_insert_popup');
				});
				
				// 회원 조회 팝업 오픈 (수정)
				_self.$updateForm.find('.searchCPTN').click( function() {
					Bplat.view.openPopup({
						  'url' : _self._memberSearchURL
						 ,'width' : 800
						 ,'height' : 600
					}, 'member_update_popup');
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
				
				$(".jdg-ui-inner").delegate('.fileUpBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});

				$(".jdg-ui-inner").delegate('.fileDownBtn','click', function() {
					event.preventDefault();
					changeElementIndex(this, +1); //다운버튼을 눌렀을때는 해당 이미지를 한칸아래로 이동
				});
				
				
				_self.$popupSelectBasicImage.delegate('.close_btn','click', function() {
					_self.closePopup();
				});
				
				_self.$popupSelectBasicImage.delegate('.popCloseBtn','click', function() {
					_self.closePopup();
				});
				
				_self.$popupSelectBasicImage.delegate('.popConfirmBtn','click', function() {
					
			        var selectedImages = [];
			        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
			        	selectedImages[i] = {'IMG_ID': $(this).val()};
			        });
			        
			        var fileList = _self.homeFileList.getFileList();
			        		
			        $.merge(fileList,selectedImages);
			        
			        //_self.homeFileList.find(".fileAddBtn").attr('id', "homeAddFile");			        
					_self.homeFileList.init(fileList );	
					
					
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();							
							_self.loadBgImage();

							return false;
						});
					};
					
					_self.closePopup();					

				});	
				
			},
			
			'closePopup' :function(){
				var _self = this;
				_self.$popupSelectBasicImage.hide();
		        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
		        	$(this).attr("checked", false);
		        });
			},		
			
			
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				var $cptnImgContainer = _self.$detailForm.find('[data-type=CPTN_IMG_ID]').parent();
				// style
				_self.selectShipId = $tr.attr('rowKey');
				var bizId = $tr.find('[data-key=BIZ_ID]').text();
				var param = {'SHIP_ID': _self.selectShipId, 'BIZ_ID' : bizId};
				$.ajax({
					 url : _self._shipDetailURL
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function(data){
						
						// 데이터 초기화
						_self.selectedRowData = {};
						
						if(data.hasOwnProperty('ship')){
							// style
							_self.selectFormShow('search', data.ship );
							_self.$listContainer.find('tr').removeClass('jdg-selected');
							$tr.addClass('jdg-selected');
							
							if(data.ship.CPTN_IMG_ID != undefined){
								jdg.util.createImgList( [{"IMG_ID" : data.ship.CPTN_IMG_ID
				 					                     ,"IMG_WIDTH" : data.ship.CPTN_IMG_WIDTH
									                     ,"IMG_HEIGHT" : data.ship.CPTN_IMG_HEIGHT}], $cptnImgContainer.find('[data-type=CPTN_IMG_ID]') );
							} else {
								jdg.util.createImgList( [], $cptnImgContainer.find('[data-type=CPTN_IMG_ID]') );
							}
						}
						
						_self.selectedRowData = data;
					}
				});
			},
	
			// 회원정보
			'getUserInfo' : function( memId ) {
				var _self = this;

				$.ajax({
					 url : '/sc/member/getLoginInfo.json'
					,type : 'POST'
					,data : {'MEM_ID' : memId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var divCaptain = $('#div_captain')
				    	
				    	if( data.info) {
				    		var info = data.info;
				    		
				    		if (info.QUIT_YN == 'Y')
				    			divCaptain.text(info.MEM_NAME + "\t ☎  " + info.TEL + "\t ***** 탈퇴한 아이디 입니다. 탈퇴한 아이디는 접속이 불가능합니다.");
				    		else				    		
				    			divCaptain.text(info.MEM_NAME + "\t ☎  " + info.TEL + "\t 아이디 : " + info.USER_ID + "\t 패스워드 : " + info.PWD );
				    	}
				    }
				});
			},
			
			
			// 선박 목록 조회
			'getShipList' : function( page, param ) {
				var _self = this;
				var defaultParam = {'PAGE' : page, 'PERPAGE' : '10'};
				$.extend(defaultParam, param);
				$.ajax({
					 url : _self._shipListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.shipList, 'SHIP_ID', function( data, $row ) {
				    			
				    			if (data.CPTN_QUIT)
				    			{
				    				$row.find('[data-key=CPTN_NAME]').text(data.CPTN_NAME + ' [' + data.CPTN_QUIT + ']');
				    			}
				    			
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			$row.find('.bizLink').click( function( e ) {
				    				// 예약관리로 이동
				    				Bplat.view.loadPage( _self._bizURL, {
				    					'BIZ_ID' : data.BIZ_ID
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    			
				    			$row.find('.memberLink').click( function( e ) {
				    				e.stopPropagation();
				    				_self.getUserInfo(data[$(e.target).data('id')]);
				    				return false;
				    			});

				    			$row.find('.cptnLink').click( function( e ) {
				    				e.stopPropagation();
				    				_self.getUserInfo(data[$(e.target).data('id')]);
				    				return false;
				    			});
				    			
				    			$row.find(".redirectLink").attr("href", "/"+data.REDIRECT_NAME+".ho");		
				    			
				    		});
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getShipList(page, param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.shipList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 선박 등록
			'insertShip' : function() {
				var _self = this;
				
				if (_self._isSaving)
				{
					alert('저장중입니다. 잠시만 기다려주세요.');
					return;
				}
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var $redirectName = $insertForm.find('[data-key=REDIRECT_NAME]');
				var checkFlag =$redirectName.attr('checkFlag');
				// IMG_ID

				var cptnImgId = _self.cptnFileList.getFile();
				var mainimageIdStr = _self.mainFileList.getFileIdString();
				var homeimageIdStr = _self.homeFileList.getFileIdString();
				
				var domAddr = $insertForm.find('[data-key=DOM_ADDR]').val();
				
				domAddr = domAddr.replace('http://','');
				domAddr = domAddr.replace('/','');
				domAddr = domAddr.replace(/ /gi,'');
				
				
				if( '' === $redirectName.val() || checkFlag === 'true' ) {
					// 선박 등록
					var insertParam = {
						  'BIZ_ID' : $insertForm.find('[data-key=BIZ_ID] option:selected').val()
						, 'SHIP_NAME' : $insertForm.find('[data-key=SHIP_NAME]').val()
						, 'PORT_ADDR' : $insertForm.find('[data-key=PORT_ADDR]').val()
						, 'SHIP_DESC' : $insertForm.find('[data-key=SHIP_DESC]').val()
						, 'SITE_TYPE' : '2'
						, 'MAIN_IMG_ID' : mainimageIdStr
						, 'HOME_IMGS_ID' : homeimageIdStr
						, 'INTRODUCE' : $insertForm.find('[data-key=INTRODUCE]').val()
						, 'CPTN_MEM_ID' :  $insertForm.find('[data-type=CPTN_MEM_ID]').attr('cptnMemId')
						, 'CPTN_IMG_ID' : (cptnImgId ? cptnImgId : '')
						, 'CPTN_NAME' : $insertForm.find('[data-key=CPTN_NAME]').val()
						, 'DEPART_TIME' : $insertForm.find('[data-key=DEPART_TIME]').val()
						, 'RETURN_TIME' : $insertForm.find('[data-key=RETURN_TIME]').val()
						, 'PSGR_CNT' : "0"
						, 'PORT_CD' : $insertForm.find('[data-key=PORT_CD] option:selected').val()
						, 'ETC_DESC' : $insertForm.find('[data-key=ETC_DESC]').val()
						, 'REDIRECT_NAME' : $insertForm.find('[data-key=REDIRECT_NAME]').val()
						, 'NAVIGATION' : $insertForm.find('[data-key=NAVIGATION]').val()
						, 'CAFE_YN' : $insertForm.find('[data-key=CAFE_YN]').val()
						, 'CAFE_URL' : $insertForm.find('[data-key=CAFE_URL]').val()
						, 'PENSION_URL' : $insertForm.find('[data-key=PENSION_URL]').val()
						, 'HOUSE_TYPE' : $insertForm.find('[data-key=HOUSE_TYPE]').val()
						, 'PENSION_TYPE' : $insertForm.find('[data-key=PENSION_TYPE]').val()
						, 'DOM_ADDR' : domAddr
						, 'SITE_TEMPLATE_CD' : $insertForm.find('[data-key=SITE_TEMPLATE_CD]').val()
						, 'TEST_YN' : $insertForm.find('[data-key=TEST_YN]').val()
						, 'BBS_YN' : $insertForm.find('[data-key=BBS_YN]').val()
						, 'AUTOPOST_YN' : "N"
						, 'META_DESC' :	$insertForm.find('[data-key=META_DESC]').val()
						, 'CARD_YN' :	$insertForm.find('[data-key=CARD_YN]').val()
						, 'COMP_SVC' :	$insertForm.find('[data-key=COMP_SVC]').val()
						, 'SUPPLY' : $insertForm.find('[data-key=SUPPLY]').val()
						, 'FISHING_CD' : '119_220'
					};

					if ($insertForm.CAFE_YN == "Y" && ($insertForm.CAFE_URL == ""|| $insertForm.CAFE_URL == ""))
					{
						alert("카페 바로가기를 하려면 카페 URL을 입력하셔야 합니다.");
						return;
					}
					
					_self._isSaving = true;
					
					$.ajax({
						 url : _self._shipInsertURL
						,type : 'POST'
						,data : insertParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	_self._isSaving = false;
					    	if( data.hasOwnProperty('result') ) {
					    		alert('등록 되었습니다');
					    		location.reload();
					    	}
					    }
	             	,error: function(result) {
	                    alert("수정실패!!!");
				    	_self._isSaving = false;
	                }
					
					});
				}else {
					alert('REDIRECT_NAME 중복체크를 해주세요');
				}
			},
			// 숙박업체 수정
			'updateShip' : function() {
				var _self = this;
				
				if (_self._isSaving)
				{
					alert('저장중입니다. 잠시만 기다려주세요.');
					return;
				}
				
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var updateData = _self.list.getListRowData(_self.selectShipId, 'SHIP_ID');
				// 선장
				var cptnMemId = $updateForm.find('[data-type=CPTN_MEM_ID]').attr('cptnMemId');
				var beforeCptnMemId = updateData.CPTN_MEM_ID;
				// IMG_ID

				var cptnImgId = _self.cptnFileList.getFile();

				var mainimageIdStr = _self.mainFileList.getFileIdString();
				var homeimageIdStr = _self.homeFileList.getFileIdString();				
				
				var beforeMainImgId = updateData.MAIN_IMG_ID ? updateData.MAIN_IMG_ID : '';
				var beforeCptnImgId = updateData.CPTN_IMG_ID ? updateData.CPTN_IMG_ID : '';
				
				var $redirectName = $updateForm.find('[data-key=REDIRECT_NAME]');
				
				if( _self.redirectNameTemp == $redirectName.val() ){
					$redirectName.attr('checkFlag', true);
				}
				
				var checkFlag =$redirectName.attr('checkFlag');

				var domAddr = $updateForm.find('[data-key=DOM_ADDR]').val();
				
				domAddr = domAddr.replace('http://','');
				domAddr = domAddr.replace('/','');
				domAddr = domAddr.replace(/ /gi,'');
				
				if( '' === $redirectName.val() || checkFlag === 'true' ) {
					// 업체 수정
					var updateParam = {
						  'SHIP_ID' : updateData.SHIP_ID
						, 'BIZ_ID' : $updateForm.find('[data-key=BIZ_ID] option:selected').val()
						, 'SHIP_NAME' : $updateForm.find('[data-key=SHIP_NAME]').val()
						, 'PORT_ADDR' : $updateForm.find('[data-key=PORT_ADDR]').val()
						, 'SHIP_DESC' : $updateForm.find('[data-key=SHIP_DESC]').val()
						, 'MAIN_IMG_ID' : mainimageIdStr
						, 'HOME_IMGS_ID' : homeimageIdStr
						, 'BEFORE_MAIN_IMG_ID' : beforeMainImgId
						, 'INTRODUCE' : $updateForm.find('[data-key=INTRODUCE]').val()
						, 'CPTN_MEM_ID' : cptnMemId
						, 'BEFORE_CPTN_MEM_ID' : (beforeCptnMemId === cptnMemId || !beforeCptnMemId) ? "" : beforeCptnMemId
						, 'CPTN_IMG_ID' : (cptnImgId ? cptnImgId : '')
						, 'BEFORE_CPTN_IMG_ID' : beforeCptnImgId
						, 'CPTN_NAME' : $updateForm.find('[data-key=CPTN_NAME]').val()
						, 'DEPART_TIME' : $updateForm.find('[data-key=DEPART_TIME]').val()
						, 'RETURN_TIME' : $updateForm.find('[data-key=RETURN_TIME]').val()
						, 'PORT_CD' : $updateForm.find('[data-key=PORT_CD] option:selected').val()
						, 'ETC_DESC' : $updateForm.find('[data-key=ETC_DESC]').val()
						, 'NAVIGATION' : $updateForm.find('[data-key=NAVIGATION]').val()
						, 'REDIRECT_NAME' : $updateForm.find('[data-key=REDIRECT_NAME]').val()
						, 'CAFE_YN' : $updateForm.find('[data-key=CAFE_YN]').val()
						, 'CAFE_URL' : $updateForm.find('[data-key=CAFE_URL]').val()						
						, 'PENSION_URL' : $updateForm.find('[data-key=PENSION_URL]').val()
						, 'HOUSE_TYPE' : $updateForm.find('[data-key=HOUSE_TYPE]').val()
						, 'PENSION_TYPE' : $updateForm.find('[data-key=PENSION_TYPE]').val()
						, 'DOM_ADDR' : domAddr
						, 'SITE_TEMPLATE_CD' : $updateForm.find('[data-key=SITE_TEMPLATE_CD]').val()
						, 'TEST_YN' : $updateForm.find('[data-key=TEST_YN]').val()
						, 'BBS_YN' : $updateForm.find('[data-key=BBS_YN]').val()
						, 'AUTOPOST_YN' : 'N'
						, 'SITE_TYPE' : '2'
						, 'META_DESC' :	$updateForm.find('[data-key=META_DESC]').val()						
						, 'CARD_YN' :	$updateForm.find('[data-key=CARD_YN]').val()
						, 'COMP_SVC' :	$updateForm.find('[data-key=COMP_SVC]').val()
						, 'SUPPLY' : $updateForm.find('[data-key=SUPPLY]').val()
						, 'PSGR_CNT' : '0'
					};
					
					if (updateParam.CAFE_YN == "Y" && updateParam.CAFE_URL == "")
					{
						alert("카페 바로가기를 하려면 카페 URL을 입력하셔야 합니다.");
						return;
					}
					
					_self._isSaving = true;
					
					$.ajax({
						 url : _self._shipUpdateURL
						,type : 'POST'
						,data : updateParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	_self._isSaving = false;
					    	if( data.hasOwnProperty('result') ) {
					    		alert('수정 되었습니다');
					    		location.href="/sc/pension?SHIP_ID="+updateData.SHIP_ID;
					    	}else{
					    		  alert("수정실패!!!");
							     _self._isSaving = false;
					    	}
					    }
		             	,error: function(result) {
		                    alert("수정실패!!!");
					    	_self._isSaving = false;
		                }
					});
				}else {
					alert('REDIRECT_NAME 중복체크를 해주세요');
				}
			},
			// 선박 삭제
			'deleteShip' : function() {
				var _self = this;
				var selectData = _self.list.getListRowData(_self.selectShipId, 'SHIP_ID');
				$.ajax({
					 url : _self._shipDeleteURL
					,type : 'POST'
					,data : {
						  'SHIP_ID' : _self.selectShipId
						 ,'MAIN_IMG_ID' : selectData.MAIN_IMG_ID
						 ,'CPTN_IMG_ID' : selectData.CPTN_IMG_ID
						 ,'CPTN_MEM_ID' : selectData.CPTN_MEM_ID 
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			
			//이미지 컨테이너에 이미지들을 셋팅
			'setImageContainer' : function( fieldName,data) {
				
				var _self = this;
				
				var imgContainer = _self.$detailForm.find('[data-type="' + fieldName + '"]');	
				var images = data[fieldName] ? data[fieldName].split(",") : null;		
				var imgList = [];
									
				if (images == null)
				{
					imgContainer.empty();						
				}
				else
				{
					$.each(images, function(index, value)
							{
								imgList.push({"IMG_ID":value});						
							});						
					jdg.util.createImgList( imgList, imgContainer );
					
				}	
				
				return imgList;
				
			},
			
			
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					
					//data.MAIN_IMG_ID = null;					
					
					//선박이미지 멀티이미지 처리
					_self.shipImageList = _self.setImageContainer("MAIN_IMGS_ID", data);
					//홈이미지 멀티이미지 처리
					_self.homeImageList = _self.setImageContainer("HOME_IMGS_ID", data);
				
					jdg.util.detailDataSetting( $detailForm, data );

					
					var $redirectName = _self.$detailForm.find('[data-key=REDIRECT_NAME]');
					if( $redirectName.text() != "" ){
						$redirectName.text("/"+$redirectName.text() + ".ps");
					}
					
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					
					// 선장
					$insertForm.find('[data-type=CPTN_MEM_ID]').val('');
					$insertForm.find('[data-type=CPTN_MEM_ID]').attr('cptnMemId','');
					
					// 파일리스트 초기화
					
					//선박이미지는 멀티로
					_self.mainFileList = new component.FileList({
						 'id' : 'INSERT_MAIN_IMGS_ID'
						,'container' : $('#INSERT_MAIN_IMGS_ID')
					});
					_self.mainFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
			        //_self.mainFileList.find(".fileAddBtn").attr('id', "mainAddFile");
					_self.mainFileList.init([]);
					
					// 홈화면 배경 이미지 셋팅
					_self.homeFileList = new component.FileList({
						 'id' : 'INSERT_HOME_IMGS_ID'
						,'container' : $('#INSERT_HOME_IMGS_ID')
					});
					
			        _self.homeFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
					_self.homeFileList.init([]);	
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();
							_self.loadBgImage();
							return false;
						});
					}
					
					//선장이미지는 싱글(한개)로
					_self.cptnFileList = new component.File({
						 'id' : 'INSERT_CPTN_IMG_ID'
						,'container' : $('#INSERT_CPTN_IMG_ID')
					});
					_self.cptnFileList.init();
					_self.$insertForm.find('[data-key=REDIRECT_NAME]').removeClass('jdg-disabled');
					_self.$insertForm.find('[data-key=REDIRECT_NAME]').attr('readonly', false);
					_self.$insertForm.find('[data-key=REDIRECT_NAME]').attr('checkFlag', 'flase');
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅

					jdg.util.detailDataSetting( $updateForm, data );
			
					//선박이미지 셋팅
					_self.mainFileList = new component.FileList({
						 'id' : 'UPDATE_MAIN_IMGS_ID'
						,'container' : $('#UPDATE_MAIN_IMGS_ID')
					});
					
			        _self.mainFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
			        //_self.mainFileList.find(".fileAddBtn").attr('id', "mainAddFile");
					_self.mainFileList.init(_self.shipImageList );
					
					
					// 홈화면 배경 이미지 셋팅
					_self.homeFileList = new component.FileList({
						 'id' : 'UPDATE_HOME_IMGS_ID'
						,'container' : $('#UPDATE_HOME_IMGS_ID')
					});
					

			        _self.homeFileList.ele.fileListRow = $('#commonTemplate').find('.fileListRow2');
			        //_self.homeFileList.find(".fileAddBtn").attr('id', "homeAddFile");
					_self.homeFileList.init(_self.homeImageList );	
					
					//배경화면 기본이미지 추가버튼 보이기
					var basicBtn = _self.homeFileList.ele.container.find(".basicfileAddBtn");	
					
					if (basicBtn.is(':hidden'))
					{
						basicBtn.show(); //기본이미지 추가 버튼 보이기
						basicBtn.click( function() {
							_self.$popupSelectBasicImage.show();
							_self.loadBgImage();
							return false;
						});
					};
					
					
					//선장이미지 셋팅
					_self.cptnFileList = new component.File({
						 'id' : 'UPDATE_CPTN_IMG_ID'
						,'container' : $('#UPDATE_CPTN_IMG_ID')
					});
					_self.cptnFileList.init( data.CPTN_IMG_ID ? data : null );
					
					_self.redirectNameTemp = $updateForm.find('[data-key=REDIRECT_NAME]').val();
					
					//_self.$updateForm.find('[data-type=PORT_CD]').val(data.PORT_CD);
					_self.$updateForm.find('[data-type=CPTN_MEM_ID]').text(data.CPTN_MEM_ID);
					_self.$updateForm.find('[data-type=GRADE_NAME]').parent().hide();
					_self.$updateForm.find('[data-type=MEM_NAME]').text(data.CPTN_MEM_NAME);
					_self.$updateForm.find('[data-type=EMAIL]').parent().hide();
					_self.$updateForm.find('[data-type=TEL]').parent().hide();
					
					// 선장
					$updateForm.find('[data-type=CPTN_MEM_ID]').attr( 'cptnMemId', data.CPTN_MEM_ID ? data.CPTN_MEM_ID : '' );
					_self.$updateForm.find('[data-key=REDIRECT_NAME]').removeClass('jdg-disabled');
					_self.$updateForm.find('[data-key=REDIRECT_NAME]').attr('readonly', false);
					_self.$updateForm.find('[data-key=REDIRECT_NAME]').attr('checkFlag', 'flase');
					$updateForm.show ();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			// REDIRECT_NAME 중복체크
			'redirectNameCheck' : function( $redirectName ) {
				var _self = this;
				var redirectName = $.trim( $redirectName.val() );
				if( '' === redirectName ) {
					alert('리다이렉트 명칭을 입력해주세요');
					return false;
				}
				$.ajax({
					 url : _self._redirectNameCheckURL
					,type : 'POST'
					,data : {
						 'REDIRECT_NAME' : redirectName
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('count') ) {
				    		if( data.count == 0 ) {
				    			alert('등록 가능한 리다이렉트 명칭 입니다');
				    			// 닉네임창 비활성화
				    			$redirectName.addClass('jdg-disabled');
				    			$redirectName.attr('readonly', true);
				    			$redirectName.attr('checkFlag', 'true');
				    		} else {
				    			alert('사용중인 리다이렉트 명칭 입니다');
				    			$redirectName.attr('checkFlag', 'false');
				    		}
				    	}
				    }
				});
			},

			// 배경이미지 로딩
			'loadBgImage' : function() {
				var _self = this;
				
				if (_self._bgImgloaded) return;
				_self._bgImgloaded = true;
				
				var bgCon = $('#bgCon');
				var imgitem;
				var imgNum;
				
	    		for(var i=1; i <= 609; i++)
	    		{
	    			imgNum = "HOMEBG" + (("000" + i).slice(-4));

	    			imgitem = 				    			
						'<li class="basicImgRow" style="float:left; padding: 10px;">' +	
							'<input type="checkbox" class="chkImgs" value="' + imgNum + '">' +	
							'<img style="width:240px;height:120px;" src="https://img.fishapp.co.kr/legacy/b0/' + imgNum +'.jpg">' +						
						'</li>';	
	    			bgCon.append(imgitem);
	    			
	    		} 
			},
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선박목록조회
				if( p_param.hasOwnProperty('SHIP_ID') ) {
					for(var i = 0 ;i < arryShip.length ;i++){
						if(arryShip[i].ship_id == p_param.SHIP_ID){
							$("#searchText").val(arryShip[i].ship_nm).trigger("focusout");
						}
					}
					this.getShipList(1, {SHIP_ID : p_param.SHIP_ID});
				}
				else
					this.getShipList('1');
				
				$('.jdg-ui-inner').prop('disabled',true);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
				// 관리자 팝업 close
				if( 'member_insert_popup' === p_param.id ) {
					var $cptnMemId = _self.$insertForm.find('[data-type=CPTN_MEM_ID]');
					var $gradeName = _self.$insertForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$insertForm.find('[data-type=MEM_NAME]');
					var $email = _self.$insertForm.find('[data-type=EMAIL]');
					var $tel = _self.$insertForm.find('[data-type=TEL]');
					if( data ) {
						$cptnMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME );
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL );
						$tel.text( data.TEL );

						$cptnMemId.attr('cptnMemId', data.MEM_ID );
					//} else {
						//$cptnMemId.val( '' );
						//$cptnMemId.attr('cptnMemId', '' );
					}
				} else if( 'member_update_popup' === p_param.id ) {
					var $cptnMemId = _self.$updateForm.find('[data-type=CPTN_MEM_ID]');
					var $gradeName = _self.$updateForm.find('[data-type=GRADE_NAME]');
					var $memName = _self.$updateForm.find('[data-type=MEM_NAME]');
					var $email = _self.$updateForm.find('[data-type=EMAIL]');
					var $tel = _self.$updateForm.find('[data-type=TEL]');
					if( data ) {
						$cptnMemId.text( data.MEM_ID );
						$gradeName.text( data.GRADE_NAME ).parent().show();
						$memName.text( data.MEM_NAME );
						$email.text( data.EMAIL ).parent().show();
						$tel.text( data.TEL ).parent().show();
						
						$cptnMemId.attr('cptnMemId', data.MEM_ID );
					//} else {
						//$cptnMemId.val( '' );
						//$cptnMemId.attr('cptnMemId', '' );
					}
				}
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_main] onDestroy Method' );
			}
	  }
});
