defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._codeURL = $('#codeURL').val();
				this._codeCategoryListURL = $('#codeCategoryListURL').val();
				this._codeCategoryInsertURL = $('#codeCategoryInsertURL').val();
				this._codeCategoryUpdateURL = $('#codeCategoryUpdateURL').val();
				this._codeCategoryDeleteURL = $('#codeCategoryDeleteURL').val();
				// element
				this.$listContainer = $('#codeCategoryListContainer');
				this.$listTemplate = $('#codeCategoryListTemplate');
				this.$detailForm = $('#codeCategoryDetailForm');
				this.$regBtn = $('#regBtn');
				this.$mfyBtn = $('#mfyBtn');
				this.$delBtn = $('#delBtn');
				this.$regCancelBtn = $('#regCancelBtn');
				this.$mfyCancelBtn = $('#mfyCancelBtn');
				// form
				this.$srchForm = $('#codeCategorySearchForm');
				this.$insertForm = $('#codeCategoryInsertForm');
				this.$updateForm = $('#codeCategoryUpdateForm');
				// static variable
				this.selectCodeCategoryId = '';
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조회
				_self.$srchForm.submit(function() {
					// 코드 카테고리 목록 조회
					_self.getCodeCategoryList('1');
					return false;
				});
				
				// 등록폼요청버튼클릭
				_self.$regBtn.click( function() {
					_self.selectFormShow('insert');
				});
				
				// 신규등록 취소
				_self.$regCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 신규등록
				_self.$insertForm.submit( function() {
					_self.insertCodeCategory();
					return false;
				});
				
				// 수정폼요청버튼클릭
				_self.$mfyBtn.click( function() {
					_self.selectFormShow('update', _self.list.getListRowData( _self.selectCodeCategoryId, 'CODE_CATE') );
				});
				
				// 수정 취소
				_self.$mfyCancelBtn.click( function() {
					_self.selectFormShow('none');
				});
				
				// 수정
				_self.$updateForm.submit( function() {
					_self.updateCodeCategory();
					return false;
				});
				
				// 삭제
				_self.$delBtn.click( function() {
					
					// 삭제확인(아니오를 하면 삭제를 취소함
					if(!confirm("삭제하시겠습니까?")) {return;}
					
					_self.deleteCodeCategory();
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self.selectCodeCategoryId = $tr.attr('rowKey');
				_self.selectFormShow('search', _self.list.getListRowData(_self.selectCodeCategoryId, 'CODE_CATE'));
				// style
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
			},
			// 코드 카테고리 목록 조회
			'getCodeCategoryList' : function( page, param ) {
				var _self = this;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '5'
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._codeCategoryListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('codeCategoryList') ) {
				    		// 리스트초기화
				    		_self.list.createList( data.codeCategoryList, 'CODE_CATE', function( data, $row ){
				    			if( data.UPDATED_AT ) {
				    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
				    				$row.find('[data-key=CREATED_NAME]').text( data.UPDATED_NAME );
				    			}
				    			$row.find('.codeCntLink').click( function( e ) {
				    				// 코드관리로 이동
				    				Bplat.view.loadPage( _self._codeURL, {
				    					'CODE_CATE' : data.CODE_CATE
				    				});
				    				e.stopPropagation();
				    				return false;
				    			});
				    		});
				    		// 페이징 초기화
				    		$('#codeCategoryListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 5))
								,onclick:function(e,page){
									_self.getCodeCategoryList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.codeCategoryList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		}
				    	}
				    }
				});
			},
			// 코드 카테고리 등록
			'insertCodeCategory' : function() {
				var _self = this;
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				var param = {
						 'CODE_CATE' : $insertForm.find('[data-key=CODE_CATE]').val()
						,'USE_YN' : $insertForm.find('[data-type=USE_YN] option:selected').val()
						,'DESCR' : $insertForm.find('[data-key=DESCR]').val()
				};
				$.ajax({
					 url : _self._codeCategoryInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 코드 카테고리 수정
			'updateCodeCategory' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				var param = {
					'CODE_CATE' : _self.selectCodeCategoryId
					,'USE_YN' : $updateForm.find('[data-type=USE_YN] option:selected').val()
					,'DESCR' : $updateForm.find('[data-key=DESCR]').val()
				};
				$.ajax({
					 url : _self._codeCategoryUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('수정 되었습니다');
				    		location.reload();
				    	}
				    }
				});
			},
			// 코드 카테고리 삭제
			'deleteCodeCategory' : function() {
				var _self = this;
				$.ajax({
					 url : _self._codeCategoryDeleteURL
					,type : 'POST'
					,data : {
						 'CODE_CATE' : _self.selectCodeCategoryId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('삭제 되었습니다');
				    		location.reload();
				    	}
				    	alert( data.error.userMessage );
				    }
				});
			},
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var $updateForm = _self.$updateForm;
				var $detailForm = _self.$detailForm;
				
				// 상세조회
				if( 'search' === mode) {
					$updateForm.hide();
					$insertForm.hide();
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				// 신규등록
				else if( 'insert' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					// 데이터 초기화
					jdg.util.detailDataSetting( $insertForm, {} );
					$insertForm.find('[data-type=USE_YN] option:eq(0)').attr('selected',true);
					$insertForm.show();
				}
				// 수정
				else if( 'update' === mode ) {
					$detailForm.hide();
					$insertForm.hide();
					// 수정데이터셋팅
					jdg.util.detailDataSetting( $updateForm, data );
					$updateForm.find('[data-type=USE_YN]').val(data['USE_YN']);
					$updateForm.show();
				}
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$updateForm.hide();
					$detailForm.hide();
					$insertForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[code_category_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				if( p_param.hasOwnProperty('CODE_CATE') ) {
					// 코드 카테고리 목록 조회
					this.getCodeCategoryList('1',{
						'CODE_CATE' : p_param.CODE_CATE
					});
				} else {
					// 코드 카테고리 목록 조회
					this.getCodeCategoryList('1');
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[code_category_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[code_category_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[code_category_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[code_category_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[code_category_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[code_category_main] onDestroy Method' );
			}		
	  }
});
