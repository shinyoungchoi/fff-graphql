defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._bizURL = $('#bizURL').val();
				this._shipListURL = $('#shipListURL').val();
				this._registerCompleteURL = $("#registerCompleteURL").val();
				this._deleteFreeURL = $("#deleteFreeURL").val();
			
				this._excelURL = $('#memberSearchURL').val();
				
				// element
				this.$listContainer = $('#shipListContainer');
				this.$listTemplate = $('#shipListTemplate');
				this.$detailForm = $('#shipDetailForm');
				
				this.$prepaidlistContainer = $("#msgHistoryListContainer");
				this.$prepaidlistTemplate = $("#prepaidlistTemplate");
				
				
				//기본이미지 추가(파일업로드가 아닌 서버에 있는 이미지 선택)
				this.$basicfileAddBtn = $('.basicfileAddBtn');		
				
				this.$popupSelectBasicImage = $('#popupSelectBasicImage');	
				
				// form
				this.$srchForm = $('#shipSearchForm');
				this.$insertForm = $('#shipInsertForm');
				this.$updateForm = $('#shipUpdateForm');
				
				// static variable
				this.selectShipId = '';
				this.selectedRowData = {};
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
		
				this.redirectNameTemp = "";
				
				// 배경이미지 선택용
				var _flstRow = $(".fileListRow2");
				
				this._bgImgloaded = false;
				
				this._isSaving = false;				
			},
			'setEvent'		: function() {
				var _self = this;
				// 조회
				_self.$srchForm.submit(function() {
					var $this = $(this);
					var param = {};
					var searchText = $.trim($this.find('#searchText').val());
					param = {'PHONE' : searchText};
					// 회원목록조회
					_self.getShipList('1', param);
					return false;
				});
				
			
				
			
				
			},
	
			'closePopup' :function(){
				var _self = this;
				_self.$popupSelectBasicImage.hide();
		        _self.$popupSelectBasicImage.find(':checkbox:checked').each(function(i){
		        	$(this).attr("checked", false);
		        });
			},		
					
			// 홈피 인증번호 목록 조회
			'getShipList' : function( page, param ) {
				var _self = this;
				var defaultParam = {'PAGE' : page, 'PERPAGE' : '10'};
				$.extend(defaultParam, param);
				$.ajax({
					 url : _self._shipListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('shipList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.shipList, 'TR_NUM');
				    		
				    		// 페이징 초기화
				    		$('#shipListPaging').paging({
								 current: page
								,max: (Math.ceil(data.total / 10))
								,onclick:function(e,page){
									_self.getShipList(page, param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    	
				    	}
				    }
				});
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[ship_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 선박목록조회
				this.getShipList('1');
				
				$('.jdg-ui-inner').prop('disabled',true);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[ship_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onHidePopup Method', JSON.stringify( p_param ) );
				var _self = this;
				var data = p_param.value;
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[ship_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[ship_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[ship_main] onDestroy Method' );
			}
	  }
});
