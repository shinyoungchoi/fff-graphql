defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._memberListURL = "/sc/member/qna/list";
				this._memberDetailURL = "/sc/member/qna/detail";
				this._qnaInsertURL = "/sc/member/qna/updateAnswer";
				this._page = 1;
			
				// element
				this.$listContainer = $('#memberListContainer');
				this.$listTemplate = $('#memberListTemplate');
				this.$detailForm  = $('#memberDetailForm');
				this.$regBtn = $('#regBtn');
			
				this.$mGradeSel = $('#memberGradeSel');
				this.$mSrhKeyRadio = $('[name=memberSearchTerms]');
				this.$mSrhVal = $('#memberSearchVal');
				
				// form
				this.$srchForm = $('#memberSearchForm');
				
				// static variable
				this.ShipMemberList = [];
				this.selectMemberId = '';
				this.selectDetailData = {};
				this.updateShipMemberList = [];
				this.selectPage = ''; // 회원 목록 페이지
				this.selectSubPage = ''; //포인트 내역 목록 페이징
				this.list = new component.List({
					 'container' : this.$listContainer
					,'template' : this.$listTemplate.find('.searchRow')
					,'nodata' : this.$listTemplate.find('.nodataRow')
				});
				
				this._selectPostId = "";
				this.$selectedSortOption = "";
				this.$portalYn = "N";
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 1:1 문의 조회
				_self.$srchForm.submit(function() {
					// 1:1 문의 조회
					var param = {};
					var key = _self.$mSrhKeyRadio.filter(':checked').val();
					if( '' !== key ) {
						param[key] = $.trim(_self.$mSrhVal.val());
					}
					_self.getQnaList('1',param);
					return false;
				});
				
				_self.$selectedSortOption = $(".btnSort:first");
				
				$(".btnSort").click( function(event) {

					clicked = event.target.value;
					
					var oldSel = _self.$selectedSortOption;
					var newSel = $(event.target);
					
					if (oldSel != newSel)
					{
						oldSel.css("background-color",newSel.css("background-color"));
						newSel.css("background-color","yellow");
						
						_self.$selectedSortOption = newSel;
						
						_self.$srchForm.submit();
					}
					
					return false;
				});				

				$("#regBtn").click(function(){
					
					if($("#content_answer").val() == "" || $("#subject_answer").val() == "" ){
						alert("답변 제목과 내용을 모두 입력해주세요.");
						return;
					}
					
					var param = {
							CONTENT_A : $("#content_answer").val()
							, SUBJECT_A : $("#subject_answer").val()
							, POST_ID : _self._selectPostId 
					}
					
					$.ajax({
						 url : _self._qnaInsertURL
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	console.log(data);
					    	if(data.result == "success"){
					    		alert("답변이 저장되었습니다.");
					    		_self.getQnaList(_self._page, null, _self._selectPostId );
					    	}else{
					    		alert("저장도중 오류가 발생하였습니다.");
					    		return;
					    	}
					    	
					    }
					});
				});
				
				//답변 입력 취소시
				$("#cancleBtn").click(function(){
					_self.selectFormShow('none');
				});
				
				// 테이블 ROW 선택시 상세보기
				_self.$listContainer.delegate('tr','click', function() {
					var $this = $( this );
					_self.openDetailForm( $this );
				});
			},
			// 상세 펼침
			'openDetailForm' : function( $tr ) {
				var _self = this;
				_self._selectPostId = $tr.attr('rowKey');
				this._selectPostId  = _self._selectPostId;
				
				_self.$listContainer.find('tr').removeClass('jdg-selected');
				$tr.addClass('jdg-selected');
				$.ajax({
					 url : _self._memberDetailURL
					,type : 'POST'
					,data : {'POST_ID' : _self._selectPostId}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('qna_detail') ) {
				    		var detail = data.qna_detail;
				    		_self.selectDetailData = detail;
				    		_self.selectFormShow('search', detail);
				    	}
				    }
				});
			},
			// 1:1 문의내역 조회
			'getQnaList' : function( page, param, showDetailId ) {
				var _self = this;
				_self._page = page;
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				    ,'SORT': _self.$selectedSortOption.val()
				};
				$.extend( defaultParam, param );
				// 페이지 저장
				_self.selectPage = page;
				$.ajax({
					 url : _self._memberListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('qnaList') ) {
				    		// 리스트 초기화
				    		_self.list.createList( data.qnaList, 'POST_ID' , function( data, $row ) {

				    		});
				    		
				    		var max_ = 0;
				    		if(data.qnaList != null && data.qnaList.length > 0){
				    			max_ = Math.ceil(data.qnaList[0].TOTAL / 10)
				    		}
				    		
				    		// 페이징 초기화
				    		$('#memberListPaging').paging({
								 current: page
								,max: max_
								,onclick:function(e,page){
									_self.getQnaList(page,param);
								}
		    					,prev : '이전'
				    			,next : '다음'
							});
				    		_self.selectFormShow('none');
				    		// 데이터1개일 경우 자동 펼침
				    		if( data.qnaList.length == 1 ) {
				    			_self.openDetailForm( _self.$listContainer.find('tr:eq(0)') );
				    		} 
				    		// 선택하고자 하는 데이터 자동 펼침
				    		else if( showDetailId ) {
				    			_self.openDetailForm( _self.$listContainer.find('[rowKey='+showDetailId+']') );
				    		}
				    	}
				    }
				});
			},
			
			// 선택한 폼을 보여준다
			'selectFormShow' : function( mode, data ) {
				var _self = this;
				var $detailForm = _self.$detailForm;
				// 상세조회
				if( 'search' === mode) {
					// 상세데이터셋팅
					jdg.util.detailDataSetting( $detailForm, data );
					$detailForm.show();
				}
				
				// 하단 폼 모두 제거
				else if( 'none' === mode ) {
					$detailForm.hide();
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[member_main] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				// 1:1 문의내역 조회
				this.getQnaList('1', p_param);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[member_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[member_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[member_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[member_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[member_main] onDestroy Method' );
			}		
	  }
});
