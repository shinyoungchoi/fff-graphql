defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._context = $('#context').val();
				this._state = $('#state').val();
				this._loginURL = $('#loginURL').val();
				this._signupURL = $('#signupURL').val();
				this._signupSimpleURL = $('#signupSimpleURL').val();
				this._pwdResetURL = $('#pwdResetURL').val();
				this._idFindURL = $('#idFindURL').val();
				
				// element
				this.$loginForm = $('#loginForm');
				this.$idFindLayer = $('#idFindLayer');
				this.$pwInitLayer = $('#pwInitLayer');
				this.$userIdFindBtn = $('#userIdFindBtn');
				this.$pwdInitBtn = $('#pwdInitBtn');
				
				this.$idTxt = $('#jdg-id');
				this.$pwTxt = $('#jdg-pw');
				this.$signUpBtn = $('#signUpBtn');
				this.$pwdReset = $('#pwdReset');
			},
			'setEvent'		: function() {
				var _self = this;
				// 로그인 폼 전송
				var options = {
					 type : 'POST'
					,url : _self._loginURL
				    ,dataType : 'json'
				    ,beforeSubmit : function( formData, jqForm, options ) {
						// validation
						if( !jdg.util.validator( _self.$loginForm, true ) ) return false;
				    }
				    ,success : function( data ) {
				    	if("N" == data.simpleLogin){
					    	if( data.msg || null != data.msg ) {
					    		alert( data.msg );
					    		
					    		if (data.certUrl != null)
					    		{
					    			Bplat.view.loadPage( data.certUrl );
					    		}
					    		
					    		return false;
					    	}
					    	var url =  data.redirectUrl;
					    	Bplat.view.loadPage( url );
				    	}else{
				    		if( confirm(data.msg) == true){
				    			Bplat.view.loadPage(_self._signupSimpleURL,{
				    				'email' : _self.$idTxt.val()
				    			});
				    		}else{
				    			return false;
				    		}
				    	}
				    }
				};
				_self.$loginForm.ajaxForm( options );
				
				//비번초기화 버튼.
				_self.$pwdInitBtn.click(function(){
					Bplat.view.loadPage( _self._pwdResetURL );
				});

				//회원ID 찾기 버튼.
				_self.$userIdFindBtn.click(function(){
					Bplat.view.loadPage( _self._idFindURL );
				});
				
				//회원가입 버튼
				_self.$signUpBtn.click(function(){
					Bplat.view.loadPage( _self._signupURL );
				});
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[login] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[login] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[login] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[login] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[login] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[login] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[login] onDestroy Method' );
			}		
	  }
});