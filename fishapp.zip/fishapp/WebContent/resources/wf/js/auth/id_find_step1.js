defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._sendAuthCodeURL = $('#sendAuthCodeURL').val();
				this._confirmAuthCodeURL = $('#confirmAuthCodeURL').val();
				this._resultUrl = $('#resultUrl').val();				

				this.$tblPhone = $('#tblPhone');
				this.$tblEmail = $('#tblEmail');
				
				this.$phoneNum1 = $('#PHONE_NUM_1');
				this.$phoneNum2 = $('#PHONE_NUM_2');
				this.$phoneNum3 = $('#PHONE_NUM_3');
				
				this.$btnAuthSend = $('#btnAuthSend');
				this.$expTime = $('#expTime');
				this.$authCode = $('#AUTH_CODE');
				this.$divAuth = $('#divAuth');

				this.msg = $('#msg').val();
				this._authType;
				
				this.$fieldSet = $('fieldset');
			},
			'setEvent'		: function() {
				var _self = this;
			
				$('.mainImageCheck').click(function( event ){
					
					var v = event.target.value;
					
					if (v == "phone")
					{
						_self.$tblPhone.show();
						_self.$tblEmail.hide();						
						$(_self.$fieldSet[0]).after(_self.$divAuth);	
					}
					else
					{
						_self.$tblPhone.hide();
						_self.$tblEmail.show();			
						$(_self.$fieldSet[1]).after(_self.$divAuth);
					}

				});
				
				$('._reqAuth').click(function( event ){
					
					event.preventDefault();
					
					var v = event.currentTarget.value;
					
					var userName = null;
					var phoneNum = null;
					var email = null;
					
					_self._authType = v;
					
					
					if (v == "phone")
						{
							userName = $("#phone_userName").val();
							
							if (userName == "" || userName.length < 2)
							{
								alert('이름을 입력해주십시오.');
								return false;
							}							
							
							phoneNum = _self.$phoneNum1.val() + '-' + _self.$phoneNum2.val() + '-' + _self.$phoneNum3.val();
							
							//전화번호 형식 체크
							var regExp = /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/;
							if(!regExp.test(phoneNum)){
								alert('정상적인 전화번호를 입력해주세요.');
								return false;
							}
						}
					else
						{
							userName = $("#email_userName").val();
							
							if (userName == "" || userName.length < 2)
							{
								alert('이름을 입력해주십시오.');
								return false;
							}	
							
							email = $("#email").val();	
							
							//이메일 형식 체크
							var regExp = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
							if(!regExp.test(email)){
								alert('정상적인 Email을 입력해주세요.');
								return false;
							}
						}

			    	var param = {
					    	USER_NAME : userName
					    	,TEL: phoneNum
					    	,EMAIL: email
			    	};

			    	
			    	$('._reqAuth').hide();
					
					$.ajax({
						url : _self._sendAuthCodeURL
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
							
							if(data.ERR != null)
							{
								alert(data.ERR);
								$('._reqAuth').show();
								
								return false;
							}

					
							window.$timeLeft = 180;
							_self.$expTime.text(window.$timeLeft + '초');
							_self.$authCode.val('');
							_self.$divAuth.show();
							
							window.$timerId = setInterval(_self.countdown, 1000);
							var aType = (_self.authType == "phone") ? "문자가":"메일이";							
					    	alert('인증 번호가 발송되었습니다.');
							
					    	return false;
					    }

					});
					
					
				});
					
				//확인 버튼
				_self.$btnAuthSend.click(function(){
					
					var authcode = _self.$authCode.val();
					
					if (authcode == "" || authcode.length != 6 || isNaN(authcode))
					{
					   alert("인증번호는 6자리 숫자입니다.");	
					   return;
					}

					var memId = $('#MID').val();

			    	var param = {
					    	AUTH_CODE: authcode
			    	};
					
					$.ajax({
						url : _self._confirmAuthCodeURL
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
							
							if(data.ERR != null)
							{
								alert(data.ERR);
								$('._reqAuth').show();
								
								return false;
							}
							
					    	if( data.SUCCESS == 'Y' ){
					    		
						    	var url = _self._resultUrl;
						    	Bplat.view.loadPage( url );
					    	}
					    	else
					    	{
					    		alert('[시스템오류] ID찾기를 실패하였습니다.');
					    	}
					    }

					});

				});
			},
			

			'countdown': function(event) {
			
			  var expTime = $('#expTime');	
			  var timeLeft = window.$timeLeft;
				
			  if (timeLeft== 0) {
				  
				  clearTimeout(window.$timerId);
				  $('#message').hide();
				  expTime.text('만료');
				  
				  $("#btnReqSMS").show();
				  $('#divAuth').hide();

			  } else {
				  timeLeft --;
				  window.$timeLeft = timeLeft;
				  expTime.text(timeLeft + '초');
			  }
			},		
				
			'loading': function(){
				var _self = this;
				var $loadingImg = $('#loading');
				$loadingImg.css("top", (($(window).height() - $loadingImg.outerHeight()) / 2) + $(window).scrollTop() + "px");
				$loadingImg.css("left", (($(window).width() - $loadingImg.outerWidth()) / 2) + $(window).scrollLeft() + "px");
				$loadingImg.show();
				setInterval(function(){
					$loadingImg.fadeOut('slow').fadeIn('slow');
				},2000);
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_simple3] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_simple3] onStart Method' );
				var _self = this;
				if(_self.msg !=  null && _self.msg != undefined && _self.msg != ""){
					alert(_self.msg);
				}
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_simple3] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_simple3] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_simple3] onDestroy Method' );
			}		
	  }
});
