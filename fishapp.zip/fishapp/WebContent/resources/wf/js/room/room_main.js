defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishListURL = $('#fishListURL').val();
				this.fishDetailURL = $('#fishDetailURL').val();
				this.imageURL = $('#imageURL').val();
				this.fishInsertURL = $('#fishInsertURL').val();
				// element
				this.$fishContainer = $('#fishContainer');
				this.$fishListContainer = $('#fishListContainer');
				this.$searchRow = $('#fishTemplate').find('.searchRow');
				this.$imageRow = $('#fishTemplate').find('.imageRow');
				this.$insertBtn = $('#insertBtn');
				// static variable
				this.$typeCd = $('#TYPE_CD').val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$insertBtn.click(function (){
					Bplat.view.loadPage(_self.fishInsertURL);
				});
			},
			'getFishList' : function( page ) {
				var _self = this;
				var $fishContainer = _self.$fishContainer;
				var $fishListContainer = _self.$fishListContainer;
				// 초기화
				$fishContainer.empty();
				$fishListContainer.empty();
				// 조회 데이터
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
				};
				$.ajax({
					 url : _self.fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
					    ,success : function( data ) {
					    	var roomList = data.roomList;
					    	var imgUrl;
					    	
					    	if( roomList.length <= 0 ) {
					    		// nodata
					    		$('.jdg-ui-nodata').show();
					    		$('.jdg-ui-gallery-list').hide();
					    	} else {
					    		$.each( roomList, function(idx,data) {
					    			console.log(data);
						    		var $row = _self.$searchRow.clone();
						    		if( idx == 0 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-left') );
						    		if( idx == 1 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-right') );
						    		
						    		$row.find('[data-key=CREATED_NAME]').text("숙박 기준인원 : "+ data.STD_MAN +"명 ( 최대 인원 : "+ data.PSGR_CNT +"명 )" );
						    		if(data.ROOM_TYPE == 'P'){
						    			$row.find('[data-key=TITLE]').text( data.ROOM_NM );
						    		}else{
						    			$row.find('[data-key=TITLE]').html(data.ROOM_NM + " <img src='/resources/wf/images/guesth.jpg' width='50px'>");
						    		}
						    	
				    				$row.find('[data-key=SUMMARY]').html( data.ROOM_DESC );
				    				if(data.IMAGE_LIST != null){
				    					var images = data.IMAGE_LIST;
				    					var image = images[0];
				    					$row.find('[data-key=MAIN_IMAGE]').attr('src', image.HOSTING_URL);
				    					$row.find('[data-key=MAIN_IMAGE]').attr('onerror', function(){ this.src=""+_self.imageURL+ image.IMG_ID});
				    				}
				    			
				    				if( 0 == idx%2 ) {
						    			$fishContainer.find('.jdg-ui-gallery-left').append( $row );
						    		} else {
						    			$fishContainer.find('.jdg-ui-gallery-right').append( $row );
						    		}
				    				$row.find('a').attr('href', _self.fishDetailURL + '?ROOM_ID=' + data.ROOM_ID);
				    				
				    				// 모바일리스트에도추가
				    				$fishListContainer.append( $row.clone() );		    				
					    	});
				    		
				    		//페이징 초기화
				    		$('#fishListPaging').paging({
								 current: defaultParam.PAGE
								,max: (Math.ceil(data.total / 10))
								,itemClass: 'jdg-btn-page'
								,prevClass: 'jdg-btn-page-prev'
								,nextClass: 'jdg-btn-page-next'
								,firstClass: 'jdg-btn-page-first'
								,lastClass: 'jdg-btn-page-last'
								,onclick:function(e,page){
									location.hash = page;
								}
							});
				    		
				    		$('.jdg-ui-nodata').hide();
				    		$('.jdg-ui-gallery-list').show();
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				var hash = location.hash;
				console.log(hash);
				if( '' == hash ) {
					// set hash
					location.hash = 1;
					_self.getFishList(1);
				} else {
					// 목록조회
					_self.getFishList( hash.replace('#','') );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
