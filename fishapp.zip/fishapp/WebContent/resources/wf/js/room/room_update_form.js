defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._fishUpdateURL = $('#fishUpdateURL').val();
				this._fishUpdateDetailURL = $('#fishUpdateDetailURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$updateForm = $('#memberFishUpdateForm');
				this.$fishDate = $('#fishDate');
				this.$updateBtn = $('#updateFishBtn');
				this.$detailFishBtn = $('#detailFishBtn');
				this.roomId = $('#roomId').val();
				this.$movieListRow = $('.movieListRow');
				
				// 파일리스트
				this.fileList  = new component.FileList({
					 'id' : this.$updateForm.attr('id')
					,'container' : this.$updateForm.find('[data-type=IMAGE_LIST]')
				});
				

				//파일 이미지 div 스타일변경
				$("#commonTemplate").find(".fileListRow").attr("style","padding-left:1px;");
				$("#commonTemplate").find("#movieAddBtn").hide();
				$("#commonTemplate").find(".mainImageCheck").hide();
				$("#commonTemplate").find("textarea").attr("style","opacity:0");
				$("#commonTemplate").find("textarea").attr("disabled","disabled");
				$("#commonTemplate").find(".jdg-icon-flag").hide();
			},
			'setEvent'		: function() {
				var _self = this;
			
			_self.$updateBtn.click( function() {
				_self.updateRoom();
			});
			
			_self.$detailFishBtn.click( function(){
				Bplat.view.loadPage(_self._fishDetailURL + '?ROOM_ID=' + _self.roomId  );
			});
			
			$("select[data-handle]").change(function(evt)
					{
						var tgt = $(evt.target);							
						var hd = tgt.attr('data-handle');
						
						var hdObj = _self.$updateForm.find('input[data-key=' + hd + ']');
						
						if (tgt.val() == "etc")
						{
							hdObj.show();
						}
						else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
						{
							hdObj.hide();
							hdObj.val('');
						}
					}
			);
			
			_self.$detailFishBtn.click( function(){
				Bplat.view.loadPage(_self._fishDetailURL + '?ROOM_ID=' + _self.roomId  );
			});
			
			$("[data-type='IMAGE_LIST']").delegate('div.up','click', function() {
				event.preventDefault();
				_self.changeImageIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
			});

			$("[data-type='IMAGE_LIST']").delegate('div.down','click', function() {
				event.preventDefault();
				_self.changeImageIndex(this, +1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
			});
			
			},

			'changeImageIndex' : function(btnObj, c)
			{
				if (c == null || isNaN(c)) return;
				
				var me = $(btnObj).parent().parent();
				var brothers = $("[data-type='IMAGE_LIST']").find('li');
				var cnt = brothers.length;
				var idx = me.index();
				
				if (c == -1)
					{
						if (cnt == 1 || idx == 0) return;		
						brothers.eq(idx - 1).before(me);
					}
				else if (c == +1)
					{
						if (idx == cnt - 1) return;	
						brothers.eq(idx + 1).after(me);		
					}

			},
			
			//객실 정보 상세 조회
			'getFishDetail' : function( roomId ) {
				var _self = this;
				var $updateForm = _self.$updateForm;
				$.ajax({
					 url : _self._fishUpdateDetailURL
					,type : 'POST'
					,data : {
						'ROOM_ID' : roomId
					}
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('detail') ) {
				    		var detail = data.detail;
				    		
				    		console.info(detail.imageList);
				    		var imgList = detail.imageList;
				    						    		
				    		if (detail.SHIP_ID != null)
				    		{
				    			_self.shipId = detail.SHIP_ID;
				    		}
				    		
				    		
							// 상세폼셋팅
							jdg.util.detailDataSetting( _self.$updateForm, detail );

							//기타 입력칸 셋팅
							setupEtcInput(_self.$updateForm, detail );
							
							// 파일리스트 초기화
							_self.fileList = new component.FileList({
								'id' : $updateForm.attr('id')
								,'container' : $updateForm.find('[data-type=IMAGE_LIST]')
							});
							_self.fileList.init(detail.imageList);
						}
				    }
				});
			},
			// 객실정보 업데이트
			'updateRoom' : function() {
				var _self = this;
				var $updateForm = _self.$updateForm;
				
				// validation
				if( !jdg.util.validator( $updateForm, true ) ) return false;
				
				var param = autoDataGetter($updateForm);
				
				param.REMAIN_FILE = JSON.stringify( _self.fileList.getFileList());
				param.ROOM_ID = $('#roomId').val();		
				
				if (param.REMAIN_FILE == '[]')
				{
					alert('이미지를 하나이상 첨부해 주십시오.');
					return false;
				}

				$.ajax({
					 url : _self._fishUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('msg') ) {
				    		alert('수정 되었습니다');
				    		var url = window.location.href;
							Bplat.view.loadPage(_self._fishDetailURL + '?ROOM_ID=' + _self.roomId  );
				    	}else{
				    		alert("수정 도중 오류가 발생하였습니다.")
				    		return;
				    	}
				    }
				});
			},
			'pageInit'		: function() {
				var _self = this;
				
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				_self.getFishDetail(_self.roomId);

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
