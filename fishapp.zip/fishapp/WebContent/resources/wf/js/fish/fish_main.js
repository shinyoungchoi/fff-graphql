defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishListURL = $('#fishListURL').val();
				this.fishDetailURL = $('#fishDetailURL').val();
				this.imageURL = $('#imageURL').val();
				this.fishInsertURL = $('#fishInsertURL').val();
				this._updateFishURL = $("#updateFishURL").val();
				// element
				this.$fishContainer = $('#fishContainer');
				this.$fishListContainer = $('#fishListContainer');
				this.$searchRow = $('#fishTemplate').find('.searchRow');
				this.$imageRow = $('#fishTemplate').find('.imageRow');
				this.$insertBtn = $('#insertBtn');
				this.$resaveBtn = $('#resaveBtn'); //자동조황
				// static variable
				this.$typeCd = $('#TYPE_CD').val();
				this.$fishGalrId = $("#LAST_GALR_ID").val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$insertBtn.click(function (){
					Bplat.view.loadPage(_self.fishInsertURL);
				});
				
				_self.$resaveBtn.click(function(){
					Bplat.view.loadPage(_self._updateFishURL + '?GALR_ID=' + _self.$fishGalrId +'&mode=rewrite');
				});
			},
			'getFishList' : function( page ) {
				var _self = this;
				var $fishContainer = _self.$fishContainer;
				var $fishListContainer = _self.$fishListContainer;
				// 초기화
				$fishContainer.empty();
				$fishListContainer.empty();
				// 조회 데이터
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '10'
					,'TYPE_CD' : _self.$typeCd
				};
				$.ajax({
					 url : _self.fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
					    ,success : function( data ) {
					    	var fishList = data.fishList;
					    	var imgUrl;
					    	
					    	if( fishList.length <= 0 ) {
					    		// nodata
					    		$('.jdg-ui-nodata').show();
					    		$('.jdg-ui-gallery-list').hide();
					    	} else {
					    		$.each( fishList, function(idx,data) {
					    			
						    		var $row = _self.$searchRow.clone();
						    		if( idx == 0 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-left') );
						    		if( idx == 1 ) $fishContainer.append( $('<div>').addClass('jdg-ui-gallery-right') );
						    		$row.find('[data-key=FISH_DATE]').text( jdg.util.replaceDate(data.FISH_DATE,null,'.') );
						    		$row.find('[data-key=CREATED_NAME]').text( data.CREATED_NICK );
						    		$row.find('[data-key=TITLE]').text( data.TITLE );
				    				$row.find('[data-key=SUMMARY]').html( data.SUMMARY );
				    				$row.find('[data-key=MAIN_IMAGE]').attr('src', data.IMGHOST_URL);

				    				if( 0 == idx%2 ) {
						    			$fishContainer.find('.jdg-ui-gallery-left').append( $row );
						    		} else {
						    			$fishContainer.find('.jdg-ui-gallery-right').append( $row );
						    		}
				    				$row.find('a').attr('href', _self.fishDetailURL + '?GALR_ID=' + data.GALR_ID);
				    				
				    				// 모바일리스트에도추가
				    				$fishListContainer.append( $row.clone() );		    				
					    	});
				    		
				    		//페이징 초기화
				    		$('#fishListPaging').paging({
								 current: defaultParam.PAGE
								,max: (Math.ceil(data.total / 10))
								,itemClass: 'jdg-btn-page'
								,prevClass: 'jdg-btn-page-prev'
								,nextClass: 'jdg-btn-page-next'
								,firstClass: 'jdg-btn-page-first'
								,lastClass: 'jdg-btn-page-last'
								,onclick:function(e,page){
									location.hash = page;
								}
							});
				    		
				    		$('.jdg-ui-nodata').hide();
				    		$('.jdg-ui-gallery-list').show();
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				var hash = location.hash;
				if( '' == hash ) {
					// set hash
					location.hash = 1;
				} else {
					// 목록조회
					_self.getFishList( hash.replace('#','') );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
