defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._msgInsertURL = $('#msgInsertURL').val();
				this._msgDetailURL = $('#msgDetailURL').val();
				this._sendTextURL = $("#sendTextURL").val();
				this._msgDetailURL = $("#msgDetailURL").val();
				this._loginURL = $('#loginURL').val();
				this._saveMemberURL = $("#saveMemberURL").val();
				this._deleteMember = $("#deleteMemberURL").val();
				// element
				this.$insertForm = $('#frm');
				this.$insertBtn = $('#insertBbsBtn');
				this.$type;

				this.$smsPopWrap = $("#smsPopWrap");
				this.fileList = null;
				this.type = $("#type").val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				$('#textDatePicker').datepick({ showOtherMonths: true,
				      selectOtherMonths: true, showOnFocus: false, dateFormat: 'yyyy-mm-dd'
				    ,showTrigger: '<a href="javascript:void(0);" class="jdg-btn-calendar" title="달력"></a>'			    	
				});
				
				$('#textTimePicker').timepicker({
				    timeFormat: 'HH:mm',
				    interval: 1,
				    defaultTime: 'now',
				    startTime: '03:00',
				    dynamic: true,
				    dropdown: true,
				    scrollbar: true
				});
				
				$("#noticeTbl").on("click", "td.name_td", function(){
					if($(this).closest("tr").find("input:checkbox[name='checkbox_mem']").is(":checked"))
						$(this).closest("tr").find("input:checkbox[name='checkbox_mem']").removeAttr("checked");
					else
						$(this).closest("tr").find("input:checkbox[name='checkbox_mem']").attr("checked","checked");
				});
				
				
				//전체 선택 클릭
				$("#select_all_btn").on("click", function(){
					var checkYn = $(this).is(":checked");
					if(checkYn){
						$("input:checkbox[name='checkbox_mem']").attr("checked","checked");
					}else{
						$("input:checkbox[name='checkbox_mem']").removeAttr("checked");
					}
				});
				
				//전송 시간
				$("#smsPopWrap").on("click", "input:radio[name='SEND_TIME']", function(){
					var value = $(this).val();
					if(value == 'NOW'){
						$(".sendDate").hide();
					}else{
						$(".sendDate").show();
					}
				});
				
				$("[data-type='IMAGE_LIST']").delegate('div.up','click', function() {
					event.preventDefault();
					_self.changeImageIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});

				$("[data-type='IMAGE_LIST']").delegate('div.down','click', function() {
					event.preventDefault();
					_self.changeImageIndex(this, +1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});
								
				
				
				//템플릿 선택 시
				$("select.temp_select").on("change", function(){
					var seq = $(this).val();
					if(seq == ""){
						$("#smsPopWrap").find("input[name='SEND_TITLE']").val("");
						$("#smsPopWrap").find("div.title_div").hide();
						$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val("");
						$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
						_self.fileList.init();
						return;
					}
					$.ajax({
						 url : _self._msgDetailURL
						,type : 'POST'
						,data : {SEQ : seq}
					    ,dataType : 'json'
					    ,success : function( data ) {				    	
					    	console.log(data);
					    	var result = data.result;	
					    	if(result.SMS_TYPE == 'LMS'){
					    		$("#smsPopWrap").find("div.title_div").show();
					    	}else{
					    		$("#smsPopWrap").find("div.title_div").hide();
					    	}					    	
					    	$("#smsPopWrap").find("input[name='SEND_TITLE']").val(result.TITLE);
					      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val(result.CONTENT);
					      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
					      	if(result.MAIN_IMG_ID != null && result.MAIN_IMG_ID != ''){
					      		_self.fileList.init(result);
					      	}else{
					      		_self.fileList.init();
					      	}
					    }
					}); 
				});
				
				//byte 체크
				$("#smsPopWrap").on("keyup", "textarea[name='SEND_CONTENT']", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){ //LMS인경우부터는 제목 가능
			    		$("#smsPopWrap").find("div.title_div").show();
					}else{
						$("#smsPopWrap").find("div.title_div").hide();
					}
					if(value > 1499){
						var content_ = content.substr(0,1499);
						$("#smsPopWrap textarea[name='SEND_CONTENT']").val(content_);
						return false;
					}
					
				});
			
				
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
						}
				);
				
				//발송
				$("#sendtxt_button").on("click", function(){					
						var param = { SEND_TEL : $("#smsPopWrap").find(".sendTel").html()};											
						var sendTimeType = $("#smsPopWrap").find("input:radio[name='SEND_TIME']:checked").val();
						if(sendTimeType == 'RESERVE'){
							var textDatePicker = $("#smsPopWrap").find("#textDatePicker").val();
							param.SEND_DATE = textDatePicker;
							
							var textTimePicker = $("#smsPopWrap").find("#textTimePicker").val();
							if(!(/^[0-9\:]*$/.test(textTimePicker))){
								alert("00:00 형태로 입력하셔야 합니다.");
								return;
							}
							
							if(textTimePicker == ''){
								alert("예약 시간을 입력해주세요.");
								return;
							}
							param.SEND_TIME = textTimePicker; 
						}
						param.SEND_TIME_TYPE = sendTimeType;
																	
						var content = $("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val();
						if(content == ''){
							alert("내용을 입력해주세요.");
							return;
						}
						param.SEND_CONTENT = content;
						
						var count = _self.checkBytes(content);
						param.MSG_TYPE = "SMS";
						
						if(count > 130){
							var title = $("#smsPopWrap").find("input[name='SEND_TITLE']").val();
							if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(title))){
								alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
								return;
							}else{
								param.SEND_TITLE = title;
							}
							param.MSG_TYPE = "LMS";
						}
												
						var phones = [];
						var checkYn = false;
						$("#noticeTbl").find("input:checkbox[name='checkbox_mem']").each(function(){
							if($(this).is(":checked")){
								var id = $(this).attr("pid");
								var tel = $(this).attr("ptel");
								var name = $(this).attr("pname");
								phones.push({RSV_ID: id,RSV_TEL: tel, RSV_NAME : name});
								checkYn = true;
							}
						});
						
						if(!checkYn){
							alert("수신자를 한명이상 선택해주세요.");
							return;
						}
						
						//파일 정보 가져가기
						param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
						
						param.RSV_TELS = JSON.stringify(phones);
												
						if(confirm("전송하시겠습니까?")){
						$.ajax({
							 url : _self._sendTextURL
							,type : 'POST'
							,data : param
						    ,dataType : 'json'
						    ,success : function( data ){
						    	if(data.msg == "success"){
						    		alert("문자 전송에 성공하였습니다.");
						    		$("#smsPopWrap").find("input[name='SEND_TITLE']").val("");
									$("#smsPopWrap").find("div.title_div").hide();
									$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val("");
									$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
									$("#noticeTbl").find("input:checkbox[name='checkbox_mem']").removeAttr("checked");
									_self.fileList.init();
						    		return;
						    	}
						    	
						     	if(data.nosessionmsg != null){
						    		alert("세션이 종료되었습니다. 로그인해주세요.");
						    		return;
						    	}
						     	
						    	if(data.failmsg != null){
						    		alert(data.failmsg);
						    		return;
						    	}
						    	alert("문자 전송도중 오류가 발생하였습니다.");
						    	return;
						    }
						    ,error : function(error){
						    	alert("문자 전송도중 오류가 발생하였습니다.");
						    	return;
						    }
						});
						}
				});
				
				//회원정보 저장
				$("#saveMember").on("click", function(){
					var param = { NICK_NAME : $("#nickname").val(), MEM_NAME : $("#name").val(), TEL : $("#phone").val() };
					
					if(param.MEM_NAME == ""){
						alert("회원명을 입력해주세요.");
						return;
					}
					
					if(param.NICK_NAME == ""){
						alert("닉네임을 입력해주세요");
						return;
					}
					
					if(param.TEL == ""){
						alert("휴대전화를 입력해주세요");
						return;
					}
					
					if( $.trim( param.TEL ).length > 0 ){
						if( ! /^\d{3}-?\d{3,4}-?\d{4}$/.test(param.TEL) ){
							alert("휴대전화번호가 유효하지 않습니다.");
							return;
						}
					}
			
					
					$.ajax({
						 url : _self._saveMemberURL
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ){
					    	if(data.msg == "success"){
					    		alert("저장되었습니다.");
					    		location.reload();
					    		return;
					    	}
					    	
					      	alert("저장도중 오류가 발생하였습니다.");
					    	return;
					    },error : function(error){
					    	alert("저장도중 오류가 발생하였습니다.");
					    	return;
					    }
					});
					
				});
				
				//삭제버튼 클릭 시 
				$(document).on("click", "span.delete_btn", function(){
					var id = $(this).attr('pid');
					if(!confirm("삭제하시겠습니까?")){
						return;
					}
					
					$.ajax({
						 url : _self._deleteMember
						,type : 'POST'
						,data : {GUEST_ID : id}
					    ,dataType : 'json'
					    ,success : function( data ){
					    	if(data.msg == "success"){
					    		alert("삭제되었습니다.");
					    		location.reload();
					    		return;
					    	}
					    	
					      	alert("삭제도중 오류가 발생하였습니다.");
					    	return;
					    },error : function(error){
					    	alert("삭제도중 오류가 발생하였습니다.");
					    	return;
					    }
					});
				});
				
				
			},
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},
			'changeImageIndex' : function(btnObj, c)
			{
				if (c == null || isNaN(c)) return;
				
				var me = $(btnObj).parent().parent();
				var brothers = $("[data-type='IMAGE_LIST']").find('li');
				var cnt = brothers.length;
				var idx = me.index();
				
				if (c == -1)
					{
						if (cnt == 1 || idx == 0) return;		
						brothers.eq(idx - 1).before(me);
					}
				else if (c == +1)
					{
						if (idx == cnt - 1) return;	
						brothers.eq(idx + 1).after(me);		
					}

			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				// 파일리스트
				_self.fileList  = new component.FileList({
					 'id' : this.$smsPopWrap.attr('id')
					,'container' : this.$smsPopWrap.find('[data-type=IMAGE_LIST]')
					,'selection' : "N"
					,'max_file' : 3
				});
				// 파일리스트 초기화
				_self.fileList.init();
				
				$("div.jdg-ui-img-description").find("textarea").css("opacity","0");
				$("a.jdg-btn-mov").hide();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});