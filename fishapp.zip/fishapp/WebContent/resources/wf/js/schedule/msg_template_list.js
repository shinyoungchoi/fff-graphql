defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.msgListURL 		= $('#msgListURL').val();
				this.msgInsertURL 	    = $('#msgInsertURL').val();
				this.total 		 		= $('#total').val();
				// element
				
				this.$imageURL		 			= $('#imageURL').val();
				
				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$pcListTemplate 			= $('#bbsListTemplate').find('.bbsListRow');
				this.$nodataTemplate 			= $('#bbsListTemplate').find('.nodata');
				
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				this.$nickName = $('#nickName');
				
				this.$divControl = $('.divControl');
				
				
				this.tabList = $('.cdt_tab_menu li');
				
				this.tabIndex = 0;
				this.postId;
				
				this.$insertBtn = $('#writeBtn');
				this.$updateBtn = $('#updateBtn');
				
				this.session = $('#session').val();
				this.auth = $('#auth').val();

			},
			'setEvent'		: function() {
				var _self = this;
				
	            _self.$insertBtn.on('click', function(e) {
	            	location.href=_self.msgInsertURL;
	            });

	            //제목 클릭시
	           $("#noticeTbl").on("click", ".temp_title", function(){
	        	   var seq = $(this).attr("pid");
	        	   location.href= _self.msgInsertURL+"?SEQ="+seq;
	           });
	            			

			},

			// 목록 조회
			'getPostList' : function( hash ) {
				
				if (hash == null || hash == '')
				{
					hash = '#c1';
				}
               
                var page = hash.substr(2);				
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer;
				_contatiner.empty();
				_paging = $('#templateListPaging');
				
				// defaultParam 세팅
				var itemCnt     = 10;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
				};
				
				
				$.ajax({
					 url : _self.msgListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('templateList') ) {
				    		
				    		var list = data.templateList;
				    		
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$nodataTemplate.clone();
				    			_self.$listContainer.append( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}else{
									rowCount++;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $pcRow = _self.$pcListTemplate.clone();
					    			
					    			$pcRow.attr( 'rowKey', data.SEQ );
					    								    							    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;
					    			console.log(data);
					    			// 제목
					    			$pcRow.find('[data-key=RN]').text( rowCount );
					    			$pcRow.find('[data-key=TITLE]').text( data.TITLE );
					    			$pcRow.find('.temp_title').attr("pid", data.SEQ);
					    			if(data.TEMP_TYPE == '직접작성')
					    				$pcRow.find('[data-key=TEMP_TYPE]').text( data.TEMP_SUBTITLE +"("+ data.SMS_TYPE +")");
					    			else
					    				$pcRow.find('[data-key=TEMP_TYPE]').text( data.TEMP_TYPE +"("+ data.SMS_TYPE +")");
					    			$pcRow.find('[data-key=CONTENT]').html(data.CONTENT);
					    			if(data.MAIN_IMG_ID != null && data.MAIN_IMG_ID != undefined)
					    				$pcRow.find('[data-key=MAIN_IMG_ID]').html("<img style='width:100px;height100px;' src='/cm/file/image/"+data.MAIN_IMG_ID+"/thumbnail'>");
					    			if(data.USE_YN == 'Y'){
					    				$pcRow.find('[data-key=USE_YN]').text("사용함");	
					    			}else{
					    				$pcRow.find('[data-key=USE_YN]').text("사용안함");
					    			}
				    				$pcRow.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			
					    			_contatiner.append( $pcRow );
					    		});
					    		
					    	}
				    		
//				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
									
									var hash = (location.hash == "")? "#c1" : location.hash;
									location.hash = hash.substr(0,2) + page;

									_self.getPostList( location.hash );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		_paging.find('.paging_next').text(">");
				    		

				    		
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				var hash = location.hash;
				_self.getPostList(hash);

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
