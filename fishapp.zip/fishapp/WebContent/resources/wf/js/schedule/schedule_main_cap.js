defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();

				this._scheduleDetailFormURL = $('#scheduleDetailFormURL').val();
				this._watingCompDelURL = $("#watingCompDel").val();

				//예약자 리스트
				this._sendReseveListURL = $("#sendReseveListURL").val();
				
				//문자 메시지 화면 보기 
				this._showSendMsgURL = $("#showSendMsgURL").val();
				
				//템플릿 호츨
				this._msgDetailURL = $("#msgDetailURL").val();
				
				// element
				this.$dateYear = $('#dateYear');
				this.$dateMonth = $('#dateMonth');
				this.$prevMonth = $('#schedulePrevMonth');
				this.$nextMonth = $('#scheduleNextMonth');
				this.$calendarTemplate = $('#calendarTemplate');
				
				// Calendar
				this.$calendarContainer = $('#calendarContainer');
				this.$calendarRow = this.$calendarTemplate.find('#calendarRow');
				this.$scheduleRow = this.$calendarTemplate.find('.scheduleRow');
				
				// Calendar List
				this.$calendarListContainer = $('#calendarListContainer');
				this.$calendarListRow = this.$calendarTemplate.find('.calendarListRow');
				
				// static variable
				this.currentScheduleList = null;
				this.weekArr = ['일요일', '월요일','화요일','수요일','목요일','금요일','토요일'];
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
				
				this.bizId = $('#bizId').val();
				this.shipId = $('#shipId').val();
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				
				this._selectedDay = null;
				
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
				
				this.$modSchdFormTemplate = $('.modSchdFormTemplate');
				this.$modNoChoiceSchdFormTemplate  = $(".modNoChoiceSchdFormTemplate");
				this.$modSchdForm;
				this.$modSchdLi;
				
				
				this.$modRsvFormTemplate = $('.modRsvFormTemplate');
				this.$modRsvForm;
				this.$modRsvDiv;
				this.$rsvId;	
				this.psgrCnt;
				this.feeWhole;
				this.feeMan;
				
				this.$scrollTop = 0;
				
				this._selectedDay = null;
				this._todayTd = null;
				this._selectedTd = null;
				this.fileList = null;
			},
			'setEvent'		: function() {
				var _self = this;
				 
				  //취소사유 클릭 시 
		        $("#calendarListContainer").on("change", "select[data-key='CANCEL_DESC']", function(){
		        	var value = $(this).val();
		        	var html = "템플릿에서 문자문구를 선택해주시거나 직접 입력해주세요.";
		        	if(value  == '기상악화로 인하여'){ //출조취소(기상악화)
		        		html = "[선박명] [출조날짜]\n기상악화로 출조취소.\n입금자명의 환불계좌를 부탁드립니다."; 
					}else if(value == '선박 정비 관계로'){ //출조취소(선박정비)
						html = "[선박명] [출조날짜]\n선박정비로 출조취소.\n입금자명의 환불계좌를 부탁드립니다.";
					}else if(value == '선장 개인사정으로'){ //출조취소(개인사정) 
						html = "[선박명] [출조날짜]\n개인사정으로 출조취소.\n입금자명의 환불계좌를 부탁드립니다.";
					}
		        	_self.$modSchdForm.find("textarea[name='SEND_CONTENT']").val(html);
		        	_self.$modSchdForm.find("textarea[name='SEND_CONTENT']").trigger("keyup");
		        	
		        	_self.fileList.init();
		        });
		        
		      //템플릿 선택 시
		        $("#calendarListContainer").on("change","select.temp_select", function(){
					var seq = $(this).val();
					if(seq == ""){
						_self.$modSchdForm.find("input[name='SEND_TITLE']").val("");
						_self.$modSchdForm.find("div.title_div").hide();
						_self.$modSchdForm.find("textarea[name='SEND_CONTENT']").val("");
						_self.fileList.init();
					}else{
						$.ajax({
							 url : _self._msgDetailURL
							,type : 'POST'
							,data : {SEQ : seq}
						    ,dataType : 'json'
						    ,success : function( data ) {				    	
						    	console.log(data);
						    	var result = data.result;	
						    	$("tr.smsWrap").find("input[name='SEND_TITLE']").val(result.TITLE);
						    	if(result.SMS_TYPE == 'LMS'){
						    		_self.$modSchdForm.find("div.title_div").show();
						    	}else{
						    		_self.$modSchdForm.find("div.title_div").hide();
						    	}					    	
						    	
						    	_self.$modSchdForm.find("#content").val(result.CONTENT);
						    	_self.$modSchdForm.find("#content").trigger("keyup");
						      	if(result.MAIN_IMG_ID != null && result.MAIN_IMG_ID != ''){
						      		_self.fileList.init(result);
						      	}
						    }
						});
					}
				});
				
		        //byte 체크
				$("#calendarListContainer").on("keyup", "textarea[name='SEND_CONTENT']", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){ //LMS인경우부터는 제목 가능
			    		$("tr.smsWrap").find("div.title_div").show();
					}else{
						$("tr.smsWrap").find("div.title_div").hide();
					}
					if(value > 1499){
						var content_ = content.substr(0,1499);
						$("tr.smsWrap textarea[name='SEND_CONTENT']").val(content_);
						return false;
					}				
				});
				
				//메시지 전송 버튼
				$("#calendarListContainer").on("click", ".btnSendMsg", function(){
					var schdId = $(this).attr("schdid");
					var sendmsg = $(this).attr("sendmsgyn");
					if(sendmsg != 'Y'){
						alert("문자메시지 서비스를 원하시면 고객센터(1800-0023)으로 전화주세요.");
						return;
					}
					
					location.href=_self._showSendMsgURL+"?SCHD_ID="+schdId;
				});
		        				
				$(document).on('click','span.detail_show_btn',function() {
					if($("#warning_div").css("display") == "none"){
						$("#warning_div").show();
					}else{
						$("#warning_div").hide();
					}
				});
				
				
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {					
					jdg.util.showLoader();
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 1 ) {
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					jdg.util.showLoader();
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 12 ) {
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				_self.$calendarListContainer.delegate('.jdg-status-a','click',function() {					
					Bplat.view.loadPage('schedule/detail_form?SCHD_ID=' + $(this).data('scheId'));
				});
				
				_self.$calendarContainer.delegate('td.on','click',function() {	
					
					var _td = $(this);
					_self.getDaySchedule(_td.attr('date'));					
				});			
				
				
				// 상세이동
				_self.$calendarContainer.delegate('span.jdg-data-status','click',function() {
					Bplat.view.loadPage(_self._scheduleDetailFormURL + '?SCHD_ID=' + $(this).parent().attr('scheId'));
				});
				

				//수정화면 이동.
				_self.$calendarListContainer.delegate('.btnModifySchedule','click',function() {
					//다른 수정화면 닫기.
					if(_self.$modSchdForm != null){
						_self.$modSchdForm.empty();
						_self.$modSchdForm = null;
						_self.$modSchdLi.css('background-color','');
					}
					
					_self.$modSchdLi = $(this).closest('li');
					var scheId = _self.$modSchdLi.attr('scheId');
					var choiceGenre = _self.$modSchdLi.attr("pchoice");
					var timeType = _self.$modSchdLi.attr("pschetype");
					
					if(timeType == '0' && ( choiceGenre =='' || choiceGenre == undefined)){
						_self.$modSchdForm = _self.$modNoChoiceSchdFormTemplate.clone();
						_self.$modSchdLi.append(_self.$modSchdForm);
						_self.$modSchdForm.show();
						
						$(this).hide();
						
						_self.$modSchdLi.css('background-color','#E0E0E0');					
						_self.getScheduleDetail({SCHD_ID: scheId, CHOICE : 'N'});	
						
					}else{
					
						_self.$modSchdForm = _self.$modSchdFormTemplate.clone();					
						_self.$modSchdLi.append(_self.$modSchdForm);
						_self.$modSchdForm.show();
						
						$(this).hide();
						
						_self.$modSchdLi.css('background-color','#E0E0E0');					
						_self.getScheduleDetail({SCHD_ID: scheId , CHOICE : 'Y'});
					
					}
					
					//예약자 정보 검색
					_self.getReserveList(scheId);
				

				});
				
				
				_self.$calendarListContainer.delegate('.btnModifyRsv','click',function() {
					
					if (_self.$modRsvForm != null)
					{
						_self.$modRsvForm.empty();
						_self.$modRsvForm = null;
						_self.$modRsvDiv.css('background-color','');						
					}
					
					_self.$modSchdLi = $(this).closest('li');
					
					_self.$modRsvDiv = $(this).closest('div');
					_self.$modRsvForm = _self.$modRsvFormTemplate.clone();					
					_self.$modRsvDiv.append(_self.$modRsvForm);
					_self.$modRsvForm.show();
					
					_self.$rsvId = $(this).attr('rsv_id');
					_self.psgrCnt = _self.$modSchdLi.attr('PSGR_CNT');
					_self.feeWhole = _self.$modSchdLi.attr('FEE_WHOLE');
					_self.feeMan = _self.$modSchdLi.attr('FEE');
										
					_self.$modRsvDiv.css('background-color','#E0E0E0');
					_self.getReserveDetail({RSV_ID: _self.$rsvId});
				});
				
				//생활낚시 혹은 선택된 일반 낚시 
				$(document).on('click','span.btnSchdSave',function() {
					_self.updateSchdeule();
				});
				
				//장르 선택 전 일반 낚시
				$(document).on('click','span.btnNoChoiceSchdSave',function() {
					_self.updateNoChoiceSchdeule();
				});
				
					$(document.body).on("click", ".watingDeleteBtn", function(){
					var watingSeq =  $(this).attr("pid");
						$.ajax({
						 url : _self._watingCompDelURL
						,type : 'POST'
						,data : {SEQ : watingSeq}
					    ,dataType : 'json'
					    ,success : function( data ) {				    	
					    	console.log(data);
					    	if(data.result = "ok"){
					    		alert("예약 대기자가 삭제처리되었습니다.");
					    		_self.$scrollTop = $(window).scrollTop();
								_self.getDaySchedule(_self._selectedDay);
					    	}else{
						    	alert("처리도중 오류가 발생하였습니다.");
						    	return;
					    	}
					    }
					}); 
				
				});
				
				$(document).on('click','span.btnRsvSave',function() {
					_self.updateReserve();
				});
				
				
				$(document).delegate('span.btnCancel','click',function() {
					
					$('.btn1').show();
					
					if (_self.$modSchdForm != null)
					{
						_self.$modSchdForm.empty();
						_self.$modSchdForm = null;
						_self.$modSchdLi.css('background-color','');
					}
					
					if (_self.$modRsvForm != null)
					{
						_self.$modRsvForm.empty();
						_self.$modRsvForm = null;
						_self.$modRsvDiv.css('background-color','');						
					}
				});

				$(document).delegate('select[data-key="STATUS_CD"]','change',function() {
					
					if  (_self.$modSchdForm == null)
					{
						return;
					}					
					
					var cd = $(this).val();
					
					if (cd == "113_210")
					{
						_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').show();
						_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').trigger("change");
						if(_self.$modSchdForm.find('div.reserveList').html() != ''){
							$("tr.smsWrap").show();
						}
					}
					else
					{
						_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').hide();
						$("tr.smsWrap").hide();
					}
				});

				
				// 인원수 변경
				$(document).delegate('select[data-key=MAN_CNT]','change',function() {	
					
					_self.totalCost();
				});						
				
				
				// 독선여부 체크
				$(document).delegate('#wholeYnCheck','change',function() {				
					
					var $manCntSel = _self.$modRsvForm.find('[data-key=MAN_CNT]');
					
					
					if( $(this).is(':checked') ) {
						if( undefined != _self.feeWhole && '' != _self.feeWhole ) {
							_self.$modRsvForm.find('em[data-key=TOT_COST]').text( _self.stringFilter(_self.feeWhole, 'money'));
						} else {
							_self.totalCost();
						}
						$manCntSel.val( $manCntSel.find('option:last').val() );
						$manCntSel.attr('disabled', true);
					} else {
						$manCntSel.attr('disabled', false);
					}
				});						
				
				
				//날씨 버튼 클릭
				$(document).on('click','span.jdg-btn-weather',function() {
					var year =  $('#dateYear').text();
					var month =  new Number($('#dateMonth').text());
					var srhMonth = (month < 10) ? '0'+month : month;
					var day = $(this).parent().parent().find('.jdg-data-date').text();
					var srhDate = (day<10) ? '0'+day : day;
					var date = year+srhMonth+srhDate;
					
					var insertParam = {
							'WEATHER_DATE' :  date
						   ,'SHIP_ID'  :  _self.$shipId.replace('/', '')
					};
					
					$.ajax({
						url : _self._scheduleWeatherURL
						,type : 'POST'
						,data : insertParam
						,dataType : 'json'
						,success : function( data ) {
							if(data.hasOwnProperty('marineWeather')){
								
								var weatherCond = data.marineWeather.WEATHER_COND;
								var windDirect = data.marineWeather.WIND_DIRECT;
								var waveHeight = data.marineWeather.WAVE_HEIGHT;
								var windSpeed = data.marineWeather.WIND_SPEED;

								var arrweatherCond = weatherCond.split(",");
								var arrWindDirect = windDirect.split(",");
								var arrWaveHeight =  waveHeight.split(",");
								var arrWindSpeed = windSpeed.split(",");
								
								var weatherTr = _self.$weatherInfoTbl.find('tr[data-key=WEATHER_TR]');
								var windDirectTr = _self.$weatherInfoTbl.find('tr[data-key=WIND_DIRECT_TR]');
								var windSpeedTr = _self.$weatherInfoTbl.find('tr[data-key=WIND_SPEED_TR]');
								var waveHeightTr = _self.$weatherInfoTbl.find('tr[data-key=WAVE_HEIGHT_TR]');
								
								// 날씨 정보 테이블에 remove 된것이 있으면 다시 팝업을 초기화 해준다.
								if(_self.$weatherInfoTbl.find('thead').find('th').length != 3 ){
									 var weatherInfoTblTh = "<th>오후</th>";
									_self.$weatherInfoTbl.find('thead').find('tr').eq(0).append(weatherInfoTblTh);
									_self.$weatherInfoTbl.find('thead').find('th').eq(1).text("오전");
									
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(i){
										var weatherInfoTblTd = "<td></td>";
										$(this).find('td').eq(i).empty();
										$(this).append(weatherInfoTblTd);
									});
								}else{
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(){
										$(this).find('td').empty();
									});
									
								}
								
								//데이터가 오후만 있는 경우, 
								if( arrweatherCond[0] == "" ){
									var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[1]+"' width='30px' height='30px'>";

									_self.$weatherInfoTbl.find('thead').find('th').eq(1).remove();
									_self.$weatherInfoTbl.find('tr').each(function(){
										$(this).find('td').eq(0).remove();
									});
									
									weatherTr.find('td').eq(0).append(weatherImg);
									windDirectTr.find('td').eq(0).text(arrWindDirect[1]);
									windSpeedTr.find('td').eq(0).text(arrWindSpeed[1]);
									waveHeightTr.find('td').eq(0).text(arrWaveHeight[1]);
									
								}else{ 
									 //오전, 오후 일떄
										for(var i=0; i<arrweatherCond.length; i++ ){
											var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[i]+"' width='30px' height='30px'>";
											
											weatherTr.find('td').eq(i).append(weatherImg);
											windDirectTr.find('td').eq(i).text(arrWindDirect[i]);
											windSpeedTr.find('td').eq(i).text(arrWindSpeed[i]);
											waveHeightTr.find('td').eq(i).text(arrWaveHeight[i]);
										}
								}
								_self.$weatherDiv.css('display','block');
							}
						}
					});
				});

			},
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length >= 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(^[+-]?\d+)(\d{3})/;
					str += '';
					
					while(pattern.test(str)) {
						str = str.replace(pattern,'$1,$2');
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},	

			'getMyReserveList' : function() {
				var _self = this;
				
				if (_self._myReserveListURL == null) return false;

				var defaultParam = {
						 'PAGE' : 1
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    
				    	$.each(data.memReserveList, function(key,value) {
				    		 $row = _self.$tmpReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('#SCHD_DATE');
				    		 $schdDate.text(value.SCHD_DATE);

				    		 $schdTitle = $row.find('#SUB_TITLE');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 $manCnt = $row.find('#MAN_CNT');
				    		 $manCnt.text(value.MAN_CNT);

				    		 $totCost = $row.find('#TOT_COST');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money'));

				    		 var statusCd = value.STATUS_CD;

			    			$statusName = $row.find('#STATUS_NAME');
			    			if( statusCd == '104_300'){
			    				$statusName.addClass('jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$reserveList.append($row);
			    			
				    		 $row = _self.$tmpMobileReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('#SCHD_DATE');
				    		 $schdDate.text("출조:" + value.SCHD_DATE);

				    		 $schdTitle = $row.find('#SUB_TITLE');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 $manCnt = $row.find('#MAN_CNT');
				    		 $manCnt.text(value.MAN_CNT + "명");

				    		 $totCost = $row.find('#TOT_COST');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money')  + "원");

				    		 var statusCd = value.STATUS_CD;

			    			$statusName = $row.find('STATUS_NAME');
			    			if( statusCd == '104_300'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$mobileReserveList.append($row);
			    			
				    	 });				    	
				    }
				});				
			},			
			// 달력생성
			'createCalendar' : function( year, month ) {

				$('.jdg-ui-calendar').hide();
				// Calendar & Calendar List 생성
				var _self = this;
				_self.$calendarContainer.empty();
				var tmpDay = new Date();
				
				var isCurrentMonth = tmpDay.getFullYear() == year && tmpDay.getMonth() == month;
				var currentDate = tmpDay.getDate();
				
				tmpDay.setFullYear(year, month, 1);
				var dayOfMonth = tmpDay.getRangeDaysOfMonth(); //이번달
				var startDay = Number( dayOfMonth[0].split('-')[2] );
				var endDay = Number( dayOfMonth[1].split('-')[2] );
				var srhMonth = (month+1 < 10) ? '0'+(month+1) : (month+1);
				var weekCnt = 1;				
				
				_self._todayTd = null;
				
				for( var i = startDay; i <= endDay ; i++ ) {
					tmpDay.setDate(i);
					var day = tmpDay.getDay();
					var date = tmpDay.getDate();
					if( i == 1 || day == 0 ) {
						// calendar
						var $week = _self.$calendarRow.clone();
						_self.$calendarContainer.append( $week );
						
						weekCnt++;
					}
					var $td = $week.find('[day='+day+']');
					$td.text(i);
					$td.attr('id', 'td_calendar_' + i);
					
					if (isCurrentMonth && currentDate == date)
					{
						$td.css('border','blue 3px solid');
						_self._todayTd = $td;
					}
				}
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month+1);
				// 해당 Calendar의 출조 스케쥴 조회
				_self.getScheduleList({'SCHD_MONTH' : year + '' + srhMonth });

			},	
			
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var today = jdg.util.today().replaceAll('-','');
				$.ajax({
					 url : "schedule/listForManager"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var scheduleList = data.scheduleList;
			    		_self.currentScheduleList = scheduleList;
			    		
				    	var seatimeList = data.seatimeList;
				    	//var seatimeMap = {};
				    	
				    	var _td;
						
						for (var idx = 0; idx < seatimeList.length; idx ++)
						{
							var item = seatimeList[idx];
							var tDay = item.SOLAR_DATE.substr(6,2) * 1;
							
							_td = _self.$calendarContainer.find('#td_calendar_'+tDay);
							_td.addClass("on");
							_td.append( "<span class='jdg-data-tide'>" + item.MOOL + "</span>" );	
							_td.attr('date', item.SOLAR_DATE);
							
							if (item.SOLAR_DATE < today)
							{
								_td.css('color','lightgray');
								_td.find('span').css('color','lightgray');
							}							
							
							if (isHoliday(item.SOLAR_DATE))
							{
								_td.addClass("jdg-sun");
								_td.removeClass("jdg-sat");
							}
						}
			    		
			    		//달력생성 및 예약가능선박수
			    		_self.renderScheduleList( scheduleList );
			    		
			    		// Loader 삭제
						$('.jdg-ui-calendar').show();
						jdg.util.removeLoader();
						
						var searchDate;
						
						if (_self._selectedDay)
						{
							searchDate = _self._selectedDay;
							_self._selectedDay = null;
						}
						else
						{
							searchDate = (today.substr(0,6) == param.SCHD_MONTH)? today : param.SCHD_MONTH + '01';
						}

						_self.getDaySchedule(searchDate);
				    }
				});
			},
			

			// 해당일 출조스케쥴 
			'getDaySchedule' : function( schdate ) {
				
				var _self = this;
				
				var $td = $('td#td_calendar_' + (schdate.substr(6,2) * 1));
				
				if (_self._selectedTd)
				{
					_self._selectedTd.css('border', '');
				}
					
				$td.css('border','red 2px solid');						
				_self._selectedTd = $td;
				
				if (_self._todayTd && _self._todayTd != $td)
				{
					_self._todayTd.css('border','blue 3px solid');
				}	
				
				_self._selectedDay = schdate;

				var param = {SCHD_DATE:schdate};				
				
				$.ajax({
					 url : 'schedule/dayscForManager'
					,async : false
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var scheduleList = data.scheduleList;
				    	var reserveList = data.reserveList;
				    	var waitingList = data.waitingList;
				    	
				    	var _dateStr = (schdate.substr(4,2) * 1) + "월 " + (schdate.substr(6,2) * 1) + '일';
				    	
				    	if (scheduleList.length == 0)
				    	{
				    		_self.$calendarListContainer.empty();
				    		_self.$calendarListContainer.append("<div style='background-color:#FFAEAE;font-size:12pt;padding:10px;color:white;font-weight:bold'>" + _dateStr  +"에는 출조일정이 없습니다.<div>");
				    		return;
				    	}
				    	
				    	var reserveMap = {};
				    	var item;
				    	var resv;
				    	var status;
				    	
				    	var dateStr;
				    	var timeStr;
				    	var dayStr;
				    	
				    	if (reserveList != null)
				    	{
				    		var seaTime = $("#td_calendar_" + (schdate.substr(6,2) * 1) + " .jdg-data-tide").text();
				    		
				    		
							for (var idx = 0;  idx < reserveList.length;idx++ )
							{
								item = reserveList[idx];
								resv = reserveMap[item.SCHD_ID];
								
								switch(item.STATUS_CD)
								{
								case "104_300": status = " 입금완료"; break;
								case "104_310": status = " 미입금"; break;
								case "104_320": status = " 부분입금"; break;
								case "104_340": status = " 확정(미입금)"; break;
								case "104_410": status = " 취소"; break;
								case "104_420": status = " 취소(환불예정)"; break;
								case "104_430": status = " 취소(환불완료)"; break;
								}
								
								var dispText = "";
								if (item.DISP_TXT)
								{
									dispText = item.DISP_TXT.substr(0,12) 
								}
								else{
									dispText = item.RSV_NAME;
								}
								var seatText = "";
								if (item.SEAT_TXT)
								{
									seatText = " 자리:" + item.SEAT_TXT;
								}
								
								var rsvStr;
								
								
								if (item.STATUS_CD >= "104_410")
								{
									rsvStr = "<div><span class='cnl'>";
								}
								else
								{
									rsvStr = "<div><span>";
								}
								console.log(item.SITE_CD);
								if(item.SITE_CD == 'P'){
									rsvStr += "<img src='/resources/cm/images/fishapp_ico.gif'>";
								}else if(item.SITE_CD == 'S'){
									rsvStr += "<img src='/resources/cm/images/sd_ico.png'>";
								}else if(item.SITE_CD == 'C'){
									rsvStr += "<img src='/resources/cm/images/coupang.png' style='width: 20px; height: 20px;vertical-align: middle; margin-right: 5px;'>";
								}
								
								rsvStr += dispText + " 님(" + item.MAN_CNT + seatText + ') ' + status + "</span>";
								rsvStr += "<span class='btn1 btnModifyRsv' rsv_id='" + item.RSV_ID +"'>변경</span>";
								rsvStr += "<a class='rsv_tel' href='tel:" + item.RSV_TEL +"'>통화</a></div>";
								
								if (resv)
								{
									reserveMap[item.SCHD_ID] = resv + rsvStr;
								}
								else
								{
									reserveMap[item.SCHD_ID] = rsvStr;
								}
							}
				    	}
				    	
				    	 	if(waitingList != null){
				    		$.each(waitingList, function(idx, info){
			    					reserveMap[info.SCHD_ID] =  reserveMap[info.SCHD_ID] + "<p style='font-size:12px;' class='p2'>"+info.USER_NAME+"("+ info.WATING_PSGR_CNT +"명, "+  info.USER_PHONE+") 예약대기 <span class='btn1 watingDeleteBtn' pid="+info.SEQ+">삭제</span></p>";
			    				});
				    	}
				    	
				    	var cont = _self.$calendarListContainer;
				    	var tmpl ;
				    	
				    	_self.$calendarListContainer.empty();

						for (var idx = 0; idx < scheduleList.length; idx ++)
						{
							item = scheduleList[idx];
							console.log(item);
							if (idx == 0)
							{
				    			var schdDate = item.SCHD_DATE;
				    			var year = schdDate.substring(0,4);
				    			var month = schdDate.substring(4,6)-1;
				    			var date = schdDate.substring(6,8);
				    			var tmpDay = new Date();
				    			tmpDay.setFullYear(year, month, date);
				    			dayStr = _self.weekArr[tmpDay.getDay()];
				    			
								dateStr = (1 * schdDate.substr(4,2)) + '월'+ (1 * schdDate.substr(6,2)) + '일';								
							}
							
							if(item.SCHD_TIME != '' && item.SCHD_TIME != undefined)
								timeStr = item.SCHD_TIME.substr(0,2) + ':' + item.SCHD_TIME.substr(2,2);
							else
								timeStr = "";
							
							
							tmpl = _self.$calendarListRow.clone();
							
							//장르 선택 전 일반 낚시
							if(item.SCHD_TIME_TYPE == '0' && ( item.CHOICE_GENRE == '' || item.CHOICE_GENRE == undefined)){
								var genreCnt = 0;
			    				var subtitle = "";
			    				if(item.GENRE_USEYN1 == 'Y' && item.GENRE1_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE1;
			    				}
			    				if(item.GENRE_USEYN2 == 'Y' && item.GENRE2_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE2;
			    				}
			    				if(item.GENRE_USEYN3 == 'Y' && item.GENRE3_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = item.SUB_TITLE3;
			    				}
			    				
			    				var title = "출조합니다.";
			    				if(genreCnt == 1){
			    					title = subtitle;
			    				}
								if(item.SUB_SHIPNM != '' && item.SUB_SHIPNM != undefined){
									tmpl.find('#sub_title').text(item.SUB_SHIPNM +"| "+title);
								}else
									tmpl.find('#sub_title').text(title);
								
							}else{
								tmpl.find('#sub_title').text(item.SUB_TITLE);
							}
														
							tmpl.find('#date').text(dateStr);
							tmpl.find('#schd_time').text(timeStr);
							tmpl.find('#day').text(dayStr);
							tmpl.find('#seaTime').text(seaTime);
							
							
							if (item.NOTICE_TEXT)
							{
								tmpl.find('#notice_text').text(item.NOTICE_TEXT);
							}
							else
							{
								tmpl.find('#notice_text').remove();
							}

							if (reserveMap[item.SCHD_ID])
							{
								tmpl.find('#rsv').html(reserveMap[item.SCHD_ID]);
							}
							else
							{
								tmpl.find('#rsv').remove();
							}
							
							var tmplLi = tmpl.find('li');
							tmplLi.attr('PSGR_CNT',item.PSGR_CNT);
							tmplLi.attr('FEE_WHOLE',item.FEE_WHOLE);
							tmplLi.attr('FEE',item.FEE);
							tmplLi.attr('scheId', item.SCHD_ID);

							tmplLi.attr("pchoice", item.CHOICE_GENRE);
							tmplLi.attr("pschetype", item.SCHD_TIME_TYPE);
							
			    			// 예약可인원
							var reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
							if($("#waitReserveYn").val() == "Y"){
								reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT;
							}
			    			//var reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT;
							//var reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
							// Calendar & Calendar List 예약상태
			    										
			    			if(reserveMap[item.SCHD_ID]){
				    			//예약자가 있는 경우
			    				tmplLi.find(".btnSendMsg").attr("schdId",item.SCHD_ID)
			    	        	tmplLi.find(".btnSendMsg").attr("sendMsgYn", $("#sendMsgYn").val());
			    				tmplLi.find(".btnSendMsg").css("display","inline-block");
					    	}else{
					    		tmplLi.find(".btnSendMsg").css("display","none");
					    	}
			    			
			    			var statusObj = tmpl.find('em.statusCd');
			    						 
			    			if(item.DEL_FLAG == 'Y'){
			    				//해당 스케쥴 노출 안하도록 해놓았으므로
			    				statusObj.text('감추기').addClass('jdg-status-d');
			    			}else{
				    			if( '113_110' === item.STATUS_CD && reserveCnt == 0 ) {
				    				statusObj.text('마감').addClass('jdg-status-c');
				    			} 
				    			else if( '113_110' === item.STATUS_CD && reserveCnt < 0 ) {
				    				statusObj.text('마감(' + (reserveCnt * -1)  + '명초과)').addClass('jdg-status-d');
				    			}			    			
				    			else if( '113_110' === item.STATUS_CD ) {
					    				statusObj.addClass('jdg-status-a');
					    				statusObj.data('scheId',item.SCHD_ID);
					    				// 예약可인원
					    				tmpl.find('#avail_cnt').text( reserveCnt<0?0:reserveCnt + '명');
				    			} else if( '113_170' === item.STATUS_CD) {
				    				statusObj.text('마감').addClass('jdg-status-b');
				    			} else if( '113_180' === item.STATUS_CD) {
				    				statusObj.text('만료').addClass('jdg-status-c');
				    			} else if( '113_210' === item.STATUS_CD ) {
				    				statusObj.text('출조취소').addClass('jdg-status-d');
				    			}
			    			}
			    			
							_self.$calendarListContainer.append(tmpl);
							scrollBottom();
						}

				    }
				});
			},

			'renderScheduleList' : function(list){
				
				var _self = this;
				
				_self._interval_objs = null;
				
				var isBlink = false;
				
    			if (_self._interval_id)
    			{
    				clearInterval(_self._interval_id);			    				
    				_self._interval_id = null;
    			}
				
				$.each( list, function( idx, data ) {
	    			// web calendar 셋팅
	    			var schdDate = data.SCHD_DATE;
	    			var year = schdDate.substring(0,4);
	    			var month = schdDate.substring(4,6)-1;
	    			var date = schdDate.substring(6,8);
	    			
	    			var dateNum = parseInt( date, 10 );

	    			var $td = $('#td_calendar_' + dateNum);

	    			if( data.AVAILS > 0 ) {
	    				
	    				$td.append( "<div class='jdg-bgbox1'></div>" );	

	    			} 
	    			else if( data.AVAILS == 0 && data.SOLDOUTS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox2'></div>" );	
	    				$td.css("text-decoration","line-through");
	    			} 
	    			else if( data.AVAILS == 0 && data.CANCELS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox3' style='z-index: 100'>취소</div>" );	
	    				
	    				isBlink = true;
	    			}
	    			

 
    				// mobile calendar 셋팅
	    			var $ul = $( '#ul_calendar_list_'  + _self.getWeekOfMonth( new Date(year, month, dateNum) ) );

	    		});
				
	    		if (isBlink)
	    		{
	    			_interval_objs = $("div.jdg-bgbox3");
	    			_interval_index = 0;			    			
	    			_self._interval_id = setInterval(_self.blinkEffect, 400);
	    		}
			},

			'getWeekOfMonth' : function(date){
				var dayOfMonth = date.getDate();
				
				var first = new Date( date.getFullYear(), date.getMonth(), 1 );
				var monthFirstDateDay = first.getDay();
				
				return Math.ceil( (dayOfMonth + monthFirstDateDay) / 7 );
			},
			
			
			// 출조스케쥴 목록 조회(listForManager)
			'getScheduleDetail' : function( param ) {
				var _self = this;
				var tmpDay = new Date();
				$.ajax({
					 url : "schedule/detail"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {	
				    	var dataObj = data.detail;
				    	//일반낚시면서 아직 장르가 선택 안된 경우
				    	if(param.CHOICE == 'N'){
					    	_self.$modSchdForm.find("[data-key='SCHD_DATE']").html(dataObj.SCHD_DATE);
				    		_self.$modSchdForm.find("[data-key='SCHD_DATE_STR']").text(dataObj.SCHD_DATE_STR);
				    		_self.$modSchdForm.find("[data-key='DEL_FLAG'] option[value='"+ dataObj.DEL_FLAG+"']").attr("selected", "selected");
				    		_self.$modSchdForm.find("[data-key='STATUS_CD'] option[value='"+ dataObj.STATUS_CD+"']").attr("selected", "selected");
				    		_self.$modSchdForm.find("[data-key='NOTICE_TEXT']").attr("value", dataObj.NOTICE_TEXT);
				    		_self.$modSchdForm.find("[data-key='CANCEL_DESC'] option[value='"+ dataObj.CANCEL_DESC+"']").attr("selected", "selected");
				    		if(dataObj.STATUS_CD == '113_210'){
				    			_self.$modSchdForm.find("[data-key='CANCEL_DESC']").show();
				    		}
				    		_self.$modSchdForm.find("[data-key='MEMO']").attr("value", dataObj.MEMO);
				    		var html = "";
				    		
				    		if(dataObj.SITE_TYPE == '3' && dataObj.BUS_CONF_TYPE == 'C'){
				    			for(var i = 0 ; i < dataObj.detailList.length ;i++){
					    			var item = dataObj.detailList[i];
					    			if(item.TYPE_MAIN != 'MAIN'){
					    				continue;
					    			}
					    			html += "<br/><b>* 장르옵션 "+ (i+1) +"</b>";
					    			var $tmp =  $("table.modNoChoiceDetailTemplate").clone();
					    			$tmp.find("[data-key=SUB_TITLE]").attr("value", item.SUB_TITLE);
					    			$tmp.find("[data-key=SCHD_DATE_STR]").text(item.SCHD_DATE_STR);
					    			$tmp.find("[data-key=SCHD_TIME]").attr("value", item.SCHD_TIME_STR);
					    			$tmp.find("[data-key=FEE]").attr("value", item.FEE);
					    			$tmp.find("[data-key=FISH_KIND]").attr("value", item.FISH_KIND);
					    			$tmp.find("[data-key=PREPARE]").attr("value", item.PREPARE);
					    			$tmp.find("[data-key=LOC_DESC]").attr("value", item.LOC_DESC);
					    			$tmp.find("[data-key=GENRE_USEYN] option[value='"+ item.GENRE_USEYN+"']").attr("selected", "selected");
					    			$tmp.find("[data-key=FEE_WHOLE]").attr("value", item.FEE_WHOLE);
					    			$tmp.find("[data-key=PSGR_CNT]").attr("value", item.PSGR_CNT);
					    			$tmp.find("[name='bus_div']").css("display","");
					    			$tmp.find("[data-key=BUS_FEE]").attr("value", dataObj.BUS_FEE);
					    			
					    			if(item.TOOL1 == '0'){
					    				$tmp.find("[data-key=EQP1]").attr("value", item.TOOL1);
					    				$tmp.find("#eqp1_div").css("display","");
					    			}else if(item.TOOL1 != null && item.TOOL1 != ''){
					    				$tmp.find("[data-key=EQP1]").attr("value", item.TOOL1);
					    				$tmp.find("#eqp1_div").css("display","");
					    			}
					    			
					    			if(item.TOOL2 == '0'){
					    				$tmp.find("[data-key=EQP2]").attr("value", item.TOOL2);
					    				$tmp.find("#eqp2_div").css("display","");
					    			}else if(item.TOOL2 != null && item.TOOL2 != ''){
					    				$tmp.find("[data-key=EQP2]").attr("value", item.TOOL2);
					    				$tmp.find("#eqp2_div").css("display","");
					    			}
					    			
					    			if(item.TOOL3 == '0'){
					    				$tmp.find("[data-key=EQP3]").attr("value", item.TOOL3);
					    				$tmp.find("#eqp3_div").css("display","");
					    			}else if(item.TOOL3 != null && item.TOOL3 != ''){
					    				$tmp.find("[data-key=EQP3]").attr("value", item.TOOL3);
					    				$tmp.find("#eqp3_div").css("display","");
					    			}
					    			$tmp.find("[data-key=DESCR]").html(item.DESCR);
					    			html += "<table width='100%' pnum='"+ item.TYPE +"'> "+ $tmp.html() +"</table>";
					    		}
				    		}else{				    		
					    		for(var i = 0 ; i < dataObj.detailList.length ;i++){
					    			html += "<br/><b>* 장르옵션 "+ (i+1) +"</b>";
					    			var item = dataObj.detailList[i];
					    			var $tmp =  $("table.modNoChoiceDetailTemplate").clone();
					    			$tmp.find("[data-key=SUB_TITLE]").attr("value", item.SUB_TITLE);
					    			$tmp.find("[data-key=SCHD_DATE_STR]").text(item.SCHD_DATE_STR);
					    			$tmp.find("[data-key=SCHD_TIME]").attr("value", item.SCHD_TIME_STR);
					    			$tmp.find("[data-key=FEE]").attr("value", item.FEE);
					    			$tmp.find("[data-key=FISH_KIND]").attr("value", item.FISH_KIND);
					    			$tmp.find("[data-key=PREPARE]").attr("value", item.PREPARE);
					    			$tmp.find("[data-key=LOC_DESC]").attr("value", item.LOC_DESC);
					    			$tmp.find("[data-key=GENRE_USEYN] option[value='"+ item.GENRE_USEYN+"']").attr("selected", "selected");
					    			$tmp.find("[data-key=FEE_WHOLE]").attr("value", item.FEE_WHOLE);
					    			$tmp.find("[data-key=PSGR_CNT]").attr("value", item.PSGR_CNT);
					    			
					    			if(item.TOOL1 == '0'){
					    				$tmp.find("[data-key=EQP1]").attr("value", item.TOOL1);
					    				$tmp.find("#eqp1_div").css("display","");
					    			}else if(item.TOOL1 != null && item.TOOL1 != ''){
					    				$tmp.find("[data-key=EQP1]").attr("value", item.TOOL1);
					    				$tmp.find("#eqp1_div").css("display","");
					    			}
					    			
					    			if(item.TOOL2 == '0'){
					    				$tmp.find("[data-key=EQP2]").attr("value", item.TOOL2);
					    				$tmp.find("#eqp2_div").css("display","");
					    			}else if(item.TOOL2 != null && item.TOOL2 != ''){
					    				$tmp.find("[data-key=EQP2]").attr("value", item.TOOL2);
					    				$tmp.find("#eqp2_div").css("display","");
					    			}
					    			
					    			if(item.TOOL3 == '0'){
					    				$tmp.find("[data-key=EQP3]").attr("value", item.TOOL3);
					    				$tmp.find("#eqp3_div").css("display","");
					    			}else if(item.TOOL3 != null && item.TOOL3 != ''){
					    				$tmp.find("[data-key=EQP3]").attr("value", item.TOOL3);
					    				$tmp.find("#eqp3_div").css("display","");
					    			}
					    			
					    			$tmp.find("[data-key=DESCR]").html(item.DESCR);
					    			html += "<table width='100%' pnum='"+ item.TYPE +"'> "+ $tmp.html() +"</table>";
					    		}
				    		}
				    		_self.$modSchdForm.find("#updateDetailList").html(html);
				    	}else{
					    	_self.$modSchdForm.find("[data-key='SCHD_DATE']").html(dataObj.SCHD_DATE);
				    		
					    	dataObj.SCHD_TIME = dataObj.SCHD_TIME.substr(0,2) + ":" + dataObj.SCHD_TIME.substr(2,2) ;
					    	
					    	if (dataObj.STATUS_CD == '113_210')
					    	{
					    		if (dataObj.CANCEL_DESC != null)
					    		{
						    		dataObj.CANCEL_DESC = dataObj.CANCEL_DESC.replace(' 출조를 취소합니다.','');					    						    			
					    		}
					    		_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').show();
					    	}
					    	
					    	jdg.util.detailDataSetting(_self.$modSchdForm, dataObj );
					    	
					    	if(dataObj.GENRE_TOOL1 == '0'){
					    		_self.$modSchdForm.find("[data-key='EQP1']").val(dataObj.GENRE_TOOL1);
					    		_self.$modSchdForm.find("#eqp1_div").css("display","");
					    	}else if(dataObj.GENRE_TOOL1 != null && dataObj.GENRE_TOOL1 != ''){
					    		_self.$modSchdForm.find("[data-key='EQP1']").val(dataObj.GENRE_TOOL1);
					    		_self.$modSchdForm.find("#eqp1_div").css("display","");
					    	}
					    	
					    	if(dataObj.GENRE_TOOL2 == '0'){
					    		_self.$modSchdForm.find("[data-key='EQP2']").val(dataObj.GENRE_TOOL2);
					    		_self.$modSchdForm.find("#eqp2_div").css("display","");
					    	}else if(dataObj.GENRE_TOOL2 != null && dataObj.GENRE_TOOL2 != ''){
					    		_self.$modSchdForm.find("[data-key='EQP2']").val(dataObj.GENRE_TOOL2);
					    		_self.$modSchdForm.find("#eqp2_div").css("display","");
					    	}
					    	
					    	if(dataObj.GENRE_TOOL3 == '0'){
					    		_self.$modSchdForm.find("[data-key='EQP3']").val(dataObj.GENRE_TOOL3);
					    		_self.$modSchdForm.find("#eqp3_div").css("display","");
					    	}else if(dataObj.GENRE_TOOL3 != null && dataObj.GENRE_TOOL3 != ''){
					    		_self.$modSchdForm.find("[data-key='EQP3']").val(dataObj.GENRE_TOOL3);
					    		_self.$modSchdForm.find("#eqp3_div").css("display","");
					    	}
					    	
					    	if(dataObj.SITE_TYPE == '3' && dataObj.BUS_CONF_TYPE == 'C'){
					    		_self.$modSchdForm.find("[name='bus_div']").css("display","");
					    	}
					    	
					    	_self.$modSchdForm.find('[data-key="DESCR_TEXT"]').html(dataObj.DESCR_HTML);
					    	
					    	/*예약된 경우에는 비용 막음.
					    	if(dataObj.RESERVE_CONFIRM_CNT > 0 || dataObj.RESERVE_WAIT_CNT > 0){
					    		_self.$modSchdForm.find("[data-key=FEE]").parent().html("<span data-key=FEE>"+ _self.stringFilter(dataObj.FEE,'money') +"원 </span>");
				    		}*/
				    	}
				    }
				});
			},
			'updateNoChoiceSchdeule' : function(){
				var _self = this;
				var $form = _self.$modSchdForm;
				
				var param = {
						DEL_FLAG : $form.find("[data-key=DEL_FLAG] option:selected").val(),
						NOTICE_TEXT : $form.find("[data-key=NOTICE_TEXT]").val(),
						MEMO : $form.find("[data-key=MEMO]").val(),
						STATUS_CD : $form.find("[data-key=STATUS_CD] option:selected").val(), 
						CANCEL_DESC : $form.find("[data-key=CANCEL_DESC]").val(),
						SCHD_ID :  _self.$modSchdLi.attr('scheId')
				}
				
				// validation
				if( !jdg.util.validator( $form, true ) ) return false;
								
				var genreAllUseYn = false;
				$form.find("#updateDetailList table").each(function(index, item){
					console.log(item);
					var type = $(this).attr("pnum");
					if(type == "1"){
						param.SUB_TITLE1 = $(this).find("[data-key=SUB_TITLE]").val();
						param.FEE1 =  $(this).find("[data-key=FEE]").val();
						param.FEE_WHOLE1 =  $(this).find("[data-key=FEE_WHOLE]").val();
						param.FISH_KIND1 =  $(this).find("[data-key=FISH_KIND]").val();
						param.PREPARE1 =  $(this).find("[data-key=PREPARE]").val();
						param.LOC_DESC1 =  $(this).find("[data-key=LOC_DESC]").val();
						param.PSGR_CNT1 =  $(this).find("[data-key=PSGR_CNT]").val();
						param.GENRE_USEYN1 =  $(this).find("[data-key=GENRE_USEYN] option:selected").val();
						param.SCHD_TIME1 =  $(this).find("[data-key=SCHD_TIME]").val();
						param.GENRE1_TOOL1 =  $(this).find("[data-key=EQP1]").val();
						param.GENRE1_TOOL2 =  $(this).find("[data-key=EQP2]").val();
						param.GENRE1_TOOL3 =  $(this).find("[data-key=EQP3]").val();
						param.GENRE1_DESCR =  $(this).find("[data-key=DESCR]").val();
						
						if(param.GENRE_USEYN1 == 'Y'){
							genreAllUseYn = true;
						}
						if (param.SCHD_TIME1 == null || param.SCHD_TIME1.length < 5)
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
						
						param.SCHD_TIME1 = param.SCHD_TIME1.replace(':','');	
						
						if (param.SCHD_TIME1 < "0000" || param.SCHD_TIME1 > "2359" || param.SCHD_TIME1.length != 4 || isNaN(param.SCHD_TIME1))
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
						
					}else if(type == "2"){
						param.SUB_TITLE2 = $(this).find("[data-key=SUB_TITLE]").val();
						param.FEE2 =  $(this).find("[data-key=FEE]").val();
						param.FEE_WHOLE2 =  $(this).find("[data-key=FEE_WHOLE]").val();
						param.FISH_KIND2 =  $(this).find("[data-key=FISH_KIND]").val();
						param.PREPARE2 =  $(this).find("[data-key=PREPARE]").val();
						param.LOC_DESC2 =  $(this).find("[data-key=LOC_DESC]").val();
						param.PSGR_CNT2 =  $(this).find("[data-key=PSGR_CNT]").val();
						param.GENRE_USEYN2 =  $(this).find("[data-key=GENRE_USEYN] option:selected").val();
						param.SCHD_TIME2 =  $(this).find("[data-key=SCHD_TIME]").val();
						
						param.GENRE2_TOOL1 =  $(this).find("[data-key=EQP1]").val();
						param.GENRE2_TOOL2 =  $(this).find("[data-key=EQP2]").val();
						param.GENRE2_TOOL3 =  $(this).find("[data-key=EQP3]").val();
						param.GENRE2_DESCR =  $(this).find("[data-key=DESCR]").val();
						
						if(param.GENRE_USEYN2 == 'Y'){
							genreAllUseYn = true;
						}
						if (param.SCHD_TIME2 == null || param.SCHD_TIME2.length < 5)
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
						
						param.SCHD_TIME2 = param.SCHD_TIME2.replace(':','');	
						
						if (param.SCHD_TIME2 < "0000" || param.SCHD_TIME2 > "2359" || param.SCHD_TIME2.length != 4 || isNaN(param.SCHD_TIME2))
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
					}else if(type == "3"){
						param.SUB_TITLE3 = $(this).find("[data-key=SUB_TITLE]").val();
						param.FEE3 =  $(this).find("[data-key=FEE]").val();
						param.FEE_WHOLE3 =  $(this).find("[data-key=FEE_WHOLE]").val();
						param.FISH_KIND3 =  $(this).find("[data-key=FISH_KIND]").val();
						param.PREPARE3 =  $(this).find("[data-key=PREPARE]").val();
						param.LOC_DESC3 =  $(this).find("[data-key=LOC_DESC]").val();
						param.PSGR_CNT3 =  $(this).find("[data-key=PSGR_CNT]").val();
						param.GENRE_USEYN3 =  $(this).find("[data-key=GENRE_USEYN] option:selected").val();
						param.SCHD_TIME3 =  $(this).find("[data-key=SCHD_TIME]").val();
						param.GENRE3_TOOL1 =  $(this).find("[data-key=EQP1]").val();
						param.GENRE3_TOOL2 =  $(this).find("[data-key=EQP2]").val();
						param.GENRE3_TOOL3 =  $(this).find("[data-key=EQP3]").val();
						param.GENRE3_DESCR =  $(this).find("[data-key=DESCR]").val();
						
						if(param.GENRE_USEYN3 == 'Y'){
							genreAllUseYn = true;
						}
						if (param.SCHD_TIME3 == null || param.SCHD_TIME3.length < 5)
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
						
						param.SCHD_TIME3 = param.SCHD_TIME3.replace(':','');	
						
						if (param.SCHD_TIME3 < "0000" || param.SCHD_TIME3 > "2359" || param.SCHD_TIME3.length != 4 || isNaN(param.SCHD_TIME3))
						{
							alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
							return;
						}
					}
				});
				
				if(!genreAllUseYn){
					alert("장르옵션 중 하나는 사용가능 상태여야 합니다.");
					return;
				}
				
				if (param.STATUS_CD == '113_210')
				{
					param.CANCEL_DESC = param.CANCEL_DESC + ' 출조를 취소합니다.';
				}
				else
				{
					param.CANCEL_DESC = null;
				}
				
				console.log(param);
				
				$.ajax({
					 url : 'schedule/updateScheduleByCap'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if (data.error)
				    	{
				    		alert(data.error);
				    	}
				    	else
				    	{
				    		_self.upadateReload();
				    	}

				    }
				});
			},
			// 출조수정
			'updateSchdeule' : function( param )
			{
				var _self = this;
				var $form = _self.$modSchdForm;
				
				// validation
				if( !jdg.util.validator( $form, true ) ) return false;
				
				var param = autoDataGetter($form);
				param.FEE = param.FEE;

				param.SCHD_ID = _self.$modSchdLi.attr('scheId');
				param.DESCR = param.DESCR_TEXT;
				
				if (param.SCHD_TIME == null || param.SCHD_TIME.length < 5)
				{
					alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
					return;
				}
				
				param.SCHD_TIME = param.SCHD_TIME.replace(':','');	
				
				if (param.SCHD_TIME < "0000" || param.SCHD_TIME > "2359" || param.SCHD_TIME.length != 4 || isNaN(param.SCHD_TIME))
				{
					alert('출조시간형식이 잘못되었습니다.\n(예시) 06:00');
					return;
				}
				
				
				if (param.FEE < 10000)
				{
					alert('1인 선비는 만원이하로 입력할수 없습니다.');
					return;
				}
				
				if (param.STATUS_CD == '113_210')
				{
					param.CANCEL_DESC = param.CANCEL_DESC + ' 출조를 취소합니다.';
				}
				else
				{
					param.CANCEL_DESC = null;
				}
				
				//출조취소인 경우에만
				if(param.STATUS_CD == '113_210'){
					var phones = [];
					var checkYn = false;
					$form.find("input:checkbox[name='RSV_MEM']").each(function(){
						if($(this).is(":checked")){
							var tel = $(this).attr("ptel");
							var name = $(this).attr("pname");
							var id = $(this).attr("pid");
							phones.push({RSV_TEL: tel, RSV_NAME : name,  RSV_ID : id});
							checkYn = true;
						}
					});
					
					if(!checkYn){
						if(confirm("취소문자를 보내지 않으시겠습니까?")){
							//문자받는 사람없이 보내기
							param.SEND_TXT_YN = "N";
						}else{
							alert("수신자를 선택해주세요.");
							return;
						}
					}else{
							param.SEND_TXT_YN = "Y";
							var content = $form.find("textarea[name='SEND_CONTENT']").val();
							if(content == ''){
								alert("내용을 입력해주세요.");
								return;
							}
							param.SEND_CONTENT = content;
							
							var count = _self.checkBytes(content);
							param.MSG_TYPE = "SMS";							
							if(count > 130){
								var title = $form.find("input[name='SEND_TITLE']").val();
								if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(title))){
									alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
									return;
								}else{
									param.SEND_TITLE = title;
								}
								param.MSG_TYPE = "LMS";
							}												
							//파일 정보 가져가기
							param.IMG_ID = JSON.stringify( _self.fileList.getFileList());							
							param.RSV_TELS = JSON.stringify(phones);
					}
				}
				
				$.ajax({
					 url : 'schedule/update_schedule'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if(data.result == "1"){
				    		_self.upadateReload();
				    	}else if(data.desc){
				    		alert(data.desc);
				    	}else{
				    		alert(" 수정도중 오류가 발생하였습니다.");
				    	}

				    },error: function(error){
				    	alert("수정도중 오류가 발생하였습니다.");
				    	return;
				    }
				});
			},

			
			
			// 예약수정
			'updateReserve' : function()
			{
				var _self = this;
				var $form = _self.$modRsvForm;
				
				// validation
				if( !jdg.util.validator( $form, true ) ) return false;
				
				var param = autoDataGetter($form);
				param.RSV_ID = _self.$rsvId;
				param.TOT_COST = param.TOT_COST.replaceAll( ',', '' ).replaceAll( '원', '' );

				
				$.ajax({
					 url : 'schedule/update_reserve_manager'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if (data.error)
				    	{
				    		alert(data.error);
				    	}
				    	else
				    	{
				    		_self.upadateReload();
				    	}

				    }
				});
			},			
			 //byte 체크
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},		
			//문자메시지 수신자 리스트
			'getReserveList' : function(schdId){
				var _self = this;
				var schdId = schdId;
				$.ajax({
					 url : _self._sendReseveListURL
					,type : 'POST'
					,data : { SCHD_ID : schdId }
				    ,dataType : 'json'
				    ,success : function( data ){
				    	var list = data.memReserveList;
				    	_self.$modSchdForm.find("div.reserveList").empty();
				    	if(list != null && list.length > 0){
					    	for(var i = 0 ;i < list.length ; i++){
					    		var item = list[i];
					    		var html = "<span style='margin-right:8px;'>";
					    		html += "<input type='checkbox' style='width:10%;' id='"+ item.RSV_ID+"' pid='"+ item.RSV_ID+"' name='RSV_MEM' value='Y' pname='"+item.RSV_NAME+"' ptel='"+item.RSV_TEL+"'>";
					    		if(item.SITE_CD == 'P'){
					    			html += "<img src='/resources/cm/images/fishapp_ico.gif'>";
					    		}else if(item.SITE_CD == 'S'){
					    			html += "<img src='/resources/cm/images/sd_ico.png'>";
					    		}
					    		html += "<label for='"+item.RSV_ID+"'>"+item.RSV_NAME+"("+item.MAN_CNT+"명 예약:"+item.STATUS_NAME+")</label></span>";
					    		_self.$modSchdForm.find("div.reserveList").append(html);
					    	}
				    	}
				    	_self.$modSchdForm.find("#smsWrap").attr("id","smsWrap_"+schdId);

						// 파일리스트
				    	console.log(_self.fileList );
				    	if(	_self.fileList == null){
							_self.fileList  = new component.FileList({
								 'id' : "smsWrap_"+schdId
								,'container' :  $("#calendarListContainer").find('[data-type=IMAGE_LIST]')
								,'selection' : "N"
								,'max_file' : 3
							});
				    	}
				    	
				    }, error : function(error){
				    	alert("오류가 발생하였습니다. \n다시 시도해주세요.");
				    	return;
				    }
				});		
			},
			// 예약상세 조회(관리자용)
			'getReserveDetail' : function( param ) {
				var _self = this;
				$.ajax({
					 url : "schedule/reserve_detail_manager"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var form = _self.$modRsvForm;
				        var selectMan = form.find('[data-key="MAN_CNT"]');
				        var selectEqp = form.find('[data-key="EQP_CNT"]');
				        var selectEqp1 = form.find('[data-key="EQP1"]');
				        var selectEqp2 = form.find('[data-key="EQP2"]');
				        var selectEqp3 = form.find('[data-key="EQP3"]');
				        
				        var cnt = _self.psgrCnt;
				        
				        selectEqp.append('<option value="0">0대</option>');
				    	
				        for (var i=1; i <= cnt; i++)
				        {
				        	selectMan.append('<option value="' + i + '">' + i + '명</option>');
				        	selectEqp.append('<option value="' + i + '">' + i + '대</option>');
				        }
				    	
				    	var dataObj = data.detail;
				    	dataObj.TOT_COST = _self.stringFilter(dataObj.TOT_COST,'money');
				    	
				    	if(dataObj.EQP1 != null && dataObj.EQP1 != ''){
				    		for (var i=1; i <= cnt; i++)
					        {
				    			selectEqp1.append('<option value="' + i + '">' + i + '대</option>');
					        }
				    		selectEqp1.val(dataObj.EQP1);
				    		form.find("#eqp1_div").css("display","");
				    	}
				    	
				    	if(dataObj.EQP2 != null && dataObj.EQP2  != ''){
				    		for (var i=1; i <= cnt; i++)
					        {
				    			selectEqp2.append('<option value="' + i + '">' + i + '대</option>');
					        }
				    		selectEqp2.val(dataObj.EQP2);
				    		form.find("#eqp2_div").css("display","");
				    	}
				    	
				    	if(dataObj.EQP3 != null && dataObj.EQP3 != ''){
				    		for (var i=1; i <= cnt; i++)
					        {
				    			selectEqp3.append('<option value="' + i + '">' + i + '대</option>');
					        }
				    		selectEqp3.val(dataObj.EQP3);
				    		form.find("#eqp1_div").css("display","");
				    	}
				    	
				    	if (dataObj.SITE_CD == 'P')
				    	{
				    		var warn_text ='** 포털에서 예약하신 고객입니다. 포털예약은 수정하실 수 없습니다.';
				    		form.find('.btnRsvSave').detach(); 
				    		form.find('.memo').detach();
				    		form.find('input,textarea,select').prop('disabled', true);
				    		
//				    		var tomo = jdg.util.todayAdd(1).replaceAll('-','');
//				    		
//				    		if (tomo < dataObj.SCHD_DATE)
//				    		{
//				    			dataObj.RSV_TEL = '***-***-****';
//				    			dataObj.RSV_EMAIL = '***************';
//				    			warn_text += '<br>※ 연락처는 출조일 하루전부터 조회가능합니다.';
//				    		}
				    		
				    		form.find('.warning').text(warn_text);
				    	}
				    	else if(dataObj.SITE_CD == 'S'){
				    		var warn_text ='** 선단에서 예약하신 고객입니다. 선단예약은 수정하실 수 없습니다.';
				    		form.find('.btnRsvSave').detach(); 
				    		form.find('.memo').detach();
				    		form.find('input,textarea,select').prop('disabled', true);
				    		form.find('.warning').text(warn_text);
				    	}else if(dataObj.SITE_CD == 'C'){
				    		warn_text = '쿠팡을 통해서 예약하신 고객입니다. <br/>쿠팡을 통한 예약은 수정하실 수 없습니다.';
				    		form.find('.btnRsvSave').detach(); 
				    		form.find('.memo').detach();
				    		form.find('input,textarea,select').prop('disabled', true);
				    		form.find('.warning').html(warn_text);
				    	}
				    	
				    	jdg.util.detailDataSetting(form, dataObj );		
				    	
				    	var checked = dataObj.WHOLE_YN == "Y";
			    		$("#wholeYnCheck").attr('checked', checked);	
			    		
						var $manCntSel = _self.$modRsvForm.find('[data-key="MAN_CNT"]');
						$manCntSel.attr('disabled', checked);
						
						_self.$modRsvForm.find('[data-key="MEMO"]').val(dataObj.MEMO); 
						_self.$modRsvForm.find('[data-key="SEAT_TXT"]').val(dataObj.SEAT_TXT); 
						
						if(data.refundObj != null){
							var refundObj = data.refundObj;
							_self.$modRsvForm.find('.refundDiv').css("display","contents");
							_self.$modRsvForm.find('[data-key="REFUND_INFO"]').html("예금주명:"+refundObj.REFUND_RSV_NAME +", 은행명: "+ refundObj.REFUND_BANK+"[계좌정보: "+refundObj.REFUND_ACCOUNT_NUM+"]");
						}else{
							_self.$modRsvForm.find('.refundDiv').css("display","none");
							_self.$modRsvForm.find('[data-key="REFUND_INFO"]').html("");
						}
						
						if($("#siteType").val() == "4"){
							form.find('[data-key="MAN_CNT"]').css("display","none");
						}else{
							form.find('[data-key="MAN_CNT"]').css("display","");
						}
			    		
				    }
				});
			},
	
			
			// 예약금액 자동 셋팅
			'totalCost' : function() {
				var _self = this;
				var man = _self.$modRsvForm.find('[data-key=MAN_CNT] option:selected').val();
				var sum = man * _self.feeMan;
				if( !sum ) sum = 0;
				_self.$modRsvForm.find('[data-key=TOT_COST]').text( _self.stringFilter(sum, 'money') );
				$(".jdg-page-schedule").css("width","+=1");
				$(".jdg-page-schedule").removeAttr("style");
			},			
			
			'upadateReload' : function() {
				
				var _self = this;
				
				alert('변경되었습니다');							
				_self.$scrollTop = $(window).scrollTop();
				$('.btn1').show();
				_self.getDaySchedule(_self._selectedDay);
			},
			
			
			'onCreate' : function( p_param, _viewClass ) {
				// 로더 생성
				jdg.util.showLoader();
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.getMyReserveList();
				
				$("div.jdg-ui-img-description").find("textarea").css("opacity","0");
				$("div.jdg-ui-img-description").find("textarea").css("height","10px");
				
				// 캘린더 초기화
				var hash = location.hash;
				if( '' == hash ) {
					var today = new Date();
					var year = today.getFullYear();
					var month = today.getMonth() + 1;
					// set hash
					location.hash = year + '' + jdg.util.setStringFillZero(month,2);
				} else {
					var hashDay = hash.replace('#','');
					var year = hashDay.substring(0,4);
					var month = hashDay.substring(4,6);
					if (hashDay.length == 8)
					{
						_self._selectedDay = hashDay;
					}
					
					_self.createCalendar( year, month-1 );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
