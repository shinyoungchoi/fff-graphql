defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._msgHistoryListURL = $('#msgHistoryListURL').val();
				this._msgtemplateURL = $("#msgtemplateURL").val();
				this.$bbsListTemplate = $("#bbsListTemplate");
				this.$bbsListNoTemplate = $("#bbsListNoTemplate");
				this._msgPrepaidURL = $("#msgPrepaidURL").val();
				this._msgSendMemberURL = $("#msgSendMemberURL").val();
				
				// element
				this.$insertForm = $('#frm');
				this.$insertBtn = $('#insertBbsBtn');
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				//문자 템플릿 보기
				$("div.btnMsgTemp").on("click", function(){
					location.href=_self._msgtemplateURL;
				});
				
				//회원에게 문자보내기
				$("div.btnMsgMember").on("click", function(){
					location.href=_self._msgSendMemberURL;
				});
				
				//결제하기
				$("span.btnPay").on("click", function(){
					  if($("#FAIL_PREPAID_SEQ").val() != null && $("#FAIL_PREPAID_SEQ").val() != ""){
						  if(confirm("실패한 주문건이 있습니다. 진행하시겠습니까?")){
							  $("#payviewer").find("[name='TOT_PAY_COST']").val("");
						  }else{
							  $("#payviewer").find("[name='FAIL_PREPAID_SEQ']").val("");							  
							  $("#payviewer").find("[name='TOT_PAY_COST']").val($("#prepaidCost").val());
						  }
					  }else{
						  $("#payviewer").find("[name='FAIL_PREPAID_SEQ']").val("");
						  $("#payviewer").find("[name='TOT_PAY_COST']").val($("#prepaidCost").val());
					  }
					 
					  var frm =document.payviewer;
				      frm.action = _self._msgPrepaidURL;
				      frm.method ="post";
				      frm.submit();
				});
								
				$("#ir1").on("keyup", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){
						$("span.msg_type").html("LMS");
					}else{
						$("span.msg_type").html("SMS");
					}
					if(value > 1499){ // 최대 1500자
						var content_ = content.substr(0,1499);
						$("#ir1").val(content_);
						return false;
					}
				});
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
						}
				);
				
				
			},
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},
			// 히스토리 내역 조회
			'getHistoryList' : function( page ) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = $("#noticeTbl");
				_paging = $('#bbsListPaging');
				
				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE' : $("#SEND_MSG_BUDGET_TYPE").val()
				};
				$.ajax({
					 url : _self._msgHistoryListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
			    		//총 금액(선불의 경우 잔여금액, 후불의 경우 결제 예상 금액)
			    		$("#totalPrice").html(data.TOTAL_PRICE);
				    	if( data.hasOwnProperty('msgHistoryList') ) {
				    		// 초기화
				    		_contatiner.empty();
				    		var list = data.msgHistoryList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$bbsListNoTemplate.find("tr").clone();
				    			_contatiner.html( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			console.log(data);
					    			var $row = _self.$bbsListTemplate.find("tr").clone();
					    			
					    			if (idx % 2 == 1)
					    			{
					    				$row.addClass("even");
					    			}
					    			
					    			$row.attr( 'rowKey', data.MSG_SEQ);
					    							    			
					    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;

					    			// 제목
					    			$row.find('[data-key=RN]').text( data.ROW_NUMBER );
					    			$row.find('[data-key=MSG_TYPE]').text( data.MSG_TYPE );
					    			$row.find('[data-key=TITLE]').text( data.TITLE );
					    			$row.find('[data-key=CONTENT]').text( data.CONTENT );
					    			$row.find('[data-key=CREATED_AT]').text( data.SEND_DATE_STR );
					    			$row.find('[data-key=MSG_TOTAL]').text( data.MSG_TOTAL +"원");
					    			$row.find('[data-key=MSG_COUNT]').text( data.MSG_COUNT +"개");
					    			
					    			_contatiner.append( $row );
					    		});					    		
					    	}
				    		
					    	var numOfPages = Math.ceil(data.total / itemCnt);
					    	
				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: numOfPages
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
									_self.getHistoryList( page );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		
				    		if (numOfPages > 5)
					    		_paging.find('.paging_next').text(">");				    		
				    	}
				    }
				});
			},		
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.getHistoryList(1);
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});