defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();

				this._scheduleDetailFormURL = $('#scheduleDetailFormURL').val();
				
				// element
				this.$dateYear = $('#dateYear');
				this.$dateMonth = $('#dateMonth');
				this.$prevMonth = $('#schedulePrevMonth');
				this.$nextMonth = $('#scheduleNextMonth');
				this.$calendarTemplate = $('#calendarTemplate');
				
				// Calendar
				this.$calendarContainer = $('#calendarContainer');
				this.$calendarRow = this.$calendarTemplate.find('#calendarRow');
				this.$scheduleRow = this.$calendarTemplate.find('.scheduleRow');
				
				// Calendar List
				this.$calendarListContainer = $('#calendarListContainer');
				this.$calendarListRow = this.$calendarTemplate.find('.calendarListRow');
				
				// static variable
				this.currentScheduleList = null;
				this.weekArr = ['일요일', '월요일','화요일','수요일','목요일','금요일','토요일'];
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
				
				this.bizId = $('#bizId').val();
				this.shipId = $('#shipId').val();
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				
				this._selectedDay = null;
				
				this.$reserveList = $('#listContainer');
				this.$mobileReserveList = $('#mobile_listContainer');
				
				this.$tmpReserveListRow = $('#reserve_list_row');
				this.$tmpMobileReserveListRow = $('#mobile_reserve_list_row');
				
				this.$modSchdFormTemplate = $('.modSchdFormTemplate');
				this.$modNoChoiceSchdFormTemplate  = $(".modNoChoiceSchdFormTemplate");
				this.$modSchdForm;
				this.$modSchdLi;
				
				this.$modRsvFormTemplate = $('.modRsvFormTemplate');
				this.$modRsvForm;
				this.$modRsvDiv;
				this.$rsvId;	
				this.psgrCnt;
				this.feeWhole;
				this.feeMan;
				
				this.$scrollTop = 0;
				
				this._selectedDay = null;
				this._todayTd = null;
				this._selectedTd = null;
			},
			'setEvent'		: function() {
				var _self = this;
				// Calendar 이전달로 이동
				_self.$prevMonth.click( function() {					
					jdg.util.showLoader();
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 1 ) {
						year = year-1;
						month = 12;
					} else {
						month = month-1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				// Calendar 다음달로 이동
				_self.$nextMonth.click( function() {
					jdg.util.showLoader();
					var year = Number(_self.$dateYear.text());
					var month = Number(_self.$dateMonth.text());
					if( month == 12 ) {
						year = year+1;
						month = 1;
					} else {
						month = month+1;
					}
					_self.$dateYear.text(year);
					_self.$dateMonth.text(month);
					_self._selectedDay = null;
					
					// set hash
					location.hash = '#' + year + jdg.util.setStringFillZero(month,2);
				});
				
				_self.$calendarListContainer.delegate('.jdg-status-a','click',function() {					
					Bplat.view.loadPage('schedule/pension/detail_form?SCHD_ID=' + $(this).data('scheId'));
				});
				
				_self.$calendarContainer.delegate('td.on','click',function() {	
					
					var _td = $(this);
					_self.getDaySchedule(_td.attr('date'));					
				});			
				
				
				// 상세이동
				_self.$calendarContainer.delegate('span.jdg-data-status','click',function() {
					Bplat.view.loadPage(_self._scheduleDetailFormURL + '?SCHD_ID=' + $(this).parent().attr('scheId'));
				});
				

				//수정화면 이동.
				_self.$calendarListContainer.delegate('.btnModifySchedule','click',function() {
					
					_self.$modSchdLi = $(this).closest('li');
					var scheId = _self.$modSchdLi.attr('scheId');
					var choiceGenre = _self.$modSchdLi.attr("pchoice");
					var timeType = _self.$modSchdLi.attr("pschetype");
					
					if(timeType == '0' && ( choiceGenre =='' || choiceGenre == undefined)){
						_self.$modSchdForm = _self.$modNoChoiceSchdFormTemplate.clone();
						_self.$modSchdLi.append(_self.$modSchdForm);
						_self.$modSchdForm.show();
						
						$(this).hide();
						
						_self.$modSchdLi.css('background-color','#E0E0E0');					
						_self.getScheduleDetail({SCHD_ID: scheId, CHOICE : 'N'});	
						
					}else{
					
						_self.$modSchdForm = _self.$modSchdFormTemplate.clone();					
						_self.$modSchdLi.append(_self.$modSchdForm);
						_self.$modSchdForm.show();
						
						$(this).hide();
						
						_self.$modSchdLi.css('background-color','#E0E0E0');					
						_self.getScheduleDetail({SCHD_ID: scheId , CHOICE : 'Y'});
					
					}
				

				});
				
				
				_self.$calendarListContainer.delegate('.btnModifyRsv','click',function() {
					
					_self.$modSchdLi = $(this).closest('li');
					
					_self.$modRsvDiv = $(this).closest('div');
					_self.$modRsvForm = _self.$modRsvFormTemplate.clone();					
					_self.$modRsvDiv.append(_self.$modRsvForm);
					_self.$modRsvForm.show();
					
					_self.$rsvId = $(this).attr('rsv_id');
					_self.psgrCnt = _self.$modSchdLi.attr('PSGR_CNT');
					_self.feeWhole = _self.$modSchdLi.attr('FEE_WHOLE');
					_self.feeMan = _self.$modSchdLi.attr('FEE');
					
					$('.btn1').hide();
					
					_self.$modRsvDiv.css('background-color','#E0E0E0');
					_self.getReserveDetail({RSV_ID: _self.$rsvId});
				});
				
				//생활낚시 혹은 선택된 일반 낚시 
				$(document).on('click','span.btnSchdSave',function() {
					_self.updateSchdeule();
				});
				
				//장르 선택 전 일반 낚시
				$(document).on('click','span.btnNoChoiceSchdSave',function() {
					_self.updateNoChoiceSchdeule();
				});
				
				$(document).on('click','span.btnRsvSave',function() {
					_self.updateReserve();
				});
				
				
				$(document).delegate('span.btnCancel','click',function() {
					
					$('.btn1').show();
					
					if (_self.$modSchdForm != null)
					{
						_self.$modSchdForm.empty();
						_self.$modSchdForm = null;
						_self.$modSchdLi.css('background-color','');
					}
					else if (_self.$modRsvForm != null)
					{
						_self.$modRsvForm.empty();
						_self.$modRsvForm = null;
						_self.$modRsvDiv.css('background-color','');						
					}
				});

				$(document).delegate('select[data-key="STATUS_CD"]','change',function() {
					
					if  (_self.$modSchdForm == null)
					{
						return;
					}					
					
					var cd = $(this).val();
					
					if (cd == "113_210")
					{
						_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').show();
					}
					else
					{
						_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').hide();
					}
				});

				
				// 인원수 변경
				$(document).delegate('select[data-key=MAN_CNT]','change',function() {	
					
					_self.totalCost();
				});						
				
				
			
				
				//날씨 버튼 클릭
				$(document).on('click','span.jdg-btn-weather',function() {
					var year =  $('#dateYear').text();
					var month =  new Number($('#dateMonth').text());
					var srhMonth = (month < 10) ? '0'+month : month;
					var day = $(this).parent().parent().find('.jdg-data-date').text();
					var srhDate = (day<10) ? '0'+day : day;
					var date = year+srhMonth+srhDate;
					
					var insertParam = {
							'WEATHER_DATE' :  date
						   ,'SHIP_ID'  :  _self.$shipId.replace('/', '')
					};
					
					$.ajax({
						url : _self._scheduleWeatherURL
						,type : 'POST'
						,data : insertParam
						,dataType : 'json'
						,success : function( data ) {
							if(data.hasOwnProperty('marineWeather')){
								
								var weatherCond = data.marineWeather.WEATHER_COND;
								var windDirect = data.marineWeather.WIND_DIRECT;
								var waveHeight = data.marineWeather.WAVE_HEIGHT;
								var windSpeed = data.marineWeather.WIND_SPEED;

								var arrweatherCond = weatherCond.split(",");
								var arrWindDirect = windDirect.split(",");
								var arrWaveHeight =  waveHeight.split(",");
								var arrWindSpeed = windSpeed.split(",");
								
								var weatherTr = _self.$weatherInfoTbl.find('tr[data-key=WEATHER_TR]');
								var windDirectTr = _self.$weatherInfoTbl.find('tr[data-key=WIND_DIRECT_TR]');
								var windSpeedTr = _self.$weatherInfoTbl.find('tr[data-key=WIND_SPEED_TR]');
								var waveHeightTr = _self.$weatherInfoTbl.find('tr[data-key=WAVE_HEIGHT_TR]');
								
								// 날씨 정보 테이블에 remove 된것이 있으면 다시 팝업을 초기화 해준다.
								if(_self.$weatherInfoTbl.find('thead').find('th').length != 3 ){
									 var weatherInfoTblTh = "<th>오후</th>";
									_self.$weatherInfoTbl.find('thead').find('tr').eq(0).append(weatherInfoTblTh);
									_self.$weatherInfoTbl.find('thead').find('th').eq(1).text("오전");
									
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(i){
										var weatherInfoTblTd = "<td></td>";
										$(this).find('td').eq(i).empty();
										$(this).append(weatherInfoTblTd);
									});
								}else{
									_self.$weatherInfoTbl.find('tbody').find('tr').each(function(){
										$(this).find('td').empty();
									});
									
								}
								
								//데이터가 오후만 있는 경우, 
								if( arrweatherCond[0] == "" ){
									var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[1]+"' width='30px' height='30px'>";

									_self.$weatherInfoTbl.find('thead').find('th').eq(1).remove();
									_self.$weatherInfoTbl.find('tr').each(function(){
										$(this).find('td').eq(0).remove();
									});
									
									weatherTr.find('td').eq(0).append(weatherImg);
									windDirectTr.find('td').eq(0).text(arrWindDirect[1]);
									windSpeedTr.find('td').eq(0).text(arrWindSpeed[1]);
									waveHeightTr.find('td').eq(0).text(arrWaveHeight[1]);
									
								}else{ 
									 //오전, 오후 일떄
										for(var i=0; i<arrweatherCond.length; i++ ){
											var weatherImg = "<img src='https://www.kma.go.kr"+arrweatherCond[i]+"' width='30px' height='30px'>";
											
											weatherTr.find('td').eq(i).append(weatherImg);
											windDirectTr.find('td').eq(i).text(arrWindDirect[i]);
											windSpeedTr.find('td').eq(i).text(arrWindSpeed[i]);
											waveHeightTr.find('td').eq(i).text(arrWaveHeight[i]);
										}
								}
								_self.$weatherDiv.css('display','block');
							}
						}
					});
				});

			},
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length >= 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(^[+-]?\d+)(\d{3})/;
					str += '';
					
					while(pattern.test(str)) {
						str = str.replace(pattern,'$1,$2');
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},	

			'getMyReserveList' : function() {
				var _self = this;
				
				if (_self._myReserveListURL == null) return false;

				var defaultParam = {
						 'PAGE' : 1
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	$.each(data.memReserveList, function(key,value) {
				    		console.log(value);
				    		 $row = _self.$tmpReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('#SCHD_DATE');
				    		 $schdDate.text(value.SCHD_DATE);

				    		 $schdTitle = $row.find('#SUB_TITLE');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 if(value.ROOM_TYPE == 'P'){
				    			 $manCnt = $row.find('#MAN_CNT');
				    			 $manCnt.text("1팀");
				    		 }else{
				    			 $manCnt = $row.find('#MAN_CNT');
				    			 $manCnt.text(value.MAN_CNT+"명");
				    		 }

				    		 $totCost = $row.find('#TOT_COST');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money'));

				    		 var statusCd = value.STATUS_CD;

			    			$statusName = $row.find('#STATUS_NAME');
			    			if( statusCd == '104_300'){
			    				$statusName.addClass('jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$reserveList.append($row);
			    			
				    		 $row = _self.$tmpMobileReserveListRow.clone();
				    		 $row.attr('id', null);
				    		 
				    		 $schdDate = $row.find('#SCHD_DATE');
				    		 $schdDate.text("출조:" + value.SCHD_DATE);

				    		 $schdTitle = $row.find('#SUB_TITLE');
				    		 $schdTitle.text(value.SUB_TITLE);

				    		 $manCnt = $row.find('#MAN_CNT');
				    		 $manCnt.text(value.MAN_CNT + "명");

				    		 $totCost = $row.find('#TOT_COST');
				    		 $totCost.text(_self.stringFilter(value.TOT_COST, 'money')  + "원");

				    		 var statusCd = value.STATUS_CD;

			    			$statusName = $row.find('STATUS_NAME');
			    			if( statusCd == '104_300'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-a');
			    			}else if( statusCd == '104_310'){
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-b');
			    			}else{
			    				$statusName.addClass('jdg-data-reservation-status jdg-status-c');
			    			}
			    			$statusName.text(value.STATUS_NAME);
			    			
			    			$row.click( function(){
			    				Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + value.RSV_ID, {
			    					'RSV_ID' : value.RSV_ID
			    				});
			    				return false;
			    			});

			    			_self.$mobileReserveList.append($row);
			    			
				    	 });				    	
				    }
				});				
			},			
			// 달력생성
			'createCalendar' : function( year, month ) {

				$('.jdg-ui-calendar').hide();
				// Calendar & Calendar List 생성
				var _self = this;
				_self.$calendarContainer.empty();
				var tmpDay = new Date();
				
				var isCurrentMonth = tmpDay.getFullYear() == year && tmpDay.getMonth() == month;
				var currentDate = tmpDay.getDate();
				
				tmpDay.setFullYear(year, month, 1);
				var dayOfMonth = tmpDay.getRangeDaysOfMonth(); //이번달
				var startDay = Number( dayOfMonth[0].split('-')[2] );
				var endDay = Number( dayOfMonth[1].split('-')[2] );
				var srhMonth = (month+1 < 10) ? '0'+(month+1) : (month+1);
				var weekCnt = 1;				
				
				_self._todayTd = null;
				
				for( var i = startDay; i <= endDay ; i++ ) {
					tmpDay.setDate(i);
					var day = tmpDay.getDay();
					var date = tmpDay.getDate();
					if( i == 1 || day == 0 ) {
						// calendar
						var $week = _self.$calendarRow.clone();
						_self.$calendarContainer.append( $week );
						
						weekCnt++;
					}
					var $td = $week.find('[day='+day+']');
					$td.text(i);
					$td.attr('id', 'td_calendar_' + i);
					
					if (isCurrentMonth && currentDate == date)
					{
						$td.css('border','blue 3px solid');
						_self._todayTd = $td;
					}
				}
				_self.$dateYear.text(year);
				_self.$dateMonth.text(month+1);
				// 해당 Calendar의 출조 스케쥴 조회
				_self.getScheduleList({'SCHD_MONTH' : year + '' + srhMonth });

			},	
			
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var today = jdg.util.today().replaceAll('-','');
				$.ajax({
					 url : "schedule/listForManager"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var scheduleList = data.scheduleList;
			    		_self.currentScheduleList = scheduleList;
			    		
				    	var seatimeList = data.seatimeList;
				    	//var seatimeMap = {};
				    	
				    	var _td;
						
						for (var idx = 0; idx < seatimeList.length; idx ++)
						{
							var item = seatimeList[idx];
							var tDay = item.SOLAR_DATE.substr(6,2) * 1;
							
							_td = _self.$calendarContainer.find('#td_calendar_'+tDay);
							_td.addClass("on");
							_td.append( "<span class='jdg-data-tide'>" + item.MOOL + "</span>" );	
							_td.attr('date', item.SOLAR_DATE);
							
							if (item.SOLAR_DATE < today)
							{
								_td.css('color','lightgray');
								_td.find('span').css('color','lightgray');
							}							
							
							if (isHoliday(item.SOLAR_DATE))
							{
								_td.addClass("jdg-sun");
								_td.removeClass("jdg-sat");
							}
						}
			    		
			    		//달력생성 및 예약가능선박수
			    		_self.renderScheduleList( scheduleList );
			    		
			    		// Loader 삭제
						$('.jdg-ui-calendar').show();
						jdg.util.removeLoader();
						
						var searchDate;
						
						if (_self._selectedDay)
						{
							searchDate = _self._selectedDay;
							_self._selectedDay = null;
						}
						else
						{
							searchDate = (today.substr(0,6) == param.SCHD_MONTH)? today : param.SCHD_MONTH + '01';
						}

						_self.getDaySchedule(searchDate);
				    }
				});
			},
			

			// 해당일 출조스케쥴 
			'getDaySchedule' : function( schdate ) {
				
				var _self = this;
				
				var $td = $('td#td_calendar_' + (schdate.substr(6,2) * 1));
				
				if (_self._selectedTd)
				{
					_self._selectedTd.css('border', '');
				}
					
				$td.css('border','red 2px solid');						
				_self._selectedTd = $td;
				
				if (_self._todayTd && _self._todayTd != $td)
				{
					_self._todayTd.css('border','blue 3px solid');
				}	
				
				_self._selectedDay = schdate;

				var param = {SCHD_DATE:schdate};				
				
				$.ajax({
					 url : 'schedule/dayscForManager'
					,async : false
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var scheduleList = data.scheduleList;
				    	var reserveList = data.reserveList;
				    	
				    	var _dateStr = (schdate.substr(4,2) * 1) + "월 " + (schdate.substr(6,2) * 1) + '일';
				    	
				    	if (scheduleList.length == 0)
				    	{
				    		_self.$calendarListContainer.empty();
				    		_self.$calendarListContainer.append("<div style='background-color:#FFAEAE;font-size:12pt;padding:10px;color:white;font-weight:bold'>" + _dateStr  +"에는 출조일정이 없습니다.<div>");
				    		return;
				    	}
				    	
				    	var reserveMap = {};
				    	var item;
				    	var resv;
				    	var status;
				    	
				    	var dateStr;
				    	var timeStr;
				    	var dayStr;
				    	
				    	if (reserveList != null)
				    	{
				    		var seaTime = $("#td_calendar_" + (schdate.substr(6,2) * 1) + " .jdg-data-tide").text();
				    		
				    		
							for (var idx = 0;  idx < reserveList.length;idx++ )
							{
								item = reserveList[idx];
								resv = reserveMap[item.SCHD_ID];
								
								switch(item.STATUS_CD)
								{
								case "104_300": status = " 확정"; break;
								case "104_310": status = " 미입금"; break;
								case "104_320": status = " 부분입금"; break;
								case "104_340": status = " 확정(미입금)"; break;
								case "104_410": status = " 취소"; break;
								case "104_420": status = " 취소(환불예정)"; break;
								case "104_430": status = " 취소(환불완료)"; break;
								}
								
								var dispText = "";
								if (item.DISP_TXT)
								{
									dispText = item.DISP_TXT.substr(0,12) 
								}
								
								
								var rsvStr;
								
								
								if (item.STATUS_CD >= "104_410")
								{
									if(item.ROOM_TYPE == 'P')
										rsvStr = "<div><span class='cnl'>" +  dispText + ' 님 ' + status + "</span><span class='btn1 btnModifyRsv' rsv_id='" + item.RSV_ID +"'>변경</span></div>";
									else
										rsvStr = "<div><span class='cnl'>" + dispText + ' 님(' + item.MAN_CNT +  '명 ) ' + status + "</span><span class='btn1 btnModifyRsv' rsv_id='" + item.RSV_ID +"'>변경</span></div>";
								}
								else
								{
									if(item.ROOM_TYPE == 'P')
										rsvStr = "<div><span>" + dispText + ' 님 ' + status + "</span><span class='btn1 btnModifyRsv' rsv_id='" + item.RSV_ID +"'>변경</span></div>";
									else
										rsvStr = "<div><span>" + dispText + ' 님(' + item.MAN_CNT +  '명 ) ' + status + "</span><span class='btn1 btnModifyRsv' rsv_id='" + item.RSV_ID +"'>변경</span></div>";
								}
								
								
								if (resv)
								{
									reserveMap[item.SCHD_ID] = resv + rsvStr;
								}
								else
								{
									reserveMap[item.SCHD_ID] = rsvStr;
								}
							}
				    	}
				    	
				    	var cont = _self.$calendarListContainer;
				    	var tmpl ;
				    	
				    	_self.$calendarListContainer.empty();

						for (var idx = 0; idx < scheduleList.length; idx ++)
						{
							item = scheduleList[idx];
							console.log(item);
							if (idx == 0)
							{
				    			var schdDate = item.SCHD_DATE;
				    			var year = schdDate.substring(0,4);
				    			var month = schdDate.substring(4,6)-1;
				    			var date = schdDate.substring(6,8);
				    			var tmpDay = new Date();
				    			tmpDay.setFullYear(year, month, date);
				    			dayStr = _self.weekArr[tmpDay.getDay()];
				    			
								dateStr = (1 * schdDate.substr(4,2)) + '월'+ (1 * schdDate.substr(6,2)) + '일';								
							}
							
							tmpl = _self.$calendarListRow.clone();
							
						
							if(item.ROOM_TYPE == 'G'){
								tmpl.find('#sub_title').html(item.SUB_TITLE+ " <img src='/resources/wf/images/guesth.jpg' style='width:50px;'>");	
							}else{
								tmpl.find('#sub_title').text(item.SUB_TITLE);
							}
							tmpl.find('#date').text(dateStr);
							tmpl.find('#day').text(dayStr);
							
							if (item.NOTICE_TEXT)
							{
								tmpl.find('#notice_text').text(item.NOTICE_TEXT);
							}
							else
							{
								tmpl.find('#notice_text').remove();
							}

							if (reserveMap[item.SCHD_ID])
							{
								tmpl.find('#rsv').html(reserveMap[item.SCHD_ID]);
							}
							else
							{
								tmpl.find('#rsv').remove();
							}
							
							var tmplLi = tmpl.find('li');
							tmplLi.attr("ROOM_TYPE", item.ROOM_TYPE);
							tmplLi.attr('PSGR_CNT',item.PSGR_CNT);
							tmplLi.attr('FEE_WHOLE',item.FEE_WHOLE);
							tmplLi.attr('FEE',item.FEE);
							tmplLi.attr('scheId', item.SCHD_ID);

							tmplLi.attr("pchoice", item.CHOICE_GENRE);
							tmplLi.attr("pschetype", item.SCHD_TIME_TYPE);
							
			    			// 예약可인원
			    			//var reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT;
							var reserveCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
							
			    			// Calendar & Calendar List 예약상태
			    			
			    			var statusObj = tmpl.find('em.statusCd');
			    						 
			    			if(item.DEL_FLAG == 'Y'){
			    				//해당 스케쥴 노출 안하도록 해놓았으므로
			    				statusObj.text('감추기').addClass('jdg-status-d');
			    			}else{
				    			if( '113_110' === item.STATUS_CD && reserveCnt == 0 ) {
				    				statusObj.text('마감').addClass('jdg-status-c');
				    			} 
				    			else if( '113_110' === item.STATUS_CD && reserveCnt < 0 ) {
				    				statusObj.text('마감(' + (reserveCnt * -1)  + '명초과)').addClass('jdg-status-d');
				    			}			    			
				    			else if( '113_110' === item.STATUS_CD ) {
					    				statusObj.addClass('jdg-status-a');
					    				statusObj.data('scheId',item.SCHD_ID);
					    				// 예약可인원
					    				if(item.ROOM_TYPE == 'P'){
					    					tmpl.find('#avail_cnt').text("빈방");
					    				}else
					    					tmpl.find('#avail_cnt').text( reserveCnt<0?0:reserveCnt + '명');
				    			} else if( '113_170' === item.STATUS_CD) {
				    				statusObj.text('마감').addClass('jdg-status-b');
				    			} else if( '113_180' === item.STATUS_CD) {
				    				statusObj.text('만료').addClass('jdg-status-c');
				    			} else if( '113_210' === item.STATUS_CD ) {
				    				statusObj.text('예약불가').addClass('jdg-status-d');
				    			}
			    			}
			    			

			    		
			    			
							_self.$calendarListContainer.append(tmpl);
							scrollBottom();
						}

				    }
				});
			},

			'renderScheduleList' : function(list){
				
				var _self = this;
				
				_self._interval_objs = null;
				
				var isBlink = false;
				
    			if (_self._interval_id)
    			{
    				clearInterval(_self._interval_id);			    				
    				_self._interval_id = null;
    			}
				
				$.each( list, function( idx, data ) {
	    			// web calendar 셋팅
	    			var schdDate = data.SCHD_DATE;
	    			var year = schdDate.substring(0,4);
	    			var month = schdDate.substring(4,6)-1;
	    			var date = schdDate.substring(6,8);
	    			
	    			var dateNum = parseInt( date, 10 );

	    			var $td = $('#td_calendar_' + dateNum);

	    			if( data.AVAILS > 0 ) {
	    				
	    				$td.append( "<div class='jdg-bgbox1'></div>" );	

	    			} 
	    			else if( data.AVAILS == 0 && data.SOLDOUTS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox2'></div>" );	
	    				$td.css("text-decoration","line-through");
	    			} 
	    			else if( data.AVAILS == 0 && data.CANCELS > 0 )  {

	    				$td.append( "<div class='jdg-bgbox3' style='z-index: 100'>취소</div>" );	
	    				
	    				isBlink = true;
	    			}
	    			

 
    				// mobile calendar 셋팅
	    			var $ul = $( '#ul_calendar_list_'  + _self.getWeekOfMonth( new Date(year, month, dateNum) ) );

	    		});
				
	    		if (isBlink)
	    		{
	    			_interval_objs = $("div.jdg-bgbox3");
	    			_interval_index = 0;			    			
	    			_self._interval_id = setInterval(_self.blinkEffect, 400);
	    		}
			},

			'getWeekOfMonth' : function(date){
				var dayOfMonth = date.getDate();
				
				var first = new Date( date.getFullYear(), date.getMonth(), 1 );
				var monthFirstDateDay = first.getDay();
				
				return Math.ceil( (dayOfMonth + monthFirstDateDay) / 7 );
			},
			
			
			// 출조스케쥴 목록 조회(listForManager)
			'getScheduleDetail' : function( param ) {
				var _self = this;
				var tmpDay = new Date();
				$.ajax({
					 url : "schedule/detail"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {	
				    	var dataObj = data.detail;
				    	
				    		console.log(dataObj);
				    		
					    	
					    	if (dataObj.STATUS_CD == '113_210')
					    	{
					    		if (dataObj.CANCEL_DESC != null)
					    		{
						    		dataObj.CANCEL_DESC = dataObj.CANCEL_DESC.replace(' 취소합니다.','');					    						    			
					    		}
					    		_self.$modSchdForm.find('[data-key="CANCEL_DESC"]').show();
					    	}
					    	
					    	jdg.util.detailDataSetting(_self.$modSchdForm, dataObj );
					    	//펜션일 경우
					    	if(dataObj.ROOM_TYPE == 'P'){
					    		_self.$modSchdForm.find("#modPenDiv").show();
					    		_self.$modSchdForm.find("#modPenPerDiv").show();
					    		_self.$modSchdForm.find("[data-key='MAN']").text(dataObj.PSGR_CNT+"명");
					    	}else{
					    		_self.$modSchdForm.find("#modGuestDiv").show();
					    		_self.$modSchdForm.find("#modGuestPerDiv").show();
					    	}
				    }
				});
			},
			// 스케쥴 수정
			'updateSchdeule' : function( param )
			{
				var _self = this;
				var $form = _self.$modSchdForm;
				
				// validation
				if( !jdg.util.validator( $form, true ) ) return false;
				
				var param = autoDataGetter($form);
				console.log(param);
				if(param.ROOM_TYPE == 'P'){
					
					if (param.FEE_WHOLE < 10000)
					{
						alert('숙박비용은 만원이하로 입력할수 없습니다.');
						return;
					}
				}else{

					
					if (param.FEE < 10000)
					{
						alert('1인 선비는 만원이하로 입력할수 없습니다.');
						return;
					}
				}

				param.SCHD_ID = _self.$modSchdLi.attr('scheId');
				
				
				if (param.STATUS_CD == '113_210')
				{
					param.CANCEL_DESC = param.CANCEL_DESC + ' 출조를 취소합니다.';
				}
				else
				{
					param.CANCEL_DESC = null;
				}
				
				$.ajax({
					 url : 'schedule/update_schedule'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if (data.error)
				    	{
				    		alert(data.error);
				    	}
				    	else
				    	{
				    		_self.upadateReload();
				    	}

				    }
				});
			},

			
			
			// 예약수정
			'updateReserve' : function()
			{
				var _self = this;
				var $form = _self.$modRsvForm;
				
				// validation
				if( !jdg.util.validator( $form, true ) ) return false;
				
				var param = autoDataGetter($form);
				param.RSV_ID = _self.$rsvId;
				param.TOT_COST = param.TOT_COST.replaceAll( ',', '' ).replaceAll( '원', '' );

				
				$.ajax({
					 url : 'schedule/update_reserve_manager'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if (data.error)
				    	{
				    		alert(data.error);
				    	}
				    	else
				    	{
				    		_self.upadateReload();
				    	}

				    }
				});
			},
			

			// 예약상세 조회(관리자용)
			'getReserveDetail' : function( param ) {
				var _self = this;
				$.ajax({
					 url : "schedule/reserve_detail_manager"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	console.log(data);
				    	var form = _self.$modRsvForm;
				        var selectMan = form.find('[data-key="MAN_CNT"]');
				        
				        var cnt = _self.psgrCnt;	        
				    	
				        for (var i=1; i <= cnt; i++)
				        {
				        	selectMan.append('<option value="' + i + '">' + i + '명</option>');
				        }
				    	
				    	var dataObj = data.detail;
				    	dataObj.TOT_COST = _self.stringFilter(dataObj.TOT_COST,'money');
				    	
				    	if (dataObj.SITE_CD == 'P')
				    	{
				    		var warn_text ='** 포털에서 예약하신 고객입니다. 포털예약은 수정하실 수 없습니다.';
				    		form.find('.btnRsvSave').detach(); 
				    		form.find('.memo').detach();
				    		form.find('input,textarea,select').prop('disabled', true);
				    						    		
				    		form.find('.warning').text(warn_text);
				    	}
				    	
				    	jdg.util.detailDataSetting(form, dataObj );		
				    				    		
				    	if(dataObj.ROOM_TYPE == 'P'){
				    		form.find("[data-key='MAN']").text(dataObj.MAN_CNT);
				    		form.find("#rsvPenDiv").show();
				    		form.find("#rsvGuestDiv").hide();
				    	}else{
				    		form.find("#rsvPenDiv").hide();
				    		form.find("#rsvGuestDiv").show();
				    	}
						
						_self.$modRsvForm.find('[data-key="MEMO"]').val(dataObj.MEMO); 
			    		
				    }
				});
			},
	
			
			// 예약금액 자동 셋팅
			'totalCost' : function() {
				var _self = this;
				var man = _self.$modRsvForm.find('[data-key=MAN_CNT] option:selected').val();
				var sum = man * _self.feeMan;
				if( !sum ) sum = 0;
				_self.$modRsvForm.find('[data-key=TOT_COST]').text( _self.stringFilter(sum, 'money') );
				$(".jdg-page-schedule").css("width","+=1");
				$(".jdg-page-schedule").removeAttr("style");
			},			
			
			'upadateReload' : function() {
				
				var _self = this;
				
				alert('변경되었습니다');							
				_self.$scrollTop = $(window).scrollTop();
				$('.btn1').show();
				_self.getDaySchedule(_self._selectedDay);
			},
			
			
			'onCreate' : function( p_param, _viewClass ) {
				// 로더 생성
				jdg.util.showLoader();
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.getMyReserveList();
				
				// 캘린더 초기화
				var hash = location.hash;
				if( '' == hash ) {
					var today = new Date();
					var year = today.getFullYear();
					var month = today.getMonth() + 1;
					// set hash
					location.hash = year + '' + jdg.util.setStringFillZero(month,2);
				} else {
					var hashDay = hash.replace('#','');
					var year = hashDay.substring(0,4);
					var month = hashDay.substring(4,6);
					if (hashDay.length == 8)
					{
						_self._selectedDay = hashDay;
					}
					
					_self.createCalendar( year, month-1 );
				}
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
