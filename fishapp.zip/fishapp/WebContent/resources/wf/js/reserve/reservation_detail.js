defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				this._loginURL = $('#loginURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				this._memReserveListURL = $('#memReserveListURL').val();
				this._memReserveCancelURL = $('#memReserveCancelURL').val();
				this.$loginBtn = $('#loginBtn');
				this.$goList = $('#goList');
				this.$reserveCancel = $('#reserveCancel');
				this.$rsvId = $('#rsvId').val();
				this.reserveStatusCd = null;
			},
			'setEvent'		: function() {
				var _self = this;
				// 예약하기 위해 로그인
				_self.$loginBtn.click( function() {
					Bplat.view.loadPage( _self._loginURL );
				});
				
				_self.$goList.click( function(){
					Bplat.view.loadPage(_self._memReserveListURL );
				});
				
				_self.$reserveCancel.click( function(){
					if (confirm("예약 취소 하시겠습니까?") == true) {   
						_self.deleteReserve(_self.$rsvId);
					} else {   
						 return;
					}
				});
			},
			'pageInit'		: function() {
				var _self = this;
				
				
			},
			'deleteReserve' : function( rsvId ) {
				var _self = this;
				var defaultParam = {
					'RSV_ID' : rsvId,
					'STATUS_CD' : this.reserveStatusCd == '104_300' ? '104_420' : '104_410'
				};
				
				$.ajax({
					 url : _self._memReserveCancelURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var val = data.result;
				    	if(val > 0){
					    	alert("예약취소 되었습니다.");
					    	console.info( data );
					    	Bplat.view.loadPage(_self._memReserveListURL);
				    	}else{
				    		if( data.error != null )
				    			alert( data.error.userMessage );
				    		else
				    			alert( '예약 취소에 실패했습니다. 잠시 후 다시 시도해주세요.' );
				    	}
				    	
			    	}
				});
			},
			'getMemberDetail' : function( rsvId ) {
				var _self = this;
				var defaultParam = {
					'rsvId' : rsvId
				};
				$.ajax({
					 url : _self._memReserveDetailURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	var val = data.memReserveDetail;
				    	console.log(val);

				    	if (val.REVOCABLE == null || val.REVOCABLE != "Y")
				    	{
				    		$('#reserveCancel').hide();
				    	}
				    	
				    	//출조일시 
				    	var SCHD_TIME = val.SCHD_TIME;
				    	var SCHD_DATE = val.SCHD_DATE;
				    	if(SCHD_TIME != null &&  SCHD_TIME != undefined ){
				    		SCHD_TIME = SCHD_TIME.substr(0, 2) + ":" + SCHD_TIME.substr(2, 4);
				    		var SCHD = SCHD_DATE.substr(0,4) +"." + SCHD_DATE.substr(4,2) + "." + SCHD_DATE.substr(6,2) + "  (" +  SCHD_TIME + ")";
				    	}else{
				    		var SCHD = SCHD_DATE;
				    	}
				    	
						//전화번호 값
				    	var rsvTel = val.RSV_TEL;
						if(rsvTel != null && rsvTel != undefined){
							if( rsvTel.length == 11  ){
								rsvTel = rsvTel.substring(0,3) + "-" + rsvTel.substring(3,7) + "-" + rsvTel.substring(7);
							}
							if( rsvTel.length == 10 ){
								rsvTel = rsvTel.substring(0,3) + "-" + rsvTel.substring(3,6) + "-" + rsvTel.substring(6);
							}
						}
				    	
						// 독선여부 y=예 그외의값=아니오
						var wholeYN = val.WHOLE_YN;
						if(wholeYN == "Y" || wholeYN == "y"){
							wholeYN = "예";
						}else{
							wholeYN = "아니오";
						}
						
						var totCost = (val.TOT_COST).toString();
						var totCostLength = totCost.length;
						
						//금액에 , 찍기
						for(var i=3; i<totCostLength ; i=i+3){
							totCost = totCost.substring(0,totCostLength-i) + "," + totCost.substring(totCostLength-i);
						}
						
				    	
				    	$('#sub_title').text(val.SUB_TITLE);
				    	$('#schd_date').text(SCHD);
				    	$('#psgr_cnt').text(val.PSGR_CNT + " 명");
				    	$('#fish_kind').text(val.FISH_KIND);
				    	$('#prepare').text(val.PREPARE);
				    	$('#loc_desc').text(val.LOC_DESC);
				    	$('#descr').append(val.DESCR);
				    	$('#rsv_name').text(val.RSV_NAME);
				    	$('#rsv_tel').text(rsvTel);
				    	$('#rsv_email').text(val.RSV_EMAIL);
				    	$('#man_cnt').text(val.MAN_CNT + " 명");
				    	$('#whole_yn').text(wholeYN);
				    	$('#tot_cost').text(totCost + " 원");
				    	$('#deposit_name').text(val.DEPOSIT_NAME);
				    	$('#status_name').text(val.STATUS_NAME);
				    	$('#account_info').text(val.BANK_ACCOUNT_INFO);
				    	$("#eqp_desc").html(val.EQP_DESC);
				    	
				    	if (val.PAY_TIME == null)
				    		{
						    	$('#depo_status').text("입금기한");
						    	$('#depo_status_time').html('<font color=red>' + val.CLOSE_TIME + '</font>');				    		
				    		}
				    	else
				    		{
						    	$('#depo_status').text("입금시간");
						    	$('#depo_status_time').html('<font color=blue>' + val.PAY_TIME + '</font>');					    		
				    		}
				    	
				    	_self.reserveStatusCd = val.STATUS_CD;

				    	if( _self.reserveStatusCd == '104_410' || _self.reserveStatusCd == '104_420' )
				    		_self.$reserveCancel.hide();
				    	
				    	$('.jdg-layout-contents').css("width","+=100");
				    	console.info("test",$('.jdg-layout-contents').width());
				    	$('.jdg-layout-contents').removeAttr("style");
				    	console.info("test1",$('.jdg-layout-contents').width());
			    	}
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				var _self = this;
				Bplat.log.debug( '[home] onCreate Method' );
				console.info('!!!!!!!!!!!!!!!! - ', p_param);
				// 초기화
				this.setElement();
				this.setEvent();
				var rsvId = _self.$rsvId;
				//var rsvId = p_param.RSV_ID; 
				_self.getMemberDetail(rsvId);
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
