defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				
				// element
				this.$fishList = $('#fishList');
				this.$pcScheduleList = $('#pcScheduleList');
				this.$TabMobScheduleList = $('#TabMobScheduleList');
				this.$postList = $('#postList');
				this.$cptnImg = $('#cptnImg');
				this.$cptnFishImg = $('.cptnFishImg');
				this.$shipImg = $('#shipImg');
				this.$shopImg = $('#shopImg');
			},
			'setEvent'		: function() {
				var _self = this;

			},
			//date 포맷 셋팅
			'setDateFormat': function() {
				var _self = this;
				
				//조행기
				var dates = _self.$fishList.find('.jdg-data-date');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(5,2) - 1;
					var day = $(dates[i]).text().trim().substr(8,2);
					
					$(dates[i]).text(new Date(year, month, day).toDateStr("mmdd","DAYS_SHORT"));
				}
				
				//출조 스케줄(pc)
				dates = _self.$pcScheduleList.find('.jdg-data-date > a');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(4,2) - 1;
					var day = $(dates[i]).text().trim().substr(6,2);
					var parseDate = new Date(year, month, day)
					
					if( parseDate.getDay() == 6){ //토요일이라면
						$(dates[i]).parents('li').addClass('jdg-sat');
					}else if( parseDate.getDay() == 0 ){//일요일이라면
						$(dates[i]).parents('li').addClass('jdg-sun');
					}
					
					$(dates[i]).text(parseDate.toDateStr("mmdd","DAYS"));
				}
				
				//출조 스케줄(태블릿,모바일)
				dates = _self.$TabMobScheduleList.find('.jdg-data-date');
				for(var i = 0 ; i < dates.size(); i ++){
					var year = $(dates[i]).text().trim().substr(0,4);
					var month = $(dates[i]).text().trim().substr(4,2) - 1;
					var day = $(dates[i]).text().trim().substr(6,2);
					
					$(dates[i]).text(new Date(year, month, day).toDateStr("mmdd","DAYS_SHORT"));
				}
				
				
			},
			//이미지 태그를 컨테이너 안에 최대한 비율에 맞게 리사이즈
			'setImgRatio' : function( p_param, _viewClass ) {
				var _self = this;
				
				jdg.util.setImgRatio(_self.$cptnImg, _self.$cptnImg.attr('imgWidth'), _self.$cptnImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shipImg, _self.$shipImg.attr('imgWidth'), _self.$shipImg.attr('imgHeight'));
				jdg.util.setImgRatio(_self.$shopImg, _self.$shopImg.attr('imgWidth'), _self.$shopImg.attr('imgHeight'));
				
				if(_self.$cptnFishImg.size() > 0){
					for(i = 0; i < _self.$cptnFishImg.size(); i++){
						jdg.util.setImgRatio(_self.$cptnFishImg[i], _self.$cptnFishImg[i].attr('imgWidth'), _self.$cptnFishImg[i].attr('imgHeight'));
					}
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();
				
				this.setDateFormat();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
