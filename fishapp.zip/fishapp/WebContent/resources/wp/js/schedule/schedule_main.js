defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				
				// url
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleDetailURL = $('#scheduleDetailURL').val();
				
				this._scheduleWeatherURL = $('#scheduleWeatherURL').val();
				this._scheduleWeatherDateURL = $('#scheduleWeatherDateURL').val();				
				
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._myReserveListURL = $('#myReserveListURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				
				this._watingReserveUrl = $("#watingReserveUrl").val();	
				
				this._sendReqAuthCodeURL = $("#sendReqAuthCodeURL").val();
				this._sendConfirmCodeURL = $("#sendConfirmCodeURL").val();
				
				this.postListURL 		= $('#postListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();

				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$postListTemplate 			= $('#postListTemplate .postListRow');
				this.$resvListTemplate 			= $('#resvListTemplate .resvListRow');			
				this.$postNoDataTemplate       = $('#postListTemplate .nodata');
				
				this.$shipId = $('#shipId').val();
				this.$weatherDiv = $('.weather_popup_wrap');
				this.$weatherInfoTbl = $('.weather_tb');
				
				// 달력스케쥴
				this.$calendarContainer = $('#tbodyCalendar');
				
				// 일자별 스케쥴
				this.$calendarListContainer = $('.schd_tb2');

				
				this.scCalendarTbl = $(".schd_tb");
				this.$template1 = $('#template1');
				this.$template2 = $('#template2 tr');			

				this.$reserveList = $('#listContainer');
				
				this.$calendarMoveBtn = $("span.prev,span.next");
				
				this.$calendarTdTemplate = $("#tbodyCalendar td:first").html();		
				
				this._schdInfo;
				
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				
				this.vrBankingYn = true;
				this.detailListForReserve = [];
				this.$checkWhole = $('#reserveForm .wholeYnCheck:checkbox');
				this.$nomemCheckWhole = $('#nomemReserveForm .wholeYnCheck:checkbox');
				
				this._feeWhole = 0;
				this._psgrCnt = 0;
				this._nickName = "nickname";
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				
				this.$reserv_status_popup_wrap = $('.reserv_status_popup_wrap');
				
				this.$telOnly = $("input#telOnly").val().replaceAll(" ","");
				
				this._schdId;
				
				this._agreeMsg = $('#agreeMsg').val();
				this._memberInfo = $("#memberInfo").val(); //회원여부 체크

				this.$imageURL		 			= $('#imageURL').val();
				//환불계좌 내역 보는 부분
				this.$refundInfo = $("#checkRefundInfo");
				//인증번호 발송
				this.$sendVerifySms = $("#sendVerifySms");
				//인증번호 확인 버튼
				this.$confirmVerifySms = $("#confirmVerifySms");
				//비회원 예약 URL
				this._reserveNoMemInsertURL = $("#reserveNoMemInsertURL").val();
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				//예약 대기
				$(document.body).on("click", ".wating_btn", function(){
				console.log(_self._watingReserveUrl);
					var schdid = $(this).attr("schdid");
					console.log(schdid);
					window.open(_self._watingReserveUrl+"?SCHD_ID="+schdid, "", "width=800,height=600");
				});
				
				//인증번호 발송.
				_self.$sendVerifySms.on("click", function(){
					jQuery.ajax({
				           type:"POST",
				           url: _self._sendReqAuthCodeURL,
				           dataType:"json",
				           data: { 'TEL' : $("#nomemReserveForm [data-key='RSV_TEL']").val()},
				           success : function(data) {
								
								if (data.msg == 'ok')
							    {
									alert("인증번호가 발송되었습니다.");
									$("#showAfterVerify").show();
									clearTimeout(_self._timerId);
									_timeLeft = 180;		
												
									_self._timerId = setInterval(function(){
										  if (_timeLeft <= 0) {			  
											  clearTimeout(_self._timerId);
											  $("#showAfterVerify span.time>em").text('만료');
									
										  } else {
											  _timeLeft--;
											  
											  if (_timeLeft == 5)
											  {
												  $("#sendVerifySms").val('인증번호 재발송');
												  $("#showAfterVerify").hide();
											  }
											 
											  
											  var minute = Math.floor(_timeLeft / 60);
											  var second = _timeLeft - minute * 60;
											  
											  $("#showAfterVerify span.time>em").text(minute + ' : ' + second);
										  }
									}, 1000);
							    }
								else
								{
									alert(data.msg);
									$("#showAfterVerify").hide();
								}
				           },
				           error : function(xhr, status, error) {
				                 alert("죄송합니다. 시스템오류로 인증번호가 발송되지 않았습니다.");
				                 $("#showAfterVerify").hide();
				           }
				     });
				});
				
				//인증번호 확인 버튼
				_self.$confirmVerifySms.on("click", function(){
						var authCode = $('#authCode').val();
						
						if (isNaN(authCode) || authCode < 100000 || authCode > 999999)
						{
							alert('인증번호는 6자리 숫자로 입력해주십시오.');
							return false;
						}
						
						if(_self._timeLeft < 1){
							alert('시간이 만료되었습니다. 재발송 처리해주세요.');
							$('#authCode').val("");
							return false;
						}
					
						_self.confirmAuthCode(authCode, $("#nomemReserveForm [data-key='RSV_TEL']").val());
						
				});	
	
				$("#agreement1_check").on("click",function(){
					if($("#agreement1_sub").css('display') === 'none' ) 
					{ 
						$('#agreement1_sub').show(); } else { $('#agreement1_sub').hide(); 
					}
				});
				
				$("#agreement2_check").on("click",function(){
					if($("#agreement2_sub").css('display') === 'none' ) 
					{ 
						$('#agreement2_sub').show(); } else { $('#agreement2_sub').hide(); 
					}
				});
				
				$("#agreement3_check").on("click",function(){
					if($("#agreement3_sub").css('display') === 'none' ) 
					{ 
						$('#agreement3_sub').show(); } else { $('#agreement3_sub').hide(); 
					}
				});
				
				
				//비회원 에약 > 환불계좌 보기
				_self.$refundInfo.on("click", function(){
					if($("#refund_info_div").css('display') === 'none' ) 
					{ 
						$('#refund_info_div').show(); } else { $('#refund_info_div').hide(); 
					}

				});
				
				//선택된 장르 옵션 상세 정보만 보여주기
				$("table[name=detail_subTable]").find("[data-type=GENRE]").on("change", function(){
					var value = $(this).val();
					$("#detail_div div").hide();
					$("#"+value).show();
				});
				
				//비회원 에약화면
				$('#nomemReserveForm select[data-key=MAN_CNT]').change(function() {
					
					var cnt = toNumber($(this).val());
					
					var fee = $(this).data('fee');
					
					_self.totalCost($("#nomemReserveForm"), cnt, fee);		            
				});		
				
				//회원 예약화면
				$('#reserveForm select[data-key=MAN_CNT]').change(function() {
					
					var cnt = toNumber($(this).val());
					
					var fee = $(this).data('fee');
					
					_self.totalCost($("#reserveForm"), cnt, fee);		            
				});							
				
				// 날씨보기 버튼 클릭
				_self.$calendarContainer.delegate('.weather_btn','click',function() {
					
					stopEvent(event);

		            $('.weather_popup_wrap').fadeIn(200);
		            $('.weather_popup_con').css({top: '60%'});
		            $('.weather_popup_con').animate({top: '50%'}, 200);
		            isScroll = false;
		            lockScroll();
		            
		            var wDate = $(this).attr('data-date');
		            
		            _self.getWeatherDetail(wDate);
				});				

				_self.$weatherDiv.delegate('.weather_close_btn','click',function() {
					stopEvent(event);
		            $('.weather_popup_wrap').fadeOut(200);
		            $('.weather_popup_con').animate({top: '60%'}, 200);
		            isScroll = true;
		            unlockScroll();
				});				
				
				
				
				//회원 독선
				_self.$checkWhole.on("change", function(){
					var $insertForm = $("#reserveForm");
					
					var $checkWhole = this;
					var $manCnt = $insertForm.find('select[data-key=MAN_CNT]');
					var $totCost = $insertForm.find('td[data-key=TOT_COST]');
					var fees =  $insertForm.find('select[data-key=MAN_CNT]').data('fee');
				
					if ($checkWhole.checked)
					{
						$manCnt.attr("disabled",true);
						$manCnt.val(_self._psgrCnt);
						if(_self._feeWhole =="0"){
							var holtotal = fees* _self._psgrCnt;
							if($("#siteType").val() == "4")
								$totCost.html("<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
						}else{
							if($("#siteType").val() == "4")
								$totCost.html("<span>"+stringFilter(_self._feeWhole, 'money') + "원</span>");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:" + stringFilter(_self._feeWhole, 'money') + "원)");
						}
					}
					else
					{
						$manCnt.attr("disabled",false);
						$manCnt.val(null);
						$totCost.text("0 원");
					}
				});			
				
				
				
				_self.$checkWhole.click(function(){
					
					var $insertForm = $("#reserveForm");
					
					var $checkWhole = this;
					var $manCnt = $insertForm.find('select[data-key=MAN_CNT]');
					var $totCost = $insertForm.find('td[data-key=TOT_COST]');
					var fees =  $insertForm.find('[data-key=MAN_CNT]').data("fee");
					
					if ($checkWhole.checked)
					{
						$manCnt.attr("disabled",true);
						$manCnt.val(_self._psgrCnt);
						if(_self._feeWhole =="0"){
							var holtotal = fees* _self._psgrCnt;
							$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
						}else{
							$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:" + stringFilter(_self._feeWhole, 'money') + "원)");
						}
					}
					else
					{
						$manCnt.attr("disabled",false);
						$manCnt.val(null);
						$totCost.text("0 원");
					}
				});			
				
				
				_self.$calendarMoveBtn.click(function(){
					
					var clsname = this.className;
					
			        var date = _self.selectDate;
			        
			        if (clsname == "prev")
			        {
			        	date.setMonth(date.getMonth() - 1);
			        }
			        else
			        {
			        	date.setMonth(date.getMonth() + 1);
			        }
			        
			        var month = date.getMonth() + 1;
			        
			        _self.yearMonth = date.getFullYear() +  ((month < 10)? "0" + month: "" + month);
			        
			        _self.renderScheduleList();
				});				
				
				_self.$calendarContainer.delegate('.poss_icon','click',function() {
					
		        	if (_self._agreeMsg)
		        	{
		        		if (confirm(_self._agreeMsg))
		        		{
		        			location.href = '../auth/agree_form';
		        		}
		        		return false;
		        	}
					
		        	if(_self._memberInfo == ""){
		        		//회원정보가 없는 경우 비회원 예약으로 진행.
		        		stopEvent(event);
						var schdId = $(this).data('schd_id');
						guestReserve(schdId);
						//_self.showNoMemberReserveForm(schdId);
					}else{
						stopEvent(event);
						var schdId = $(this).data('schd_id');
						_self.showReserveForm(schdId);
					}
				});
				
				_self.$calendarListContainer.delegate('.possible','click',function() {

		        	if (_self._agreeMsg)
		        	{
		        		if (confirm(_self._agreeMsg))
		        		{
		        			location.href = 'auth/agree_form';
		        		}	
		        		return false;
		        	}
		        	
		        	if(_self._memberInfo == ""){
		        		//회원정보가 없는 경우 비회원 예약으로 진행.
		        		stopEvent(event);
						var schdId = $(this).data('schd_id');
						guestReserve(schdId);
						//_self.showNoMemberReserveForm(schdId);
		        	}else{
						stopEvent(event);
						var schdId = $(this).data('schd_id');
						_self.showReserveForm(schdId);
					}
				});	
				
				$("#noMemButton").on("click", function(){
					 _self.renderScheduleList();
				});
				
				
				//예약하기에서 장르 변경시
				$("#reserveForm").on("change", "#genreSelect", function(){
					var $insertForm = $("#reserveForm");
					var pCnt = $(this).find("option:selected").attr("pcnt");
					var fee = $(this).find("option:selected").attr("pfee");
					var feehol = $(this).find("option:selected").attr("phol");
					var tool1 = $(this).find("option:selected").attr("ptool1");
					var tool2 = $(this).find("option:selected").attr("ptool2");
					var tool3 = $(this).find("option:selected").attr("ptool3");
					var genreId = $(this).val();
					
					for(var i = 0 ; i < _self.detailListForReserve.length ; i++){
						var items = _self.detailListForReserve[i];
						if(items.GENRE == genreId){
							_self._schdInfo = items;
						}
					}
					
					_self._feeWhole = feehol;
					_self._psgrCnt = pCnt;
										
					var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');
					
					select_manCnt.data('fee', fee);			
					
					select_manCnt.empty().append('<option value="">인원 선택</option>');
					
					for (var i=1; i <= pCnt; i++)
					{
						select_manCnt.append("<option value='"+ i + "'>" + i + " 명</option>");
					}

					var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
					select_eqpCnt.html("");
					
					for (var i=0; i <= pCnt; i++)
					{
						select_eqpCnt.append("<option value='"+ i + "'>" + i + " 대</option>");
					}
					
					$insertForm.find("span.tool1_tr_price").html("");
					$insertForm.find("span.tool2_tr_price").html("");
					$insertForm.find("span.tool3_tr_price").html("");
					$insertForm.find("[data-key='EQP1']").html("");
					$insertForm.find("[data-key='EQP2']").html("");
					$insertForm.find("[data-key='EQP3']").html("");
					$insertForm.find('tr.tool1_tr').css("display","none");	
					$insertForm.find('tr.tool2_tr').css("display","none");	
					$insertForm.find('tr.tool3_tr').css("display","none");	
					
					
					if(tool1 == '0'){
						$insertForm.find('tr.tool1_tr').css("display","");	
						$insertForm.find("span.tool1_tr_price").html("무상대여");
					
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool1 != null && tool1 != '' && tool1 != 'undefined'){
						$insertForm.find('tr.tool1_tr').css("display","");	
						$insertForm.find("span.tool1_tr_price").html("("+tool1+")원");
					
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
					
					
					if(tool2 == '0'){
						$insertForm.find('tr.tool2_tr').css("display","");
						$insertForm.find("span.tool2_tr_price").html("무상대여");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool2 != null && tool2 != '' && tool2 != 'undefined'){
						$insertForm.find('tr.tool2_tr').css("display","");
						$insertForm.find("span.tool2_tr_price").html("("+tool2+")원");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
					
					if(tool3 == '0'){
						$insertForm.find('tr.tool3_tr').css("display","");
						$insertForm.find("span.tool3_tr_price").html("무상대여");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool3 != null && tool3 != '' && tool3 != 'undefined'){
						$insertForm.find('tr.tool3_tr').css("display","");
						$insertForm.find("span.tool3_tr_price").html("("+tool3+")원");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
				
					
					if($insertForm.find("tr.tool1_tr").css("display") == 'none' && 
							$insertForm.find("tr.tool2_tr").css("display") == 'none' &&
							$insertForm.find("tr.tool3_tr").css("display") == 'none' ){
						$insertForm.find("tr.tools_div").css("display","none");
					}
					
					select_manCnt.attr("disabled",false);
					$insertForm.find('[data-key=TOT_COST]').text('0 원');
					
					$insertForm.find('#wholeYnCheck').attr('checked', false);
					$insertForm.find('[data-key=MAN_CNT]').css("display","");
					
					$insertForm.find('[data-key="DESCR_HTML"] div').css("display","none");	
					$insertForm.find('[pdiv="'+genreId+'"]').css("display","");			
					
					if($("#siteType").val() == "4"){
						$insertForm.find('#wholeYnCheck').prop('checked', true).trigger("change");
						$insertForm.find('[data-key=MAN_CNT]').css("display","none");
					}
																			
				});
				
				// 비회원 예약 버튼 클릭 핸들러
		        $('div.nomem_reserv_popup_wrap .reservation_btn').on('click', function() {

		        	stopEvent(event);
		        	
		        	var param = _self.insertCheckForNoMember();
		        	
		        	if (param == false)
	        		{
	        			return false;
	        		}		        	
		        	
		        	$('#loadingbar').show();		        	
		        	
		        	_self.insertReserveNoMem(param);
		        });

		        //회원 예약 버튼 클릭 핸들러
		        $('div.reserv_popup_wrap .reservation_btn').on('click', function() {

		        	stopEvent(event);
		        	
		        	var param = _self.insertCheck();
		        	
		        	if (param == false)
	        		{
	        			return false;
	        		}		        	
		        	
		            _self.showReservationConfirmPop();
		        });
				
				// 예약하시겠습니까? 확인 버튼 클릭 핸들러
		        $('.reserv_confirm_popup_wrap .reservation_confirm_btn').on('click', function() {
		        	
		        	stopEvent(event);
		        	
		        	$('.reserv_confirm_popup_wrap').hide(); 
		        	$('#loadingbar').show();		        	
		        	
		        	var param = _self.insertCheck();
		        	_self.insertReserve(param);
		        });	
		        
		        //상세보기
				$("td").delegate( ".info_title", "click", function() {					
					showPop('.detail_popup_wrap', '.popup_common_con');
					
					var schdId = $(this).data('schdId');
					
					_self.showScheduleDetail(schdId);					
				});
				
				$(document.body).on('click', 'a.title' ,function(){					
					showPop('.detail_popup_wrap', '.popup_common_con');					
					var schdId = $(this).data('schdId');	
					
					_self._schdId = schdId;
					_self.showScheduleDetail(schdId);					
				});
				

				$(".detail_popup_wrap").delegate( "#close_btn,.close_btn", "click", function() {	
					$('.scDetail').show();		
					$('.scUpdate').hide();
					hidePop('.detail_popup_wrap', '.popup_common_con');					
				});

				$(".detail_popup_wrap").delegate( "#reserve_btn", "click", function() {	
					
					$('.scDetail').show();		
					$('.scUpdate').hide();
					hidePop('.detail_popup_wrap', '.popup_common_con');	
					
					stopEvent(event);
					var schdId = _self._schdId;
					_self.showReserveForm(schdId);
					
				});
				
				$(".contents_wrap").delegate( ".clickEvent", "click", function() {
					
					var me = $(this);
					var bbsType = me.attr("bbsType");
					var postId =me.attr("postId");
					var titleKr;
					var titleEn;
					
					if (bbsType == null)
					{
						window.location.href = _self._memReserveDetailURL + "?ID=" + me.attr("rsvId"); 						
						return;
					}					
					if (bbsType == '108_110')
					{
						titleKr = "공지";
						titleEn = "Notice";
					}
					else
					{
						titleKr = "예약안내";
						titleEn = "Reservation";						
					}					
					
					_self.$popupTitleKr.text(titleKr);
					_self.$popupTitleEn.text(titleEn);					
					
					_self.$popSubject.text("");
					_self.$popupContent.html("");
					_self.$popupDate.text("");					
					
					showPop('.notice_pop_wrap', '.popup_common_con');					
					
					var defaultParam = {
							 'POST_ID' 		: postId
						};
					
					$.ajax({
						 url : _self.postDetailURL
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data )
						    {
					    		var dtl = data.detailPost;
					    		var content = dtl.CONTENT;
					    	
								_self.$popSubject.text(dtl.TITLE);
								
								_self.$popupDate.text(dtl.CREATED_AT);	
								
								var imglist = data.imageList;
								var imgtag;
								
								if (imglist != null && imglist.length > 0)
								{
									var leng = imglist.length;
									
									for (var i=0; i < leng; i++)
									{
										imgtag = "<p style='height:50px'></p><p><img src='" +  _self.$imageURL + imglist[i].IMG_ID + "/520'></p>";
										
										if (imglist[i].CONTENT != null)
										{
											imgtag = imglist[i].CONTENT ;
										}
										
									}		
									
									content += imgtag;
								}						    	
								
								_self.$popupContent.html(content);						    	
						    }
					});					

				});				

			},
			/** 갱신 */
			'renderScheduleList' : function() {
				
				var _self = this;
				var yearMonth = _self.yearMonth;
				
		        var tdtemp = _self.$calendarTdTemplate;		        
		        $("#tbodyCalendar td").html(tdtemp);			        
		        makeCalendar(yearMonth);
		        
		        _self.getWeatherList(yearMonth);	
		    },
			
			/**
		     * 예약확인 팝업 show
		     */
			'showReservationConfirmPop' : function() {
		        $('.reserv_confirm_popup_wrap').fadeIn(200);
		        $('.reserv_confirm_popup_con').css({top: '60%'});
		        $('.reserv_confirm_popup_con').animate({top: '50%'}, 200);
		       
		        //isScroll = false;
		        //lockScroll();
		    },

			'showScheduleDetail' : function (schdId)
			{
				var _self = this;
				
				var param = {SCHD_ID: schdId};
				
				$.ajax({
					url : _self._scheduleDetailURL
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function( data ) {
						$("#detail_div").html("");
						$("table[name=mainTable]").hide();
						$("table[name=detail_subTable]").hide();
						
						
						var type = data.detail.SCHD_TIME_TYPE;
						var index = 0;
						//일반낚시면서 선택된 장르가 없는 경우
						if(type == '0' && ( data.detail.CHOICE_GENRE == undefined || data.detail.CHOICE_GENRE == null)){ //아직 선택된 장르가 없는 경우.
							$("table[name=detail_subTable]").show();
							var item = data.detail;
							
							if(item.SITE_TYPE == '3'){
								$("table[name=detail_subTable]").find("[data-key='FEE_WHOLE_TEXT']").parent("td").html("");
							}
							
							if (item.DESCR)
								item.DESCR_HTML = item.DESCR.replaceAll("\n","<br>");
							else
								item.DESCR_HTML = "";
							
							if (item.NOTICE_TEXT)
								item.NOTICE_HTML = item.NOTICE_TEXT.replaceAll("\n","<br>");
							else
								item.NOTICE_HTML = "";
							
							if (item.STATUS_CD == "113_180")
							{
								item.STATUS_NAME = "만료"; //예약가능한 날짜가 지남
							}
							else if(item.STATUS_CD == "113_210")
							{
								item.STATUS_NAME = "출조 취소";
							}
							else
							{
								item.STATUS_NAME = "정상";
							}
							
							$("table[name=detail_subTable]").find("[data-key=STATUS_NAME]").text(item.STATUS_NAME);
							$("table[name=detail_subTable]").find("[data-key=SCHD_DATE]").text(item.SCHD_DATE_STR);
							$("table[name=detail_subTable]").find("[data-key=NOTICE_TEXT]").html(item.NOTICE_HTML);
							$("table[name=detail_subTable]").find("[data-key=DESCR_HTML]").html(item.DESCR_HTML);
						
							if(item.SUB_SHIPNM != '' && item.SUB_SHIPNM != undefined){
								var html = "";
								if(item.SUB_SHIPFILE != '' && item.SUB_SHIPFILE != undefined){
									html = "<img src='/cm/file/image/"+ item.SUB_SHIPFILE +"/50'>&nbsp;";
								}else{
									html +=  item.SUB_SHIPNM;
								}
								$("table[name=detail_subTable]").find("[data-key=SCHD_SHIP_INFO]").html(html);
								$("#show_ship_info").show();
							}else{
								$("#show_ship_info").hide();
							}
							$("table[name=detail_subTable]").find("[data-key=RSV_SUMMARY]").html('확정 '+ item.RESERVE_CONFIRM_CNT +'명, 미입금 ' + item.RESERVE_WAIT_CNT + '명,  취소 ' + item.CANCEL_CNT  +'명');
							
							//출조취소시 숨김.
							if(item.STATUS_CD != '113_110'){
								$("#reserve_btn").hide();
							}else{
								$("#reserve_btn").show();
							}
							
							var detailList = data.detail.detailList;
							var showYn = false;
							
							$("table[name=detail_subTable]").find("[data-type=GENRE]").html("");
							for(var i = 0 ;i < detailList.length ; i++){
								var detailItem = detailList[i];
								if(detailItem.GENRE_USEYN == 'N'){
									continue;
								}
							
								if(detailItem.OPEN_YN == 'N' && item.STATUS_CD == '113_110'){
									continue;
								}							
																
								$("table[name=detail_subTable]").find("[data-type=GENRE]").append("<option value='t"+i+"'>"+ detailItem.SUB_TITLE +"("+ detailItem.SCHD_TIME_STR +")</option>");
								index++;
								var $table = $("table[name='dupTable']").clone();
							
								$table.find("[data-key=SCHD_DATE]").text(stringFilter(detailItem.SCHD_DATE , 'date'));
								$table.find("[data-key=SCHD_DATE_TIME]").text(stringFilter(detailItem.SCHD_TIME , 'time'));
								
								$table.find("[data-key=SUB_TITLE]").text(detailItem.SUB_TITLE);
								$table.find("[data-key=PSGR_CNT_TEXT]").text(detailItem.PSGR_CNT+"명");
								
								$table.find("[data-key=FEE_WHOLE_TEXT]").text(stringFilter(detailItem.FEE_WHOLE, 'money'));
								$table.find("[data-key=FEE_TEXT]").text(stringFilter(detailItem.FEE, 'money') + ' 원');
								
								$table.find("[data-key=LOC_DESC]").text(detailItem.LOC_DESC);
								$table.find("[data-key=FISH_KIND]").text(detailItem.FISH_KIND).css("font-weight:700;");
								$table.find("[data-key=PREPARE]").text(detailItem.PREPARE);
								$table.find("[data-key=GENRE_USEYN]").text(detailItem.GENRE_USEYN_STR);
								
								if(item.SITE_TYPE == '3'){
									$table.find("[data-key='FEE_WHOLE_TEXT']").parent("td").html("-");
								}
								
								if (detailItem.DESCR)
									detailItem.DESCR_HTML = detailItem.DESCR.replaceAll("\n","<br>");
								
								var eqpDesc = "";
							
								if(detailItem.TOOL1 == '0'){
									eqpDesc += "낚시대 무상대여 <br/>";									
								}else if(detailItem.TOOL1 != null && detailItem.TOOL1 != ''){
									eqpDesc += "낚시대 ";
								}
								
								if(detailItem.TOOL2 == '0'){
									eqpDesc += "전동릴 무상대여 <br/>";									
								}else if(detailItem.TOOL2 != null && detailItem.TOOL2 != ''){
									eqpDesc += "전동릴 ";
								}
								
								if(detailItem.TOOL3 == '0'){
									eqpDesc += "낚시대+전동릴 무상대여 <br/>";									
								}else if(detailItem.TOOL3 != null && detailItem.TOOL3 != ''){
									eqpDesc += "낚시대+전동릴 ";
								}
																
								$table.find("[data-key=EQP_DESC]").html(eqpDesc);
								$table.find("[data-key=DESCR_HTML]").html(detailItem.DESCR_HTML);
								
								var html = "<div "; 
								if(showYn) {
									html += "style='display:none;' ";
								}else{
									showYn = true;
								}
								html += " id=t"+i+">* 장르옵션 <table class='reserve_tb scDetail'>"+ $table.html() + "</table></div>";
								
								$("#detail_div").append(html);
							}
							return;
						}
						
						
						$("table[name=mainTable]").show();
						
						if (data.detail.DESCR)
							data.detail.DESCR_HTML = data.detail.DESCR.replaceAll("\n","<br>");
						
						var comps = $('.detail_popup_wrap').find('[data-key]');
						
						
						var item = data.detail;
						item.RSV_SUMMARY = '확정 '+ item.RESERVE_CONFIRM_CNT +'명, 미입금 ' + item.RESERVE_WAIT_CNT + '명,  취소 ' + item.CANCEL_CNT  +'명';
						item.FEE_TEXT = stringFilter(item.FEE, 'money') + ' 원';
						item.FEE_WHOLE_TEXT = stringFilter(item.FEE_WHOLE, 'money');
						
						var toolDesc = "";
						
						if(item.GENRE_TOOL1 == "0"){
							toolDesc += "낚시대 무상대여 <br/>";
						}else if(item.GENRE_TOOL1 != null && item.GENRE_TOOL1 != ''){
							toolDesc += "낚시대  ";							
						}						
						
						if(item.GENRE_TOOL2 == "0"){
							toolDesc += "전동릴 무상대여 <br/>";
						}else if(item.GENRE_TOOL2 != null && item.GENRE_TOOL2 != ''){
							toolDesc += "전동릴  ";							
						}
						
						if(item.GENRE_TOOL3 == "0"){
							toolDesc += "낚시대+전동릴 무상대여 <br/>";
						}else if(item.GENRE_TOOL3 != null && item.GENRE_TOOL3 != ''){
							toolDesc += "낚시대+전동릴 ";
						}
						
						item.EQP_DESC = toolDesc;

						var availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
						if($("#waitReserveYn").val() == "Y"){
							availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT - item.WAIT_CNT;
						}
						
						if (availCnt <= 0 )
						{
							$("div#reserve_btn").hide();							
						}
						else
						{
							$("div#reserve_btn").show();
						}
						
						item.PSGR_CNT_TEXT = item.PSGR_CNT + " 명";
					
						if (item.STATUS_CD == "113_180")
						{
							item.STATUS_NAME = "만료"; //예약가능한 날짜가 지남
						}
						else if (availCnt <= 0 )
						{
							item.STATUS_NAME = "마감"; //예약인원이 마감
						}
						
						//예약 상태가 정상이 아닌경우는 예약 못함.
						if(item.STATUS_NAME != '정상'){
							$("#reserve_btn").hide();
						}else{
							$("#reserve_btn").show();
						}

						item.SCHD_DATE = stringFilter(item.SCHD_DATE , 'date');
						item.SCHD_TIME = stringFilter(item.SCHD_TIME , 'time');
						
						item.SCHD_DATE_TIME = item.SCHD_DATE + ' ' +  item.SCHD_TIME;
						
						for (var i=0; i < comps.length; i++)
						{
							var comp = $(comps[i]);	
							var value = data.detail[comp.data('key')];
							
							if (value != undefined)
							{
								if (comp.is('input') || comp.is('select') || comp.is('textarea'))
								{
									comp.val(value);
								}
								else
								{
									comp.html(value);
								}
							}
							else
							{
								comp.html("");
							}
						}
						
						if(item.SITE_TYPE == '3'){
							$('.detail_popup_wrap').find("[data-key='FEE_WHOLE_TEXT']").parent("td").html("-");
						}
					}
				});				
				
			},		
			'showNoMemberReserveForm': function(schdId){
				//비회원 예약
				var _self = this;
				var insertParam = {SCHD_ID: schdId};
				
				$.ajax({
					url : _self._scheduleDetailURL
					,type : 'POST'
					,data : insertParam
					,dataType : 'json'
					,success : function( data ) {
						
						var $insertForm = $("#nomemReserveForm");
						
						var item = data.detail;
						
						//출조일시
						$insertForm.find("[data-key='SCHD_DATE_STR']").html(item.SCHD_DATE_STR);
						
						var siteType = item.SITE_TYPE;		
						
						$insertForm.find("span.tool1_tr_price").html("");
						$insertForm.find("span.tool2_tr_price").html("");
						$insertForm.find("span.tool3_tr_price").html("");
						$insertForm.find("[data-key='EQP1']").html("");
						$insertForm.find("[data-key='EQP2']").html("");
						$insertForm.find("[data-key='EQP3']").html("");
						$insertForm.find('div.tool1_tr').css("display","none");	
						$insertForm.find('div.tool2_tr').css("display","none");	
						$insertForm.find('div.tool3_tr').css("display","none");	
						
						var availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
						if($("#waitReserveYn").val() == "Y"){
							availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT - item.WAIT_CNT;
						}
						
						var choiceGenre = (item.CHOICE_GENRE == undefined || item.CHOICE_GENRE == '') ?  '' : item.CHOICE_GENRE;
						
						var siteCheck = "N";
						//예약전 장르 선택 시
						var detailList= data.detail.detailList;
						if(choiceGenre == '' && detailList != null && detailList.length > 0){
							var html = "";
							var descrHtml = "";
							if(siteType == '3'){
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE;
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										html +=  details.SUB_TITLE + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}									
								}
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}else{
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE;
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										var time = details.SCHD_TIME_STR.substr(0,2);
										var prefix = "오후 ";
										if(time < 12){
											prefix = "오전 ";
										}
										html +=  details.SUB_TITLE+ "(" + prefix + details.SCHD_TIME_STR+ " ) " + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml += "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}			
								}
								
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}
							availCnt = 0;
							item.PSGR_CNT = 0;
							item.FEE =0;
							item.FEE_WHOLE = 0;
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').removeAttr("pchoice");							
							$insertForm.find("#showGenre").show();
						}else if(siteType == '3' && detailList != null && detailList.length > 0){
							var html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
							var descrHtml = "";
							for (var i = 0; i < detailList.length; i++) {
								var details = detailList[i];
								if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
									_self.detailListForReserve.push(details);
									html += "<option value='" + details.GENRE;
									html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ availCnt +" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
									html +=  details.SUB_TITLE + "</option>";
									if(details.DESCR != null && details.DESCR != '')
										descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
								}									
							}
							$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", data.detail.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
						}else{
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').text(data.detail.SUB_TITLE +"( 시간 : "+ data.detail.SCHD_TIME_STR + " ) ");
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", data.detail.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
							$insertForm.find('[data-key=DESCR_HTML]').html(item.DESCR_HTML);

							$insertForm.find("span.tool1_tr_price").html("");
							$insertForm.find("span.tool2_tr_price").html("");
							$insertForm.find("span.tool3_tr_price").html("");
							$insertForm.find("[data-key='EQP1']").html("");
							$insertForm.find("[data-key='EQP2']").html("");
							$insertForm.find("[data-key='EQP3']").html("");
							$insertForm.find('div.tool1_tr').css("display","none");	
							$insertForm.find('div.tool2_tr').css("display","none");	
							$insertForm.find('div.tool3_tr').css("display","none");	
							
							var tool1 = data.detail.GENRE_TOOL1;
							var tool2 = data.detail.GENRE_TOOL2;
							var tool3 = data.detail.GENRE_TOOL3;
							
							if(tool1 == '0'){
								$insertForm.find('div.tool1_tr').css("display","");
								$insertForm.find("span.tool1_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool1 != null && tool1 != ''){
								$insertForm.find('div.tool1_tr').css("display","");	
								$insertForm.find("span.tool1_tr_price").html("("+tool1+")원");
							
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool2 == '0'){
								$insertForm.find('div.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool2 != null && tool2 != ''){
								$insertForm.find('div.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("("+tool2+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool3 == '0'){
								$insertForm.find('div.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool3 != null && tool3 != ''){
								$insertForm.find('div.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("("+tool3+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
						}
												
						_self._feeWhole = data.detail.FEE_WHOLE;
						_self._psgrCnt = data.detail.PSGR_CNT;
						_self._nickName = data.nickName;
												
						if_showhide(siteType != '3' && availCnt == item.PSGR_CNT, $insertForm.find('.wholeYnCheck'));
						
						_self._schdInfo = item;
													
						var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');
						
						select_manCnt.data('fee', item.FEE);
						
						select_manCnt.empty().append('<option value="">인원 선택</option>');
						
						for (var i=1; i <= availCnt; i++)
						{
							select_manCnt.append("<option value='"+ i + "'>" + i + " 명</option>");
						}

						var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
						select_eqpCnt.html("");
						
						for (var i=0; i <= availCnt; i++)
						{
							select_eqpCnt.append("<option value='"+ i + "'>" + i + " 대</option>");
						}
																				
						var bankAccnHolder;
						
						_self.vrBankingYn = (item.VR_BANKING_YN == "Y");
						
						if (_self.vrBankingYn)
						{
							$insertForm.find('[data-key=BANK_CD]').val("");	
							$insertForm.find('[data-key=BANK_CD]').show();	
							bankAccnHolder = "가상계좌 입금은행 ";						
						}
						else
						{
							bankAccnHolder =  item.BANK_NM + " " + item.BANK_ACCN + " " + item.BANK_HOLDER;
							$insertForm.find('[data-key=BANK_CD]').hide();	
						}
						
						$insertForm.find('[data-key=BANK_ACCN_HOLDER]').text(bankAccnHolder);						
						
						
						$insertForm.find('[data-key=TOT_COST]').text('0 원');							
						
						
						//장르가 1개이면 첫번쨰것을 자동선택
						if($("#genreSelect option").size() == 2){
							$("#genreSelect option:eq(1)").attr("selected","selected");
							$("#genreSelect").trigger("change");
						}
						
						$insertForm.find('[data-key=NOTICE_HTML]').html(item.NOTICE_HTML);
						
						if(siteCheck == "Y" && $("#siteType").val() == "4"){
							$insertForm.find('#wholeYnCheck').prop('checked', true).trigger("change");
							$insertForm.find('[data-key=MAN_CNT]').css("display","none");
						}					
						
						showNoMemberReservationPop();		
										
					}
				});	
			},
			'showReserveForm' : function (schdId)
			{
				var _self = this;
				
				if (_self.$telOnly != "")
				{
					alert(_self.$telOnly);
					return;
				}
				
				
				if (isLogin() == false)
				{
					showLoginBox();
					return;
				}
				
				var insertParam = {SCHD_ID: schdId};
				
				$.ajax({
					url : _self._scheduleDetailURL
					,type : 'POST'
					,data : insertParam
					,dataType : 'json'
					,success : function( data ) {
						
						var $insertForm = $("#reserveForm");
						
						var item = data.detail;
						
						if (data.bizSeatYn == 'Y')
						{
							$('#trSeat').show();
						}
						else
						{
							$('#trSeat').hide();
						}
						
						var siteType = item.SITE_TYPE;		
						
						$insertForm.find("span.tool1_tr_price").html("");
						$insertForm.find("span.tool2_tr_price").html("");
						$insertForm.find("span.tool3_tr_price").html("");
						$insertForm.find("[data-key='EQP1']").html("");
						$insertForm.find("[data-key='EQP2']").html("");
						$insertForm.find("[data-key='EQP3']").html("");
						$insertForm.find('tr.tool1_tr').css("display","none");	
						$insertForm.find('tr.tool2_tr').css("display","none");	
						$insertForm.find('tr.tool3_tr').css("display","none");	
						
						var availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
						if($("#waitReserveYn").val() == "Y"){
							availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT - item.WAIT_CNT;
						}
						
						var choiceGenre = (item.CHOICE_GENRE == undefined || item.CHOICE_GENRE == '') ?  '' : item.CHOICE_GENRE;
						
						var siteCheck = "N";
						//예약전 장르 선택 시
						var detailList= data.detail.detailList;
						if(choiceGenre == '' && detailList != null && detailList.length > 0){
							var html = "";
							var descrHtml = "";
							if(siteType == '3'){
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE;
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										html +=  details.SUB_TITLE + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}									
								}
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}else{
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE;
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										var time = details.SCHD_TIME_STR.substr(0,2);
										var prefix = "오후 ";
										if(time < 12){
											prefix = "오전 ";
										}
										html +=  details.SUB_TITLE+ "(" + prefix + details.SCHD_TIME_STR+ " ) " + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml += "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}			
								}
								
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}
							availCnt = 0;
							item.PSGR_CNT = 0;
							item.FEE =0;
							item.FEE_WHOLE = 0;
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').removeAttr("pchoice");							
							$insertForm.find("#showGenre").show();
						}else if(siteType == '3' && detailList != null && detailList.length > 0){
							var html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
							var descrHtml = "";
							for (var i = 0; i < detailList.length; i++) {
								var details = detailList[i];
								if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
									_self.detailListForReserve.push(details);
									html += "<option value='" + details.GENRE;
									html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ availCnt +" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
									html +=  details.SUB_TITLE + "</option>";
									if(details.DESCR != null && details.DESCR != '')
										descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
								}									
							}
							$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", data.detail.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
						}else{
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').text(data.detail.SUB_TITLE +"( 시간 : "+ data.detail.SCHD_TIME_STR + " ) ");
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", data.detail.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
							$insertForm.find('[data-key=DESCR_HTML]').html(item.DESCR_HTML);

							$insertForm.find("span.tool1_tr_price").html("");
							$insertForm.find("span.tool2_tr_price").html("");
							$insertForm.find("span.tool3_tr_price").html("");
							$insertForm.find("[data-key='EQP1']").html("");
							$insertForm.find("[data-key='EQP2']").html("");
							$insertForm.find("[data-key='EQP3']").html("");
							$insertForm.find('tr.tool1_tr').css("display","none");	
							$insertForm.find('tr.tool2_tr').css("display","none");	
							$insertForm.find('tr.tool3_tr').css("display","none");	
							
							var tool1 = data.detail.GENRE_TOOL1;
							var tool2 = data.detail.GENRE_TOOL2;
							var tool3 = data.detail.GENRE_TOOL3;
							
							if(tool1 == '0'){
								$insertForm.find('tr.tool1_tr').css("display","");
								$insertForm.find("span.tool1_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool1 != null && tool1 != ''){
								$insertForm.find('tr.tool1_tr').css("display","");	
								$insertForm.find("span.tool1_tr_price").html("("+tool1+")원");
							
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool2 == '0'){
								$insertForm.find('tr.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool2 != null && tool2 != ''){
								$insertForm.find('tr.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("("+tool2+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool3 == '0'){
								$insertForm.find('tr.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool3 != null && tool3 != ''){
								$insertForm.find('tr.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("("+tool3+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
						}
												
						_self._feeWhole = data.detail.FEE_WHOLE;
						_self._psgrCnt = data.detail.PSGR_CNT;
						_self._nickName = data.nickName;
												
						if_showhide(siteType != '3' && availCnt == item.PSGR_CNT, $insertForm.find('.wholeYnCheck'));
						
						_self._schdInfo = item;
													
						var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');
						
						select_manCnt.data('fee', item.FEE);
						
						select_manCnt.empty().append('<option value="">인원 선택</option>');
						
						for (var i=1; i <= availCnt; i++)
						{
							select_manCnt.append("<option value='"+ i + "'>" + i + " 명</option>");
						}

						var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
						select_eqpCnt.html("");
						
						for (var i=0; i <= availCnt; i++)
						{
							select_eqpCnt.append("<option value='"+ i + "'>" + i + " 대</option>");
						}
																				
						var bankAccnHolder;
						
						_self.vrBankingYn = (item.VR_BANKING_YN == "Y");
						
						if (_self.vrBankingYn)
						{
							$insertForm.find('[data-key=BANK_CD]').val("");	
							$insertForm.find('[data-key=BANK_CD]').show();	
							bankAccnHolder = "* 입급할 은행선택(가상계좌입금)";						
						}
						else
						{
							bankAccnHolder =  item.BANK_NM + " " + item.BANK_ACCN + " " + item.BANK_HOLDER;
							$insertForm.find('[data-key=BANK_CD]').hide();	
						}
						
						$insertForm.find('[data-key=BANK_ACCN_HOLDER]').text(bankAccnHolder);						
						
						var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
						var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val().trim();
						var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
						var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
						
						$insertForm.find('[data-key=TOT_COST]').text('0 원');							
						$insertForm.find('[data-key=DEPOSIT_NAME]').val(rsvName);
						
						//장르가 1개이면 첫번쨰것을 자동선택
						if($("#genreSelect option").size() == 2){
							$("#genreSelect option:eq(1)").attr("selected","selected");
							$("#genreSelect").trigger("change");
						}
						
						$insertForm.find('[data-key=NOTICE_HTML]').html(item.NOTICE_HTML);
						
						if(siteCheck == "Y" && $("#siteType").val() == "4"){
							$insertForm.find('#wholeYnCheck').prop('checked', true).trigger("change");
							$insertForm.find('[data-key=MAN_CNT]').css("display","none");
						}					
						
						showReservationPop();						
					}
				});			
			},			
			
			'getWeatherDetail' : function(wDate) {
					
					var _self = this;
					
					var insertParam = {
							'WEATHER_DATE' :  wDate
						   ,'SHIP_ID'  :  _self.$shipId
					};
					
					$.ajax({
						url : _self._scheduleWeatherURL
						,type : 'POST'
						,data : insertParam
						,dataType : 'json'
						,success : function( data ) {
							if(data.hasOwnProperty('marineWeather')){
								
								var wDate = data.marineWeather.WEATHER_DATE;
								var $td = _self.$calendarContainer.find('td#' + wDate);								
								
								var ymd = $td.data('date') + ' ' + $td.data('day') + '요일';
								var mull = $td.data('mull');
								
								_self.$weatherDiv.find("[data-key='ymd']").text(ymd);
								_self.$weatherDiv.find("[data-key='mull']").text(mull);
								
								var weatherCond = data.marineWeather.WEATHER_COND;
								var windDirect = data.marineWeather.WIND_DIRECT;
								var waveHeight = data.marineWeather.WAVE_HEIGHT;
								var windSpeed = data.marineWeather.WIND_SPEED;
								
								if (windDirect == " ")
								{
									windDirect = ",";
									windSpeed = ",";
								}

								var arrWeatherCond = weatherCond.split(",");
								var arrWindDirect = windDirect.split(",");
								var arrWaveHeight =  waveHeight.split(",");
								var arrWindSpeed = windSpeed.split(",");

								var tds = _self.$weatherInfoTbl.find('td');
								
								var img0 = arrWeatherCond[0] == '' ? '' : 'https://www.kma.go.kr/' + arrWeatherCond[0];
								var img1 = 'https://www.kma.go.kr/' + arrWeatherCond[1];
								
								tds.eq(0).find('img').attr('src', img0);
								tds.eq(1).find('img').attr('src', img1);
								
								if_showhide(img0 != "", tds.eq(0).find('img'));
								
								tds.eq(2).text(arrWaveHeight[0]);
								tds.eq(3).text(arrWaveHeight[1]);

								tds.eq(4).text(arrWindDirect[0]);
								tds.eq(5).text(arrWindDirect[1]);
								
								var winsp0 = arrWindSpeed[0] == '' ? '' : arrWindSpeed[0] + " m/s";
								var winsp1 = arrWindSpeed[1] == '' ? '' : arrWindSpeed[1] + " m/s";
								
								tds.eq(6).text(winsp0);
								tds.eq(7).text(winsp1);
							}

					}});				
			},

			
			'getWeatherList': function (yearMonth) {
				
				var _self = this;
				
				$.ajax({
					url : _self._scheduleWeatherDateURL
					,type : 'POST'
					,data : null
					,dataType : 'json'
					,success : function( data ) {
						if(data.hasOwnProperty('weatherDateList')){
							var weatherDateList = data.weatherDateList;
							var wDate;
							
							var td;
							var weatherBtn ='<p class="weather"><a><img class="weather_btn" src="https://img.fishapp.co.kr/legacy/wp/weather_btn.png" alt="날씨" data-date="$wDate"/></a></p>';
								
							for(var j =0; j <weatherDateList.length; j++){								
								
								wDate = weatherDateList[j].WEATHER_DATE;
								td = _self.scCalendarTbl.find("#" + wDate +">div");								
								
								if(td){									
									
									td.append(weatherBtn.replace("$wDate", wDate));
								}
							}							
						}						
						_self.getScheduleList({'SCHD_MONTH' : yearMonth });
					}
				});				
			},
			
			
			// 예약금액 자동 셋팅
			'totalCost' : function(ele , man, fee) {
				var _self = this;
				var $insertForm = ele;

				var sum = man * fee;
				if( !sum ) sum = 0;
				$insertForm.find('[data-key=TOT_COST]').text( stringFilter(sum, 'money') + ' 원');

			},
			
				//데이터 체크 비회원
			'insertCheckForNoMember': function()
			{
				var _self = this;
				
				var schdInfo = _self._schdInfo;
				
				var $insertForm = $("#nomemReserveForm");
				// validation
				var today = jdg.util.today().replaceAll('-','');
				
				 var totCost = $insertForm.find('[data-key=TOT_COST]').text();
				 totCost = totCost.replaceAll( ',', '' );
				 totCost = totCost.replaceAll( '원', '' );
				 
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();
				var wholeYnCheck = $insertForm.find('#wholeYnCheck').is(':checked') ? "Y" : "N";
				
				var genreId = $insertForm.find("[data-key=GENRE_INFO]").attr("pchoice");
				if(genreId == '' || genreId == undefined){
					genreId = $insertForm.find("#genreSelect option:selected").val();
				}
								
				if(genreId == ""){
					alert("장르를 선택해주세요.");
					return false;
				}
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').val();
				if(rsvName == ""){
					alert("예약자명을 입력해주세요.");
					return false;
				}
					
				
				if (manCnt == "")
				{
					alert("예약인원을 선택하십시오.");
					return false;
				}
				
				var eqpCnt = $insertForm.find('[data-key=EQP_CNT]').val();
				
				if (eqpCnt == "")
				{
					alert("장비대여 대수를 선택하십시오.");
					return false;
				}				
				
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var noMemberReqAuthConfirm = $("#noMemberReqAuthConfirm").val();
				if(rsvTel == ''){
					alert("전화번호를 입력해주세요");
					return false;		
				}
				
				if(noMemberReqAuthConfirm == 'F'){
					alert("전화번호 인증을 해주세요.");
					return false;
				}
				
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
				if(rsvDepositName == ''){
					alert("입금자 명을 입력해주세요");
					return false;
				}
				
				var $bankCd = $insertForm.find('[data-key=BANK_CD]');
				var bankCd = $bankCd.val();
				var vrBankingYn;
				
				
				if (_self.vrBankingYn)
				{
						if( bankCd == '') {
						alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
						return false;
					}
					
					vrBankingYn = "Y";
				}
				else
				{
					vrBankingYn = "N";
					bankCd = null;
				}
				
				var refundBank = $insertForm.find('[data-key=REFUND_BANK] option:selected').val();
				var refundAccountNum = $insertForm.find('[data-key=REFUND_ACCOUNT_NUM]').val();
				var refundrsvName = $insertForm.find('[data-key=REFUND_RSV_NAME]').val();
				
				alert(refundBank);
				
				if(refundBank != '' || refundAccountNum != '' || refundrsvName != ''){
					if(refundBank == '' || refundAccountNum == '' || refundrsvName == ''){
						alert("환불 정보를 다 작성해주세요.");
						return false;
					}
				}
				
				if($("#all_agreement").is(":checked") == false){
					alert("규정 및 약관동의에 체크해주세요.");
					return false;
				}
				
				var insertParam = {
						  'SCHD_ID' : schdInfo.SCHD_ID
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : ""
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'DISP_CD' : '2' //예약자명으로보이기 위해
						, 'DISP_TXT': rsvName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'EQP_CNT' : $insertForm.find('[data-key=EQP_CNT] option:selected').val()
						, 'SITE_CD' : 'L'
						, 'BANK_CD' : bankCd
					    , 'VR_BANKING_YN' : vrBankingYn
					    , 'WHOLE_YN' : wholeYnCheck
					    , 'GENRE_ID' : genreId
					    , 'TOT_COST' : totCost
					    , 'AGREEMENT' : 'Y'
					    , 'REFUND_BANK' : $insertForm.find("[data-key=REFUND_BANK] option:selected").val()
					    , 'REFUND_ACCOUNT_NUM' : $insertForm.find("[data-key=REFUND_ACCOUNT_NUM]").val()
					     , 'REFUND_RSV_NAME' : $insertForm.find("[data-key=REFUND_RSV_NAME]").val()
					    ,'EQP1' :  $insertForm.find('[data-key=EQP1] option:selected').val()
					    ,'EQP2' :  $insertForm.find('[data-key=EQP2] option:selected').val()
					    ,'EQP3' :  $insertForm.find('[data-key=EQP3] option:selected').val()
					};
				
				return insertParam;
			},
			
			//데이터 체크
			'insertCheck': function()
			{
				var _self = this;
				
				var schdInfo = _self._schdInfo;
				
				var $insertForm = $("#reserveForm");
				// validation
				var today = jdg.util.today().replaceAll('-','');
				
				 var totCost = $insertForm.find('[data-key=TOT_COST]').text();
				 totCost = totCost.replaceAll( ',', '' );
				 totCost = totCost.replaceAll( '원', '' );
				 
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();
				var wholeYnCheck = $insertForm.find('#wholeYnCheck').is(':checked') ? "Y" : "N";
				
				var genreId = $insertForm.find("[data-key=GENRE_INFO]").attr("pchoice");
				if(genreId == '' || genreId == undefined){
					genreId = $insertForm.find("#genreSelect option:selected").val();
				}
								
				if(genreId == ""){
					alert("장르를 선택해주세요.");
					return false;
				}
				
				if (manCnt == "")
				{
					alert("예약인원을 선택하십시오.");
					return false;
				}
				
				var eqpCnt = $insertForm.find('[data-key=EQP_CNT]').val();
				
				if (eqpCnt == "")
				{
					alert("장비대여 대수를 선택하십시오.");
					return false;
				}				
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
				var dispCd = $insertForm.find('[data-key=DISP_CD]').val();
				var seatTxt = $insertForm.find('[data-key=SEAT_TXT]').val();
				
				var nickName = _self._nickName;
				
				var dispTxt = "예약자표시";
				
				if (dispCd == '1') {dispTxt = rsvDepositName;  }
				else if (dispCd == '2') {dispTxt = rsvName;  }
				else if (dispCd == '3') {dispTxt = nickName;  }
				
				
				var $bankCd = $insertForm.find('[data-key=BANK_CD]');
				var bankCd = $bankCd.val();
				var vrBankingYn;
				
				if (rsvTel == "")
				{
					alert("전화번호를 입력해주십시오.(비정상적인 전화번호를 넣으면 예약이 되지 않습니다.)");
					return false;
				}
				
				if (_self.vrBankingYn)
				{
						if( bankCd == '') {
						alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
						return false;
					}
					
					vrBankingYn = "Y";
				}
				else
				{
					vrBankingYn = "N";
					bankCd = null;
				}
				
				if( rsvName == '' && rsvTel == '' &&  rsvEmail == '' ) {
					alert('예약자 정보를 입력해 주세요');
					return false;
				}
				
				var insertParam = {
						  'SCHD_ID' : schdInfo.SCHD_ID
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : rsvEmail
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'EQP_CNT' : $insertForm.find('[data-key=EQP_CNT] option:selected').val()
						, 'SITE_CD' : 'L'
						, 'BANK_CD' : bankCd
					    , 'VR_BANKING_YN' : vrBankingYn
					    , 'WHOLE_YN' : wholeYnCheck
					    , 'DISP_CD' : dispCd
					    , 'DISP_TXT' : dispTxt
					    , 'SEAT_TXT' : seatTxt
					    , 'GENRE_ID' : genreId
					    , 'TOT_COST' : totCost
					    ,'EQP1' :  $insertForm.find('[data-key=EQP1] option:selected').val()
					    ,'EQP2' :  $insertForm.find('[data-key=EQP2] option:selected').val()
					    ,'EQP3' :  $insertForm.find('[data-key=EQP3] option:selected').val()
					};
				
				return insertParam;
			},
			
			
			// 예약등록
			'insertReserve' : function(insertParam) {
				
				var _self = this;
				
				$.ajax({
					 url : _self._reserveInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
						// 로더 제거
				    	$('#loadingbar').hide();
			            hideReservationConfirmPop();
			            hideReservationPop();				    	
				    	
				    	if (data.error == undefined)
				    	{
					    	var rsv_Id = data.rsv_Id;
					    	if( rsv_Id != null &&  rsv_Id != undefined ) {
			
					            showPop('.reserv_com_pop');
					            _self.renderScheduleList();
					    	}
				    	}
				    	else
				    	{
				    		if (data.error.userMessage)
				    		{
				    			alert(data.error.userMessage);
				    		}				    	
				    	}
				    	
				    	isScroll = true;
				    	unlockScroll();
				    }
				});
			},	
			
			// 비회원 예약등록
			'insertReserveNoMem' : function(insertParam) {
				var _self = this;
				
				$.ajax({
					 url : _self._reserveNoMemInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    
				    	
						// 로더 제거
				    	$('#loadingbar').hide();
			            hideReservationPop();				    	
				    	
				    	if (data.error == undefined)
				    	{
					    	var rsv_Id = data.rsv_Id;
					    	if( rsv_Id != null &&  rsv_Id != undefined ) {
			
					            showPop('.reserv_com_pop');
					            _self.renderScheduleList();
					    	}
				    	}
				    	else
				    	{
				    		if (data.error.userMessage)
				    		{
				    			alert(data.error.userMessage);
				    		}				    	
				    	}
				    	
				    	isScroll = true;
				    	unlockScroll();
				    }
				});
			},	
			
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var tmpDay = new Date();
			 	var year = tmpDay.getFullYear(); 
			 	var month =  tmpDay.getMonth() + 1 ;
			 	month = (month > 10  ) ? month : "0"+month;
			 	var date = tmpDay.getDate();
				today = year+""+month+""+date;
				
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var scheduleList = data.scheduleList;
			    		_self.currentScheduleList = scheduleList;	
			    			var watingList = data.watingList;
			    			var watingShowYn = data.WATING_SHOW_YN; //마감시 예약대기 버튼 보임여부
			    			
			    		var reserveMap1 = {};	   
			    		var reserveMap2 = {};
			    		var mapData1;
			    		var mapData2;
			    		var rsvStatus;
			    		
			    		var str1;
			    		var str2;
			    		var seatText;
			    		var isBlink = false;	
			    		
			    		$.each( data.reserveList, function( idx, data ) {
			    			
			    			mapData1  = reserveMap1[data.SCHD_ID];
			    			mapData2 = reserveMap2[data.SCHD_ID];
			    			rsvStatus = data.STATUS_CD;
			    			
			    			if (mapData1 == null)
			    			{
			    				mapData1 = "";
			    				mapData2 = "";
			    			}	
			    			
			    			seatText = (data.SEAT_TXT == null) ? "" : " 자리: " + data.SEAT_TXT;
			    					    	
			    			str1 = '<li>'+ data.RSV_INFO.replace('(', ' 님(');
			    		
			    			if($("#siteType").val() != "4"){
			    				if(data.DISP_TXT == undefined || data.DISP_TXT == "" || data.DISP_TXT == "undefined"){
			    					data.DISP_TXT = data.RSV_NAME;
			    				}
			    				str2 = '<p class="p2" style="display:block" rsv_id="' + data.RSV_ID +'" >' + data.DISP_TXT + " 님(" + data.MAN_CNT + "명" +  seatText +")" ;
			    			}else{
			    				if(data.DISP_TXT == undefined || data.DISP_TXT == "" || data.DISP_TXT == "undefined"){
			    					data.DISP_TXT = data.RSV_NAME;
			    				}
			    				str2 = '<p class="p2" style="display:block" rsv_id="' + data.RSV_ID +'" >' + data.DISP_TXT + " 님" ;
			    			}
			    			
			    			if (rsvStatus == "104_300")
			    				{
			    					str1 += ' <span class="finish">입금완료</span></li>';
			    					str2 += ' <span class="fin">입금완료</span>';
			    				
			    			}
			    			else if(rsvStatus == "104_340")
		    				{
		    					str1 += ' <span class="finish">예약완료</span></li>';
		    					str2 += ' <span class="fin">예약완료</span>';
		    				
		    				}			    			
			    			else if (rsvStatus == "104_310")
			    			{
			    					str1 += ' <span class="yet" style="color:red;font-weight:700">미입금</span></li>';
			    					str2 += ' <span class="yet" style="color:red;font-weight:700">미입금</span>';
			    			}
			    			else if (rsvStatus == "104_320")
			    			{
			    					str1 += ' <span class="finish">부분입금</span></li>';
			    					str2 += ' <span class="finish">부분입금</span>';
			    			}
			    			else
			    			{
			    				str1 += ' <span class="'+ rsvStatus + '">**</span></li>';
			    				str2 += ' <span class="'+ rsvStatus + '">**</span>';
			    			}
			    			
			    			//비회원 예약인 경우
			    			if(data.JOIN_TYPE == 'GUEST'){
			    				//비회원인경우 취소가능
			    				if(data.LEFT_DAY > 1){

			    					str1 += "<a href='javascript:cancle(\""+rsvStatus+"\",\""+ data.RSV_ID+"\")' style='font-size:9px;margin:3px;' class='cancle_guest'>취소하기</a>";
			    					str2 += "<a href='javascript:cancle(\""+rsvStatus+"\",\""+ data.RSV_ID+"\")'  class='cancle_guest'>취소하기</a>";

			    				}else{
			    					//하루전날인 경우
			    					if(rsvStatus == "104_310"){
			    						//미입금만 취소 가능.
			    						str1 += "<a href='javascript:cancle(\""+rsvStatus+"\",\""+ data.RSV_ID+"\")' class='cancle_guest'>취소하기</a>";
			    						str2 += "<a href='javascript:cancle(\""+rsvStatus+"\",\""+ data.RSV_ID+"\")'class='cancle_guest'>취소하기</a>";
			    					}else{
			    						str1 += "<a href='javascript:alert(\"출조전날은 예약취소가 불가능합니다\");' class='cancle_guest_disa'>취소하기</a>";
			    						str2 += "<a href='javascript:alert(\"출조전날은 예약취소가 불가능합니다\");' class='cancle_guest_disa'>취소하기</a>";
			    					}
			    				}
			    			}
			    			
			    			reserveMap1[data.SCHD_ID] = mapData1 + str1;
			    			reserveMap2[data.SCHD_ID] = mapData2 + str2 +"</p>";
			    		});			    		
			    		
			    		if(watingList != null){
			    				$.each(watingList, function(idx, info){
			    					if(info.SCHD_DATE >= today)
			    						reserveMap2[info.SCHD_ID] =  reserveMap2[info.SCHD_ID] + "<p style='font-size:12px;' class='p2'>"+info.USER_NAME+"("+info.WATING_PSGR_CNT+"명) 예약대기</p><br/>";
			    				});
			    		}
			    		
			    		
			    		_self.$calendarListContainer.find("tbody>tr").remove(); 	

			    		
			    		$.each( scheduleList, function( idx, data ) {
			    			var tmp1 = _self.$template1.clone();
			    						    						    		
			    			var scTimeType = data.SCHD_TIME_TYPE;
			    			
			    			var scTime = data.SCHD_TIME;
			    			
			    			var availCnt =data.PSGR_CNT - data.RESERVE_CONFIRM_CNT;
							if($("#waitReserveYn").val() == "Y"){
								availCnt =data.PSGR_CNT - data.RESERVE_CONFIRM_CNT - data.RESERVE_WAIT_CNT - data.WAIT_CNT;
							}
							
			    			var statusNm;
			    			
			    			if(scTime != '' && scTime != undefined){
			    				tmp1.find(".time_member").html(scTime.substr(0,2) + ':' + scTime.substr(2,2) + '&nbsp;' + availCnt + "명");
			    			}

			    			tmp1.find(".info_title").data('schdId', data.SCHD_ID);
			    						    			
			    			if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined)
			    				tmp1.find(".info_title").text("("+ data.SUB_SHIPNM+ ")"+ data.SUB_TITLE);
			    			else
			    				tmp1.find(".info_title").text(data.SUB_TITLE);
			    			
			    			var choiceGenre = data.CHOICE_GENRE;
			    			choiceGenre = ( choiceGenre == undefined )? '' : choiceGenre;
			    				    			
			    			if(scTimeType == '0' && choiceGenre == ''){
			    				
			    				var genreCnt = 0;
			    				var subtitle = "";
			    				if(data.GENRE_USEYN1 == 'Y' && data.GENRE1_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = data.SUB_TITLE1;
			    				}
			    				if(data.GENRE_USEYN2 == 'Y' && data.GENRE2_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = data.SUB_TITLE2;
			    				}
			    				if(data.GENRE_USEYN3 == 'Y' && data.GENRE3_OPENYN == 'Y'){
			    					genreCnt++;
			    					subtitle = data.SUB_TITLE3;
			    				}
			    				
			    				var title = "출조합니다.";
			    				if(genreCnt == 1){
			    					title = subtitle;
			    				}
			    							    				
			    				if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined)
			    					tmp1.find(".info_title").text("("+ data.SUB_SHIPNM+ ") "+title);
			    				else
			    					tmp1.find(".info_title").text(title);
							
			    				data.GENRE_MINCNT =  data.PSGR_CNT;
			    				tmp1.find(".time_member").html("시간 미정 - "+ (data.PSGR_CNT == undefined ? "" : data.PSGR_CNT+"명~ "));
			    			}
			    			
			    			
			    			data.AVAIL_CNT = availCnt;
			    			
			    			var lstString = reserveMap1[data.SCHD_ID];
			    			
			    			if (lstString == null)
			    			{
			    				lstString = "";
			    			}
			    			else
			    			{
			    				lstString += "<br>";
			    			}
	
			    			tmp1.find(".info_con").append(lstString);
			    			
			    			data.RSV_STRING = reserveMap2[data.SCHD_ID];
			    			
			    			var $td = _self.scCalendarTbl.find("#" + data.SCHD_DATE);
			    			var $div = $td.find("div").eq(0);
			    			$td.find('.sc_con').append(tmp1);
			    			   			
			    			// 상태가 정상이 아니거나, 정상이어도 인원이 마감되거나 기한이 지난 것은 예약불가 상태로 처리
			    			// 독선 미입금은 예약 마감처리
			    			if (data.STATUS_CD != "113_110" || availCnt <= 0 )			    			
			    			{			    				
			    				
			    				if (data.STATUS_CD == "113_180")
			    				{
			    					statusNm = "만료"; //예약가능한 날짜가 지남
			    				}
			    				else if (availCnt <= 0 )
			    				{
			    					statusNm = "마감"; //예약인원이 마감
			    				}
			    				else
			    				{
			    					statusNm = data.STATUS_NAME;
			    				}

			    			}
			    			else
			    			{
			    				$div.attr('class', 'possible');
			    				statusNm = "예약가";
			    				tmp1.find(".poss_icon").data('schd_id', data.SCHD_ID);
			    			}
			    			
			    			
				    			data.STATUS_NM = statusNm; 
				    			tmp1.data('scdata',data);
			    			
			    			
			    		});			    		
			    		
			    		var calendarTdList = $("#tbodyCalendar>tr>td[id!='']");	
			    		var $listCon = _self.$calendarListContainer;
			    		
			    		//ie7,8 버그대응
			    		for (var i=calendarTdList.length - 1; i >= 0 ; i--)
			    		{
			    			if (calendarTdList[i].id == "")
			    			{
			    				calendarTdList.splice(i,1);
			    			}
			    		}

			    		
			    		$.each( calendarTdList, function( idx, tdObj ) {

			    			if (_self._interval_id)
			    			{
			    				clearInterval(_self._interval_id);			    				
			    				_self._interval_id = null;
			    			}
			    		
			    			var $td = $(tdObj);
			    			
			    			var $listRow = _self.$template2.clone(); // 세로캘린더용 템플릿			    			
			    			$listRow.attr('id', tdObj.id);			    			
			    			
			    			var day = idx + 1;
			    			
			    			var dayNum = (day + firstRangeIndex - 1) % 7;
			    			
			    	        var dateTd = $listRow.find('.date');
			    	        var dayTd = $listRow.find('.day');
			    			
			    	        if (dayNum == 0) {
			    	            dateTd.addClass('sun');
			    	            dayTd.addClass('sun');
			    	            $listRow.css('background-color', '#FFF2F2');
			    	        } else if (dayNum == 6) {
			    	            dateTd.addClass('sat');
			    	            dayTd.addClass('sat');
			    	            $listRow.css('background-color', '#E0F1FB');			    	            
			    	        } else {
			    	            dateTd.removeClass('sat');
			    	            dayTd.removeClass('sat');
			    	            dateTd.removeClass('sun');
			    	            dayTd.removeClass('sun');
			    	        }
			    	        
			    	        var dayNm = dayList[dayNum];
			    	        dayTd.text(dayNm);

			    	        
			    	        $listRow.find(".date").html(day);
			    	        
			    	        var tdTemp1List = $td.find('div#template1');
			    	        
			    	        if (tdTemp1List.length > 0)
			    	        {
			    	        	var rowspan = tdTemp1List.length;
			    	        	
			    	        	if (rowspan > 1)
			    	        	{
			    	        		$listRow.find('.spanrow').attr('rowSpan',rowspan);
			    	        	}
			    	        	
			    	        	$.each(tdTemp1List, function( idx, templateObj ) {
			    	        		
			    	        		if (idx > 0)
			    	        		{
			    	        			var color = $listRow.css('background-color');			    	        			
			    	        			
			    	        			$listRow = _self.$template2.clone();
			    	        			$listRow.find('.spanrow').remove();
			    	        			
			    	        			if (color != '')
			    	        			{
			    	        				$listRow.css('background-color',  color);
			    	        			}
			    	        		}			    	        		
			    	        		
			    	        		var scdata = $(templateObj).data('scdata');
			    	        				    	        		
			    	        		var notice_text = "";
			    	        		
						    		if (scdata.NOTICE_TEXT  != null)
						    		{
						    			notice_text = '<p class="p1">' + scdata.NOTICE_TEXT.replaceAll("\n","<br>"); + '</p>';
						    		}
						    		
						    		var rsv_text = "";
						    		
						    		if (scdata.RSV_STRING != null)
						    		{
						    			rsv_text = scdata.RSV_STRING;
						    		}
						    		
						    		var scTimeType = scdata.SCHD_TIME_TYPE;
						    		var choiceGenre = scdata.CHOICE_GENRE;
					    			choiceGenre = ( choiceGenre == undefined )? '' : choiceGenre;
					    		
				    	        	$listRow.find('a.title').data('schdId', scdata.SCHD_ID);
				    	     				    	        					    			
					    			if(choiceGenre == '' && scTimeType == '0' && (scdata.SUB_TITLE == undefined || scdata.SUB_TITLE == null)){
					    				var prefix="";
					    				if(scdata.SUB_SHIPNM != '' && scdata.SUB_SHIPNM != undefined){
					    					if(scdata.SUB_SHIPFILE != '' && scdata.SUB_SHIPFILE != undefined){
					    						$listRow.find("td.title p").attr("style", "vertical-align: middle;padding-left:10px;").before("<img width='70px' height='42px' src='/cm/file/image/"+scdata.SUB_SHIPFILE +"/50'>");
					    					}
					    					prefix = "<span style='font-size:13px;color:#3170e1;text-decoration:none;letter-spacing:-0.8px;'>["+ scdata.SUB_SHIPNM + "]</span><br/>";
						    			}
					    				var genreCnt = 0;
					    				var subtitle = "";
					    				if(scdata.GENRE_USEYN1 == 'Y' && scdata.GENRE1_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE1;
					    				}
					    				if(scdata.GENRE_USEYN2 == 'Y' && scdata.GENRE2_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE2;
					    				}
					    				if(scdata.GENRE_USEYN3 == 'Y' && scdata.GENRE3_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE3;
					    				}
					    				
					    				var title = "출조합니다.";
					    				if(genreCnt == 1){
					    					title = subtitle;
					    				}
					    				
					    				
					    				$listRow.find('a.title').html(prefix+ title);
					    				if(scdata.STATUS_CD == '113_110')
					    					$listRow.find('td.yes_no').html('<span class="yes">'+scdata.GENRE_MINCNT + ' ~ </span>');
					    			}else{
					    				var prefix="";
					    				if(scdata.SUB_SHIPNM != '' && scdata.SUB_SHIPNM != undefined){
					    					if(scdata.SUB_SHIPFILE != '' && scdata.SUB_SHIPFILE != undefined){
					    						$listRow.find("td.title p").attr("style", "vertical-align: middle;padding-left:10px;").before("<img width='70px' height='42px' src='/cm/file/image/"+scdata.SUB_SHIPFILE +"/50'>");
					    					}
					    					prefix = "<span style='font-size:13px;color:#3170e1;text-decoration:none;letter-spacing:-0.8px;'>["+ scdata.SUB_SHIPNM + "]</span><br/>";
					    				}
					    				if(scTimeType == '1'){ //생활낚시
					    					$listRow.find('a.title').html(prefix +"<span style='text-decoration:underline;'>"+ scdata.SUB_TITLE+ "("+ scdata.SCHD_TIME.substr(0,2) + ':' + scdata.SCHD_TIME.substr(2,2) +")</span>");
					    				}else{
					    					$listRow.find('a.title').html(prefix+ "<span style='text-decoration:underline;'>"+ scdata.SUB_TITLE +"</span>");
					    				}
					    	        	$listRow.find('td.yes_no').html('<span class="yes">' + scdata.AVAIL_CNT +'</span>');
					    	       }
					    			
				    	        	if (scdata.TOT_EQP_CNT != null && scdata.TOT_EQP_CNT !=0)
				    	        	{
				    	        		$listRow.find('td.eqp_cnt').text(scdata.TOT_EQP_CNT);
				    	        	}
 				    	        	
				    	        	$listRow.find('div.reservers').html(notice_text + rsv_text);
				    	        	
				    	        	if (scdata.STATUS_NM == "예약가")
				    	        	{
				    	        		
				    	        		if (_self.$telOnly != "")
										{
				    	        			$listRow.find('td.status').html('<span class="button" style="border-radius:5px;cursor:pointer;color:white;background:blue;padding:3px"><a style="color:white;" href="javascript:alert(\''+_self.$telOnly+'\');" >전화예약</a></span>');
										}
				    	        		else
				    	        		{
					    	        		$listRow.find('td.status').html('<span class="possible" style="cursor:pointer">예약하기</span>');
					    	        		$listRow.find('td.status>span').data('schd_id',scdata.SCHD_ID);				    	        			
				    	        		}
				    	        	}
				    	        	else
				    	        	{
				    	        		if (scdata.STATUS_CD == '113_210')				    	        			
				    	        		{
				    	        			if (scdata.CANCEL_DESC != null && scdata.CANCEL_DESC.substr(0,4) == '기상악화')
					    	        			{
				    	        					isBlink = true;
				    	        					$listRow.find('td.status').html('<span class="cancel blink">출조취소</span>');
					    	        			}
						    	        	else
						    	        		{
						    	        			$listRow.find('td.status').html('<span class="cancel" title="' +  scdata.CANCEL_DESC  + '">출조취소</span>');
						    	        		}
				    	        		}
				    	        		else
				    	        		{
				    	        			 if(scdata.STATUS_NM == "마감" && watingShowYn == 'Y'){
				    	        				$listRow.find('td.status').html("<br>"+scdata.STATUS_NM +"<br/><button style='margin-bottom:10px;' schdid="+scdata.SCHD_ID+" class='wating_btn' name='waiting'>예약대기</button>");
					    	        		}else{
					    	        			$listRow.find('td.status').html(scdata.STATUS_NM );
				    	        			}
				    	        		}
				    	        		
				    	        		
				    	        		$listRow.find('td.yes_no').html('');
				    	        	}				    	        	

				    	        	
				    	        	if (scdata.AVAIL_CNT < 0 && scdata.STATUS_NM == "마감")
				    	        	{
				    	        		var exceed = scdata.AVAIL_CNT * -1;
				    	        		$listRow.find('td.yes_no').html('<span style="color:yellow;background-color:red;padding:10px">' + exceed + '명 초과</span>');
				    	        	}
				    	        	
				    	        	if(notice_text.includes != undefined){
					    	        	if(scdata.STATUS_NM == "만료" && notice_text.includes("취소")) {
					    	        		$listRow.find('div.reservers').html("");
					    	        	}
				    	        	}
				    	        	
				    	        	$listCon.append($listRow);
			    	        	});
			    	        }
			    	        else
			    	        {
			    	        	$listCon.append($listRow);			    	        	
			    	        }

			    		});
			    		
			    		
			    		if (isBlink)
			    		{
			    			_interval_index = 0;			    			
			    			_interval_objs = $('span.blink');
			    			_self._interval_id = setInterval(_self.blinkEffect, 500);
			    		}
			    		
						
				    	var seatimeList = data.seatimeList;
				    	
			    		$.each( seatimeList, function( idx, data ) {
			    			
			    			var _td = _self.scCalendarTbl.find("#" + data.SOLAR_DATE);
			    			_td.find('.mull').text( data.MOOL );
			    			_td.data('mull',data.MOOL);
			    			
			    			var _tr = _self.$calendarListContainer.find("#" + data.SOLAR_DATE);
			    			_tr.find('.mull').text( data.MOOL );	
			    			
							if (isHoliday(data.SOLAR_DATE))
							{
								_tr.find('td.date,td.day').addClass('sun');
								_tr.css('background-color', '#FFF2F2');
							}
			    			
			    		});
			    		
			    		
			    		if (_self.$reserv_status_popup_wrap.length > 0)
			    		{
			    			$('.schd_tb2 .p2').css("cursor","pointer");
			    		}
			    		
				    }
				});
			},
			
			'blinkEffect' : function()
			{
				  var _self = this;
				  
				  _interval_index ++;		

				  var comp = _self._interval_objs;  
				  var status = _self._interval_index;				  
				  
				  if (status == 1 || status == 3)
				  {
				  	comp.text("");
				  }
				  else if (status == 2)
				  {
				  	comp.text("기상악화");
				  	comp.css("color", "#FF9B00");
				  }
				  else if (status == 4)
				  {
				  	comp.text("출조취소");
				  	comp.css("color", "#FF4B4B");
				  	_self._interval_index = 0;
				  }					
			},
			// 공지사항 목록 조회
			'getPostList' : function( bbsType, page ) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer;
				_paging = $('#postListPaging');
				
				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: bbsType
				};
				$.ajax({
					 url : _self.postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('postList') ) {
				    		// 초기화
				    		_contatiner.empty();
				    		var list = data.postList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$postNoDataTemplate.clone();
				    			_self.$listContainer.append( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $row = _self.$postListTemplate.clone();
					    			
					    			if (idx % 2 == 1)
					    			{
					    				$row.addClass("even");
					    			}
					    			
					    			$row.attr( 'rowKey', data.POST_ID );
					    			
					    			var titleLink = $row.find('a');
					    			
					    			titleLink.attr( 'postId', data.POST_ID );
					    			titleLink.attr( 'bbsType', bbsType );					    			
					    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;

					    			// 제목
					    			$row.find('[data-key=TITLE]').text( data.TITLE );

					    			// 등록일
					    			if( data.UPDATED_AT ) {	// 업데이트 시간이 있을경우
					    				data.UPDATED_AT = data.UPDATED_AT.substr(0, 10);
					    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
					    			}else{	// 없을경우
					    				data.CREATED_AT = data.CREATED_AT.substr(0, 10);
					    				$row.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			}
					    			
					    			_contatiner.append( $row );
					    		});					    		
					    	}
				    		
					    	var numOfPages = Math.ceil(data.total / itemCnt);
					    	
				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: numOfPages
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
									_self.getPostList( bbsType, page );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		
				    		if (numOfPages > 5)
					    		_paging.find('.paging_next').text(">");				    		
				    	}
				    }
				});
			},			
			'getMyReserveList' : function(page) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer2;
				_contatiner.empty();
				
				if (isLogin() == false) 
				{
					_contatiner.append( '<td colspan=5> 예약 내역이 없습니다.</td>');
					return;
				}
								
				_paging = $('#resvListPaging');

				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
						 'PAGE' : page
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	$.each(data.memReserveList, function(idx,data) {
			    		 $row = _self.$resvListTemplate.clone();		
			    		 
			    			if (idx % 2 == 1)
			    			{
			    				$row.addClass("even");
			    			}
				    		 
				    		 $row.attr('id', null);
				    		 
				    		 if (data.STATUS_CD == '104_300')
			    			 {
				    			 data.STATUS_NAME = '<span class="finish">입금완료</span>';
			    			 }				    		 
				    		 
				    		 setFiledByDataFilter($row, 'SCHD_DATE', data, 'date');
				    		 setFiledByData($row, 'SUB_TITLE', data);
				    		 setFiledByData($row, 'MAN_CNT', data);				    		 
				    		 setFiledByData($row, 'STATUS_NAME', data);
				    		 setFiledByDataFilter($row, 'TOT_COST', data, 'money');
				    		 
			    			 var titleLink = $row.find('a');
			    			
			    			 titleLink.attr( 'rsvId', data.RSV_ID );
				    		 
				    		 _contatiner.append( $row );		    			
				    	 });
				    	
				    	var numOfPages = Math.ceil(data.total / itemCnt);
				    	
			    		// 페이징 초기화
			    		$(_paging).paging({
							 current: page
							,max: numOfPages
							,itemClass: ''
							,prevClass: 'paging_prev'
							,nextClass: 'paging_next'
							,firstClass: ''
							,lastClass: ''
							,length: 5
							,itemCurrent: 'on'
							,onclick:function(e,page){
								_self.getMyReserveList(page );
							}
						});	
			    		
			    		if (page <= 5)
			    		{
			    			_paging.css("margin-left","40px");
			    		}
			    		else
			    		{
			    			_paging.css("margin-left","");
			    		}
			    		
			    		_paging.find('.paging_prev').text("<");
			    		
			    		if (numOfPages > 5)
			    		_paging.find('.paging_next').text(">");	
				    }
				});				
			},	
			'changeImageIndex' : function(btnObj, c)
			{
				if (c == null || isNaN(c)) return;
				
				var me = $(btnObj).parent().parent();
				var brothers = $("[data-type='IMAGE_LIST']").find('li');
				var cnt = brothers.length;
				var idx = me.index();
				
				if (c == -1)
					{
						if (cnt == 1 || idx == 0) return;		
						brothers.eq(idx - 1).before(me);
					}
				else if (c == +1)
					{
						if (idx == cnt - 1) return;	
						brothers.eq(idx + 1).after(me);		
					}

			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				//캘린더 <,> 버튼 마우스포인트 처리
				_self.$calendarMoveBtn.css('cursor','pointer');
				
				_self.getMyReserveList('1');
				
				_self.getPostList('108_110', '1' );
				
		        var date = new Date();
		        var month = date.getMonth() + 1;
		        
		        date.setDate(1);
		        
		        _self.selectDate = date;
		        _self.yearMonth = date.getFullYear() +  ((month < 10)? "0" + month: "" + month);
		        _self.renderScheduleList();
		        
			},
			
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
