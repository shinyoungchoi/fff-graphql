defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleMainURL = $('#scheduleMainURL').val();
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._loginURL = $('#loginURL').val();
				this._guestURL = $('#guestURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				// element
				this.$reserveForm = $('#reserveInsertForm');
				this.$reserveBtn = $('#reserveBtn');
				this.$reserveCancelBtn = $('#reserveCancelBtn');
				this.$loginBtn = $('#loginBtn');
				this.$guestBtn = $('#guestBtn');
				this.$wholeYnCheck = $('#wholeYnCheck');
				// static variable
				this.scheId = $('#scheId').val();
				this.scheDate = $('#scheDate').val();
				this.feeMan = $('#feeMan').val();
				this.feeWhole = $('#feeWhole').val();
				this.reserveCnt = $('#reserveCnt').val();
			},
			'setEvent'		: function() {
				var _self = this;

				// 승선 인원 변경
				_self.$reserveForm.find('[data-key=MAN_CNT]').change( function() {
					_self.totalCost();
				});
				
				// 독선여부 체크
				_self.$wholeYnCheck.click( function() {
					var $manCntSel = _self.$reserveForm.find('[data-key=MAN_CNT]');
					if( $(this).is(':checked') ) {
						if( undefined != _self.feeWhole && '' != _self.feeWhole ) {
							_self.$reserveForm.find('[data-key=TOT_COST]').val( _self.feeWhole );
						} else {
							_self.totalCost();
						}
						$manCntSel.val( $manCntSel.find('option:last').val() );
						$manCntSel.attr('disabled', true);
					} else {
						$manCntSel.attr('disabled', false);
					}
				});
				
				// 예약 등록
				_self.$reserveBtn.click( function() {
					_self.insertReserve();
				});
				
				// 예약 취소
				_self.$reserveCancelBtn.click( function() {
					window.history.back();
				});
				
				// 예약하기 위해 로그인
				_self.$loginBtn.click( function() {
					Bplat.view.loadPage( _self._loginURL );
				});

				// 비회원예약
				_self.$guestBtn.click( function() {
					Bplat.view.loadPage( _self._guestURL );
				});
				
			},
			'stringFilter' : function(str, format){
				switch (format) {
				case 'date':
					if(str.length >= 8){
						//yyyy-mm-dd	
						str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
					}else if(str.length == 6){
						//yyyy-mm
						str = str.substr(0,4) + "-" + str.substr(4,2);
					}else if(str.length == 4){
						//yyyy
						str = str.substr(0,4);
					}
					break;
				case 'money':
					//comma
					var pattern = /(^[+-]?\d+)(\d{3})/;
					str += '';
					
					while(pattern.test(str)) {
						str = str.replace(pattern,'$1,$2');
					}
					break;	
				case 'removeHyphen':
					//remove hyphen date
					str = str.replaceAll('-', '');
					break;	
				default:
					break;
				}
				return str;
			},
			// 예약금액 자동 셋팅
			'totalCost' : function() {
				var _self = this;
				var man = _self.$reserveForm.find('[data-key=MAN_CNT] option:selected').val();
				var sum = man * _self.feeMan;
				if( !sum ) sum = 0;
				_self.$reserveForm.find('[data-key=TOT_COST]').val( _self.stringFilter(sum, 'money') );
				$(".jdg-page-schedule").css("width","+=1");
				$(".jdg-page-schedule").removeAttr("style");
			},
			// 예약등록
			'insertReserve' : function() {
				var _self = this;
				var $insertForm = _self.$reserveForm;
				// validation
				var today = jdg.util.today().replaceAll('-','');
//				if( today >= _self.scheDate ) {
//					alert('과거 또는 오늘에 대한 예약은 등록할 수 없습니다. 반드시 필요한 예약이라면 출조점에 문의하여 주세요');
//					return false;
//				}
				
				 var totCost = $insertForm.find('[data-key=TOT_COST]').val();
				 totCost = totCost.replaceAll( ',', '' );
				 $insertForm.find('[data-key=TOT_COST]').val( totCost );
				 
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();
				if( manCnt*1 > _self.reserveCnt*1 ){
					alert("현재 예약가능 인원은 " + _self.reserveCnt + " 명입니다. 인원 수정 후 다시 시도하여 주세요.");
					return false;
				}
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').val();
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').val();
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
				
				var $bankCd = $insertForm.find('[data-key=BANK_CD]');
				var bankCd = $bankCd.val();
				var vrBankingYn;
				
				if (bankCd != null)
				{
						if( bankCd == '') {
						alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
						return false;
					}
					
					vrBankingYn = "Y";
				}
				else
				{
					vrBankingYn = "N";
					bankCd = null;
				}
				
				if( rsvName == '' && rsvTel == '' &&  rsvEmail == '' ) {
					alert('예약자 정보를 입력해 주세요');
					return false;
				}
				if( confirm('예약하시겠습니까?') ) {
					var insertParam = {
						  'SCHD_ID' : _self.scheId
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : rsvEmail
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'WHOLE_YN' : 'N'
						, 'SITE_CD' : 'L'
						, 'BANK_CD' : bankCd
					    , 'VR_BANKING_YN' : vrBankingYn
					};
					
					// 독선예약 여부 체크 
					if( _self.$wholeYnCheck.is(':checked') ) {
						insertParam.WHOLE_YN = 'Y';
					}
					
					// 로더 생성
					jdg.util.showLoader();	
					
					$.ajax({
						 url : _self._reserveInsertURL
						,type : 'POST'
						,data : insertParam
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
							// 로더 제거
							jdg.util.removeLoader();	

					    	if (data.error == undefined)
					    	{
						    	var rsv_Id = data.rsv_Id;
						    	if( rsv_Id != null &&  rsv_Id != undefined ) {
									if (confirm('예약이 완료되었습니다.\n예약내역을 확인하시겠습니까?') == true) {   
										Bplat.view.loadPage(_self._memReserveDetailURL + "?ID=" + rsv_Id);
									} else {   
										location.reload();
									}
						    	}
					    	}
					    	else
					    	{
					    		alert(data.error.userMessage);
					    	}
					    }
					});
				}
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_detail_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				// 예약금액 초기셋팅
				_self.totalCost();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_detail_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_detail_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_detail_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_detail_form] onDestroy Method' );
			}		
	  }
});
