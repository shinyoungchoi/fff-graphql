defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleDetailURL = $('#scheduleDetailURL').val();
				
				this._scheduleWeatherURL = $('#scheduleWeatherURL').val();
				this._scheduleWeatherDateURL = $('#scheduleWeatherDateURL').val();				
				
				this._sendTextURL = $("#sendTextURL").val();
				this._sendReseveListURL = $("#sendReseveList").val();
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._myReserveListURL = $('#myReserveListURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();
				this._watingCompDelURL = $("#watingCompDel").val();
				
				this._msgDetailURL = $("#msgDetailURL").val();

				this.postListURL 		= $('#postListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();
				this.postInsertURL 		= $("#postInsertURL").val();
				this.listForManagerURL  = $("#listForManagerURL").val();

				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$postListTemplate 			= $('#postListTemplate .postListRow');
				this.$resvListTemplate 			= $('#resvListTemplate .resvListRow');			
				this.$postNoDataTemplate       = $('#postListTemplate .nodata');
				
				this.$shipId = $('#shipId').val();
				this.$weatherDiv = $('.weather_popup_wrap');
				this.$weatherInfoTbl = $('.weather_tb');
				this.detailListForReserve = [];

				this.$imageURL		 			= $('#imageURL').val();
				// 달력스케쥴
				this.$calendarContainer = $('#tbodyCalendar');
				
				// 일자별 스케쥴
				this.$calendarListContainer = $('.schd_tb2');

				
				this.scCalendarTbl = $(".schd_tb");
				this.$template1 = $('#template1');
				this.$template2 = $('#template2 tr');			

				this.$reserveList = $('#listContainer');
				
				this.$calendarMoveBtn = $("span.prev,span.next");
				
				this.$calendarTdTemplate = $("#tbodyCalendar td:first").html();		
				
				this._schdInfo;
				
				this.$popupTitleKr = $('.notice_pop_wrap .title_kr');
				this.$popupTitleEn = $('.notice_pop_wrap .title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				
				this.$smsPopWrap = $("#smsPopWrap");
				this.$movieListRow = $('.movieListRow');
				this.vrBankingYn = true;
				
				this.$checkWhole = $('.wholeYnCheck:checkbox');
				this.$instFactoryBtn = $("#instFactoryBtn");
				
				this._feeWhole = 0;
				this._psgrCnt = 0;
				this._nickName = "nickname";
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				this.fileList = null;
				
				this.$detail_notice_btn = $("#detail_notice_btn");

			},
			'setEvent'		: function() {
				var _self = this;
				
					$('#textDatePicker').datepick({showOnFocus: false, dateFormat: 'yyyy-mm-dd'
					    ,showTrigger: '<a href="#" class="jdg-btn-calendar" title="달력"></a>'			    	
					});
					
					$('#textTimePicker').timepicker({
					    timeFormat: 'HH:mm',
					    interval: 1,
					    defaultTime: 'now',
					    startTime: '03:00',
					    dynamic: true,
					    dropdown: true,
					    scrollbar: true
					});
					
					//공지사항 작성 버튼
					_self.$instFactoryBtn.on("click", function(){
						location.href=_self.postInsertURL;
					});
					
					//예약대기 버튼
					$(document.body).on("click", ".watingDeleteBtn", function(){
					var watingSeq =  $(this).attr("pid");
						$.ajax({
						 url : _self._watingCompDelURL
						,type : 'POST'
						,data : {SEQ : watingSeq}
					    ,dataType : 'json'
					    ,success : function( data ) {				    	
					    	console.log(data);
					    	if(data.result = "ok"){
					    		alert("예약 대기자가 삭제처리되었습니다.");
					    		_self.renderScheduleList();
					    	}else{
						    	alert("처리도중 오류가 발생하였습니다.");
						    	return;
					    	}
					    }
					}); 
				
				});
					
					//템플릿 선택 시
					$("select.temp_select").on("change", function(){
						var seq = $(this).val();
						if(seq == ""){
							$("#smsPopWrap").find("input[name='SEND_TITLE']").val("");
							$("#smsPopWrap").find("div.title_div").hide();
							$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val("");
							$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
							_self.fileList.init();
							return;
						}
						$.ajax({
							 url : _self._msgDetailURL
							,type : 'POST'
							,data : {SEQ : seq}
						    ,dataType : 'json'
						    ,success : function( data ) {				    	
						    	console.log(data);
						    	var result = data.result;	
						    	if(result.SMS_TYPE == 'LMS'){
						    		$("#smsPopWrap").find("div.title_div").show();
						    	}else{
						    		$("#smsPopWrap").find("div.title_div").hide();
						    	}					    	
						    	$("#smsPopWrap").find("input[name='SEND_TITLE']").val(result.TITLE);
						      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val(result.CONTENT);
						      	$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
						      	if(result.MAIN_IMG_ID != null && result.MAIN_IMG_ID != ''){
						      		_self.fileList.init(result);
						      	}
						    }
						}); 
					});
					
					//전송 시간
					$("#smsPopWrap").on("click", "input:radio[name='SEND_TIME']", function(){
						var value = $(this).val();
						if(value == 'NOW'){
							$(".sendDate").hide();
						}else{
							$(".sendDate").show();
						}
					});
					
					//byte 체크
					$("#smsPopWrap").on("keyup", "textarea[name='SEND_CONTENT']", function(){
						var content = $(this).val();
						var value = _self.checkBytes(content);
						$("span.count_txt").html(value);
						if(value > 130){ //LMS인경우부터는 제목 가능
				    		$("#smsPopWrap").find("div.title_div").show();
						}else{
							$("#smsPopWrap").find("div.title_div").hide();
						}
						if(value > 1499){
							var content_ = content.substr(0,1499);
							$("#smsPopWrap textarea[name='SEND_CONTENT']").val(content_);
							return false;
						}
						
					});
					
					//발송
					$("#smsPopWrap").on("click", "a.sendtxt_button", function(){
						var param = { SEND_TEL : $("#smsPopWrap").find(".sendTel").html()};
						
						var schdDate = $("#smsPopWrap").find("input[name='schd_date']").val();
						param.SCHD_DATE = schdDate;
						
						var schdId = $("#smsPopWrap").find("input[name='schd_id']").val();
						param.SCHD_ID = schdId;
						
						var sendTimeType = $("#smsPopWrap").find("input:radio[name='SEND_TIME']:checked").val();
						if(sendTimeType == 'RESERVE'){
							var textDatePicker = $("#smsPopWrap").find("#textDatePicker").val();
							param.SEND_DATE = textDatePicker;
							
							var textTimePicker = $("#smsPopWrap").find("#textTimePicker").val();
							if(!(/^[0-9\:]*$/.test(textTimePicker))){
								alert("00:00 형태로 입력하셔야 합니다.");
								return;
							}
							
							if(textTimePicker == ''){
								alert("예약 시간을 입력해주세요.");
								return;
							}
							param.SEND_TIME = textTimePicker; 
						}
						param.SEND_TIME_TYPE = sendTimeType;
																	
						var content = $("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val();
						if(content == ''){
							alert("내용을 입력해주세요.");
							return;
						}
						param.SEND_CONTENT = content;
						
						var count = _self.checkBytes(content);
						param.MSG_TYPE = "SMS";
						
						if(count > 130){
							var title = $("#smsPopWrap").find("input[name='SEND_TITLE']").val();
							if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(title))){
								alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
								return;
							}else{
								param.SEND_TITLE = title;
							}
							param.MSG_TYPE = "LMS";
						}
												
						var phones = [];
						var checkYn = false;
						$("#smsPopWrap").find("input:checkbox[name='RSV_MEM']").each(function(){
							if($(this).is(":checked")){
								var id = $(this).attr("pid");
								var tel = $(this).attr("ptel");
								var name = $(this).attr("pname");
								phones.push({RSV_ID: id,RSV_TEL: tel, RSV_NAME : name});
								checkYn = true;
							}
						});
						
						if(!checkYn){
							alert("수신자를 한명이상 선택해주세요.");
							return;
						}
						
						//파일 정보 가져가기
						param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
						
						param.RSV_TELS = JSON.stringify(phones);
												
						if(confirm("전송하시겠습니까?")){
						$.ajax({
							 url : _self._sendTextURL
							,type : 'POST'
							,data : param
						    ,dataType : 'json'
						    ,success : function( data ){
						    	if(data.msg == "success"){
						    		alert("문자 전송에 성공하였습니다.");
						    		hidePop('.sms_pop_wrap', 'popup_common_con');
						    		$("#smsPopWrap").find("input[name='SEND_TITLE']").val("");
									$("#smsPopWrap").find("div.title_div").hide();
									$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").val("");
									$("#smsPopWrap").find("textarea[name='SEND_CONTENT']").trigger("keyup");
									_self.fileList.init();
						    		return;
						    	}
						     	if(data.nosessionmsg != null){
						    		alert("세션이 종료되었습니다. 로그인해주세요.");
						    		return;
						    	}
						     	
						    	if(data.failmsg != null){
						    		alert(data.failmsg);
						    		return;
						    	}
						    	alert("문자 전송도중 오류가 발생하였습니다.");
						    	return;
						    }
						    ,error : function(error){
						    	alert("문자 전송도중 오류가 발생하였습니다.");
						    	return;
						    }
						});
						}
						
					});
					
					$("[data-type='IMAGE_LIST']").delegate('div.up','click', function() {
						event.preventDefault();
						_self.changeImageIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
					});

					$("[data-type='IMAGE_LIST']").delegate('div.down','click', function() {
						event.preventDefault();
						_self.changeImageIndex(this, +1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
					});
					
				//메시지 전송 버튼
				$("table.schd_tb2").on("click", ".btnSendMsg", function(){
					var schdId = $(this).attr("schdid");
					var schdDate = $(this).attr("schddate");
					var sendmsg = $(this).attr("sendmsgyn");
					if(sendmsg != 'Y'){
						alert("문자메시지 서비스를 원하시면 고객센터(1800-0023)으로 전화주세요.");
						return;
					}
					$("#smsPopWrap").find("input[name='schd_id']").val(schdId);
					$("#smsPopWrap").find("input[name='schd_date']").val(schdDate);
					
					$.ajax({
						 url : _self._sendReseveListURL
						,type : 'POST'
						,data : { SCHD_ID : schdId}
					    ,dataType : 'json'
					    ,success : function( data ){
					    	var list = data.memReserveList;
					    	$("div.reserveList").empty();
					    	if(list != null && list.length > 0){
						    	for(var i = 0 ;i < list.length ; i++){
						    		var item = list[i];
						    		var html = "<span style='margin-right:8px;display:block;'>";
						    		html += "<input type='checkbox' checked name='RSV_MEM' value='Y' pid='"+item.RSV_ID+"' pname='"+item.DEPOSIT_NAME+"' ptel='"+item.RSV_TEL+"'>";
						    		if(item.SITE_CD == 'P'){
						    			html += "<img src='/resources/cm/images/fishapp_ico.gif'>";
						    		}else if(item.SITE_CD == 'S'){
						    			html += "<img src='/resources/cm/images/sd_ico.png'>";
						    		}
						    		html += item.DEPOSIT_NAME+"("+item.MAN_CNT+"명 예약:"+item.STATUS_NAME+")</span>";
						    		$("div.reserveList").append(html);
						    	}
						    	showPop('.sms_pop_wrap', '.popup_common_con');
					    	}
					    }, error : function(error){
					    	alert("오류가 발생하였습니다. \n다시 시도해주세요.");
					    	return;
					    }
					});		
				});
				
				$('select[data-key=MAN_CNT]').change(function() {
					
					var cnt = toNumber($(this).val());
					
					var fee = $(this).data('fee');
					
					_self.totalCost(cnt, fee);		            
				});							
				
				// 날씨보기 버튼 클릭
				_self.$calendarContainer.delegate('.weather_btn','click',function() {
					
					stopEvent(event);

		            $('.weather_popup_wrap').fadeIn(200);
		            $('.weather_popup_con').css({top: '60%'});
		            $('.weather_popup_con').animate({top: '50%'}, 200);
		            isScroll = false;
		            lockScroll();
		            
		            var wDate = $(this).attr('data-date');
		            
		            _self.getWeatherDetail(wDate);
				});				

				_self.$weatherDiv.delegate('.weather_close_btn','click',function() {
					stopEvent(event);
		            $('.weather_popup_wrap').fadeOut(200);
		            $('.weather_popup_con').animate({top: '60%'}, 200);
		            isScroll = true;
		            unlockScroll();
				});				
				
				_self.$checkWhole.on("change", function(){
					var $insertForm = $("#reserveForm");
					
					var $checkWhole = this;
					var $manCnt = $insertForm.find('select[data-key=MAN_CNT]');
					var $totCost = $insertForm.find('td[data-key=TOT_COST]');
					var fees =  $insertForm.find('select[data-key=MAN_CNT]').data('fee');
				
					if ($checkWhole.checked)
					{
						$manCnt.attr("disabled",true);
						$manCnt.val(_self._psgrCnt);
						if(_self._feeWhole =="0"){
							var holtotal = fees* _self._psgrCnt;
							if($("#siteType").val() == "4")
								$totCost.html("<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
						}else{
							if($("#siteType").val() == "4")
								$totCost.html("<span>"+stringFilter(_self._feeWhole, 'money') + "원</span>");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:" + stringFilter(_self._feeWhole, 'money') + "원)");
						}
					}
					else
					{
						$manCnt.attr("disabled",false);
						$manCnt.val(null);
						$totCost.text("0 원");
					}
				});			
				
				
				
				_self.$checkWhole.on("click", function(){
					var $insertForm = $("#reserveForm");
					
					var $checkWhole = this;
					var $manCnt = $insertForm.find('select[data-key=MAN_CNT]');
					var $totCost = $insertForm.find('td[data-key=TOT_COST]');
					var fees =  $insertForm.find('select[data-key=MAN_CNT]').data('fee');
					
					if ($checkWhole.checked)
					{
						$manCnt.attr("disabled",true);
						$manCnt.val(_self._psgrCnt);
						if(_self._feeWhole =="0"){
							var holtotal = fees* _self._psgrCnt;
							if($("#siteType").val() == "4")
								$totCost.html("<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:<span class='whole_total_fee'>" + stringFilter(holtotal, 'money') + "</span>원)");
						}else{
							if($("#siteType").val() == "4")
								$totCost.html("<span>"+stringFilter(_self._feeWhole, 'money') + "원</span>");
							else
								$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:" + stringFilter(_self._feeWhole, 'money') + "원)");
						}
					}
					else
					{
						$manCnt.attr("disabled",false);
						$manCnt.val(null);
						$totCost.text("0 원");
					}
				});			
				
				
				_self.$calendarMoveBtn.click(function(){
					
					var clsname = this.className;
					
			        var date = _self.selectDate;
			       
			        
			        if (clsname == "prev")
			        {
			        	date.setMonth(date.getMonth() - 1);
			        }
			        else
			        {
			        	date.setMonth(date.getMonth() + 1);
			        }
			        
			        var month = date.getMonth() + 1;
			        
			        _self.yearMonth = date.getFullYear() +  ((month < 10)? "0" + month: "" + month);
			        
			        _self.renderScheduleList();
				});				
				
				_self.$calendarContainer.delegate('.poss_icon','click',function() {
					stopEvent(event);
					var schdId = $(this).data('schd_id');
					_self.showReserveForm(schdId);
				});
				
				_self.$calendarListContainer.delegate('.possible','click',function() {
					stopEvent(event);
					var schdId = $(this).data('schd_id');
					_self.showReserveForm(schdId);
				});	
				
				//비회원 예약 후 처리.
				$("#noMemButton").on("click", function(){
					_self.renderScheduleList();
				});
				
				//예약하기에서 장르 변경시
				$("#reserveForm").on("change", "#genreSelect", function(){
					var $insertForm = $("#reserveForm");
					var pCnt = $(this).find("option:selected").attr("pcnt");
					var fee = $(this).find("option:selected").attr("pfee");
					var feehol = $(this).find("option:selected").attr("phol");
					var tool1 = $(this).find("option:selected").attr("ptool1");
					var tool2 = $(this).find("option:selected").attr("ptool2");
					var tool3 = $(this).find("option:selected").attr("ptool3");
					var genreId = $(this).val();
					
					for(var i = 0 ; i < _self.detailListForReserve.length ; i++){
						var items = _self.detailListForReserve[i];
						if(items.GENRE == genreId){
							_self._schdInfo = items;
						}
					}
					
					_self._feeWhole = feehol;
					_self._psgrCnt = pCnt;					
									
					var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');
					
					select_manCnt.data('fee', fee);			
					
					select_manCnt.empty().append('<option value="">인원 선택</option>');
					
					for (var i=1; i <= pCnt; i++)
					{
						select_manCnt.append("<option value='"+ i + "'>" + i + " 명</option>");
					}

					var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
					select_eqpCnt.html("");
					
					for (var i=0; i <= pCnt; i++)
					{
						select_eqpCnt.append("<option value='"+ i + "'>" + i + " 대</option>");
					}
					
					$insertForm.find("span.tool1_tr_price").html("");
					$insertForm.find("span.tool2_tr_price").html("");
					$insertForm.find("span.tool3_tr_price").html("");
					$insertForm.find("[data-key='EQP1']").html("");
					$insertForm.find("[data-key='EQP2']").html("");
					$insertForm.find("[data-key='EQP3']").html("");
					$insertForm.find('tr.tool1_tr').css("display","none");	
					$insertForm.find('tr.tool2_tr').css("display","none");	
					$insertForm.find('tr.tool3_tr').css("display","none");	
					
					if(tool1 == '0'){
						$insertForm.find('tr.tool1_tr').css("display","");	
						$insertForm.find("span.tool1_tr_price").html("무상대여");
					
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool1 != null && tool1 != '' && tool1 != 'undefined'){
						$insertForm.find('tr.tool1_tr').css("display","");	
						$insertForm.find("span.tool1_tr_price").html("("+tool1+")원");
					
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
					
					
					if(tool2 == '0'){
						$insertForm.find('tr.tool2_tr').css("display","");
						$insertForm.find("span.tool2_tr_price").html("무상대여");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool2 != null && tool2 != '' && tool2 != 'undefined'){
						$insertForm.find('tr.tool2_tr').css("display","");
						$insertForm.find("span.tool2_tr_price").html("("+tool2+")원");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
					
					if(tool3 == '0'){
						$insertForm.find('tr.tool3_tr').css("display","");
						$insertForm.find("span.tool3_tr_price").html("무상대여");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}else if(tool3 != null && tool3 != '' && tool3 != 'undefined'){
						$insertForm.find('tr.tool3_tr').css("display","");
						$insertForm.find("span.tool3_tr_price").html("("+tool3+")원");
						for (var i=0; i <= pCnt; i++)
						{
							$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
						}
					}
				
					
					if($insertForm.find("tr.tool1_tr").css("display") == 'none' && 
							$insertForm.find("tr.tool2_tr").css("display") == 'none' &&
							$insertForm.find("tr.tool3_tr").css("display") == 'none' ){
						$insertForm.find("tr.tools_div").css("display","none");
					}
					
					select_manCnt.attr("disabled",false);
					$insertForm.find('[data-key=TOT_COST]').text('0 원');
					
					$insertForm.find('#wholeYnCheck').attr('checked', false);
					$insertForm.find('[data-key=MAN_CNT]').css("display","");
					
					$insertForm.find('[data-key="DESCR_HTML"] div').css("display","none");	
					$insertForm.find('[pdiv="'+genreId+'"]').css("display","");				
					
					if($("#siteType").val() == "4"){
						$insertForm.find('#wholeYnCheck').prop('checked', true).trigger("change");
						$insertForm.find('[data-key=MAN_CNT]').css("display","none");
					}
																			
				});

		        // 예약 버튼 클릭 핸들러
		        $('.reservation_btn').on('click', function() {
		        	
		        	stopEvent(event);
		        	
		        	var param = _self.insertCheck();
		        	
		        	if (param == false)
	        		{
	        			return false;
	        		}		        	
		        	
		            _self.showReservationConfirmPop();
		        });
				
				// 예약하시겠습니까? 확인 버튼 클릭 핸들러
		        $('.reserv_confirm_popup_wrap .reservation_confirm_btn').on('click', function() {
		        	
		        	stopEvent(event);
		        	
		        	$('.reserv_confirm_popup_wrap').hide(); 
		        	$('#loadingbar').show();		        	
		        	
		        	var param = _self.insertCheck();
		        	_self.insertReserve(param);
		        });	
		        
				$("td").delegate( ".info_title", "click", function() {					
					var schdId = $(this).data('schdId');
					var gsWin = window.open('about:blank','detail_popup','width=600,height=600');
					var form = document.createElement("form");     
					form.setAttribute("method","post");                    
					form.setAttribute("action","schedule/detail_cap");    
					form.setAttribute("target","detail_popup");
					document.body.appendChild(form);    
					//input
					var input_id = document.createElement("input");  
					input_id.setAttribute("type", "hidden");                 
					input_id.setAttribute("name", "SCHD_ID");                        
					input_id.setAttribute("value", schdId);                          
					form.appendChild(input_id);
					 
					//폼전송
					form.submit();  					
				});
				
				$(document.body).on('click', 'a.title' ,function(){	
					var schdId = $(this).data('schdId');
					var gsWin = window.open('about:blank','detail_popup','width=600,height=600');
					var form = document.createElement("form");     
					form.setAttribute("method","post");                    
					form.setAttribute("action","schedule/detail_cap");    
					form.setAttribute("target","detail_popup");
					document.body.appendChild(form);    
					//input
					var input_id = document.createElement("input");  
					input_id.setAttribute("type", "hidden");                 
					input_id.setAttribute("name", "SCHD_ID");                        
					input_id.setAttribute("value", schdId);                          
					form.appendChild(input_id);
					 
					//폼전송
					form.submit();  				
				});
				
				
				$(document.body).on('click', '.btnModifySchedule' ,function(){				
					var schdId = $(this).attr('schdId');	
					var gsWin = window.open('about:blank','detail_popup','width=600,height=600');
					var form = document.createElement("form");     
					form.setAttribute("method","post");                    
					form.setAttribute("action","schedule/detail_cap");    
					form.setAttribute("target","detail_popup");
					document.body.appendChild(form);    
					//input
					var input_id = document.createElement("input");  
					input_id.setAttribute("type", "hidden");                 
					input_id.setAttribute("name", "SCHD_ID");                        
					input_id.setAttribute("value", schdId);                          
					form.appendChild(input_id);
					 
					//폼전송
					form.submit();  				
				});			
				
				//공지사항 팝업 수정하기
				$(document).on("click", "a.detail_notice_btn", function(){
				    var pid = $(this).attr("pid");
					location.href=_self.postInsertURL+"?POST_ID="+pid;	
				});
				
				
				$(".contents_wrap").delegate( "a.clickEvent", "click", function() {
					
					var me = $(this);
					var bbsType = me.attr("bbsType");
					var postId =me.attr("postId");
					var titleKr;
					var titleEn;
					
					if (bbsType == null)
					{
						window.location.href = _self._memReserveDetailURL + "?ID=" + me.attr("rsvId"); 						
						return;
					}					
					if (bbsType == '108_110')
					{
						titleKr = "공지";
						titleEn = "Notice";
					}
					else
					{
						titleKr = "예약안내";
						titleEn = "Reservation";						
					}					
					
					_self.$popupTitleKr.text(titleKr);
					_self.$popupTitleEn.text(titleEn);					
					
					_self.$popSubject.text("");
					_self.$popupContent.html("");
					_self.$popupDate.text("");					
					
					showPop('.notice_pop_wrap', '.popup_common_con');					
					
					var defaultParam = {
							 'POST_ID' 		: postId
						};
					
					$.ajax({
						 url : _self.postDetailURL
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data )
						    {
					    		var dtl = data.detailPost;
					    		var content = dtl.CONTENT;
					    	
								_self.$popSubject.text(dtl.TITLE);
								
								_self.$popupDate.text(dtl.CREATED_AT);	
								
								$("div.notice_pop_wrap").find("a.detail_notice_btn").attr("pid", dtl.POST_ID);
													
								var imglist = data.imageList;
								var imgtag;
								
								if (imglist != null && imglist.length > 0)
								{
									var leng = imglist.length;
									
									for (var i=0; i < leng; i++)
									{
										imgtag = "<p style='height:50px'></p><p><img src='" +  _self.$imageURL + imglist[i].IMG_ID + "/520'></p>";
										
										if (imglist[i].CONTENT != null)
										{
											imgtag = imglist[i].CONTENT ;
										}
										
									}		
									
									content += imgtag;
								}						    	
								
								_self.$popupContent.html(content);						    	
						    }
					});					

				});				

			},
			
			/** 갱신 */
			'renderScheduleList' : function() {
				
				var _self = this;
				var yearMonth = _self.yearMonth;
				
		        var tdtemp = _self.$calendarTdTemplate;		        
		        $("#tbodyCalendar td").html(tdtemp);			        
		        makeCalendar(yearMonth);
		        
		        _self.getWeatherList(yearMonth);	
		    },
			
			/**
		     * 예약확인 팝업 show
		     */
			'showReservationConfirmPop' : function() {
		        $('.reserv_confirm_popup_wrap').fadeIn(200);
		        $('.reserv_confirm_popup_con').css({top: '60%'});
		        $('.reserv_confirm_popup_con').animate({top: '50%'}, 200);
		       
//		        isScroll = false;
//		        lockScroll();
		    },
		    //byte 체크
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},
			
			'showReserveForm' : function (schdId)
			{
				var _self = this;
				
				if (isLogin() == false)
				{
					showLoginBox();
					return;
				}
				
				var insertParam = {SCHD_ID: schdId};
				
				$.ajax({
					url : _self._scheduleDetailURL
					,type : 'POST'
					,data : insertParam
					,dataType : 'json'
					,success : function( data ) {
						var $insertForm = $("#reserveForm");
						
						var item = data.detail;
						
						var siteType = item.SITE_TYPE;		
						
						$insertForm.find("span.tool1_tr_price").html("");
						$insertForm.find("span.tool2_tr_price").html("");
						$insertForm.find("span.tool3_tr_price").html("");
						$insertForm.find("[data-key='EQP1']").html("");
						$insertForm.find("[data-key='EQP2']").html("");
						$insertForm.find("[data-key='EQP3']").html("");
						$insertForm.find('tr.tool1_tr').css("display","none");	
						$insertForm.find('tr.tool2_tr').css("display","none");	
						$insertForm.find('tr.tool3_tr').css("display","none");	
																
						var choiceGenre = (item.CHOICE_GENRE == undefined || item.CHOICE_GENRE == '') ?  '' : item.CHOICE_GENRE;
						
						var availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
						if($("#waitReserveYn").val() == "Y"){
							availCnt =item.PSGR_CNT - item.RESERVE_CONFIRM_CNT - item.RESERVE_WAIT_CNT - item.WAIT_CNT;
						}
					
						var siteCheck = "N";
						//예약전 장르 선택 시
						var detailList= data.detail.detailList;
						if(choiceGenre == '' && detailList != null && detailList.length > 0){
							var html = "";
							var descrHtml = "";
							if(siteType == '3'){
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									console.log(details);
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE; 
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										html +=  details.SUB_TITLE + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}									
								}
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}else{
								html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
								for (var i = 0; i < detailList.length; i++) {
									var details = detailList[i];
									if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
										_self.detailListForReserve.push(details);
										html += "<option value='" + details.GENRE; 
										html +=  "' ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ details.PSGR_CNT+" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
										html +=  details.SUB_TITLE+ "( 시간 : " + details.SCHD_TIME_STR+ " ) " + "</option>";
										if(details.DESCR != null && details.DESCR != '')
											descrHtml += "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
									}									
								}
								$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							}
							
							availCnt = 0;
							item.PSGR_CNT = 0;
							item.FEE =0;
							item.FEE_WHOLE = 0;
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').removeAttr("pchoice");							
							$insertForm.find("#showGenre").show();
						}else if(siteType == '3' && detailList != null && detailList.length > 0){
							var descrHtml = "";
							var html = "<select id='genreSelect' style='width:220px' data-key='GENRE_ID'><option value=''>선택</option>";
							for (var i = 0; i < detailList.length; i++) {
								var details = detailList[i];
								if(details.GENRE_USEYN == 'Y'  && details.OPEN_YN == 'Y'){
									_self.detailListForReserve.push(details);
									html += "<option value='" + details.GENRE;
									html +=  "'  ptool1="+details.TOOL1+" ptool2="+details.TOOL2+" ptool3="+details.TOOL3+" pcnt="+ availCnt +" pFee="+details.FEE+" pHol="+ details.FEE_WHOLE+" >";
									html +=  details.SUB_TITLE + "</option>";
									if(details.DESCR != null && details.DESCR != '')
										descrHtml = "<div style='display:none;' pdiv='"+details.GENRE+"'>"+details.DESCR_HTML+"</div>";
								}									
							}
							$insertForm.find('[data-key=DESCR_HTML]').html(descrHtml);
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').html(html);
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", item.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
						}else{
							siteCheck="Y";
							$insertForm.find('[data-key=GENRE_INFO]').text(data.detail.SUB_TITLE +"( 시간 : "+ data.detail.SCHD_TIME_STR + " ) ");
							$insertForm.find('[data-key=GENRE_INFO]').attr("pchoice", data.detail.CHOICE_GENRE);
							$insertForm.find("#showGenre").show();
							$insertForm.find('[data-key=DESCR_HTML]').html(item.DESCR_HTML);
							

							$insertForm.find("span.tool1_tr_price").html("");
							$insertForm.find("span.tool2_tr_price").html("");
							$insertForm.find("span.tool3_tr_price").html("");
							$insertForm.find("[data-key='EQP1']").html("");
							$insertForm.find("[data-key='EQP2']").html("");
							$insertForm.find("[data-key='EQP3']").html("");
							$insertForm.find('tr.tool1_tr').css("display","none");	
							$insertForm.find('tr.tool2_tr').css("display","none");	
							$insertForm.find('tr.tool3_tr').css("display","none");	
							
							var tool1 = data.detail.GENRE_TOOL1;
							var tool2 = data.detail.GENRE_TOOL2;
							var tool3 = data.detail.GENRE_TOOL3;
							
							if(tool1 == '0'){
								$insertForm.find('tr.tool1_tr').css("display","");
								$insertForm.find("span.tool1_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool1 != null && tool1 != ''){
								$insertForm.find('tr.tool1_tr').css("display","");	
								$insertForm.find("span.tool1_tr_price").html("("+tool1+")원");
							
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP1']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool2 == '0'){
								$insertForm.find('tr.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool2 != null && tool2 != ''){
								$insertForm.find('tr.tool2_tr').css("display","");
								$insertForm.find("span.tool2_tr_price").html("("+tool2+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP2']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
							
							if(tool3 == '0'){
								$insertForm.find('tr.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("(무상대여)");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}else if(tool3 != null && tool3 != ''){
								$insertForm.find('tr.tool3_tr').css("display","");
								$insertForm.find("span.tool3_tr_price").html("("+tool3+")원");
								for (var i=0; i <= availCnt; i++)
								{
									$insertForm.find("[data-key='EQP3']").append("<option value='"+ i + "'>" + i + " 대</option>");
								}
							}
						}
						
						_self._feeWhole = item.FEE_WHOLE;
						_self._psgrCnt = item.PSGR_CNT;
						_self._nickName = data.nickName;
											
						$insertForm.find('#wholeYnCheck').attr('checked', false);	
						
						if_showhide(siteType != '3' && availCnt == item.PSGR_CNT, $insertForm.find('.wholeYnCheck'));

						_self._schdInfo = item;
													
						var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');
						
						select_manCnt.data('fee', item.FEE);			
						
						select_manCnt.empty().append('<option value="">인원 선택</option>');
					
						
						for (var i=1; i <= availCnt; i++)
						{
							select_manCnt.append("<option value='"+ i + "'>" + i + " 명</option>");
						}

						var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
						select_eqpCnt.html("");
						
						for (var i=0; i <= availCnt; i++)
						{
							select_eqpCnt.append("<option value='"+ i + "'>" + i + " 대</option>");
						}
																				
						var bankAccnHolder;
						
						_self.vrBankingYn = (item.VR_BANKING_YN == "Y");
						
						if (_self.vrBankingYn)
						{
							$insertForm.find('[data-key=BANK_CD]').val("");	
							$insertForm.find('[data-key=BANK_CD]').show();	
							bankAccnHolder = "* 입급할 은행선택(가상계좌입금)";						
						}
						else
						{
							bankAccnHolder =  item.BANK_NM + " " + item.BANK_ACCN + " " + item.BANK_HOLDER;
							$insertForm.find('[data-key=BANK_CD]').hide();	
						}
						
						$insertForm.find('[data-key=BANK_ACCN_HOLDER]').text(bankAccnHolder);						
						
						$insertForm.find('[data-key=TOT_COST]').text('0 원');
						// 관리자는 입금자명을 비운다.
						$insertForm.find('[data-key=DEPOSIT_NAME]').val('');
						
						//장르가 1개이면 첫번쨰것을 자동선택
						if($("#genreSelect option").size() == 2){
							$("#genreSelect option:eq(1)").attr("selected","selected");
							$("#genreSelect").trigger("change");
						}
						
						$insertForm.find('[data-key=NOTICE_HTML]').html(item.NOTICE_HTML);
						
						if(siteCheck == "Y" && $("#siteType").val() == "4"){
								$insertForm.find('#wholeYnCheck').prop('checked', true).trigger("change");
								$insertForm.find('[data-key=MAN_CNT]').css("display","none");
						}
						
						showReservationPop();						
					}
				});			
			},			
			
			'getWeatherDetail' : function(wDate) {
					
					var _self = this;
					
					var insertParam = {
							'WEATHER_DATE' :  wDate
						   ,'SHIP_ID'  :  _self.$shipId
					};
					
					$.ajax({
						url : _self._scheduleWeatherURL
						,type : 'POST'
						,data : insertParam
						,dataType : 'json'
						,success : function( data ) {
							if(data.hasOwnProperty('marineWeather')){
								
								var wDate = data.marineWeather.WEATHER_DATE;
								var $td = _self.$calendarContainer.find('td#' + wDate);								
								
								var ymd = $td.data('date') + ' ' + $td.data('day') + '요일';
								var mull = $td.data('mull');
								
								_self.$weatherDiv.find("[data-key='ymd']").text(ymd);
								_self.$weatherDiv.find("[data-key='mull']").text(mull);
								
								var weatherCond = data.marineWeather.WEATHER_COND;
								var windDirect = data.marineWeather.WIND_DIRECT;
								var waveHeight = data.marineWeather.WAVE_HEIGHT;
								var windSpeed = data.marineWeather.WIND_SPEED;
								
								if (windDirect == " ")
								{
									windDirect = ",";
									windSpeed = ",";
								}

								var arrWeatherCond = weatherCond.split(",");
								var arrWindDirect = windDirect.split(",");
								var arrWaveHeight =  waveHeight.split(",");
								var arrWindSpeed = windSpeed.split(",");

								var tds = _self.$weatherInfoTbl.find('td');
								
								var img0 = arrWeatherCond[0] == '' ? '' : 'https://www.kma.go.kr/' + arrWeatherCond[0];
								var img1 = 'https://www.kma.go.kr/' + arrWeatherCond[1];
								
								tds.eq(0).find('img').attr('src', img0);
								tds.eq(1).find('img').attr('src', img1);
								
								if_showhide(img0 != "", tds.eq(0).find('img'));
								
								tds.eq(2).text(arrWaveHeight[0]);
								tds.eq(3).text(arrWaveHeight[1]);

								tds.eq(4).text(arrWindDirect[0]);
								tds.eq(5).text(arrWindDirect[1]);
								
								var winsp0 = arrWindSpeed[0] == '' ? '' : arrWindSpeed[0] + " m/s";
								var winsp1 = arrWindSpeed[1] == '' ? '' : arrWindSpeed[1] + " m/s";
								
								tds.eq(6).text(winsp0);
								tds.eq(7).text(winsp1);
							}

					}});				
			},

			
			'getWeatherList': function (yearMonth) {
				
				var _self = this;
				
				$.ajax({
					url : _self._scheduleWeatherDateURL
					,type : 'POST'
					,data : null
					,dataType : 'json'
					,success : function( data ) {
						if(data.hasOwnProperty('weatherDateList')){
							var weatherDateList = data.weatherDateList;
							var wDate;
							
							var td;
							var weatherBtn ='<p class="weather"><a><img class="weather_btn" src="https://img.fishapp.co.kr/legacy/wp/weather_btn.png" alt="날씨" data-date="$wDate"/></a></p>';
									
							for(var j =0; j <weatherDateList.length; j++){								
								
								wDate = weatherDateList[j].WEATHER_DATE;
								td = _self.scCalendarTbl.find("#" + wDate +">div");								
								
								if(td){									
									
									td.append(weatherBtn.replace("$wDate", wDate));
								}
							}							
						}						
						_self.getScheduleList({'SCHD_MONTH' : yearMonth });
					}
				});				
			},
			
			
			// 예약금액 자동 셋팅
			'totalCost' : function(man, fee) {
				var _self = this;
				var $insertForm = $("#reserveForm");

				var sum = man * fee;
				if( !sum ) sum = 0;
				$insertForm.find('[data-key=TOT_COST]').text( stringFilter(sum, 'money') + ' 원');

			},
			
			//데이터 체크
			'insertCheck': function()
			{
				var _self = this;
				
				var schdInfo = _self._schdInfo;
				
				var $insertForm = $("#reserveForm");
				// validation
				var today = jdg.util.today().replaceAll('-','');
				
				 var totCost = $insertForm.find('[data-key=TOT_COST]').text();
				 totCost = totCost.replaceAll( ',', '' );
				 totCost = totCost.replaceAll( '원', '' );
				 
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();
				var wholeYnCheck = $insertForm.find('#wholeYnCheck').is(':checked') ? "Y" : "N";
				
				
				var genreId = $insertForm.find("[data-key=GENRE_INFO]").attr("pchoice");
				if(genreId == '' || genreId == undefined){
					genreId = $insertForm.find("#genreSelect option:selected").val();
				}
								
				if(genreId == ""){
					alert("장르를 선택해주세요.");
					return false;
				}
				
				if (manCnt == "" || manCnt == "인원 선택")
				{
					alert("예약인원을 선택하십시오.");
					return false;
				}
				
				var eqpCnt = $insertForm.find('[data-key=EQP_CNT]').val();
				
				if (eqpCnt == "")
				{
					alert("장비대여 대수를 선택하십시오.");
					return false;
				}				
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val().trim();
				var dispCd = $insertForm.find('[data-key=DISP_CD]').val();
				var seatTxt = $insertForm.find('[data-key=SEAT_TXT]').val();
				
				var nickName = _self._nickName;
				
				var dispTxt = "예약자표시";
				
				if (dispCd == '1') {dispTxt = rsvDepositName;  }
				else if (dispCd == '2') {dispTxt = rsvName;  }
				else if (dispCd == '3') {dispTxt = nickName;  }
				
				
				var $bankCd = $insertForm.find('[data-key=BANK_CD]');
				var bankCd = $bankCd.val();
				var vrBankingYn;
				
				if (rsvTel == "")
				{
					alert("전화번호를 입력해주십시오.(비정상적인 전화번호를 넣으면 예약이 되지 않습니다.)");
					return false;
				}
				
				if (_self.vrBankingYn)
				{
						if( bankCd == '') {
						alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
						return false;
					}
					
					vrBankingYn = "Y";
				}
				else
				{
					vrBankingYn = "N";
					bankCd = null;
				}
				
				if( rsvName == '' && rsvTel == '' &&  rsvEmail == '' ) {
					alert('예약자 정보를 입력해 주세요');
					return false;
				}
				
				if( rsvDepositName == '') {
					alert('입금자명을 입력해 주세요');
					return false;
				}
				
				var insertParam = {
						  'SCHD_ID' : schdInfo.SCHD_ID
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : rsvEmail
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'EQP_CNT' : $insertForm.find('[data-key=EQP_CNT] option:selected').val()
						, 'BANK_CD' : bankCd
					    , 'VR_BANKING_YN' : vrBankingYn
					    , 'WHOLE_YN' : wholeYnCheck
					    , 'DISP_CD' : dispCd
					    , 'DISP_TXT' : dispTxt
					    , 'SEAT_TXT' : seatTxt
					    , 'GENRE_ID' : genreId
					    , 'TOT_COST' : totCost
					    ,'EQP1' :  $insertForm.find('[data-key=EQP1] option:selected').val()
					    ,'EQP2' :  $insertForm.find('[data-key=EQP2] option:selected').val()
					    ,'EQP3' :  $insertForm.find('[data-key=EQP3] option:selected').val()
					};
				
				return insertParam;
			},
			
			
			// 예약등록
			'insertReserve' : function(insertParam) {
				
				var _self = this;
				
				$.ajax({
					 url : _self._reserveInsertURL
					,type : 'POST'
					,data : insertParam
				    ,dataType : 'json'
				    ,success : function( data ) {
						// 로더 제거
				    	$('#loadingbar').hide();
			            hideReservationConfirmPop();
			            hideReservationPop();				    	
				    	
				    	if (data.error == undefined)
				    	{
					    	var rsv_Id = data.rsv_Id;
					    	if( rsv_Id != null &&  rsv_Id != undefined ) {
					    		
						    	isScroll = true;
						    	unlockScroll();			
					            showPop('.reserv_com_pop');
					            _self.renderScheduleList();
					    	}
				    	}
				    	else
				    	{
				    		if (data.error.userMessage)
				    		{
				    			alert(data.error.userMessage);
				    		}				    	
				    	}
				    	
				    	isScroll = true;
				    	unlockScroll();
				    }
				});
			},	
			
			// 출조스케쥴 목록 조회
			'getScheduleList' : function( param ) {
				var _self = this;
				var tmpDay = new Date();
				$.ajax({
					 url : _self.listForManagerURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	var scheduleList = data.scheduleList;
				    	console.log(scheduleList);
			    		_self.currentScheduleList = scheduleList;	
			    		var watingList = data.watingList;
			    		
			    		var reserveMap1 = {};	   
			    		var reserveMap2 = {};
			    		var mapData1;
			    		var mapData2;
			    		var rsvStatus;
			    		
			    		var str1;
			    		var str2;
			    		var seatText;
			    		var isBlink = false;	
			    					    		
			    		
			    		$.each( data.reserveList, function( idx, data ) {
			    			
			    			mapData1  = reserveMap1[data.SCHD_ID];
			    			mapData2 = reserveMap2[data.SCHD_ID];
			    			rsvStatus = data.STATUS_CD;
			    			
			    			if (mapData1 == null)
			    			{
			    				mapData1 = "";
			    				mapData2 = "";
			    			}	
			    			
			    			seatText = (data.SEAT_TXT == null) ? "" : " 자리: " + data.SEAT_TXT;
			    			
			    			var cancel_class = "";
			    			var span1;
			    			var span2
			    			
							switch(data.STATUS_CD)
							{
								case "104_300": 	span1 = ' <span class="finish">입금완료</span></li>'; 
													span2 = ' <span class="fin">입금완료</span></p>';
													break;
								case "104_310": 	span1 = ' <span class="yet">미입금</span></li>'; 
													span2 = ' <span class="yet">미입금</span></p>';
													break;
								case "104_320": 	span1 = ' <span class="finish">부분입금</span></li>'; 
													span2 = ' <span class="fin">부분입금</span></p>';
													break;
								case "104_340": 	span1 = ' <span class="finish">확정(미입금)</span></li>'; 
													span2 = ' <span class="finish">확정(미입금)</span></p>';
													break;
								case "104_410": 	span1 = ' <span class="cancel">취소</span></li>'; 
													span2 = ' <span class="cancel">취소</span></p>';
													cancel_class = " cnl";
													break;
								case "104_420": 	span1 = ' <span class="cancel">취소(환불예정)</span></li>'; 
													span2 = ' <span class="cancel">취소(환불예정)</span></p>';
													cancel_class = " cnl";
													break;
								case "104_430": 	span1 = ' <span class="cancel">취소(환불완료)</span></li>'; 
													span2 = ' <span class="cancel">취소(환불완료)</span></p>';
													cancel_class = " cnl";
													break;
							}
			    			
							var fishapp_ico_css = "";							
							if (data.SITE_CD == 'P') {fishapp_ico_css = " fico";}
							else if (data.SITE_CD == 'S') {fishapp_ico_css = " sundan";}	
							else if(data.SITE_CD == 'C') {fishapp_ico_css = " coupang";}
							
							var vrpaid_ico = (data.VR_PAID_AT) ? " <span class='vrpaid' title='가상계좌 입금완료: " + dateToString(new Date(data.VR_PAID_AT.time)) + "'>P</span>" : "";
			    			
			    			
			    			str1 = '<li>'+ data.RSV_INFO.replace('(', ' 님(');
			    			
			    			if($("#siteType").val() != "4"){
			    				if(data.DISP_TXT == undefined || data.DISP_TXT == "" || data.DISP_TXT == "undefined"){
			    					data.DISP_TXT = data.RSV_NAME;
			    				}
			    				str2 = '<p class="p2 ' + cancel_class + fishapp_ico_css + '">' + vrpaid_ico + data.DISP_TXT + " 님(" + data.MAN_CNT + "명" +  seatText +")" ;
					    	}else{
					    		if(data.DISP_TXT == undefined || data.DISP_TXT == "" || data.DISP_TXT == "undefined"){
			    					data.DISP_TXT = data.RSV_NAME;
			    				}
					    		str2 = '<p class="p2 ' + cancel_class + fishapp_ico_css + '">' + vrpaid_ico + data.DISP_TXT + " 님" ;
			    			}
			    			reserveMap1[data.SCHD_ID] = mapData1 + str1 + span1;
			    			reserveMap2[data.SCHD_ID] = mapData2 + "<p>" + str2 + span2 + "<span class='btn1 btnModifyRsv' rsv_id='" + data.RSV_ID +"'>변경</span></p>";
			    		});			    		
			    		
			    		
			    		
			    			if(watingList != null){
			    				$.each(watingList, function(idx, info){
			    					reserveMap1[info.SCHD_ID] = reserveMap1[info.SCHD_ID] + info.USER_NAME + " 예약대기";
			    					reserveMap2[info.SCHD_ID] =  reserveMap2[info.SCHD_ID] + "<p style='' class='p2'>"+info.USER_NAME+"("+ info.WATING_PSGR_CNT +"명, "+ info.USER_PHONE+") 예약대기 <span class='btn1 watingDeleteBtn' pid="+info.SEQ+">삭제</span></p><br/>";
			    				});
			    		}
			    		_self.$calendarListContainer.find("tbody>tr").remove(); 	

			    		
			    		$.each( scheduleList, function( idx, data ) {
			    			
			    			
			    			var scTimeType = data.SCHD_TIME_TYPE;
			    		
			    			_self.makeRow(data, reserveMap1, reserveMap2 );
			    			
			    		});			    		
			    		
			    		var calendarTdList = $("#tbodyCalendar>tr>td[id!='']");	
			    		var $listCon = _self.$calendarListContainer;
			    		
			    		//ie7,8 버그대응
			    		for (var i=calendarTdList.length - 1; i >= 0 ; i--)
			    		{
			    			if (calendarTdList[i].id == "")
			    			{
			    				calendarTdList.splice(i,1);
			    			}
			    		}
			    					    		
			    		$.each( calendarTdList, function( idx, tdObj ) {

			    			if (_self._interval_id)
			    			{
			    				clearInterval(_self._interval_id);			    				
			    				_self._interval_id = null;
			    			}
			    		
			    			var $td = $(tdObj);
			    			
			    			var $listRow = _self.$template2.clone(); // 세로캘린더용 템플릿			    			
			    			$listRow.attr('id', tdObj.id);			    			
			    			
			    			var day = idx + 1;
			    			
			    			var dayNum = (day + firstRangeIndex - 1) % 7;
			    			
			    	        var dateTd = $listRow.find('.date');
			    	        var dayTd = $listRow.find('.day');
			    			
			    	        if (dayNum == 0) {
			    	            dateTd.addClass('sun');
			    	            dayTd.addClass('sun');
			    	            $listRow.css('background-color', '#FFF2F2');
			    	        } else if (dayNum == 6) {
			    	            dateTd.addClass('sat');
			    	            dayTd.addClass('sat');
			    	            $listRow.css('background-color', '#E0F1FB');			    	            
			    	        } else {
			    	            dateTd.removeClass('sat');
			    	            dayTd.removeClass('sat');
			    	            dateTd.removeClass('sun');
			    	            dayTd.removeClass('sun');
			    	        }
			    	        
			    	        var dayNm = dayList[dayNum];
			    	        dayTd.text(dayNm);

			    	        
			    	        $listRow.find(".date").html(day);
			    	        
			    	        var tdTemp1List = $td.find('div#template1');
			    	        
			    	        if (tdTemp1List.length > 0)
			    	        {
			    	        	var rowspan = tdTemp1List.length;
			    	        	
			    	        	if (rowspan > 1)
			    	        	{
			    	        		$listRow.find('.spanrow').attr('rowSpan',rowspan);
			    	        	}
			    	        
			    	        	
			    	        	$.each(tdTemp1List, function( idx, templateObj ) {
			    	        			    	        		
			    	        		if (idx > 0)
			    	        		{
			    	        			var color = $listRow.css('background-color');			    	        			
			    	        			
			    	        			$listRow = _self.$template2.clone();
			    	        			$listRow.find('.spanrow').remove();
			    	        			
			    	        			if (color != '')
			    	        			{
			    	        				$listRow.css('background-color',  color);
			    	        			}
			    	        		}			    	        		
			    	        		
			    	        		var scdata = $(templateObj).data('scdata');
			    	        		
			    	        		var notice_text = "";
			    	        		
						    		if (scdata.NOTICE_TEXT != null)
						    		{
						    			notice_text = '<p class="p1">' + scdata.NOTICE_TEXT.replaceAll("\n","<br>") + '</p>';
						    		}
						    		
			    	        		var memo_text = "";
			    	        		
						    		if (scdata.MEMO != null)
						    		{
						    			memo_text = '<div class="memo">' + scdata.MEMO.replaceAll("\n","<br>") + '</div>';
						    		}

						    		var rsv_text = "";
						    		var reserveYn = true;
						    		
						    		if (scdata.RSV_STRING != null)
						    		{
						    			rsv_text = scdata.RSV_STRING;
						    		}
						    		
						    		if (scdata.STATUS_NM == "예약가")
				    	        	{
				    	        		$listRow.find('td.status').html('<span class="possible" style="cursor:pointer">예약하기</span>');
				    	        		$listRow.find('td.status>span').data('schd_id',scdata.SCHD_ID);
				    	        	}
				    	        	else
				    	        	{
				    	        		if (scdata.STATUS_CD == '113_210')				    	        			
				    	        		{
				    	        			if (scdata.CANCEL_DESC != null && scdata.CANCEL_DESC.substr(0,4) == '기상악화')
					    	        			{
				    	        					isBlink = true;
				    	        					$listRow.find('td.status').html('<span class="cancel blink">출조취소</span>');
					    	        			}
						    	        	else
						    	        		{
						    	        			$listRow.find('td.status').html('<span class="cancel" title="' +  scdata.CANCEL_DESC  + '">출조취소</span>');
						    	        		}
				    	        		}
				    	        		else
				    	        		{
				    	        			$listRow.find('td.status').html(scdata.STATUS_NM );
				    	        		}
				    	        		
				    	        		
				    	        		$listRow.find('td.yes_no').html('');
				    	        		reserveYn = false;
				    	        	}
						    								    		
						    		var type = $(templateObj).find(".info_title").attr("type");
				    	        	var scTimeType = scdata.SCHD_TIME_TYPE;
						    		var choiceGenre = scdata.CHOICE_GENRE;
					    			choiceGenre = ( choiceGenre == undefined )? '' : choiceGenre;
					    			
					    			$listRow.find('a.title').data('schdId', scdata.SCHD_ID);
				    	     	
					    			if(choiceGenre == '' && scTimeType == '0' && (scdata.SUB_TITLE == undefined || scdata.SUB_TITLE == null)){
					    				var prefix="";
					    				if(scdata.SUB_SHIPNM != '' && scdata.SUB_SHIPNM != undefined){
					    					if(scdata.SUB_SHIPFILE != '' && scdata.SUB_SHIPFILE != undefined){
					    						$listRow.find("td.title p").attr("style", "vertical-align: middle;padding-left:10px;").before("<img width='70px' height='42px' src='/cm/file/image/"+scdata.SUB_SHIPFILE +"/50'>");
					    					}
					    					prefix = "<span style='font-size:13px;color:#3170e1;text-decoration:none;letter-spacing:-0.8px;'>["+ scdata.SUB_SHIPNM + "]</span><br/>";
						    			}
					    				var genreCnt = 0;
					    				var subtitle = "";
					    				if(scdata.GENRE_USEYN1 == 'Y' && scdata.GENRE1_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE1;
					    				}
					    				if(scdata.GENRE_USEYN2 == 'Y' && scdata.GENRE2_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE2;
					    				}
					    				if(scdata.GENRE_USEYN3 == 'Y' && scdata.GENRE3_OPENYN == 'Y'){
					    					genreCnt++;
					    					subtitle = scdata.SUB_TITLE3;
					    				}
					    				
					    				var title = "출조합니다.";
					    				if(genreCnt == 1){
					    					title = subtitle;
					    				}
					    				$listRow.find('a.title').html(prefix+title);
					    				$listRow.find('td.title').append("<span class='btn1 btnModifySchedule' schdId='" + scdata.SCHD_ID +"'>수정</span></p>");
					    				if(scdata.STATUS_CD == '113_110')
					    					$listRow.find('td.yes_no').html('<span class="yes">'+scdata.GENRE_MINCNT + ' ~ </span>');
					    			}else{
					    				var prefix="";
					    				if(scdata.SUB_SHIPNM != '' && scdata.SUB_SHIPNM != undefined){
					    					if(scdata.SUB_SHIPFILE != '' && scdata.SUB_SHIPFILE != undefined){
					    						$listRow.find("td.title p").attr("style", "vertical-align: middle;padding-left:10px;").before("<img width='70px' height='42px' src='/cm/file/image/"+scdata.SUB_SHIPFILE +"/50'>");
					    					}
					    					prefix = "<span style='font-size:13px;color:#3170e1;text-decoration:none;letter-spacing:-0.8px;'>["+ scdata.SUB_SHIPNM + "]</span>";
					    				}
					    				if(scTimeType == '1'){ //생활낚시
					    					$listRow.find('a.title').html(prefix + "<span style='text-decoration:underline;'>"+ scdata.SUB_TITLE+ "("+ scdata.SCHD_TIME.substr(0,2) + ':' + scdata.SCHD_TIME.substr(2,2) +")</span>");
					    				}else{
					    					$listRow.find('a.title').html(prefix+"<span style='text-decoration:underline;'>"+scdata.SUB_TITLE+"</span>");
					    				}
					    	        	if(reserveYn){
					    	        		$listRow.find('td.yes_no').html('<span class="yes">' + scdata.AVAIL_CNT +'</span>');	
					    	        	}
					    	        	$listRow.find('td.title').append("<span class='btn1 btnModifySchedule' schdId='" + scdata.SCHD_ID +"'>수정</span></p>");
					    						    	        	
					    			}
					    			
					    			//예약자가 있는 경우에만(상태값 필요없음)
				    	        	if(	reserveMap1[scdata.SCHD_ID] || reserveMap2[scdata.SCHD_ID] ){
				    	        		$listRow.find('td.title').append("<span style='display:inline-block;margin-top:3px;padding-left:3px;padding-right:3px;border-width:1px;color: #3F51B5;border-color: #00008094;vertical-align:middle;'  class='btn1 btnSendMsg' schddate='"+scdata.SCHD_DATE+"' sendmsgyn='"+$("#sendMsgYn").val()+"' schdId='" + scdata.SCHD_ID +"'>메시지 전송</span>");
				    	        	
				    	        		//$listRow.find('td.title').append('<a href="#" style="margin-left:5px;display:inline-block; width: 26px; height: 26px;vertical-align:middle"><img src="/resources/cm/images/icon_ques.png" alt="도움말" /></a>');
				    	        			
				    	        	}
					    						    	        					    	        	
						    	        	
				    	        	if (scdata.TOT_EQP_CNT != null && scdata.TOT_EQP_CNT !=0)
				    	        		{
				    	        			$listRow.find('td.eqp_cnt').text(scdata.TOT_EQP_CNT);
				    	        		}
 				    	        	
				    	        	$listRow.find('div.reservers').html(notice_text + rsv_text + memo_text);
				    	        					    	        	
				    	        	if (scdata.AVAIL_CNT < 0 && scdata.STATUS_NM == "마감")
				    	        	{
				    	        		var exceed = scdata.AVAIL_CNT * -1;
				    	        		
				    	        		$listRow.find('td.yes_no').html('<span style="color:yellow;background-color:red;padding:10px">' + exceed + '명 초과</span>');
				    	        	}
				    	        	
				    	        	
				    	        	$listCon.append($listRow);
			    	        	});
			    	        }
			    	        else
			    	        {
			    	        	$listCon.append($listRow);			    	        	
			    	        }
			    	       
			    		});
			    		
		    	        
			    		if (isBlink)
			    		{
			    			_interval_index = 0;			    			
			    			_interval_objs = $('span.blink');
			    			_self._interval_id = setInterval(_self.blinkEffect, 500);
			    		}
			    		
						
				    	var seatimeList = data.seatimeList;
				    	
			    		$.each( seatimeList, function( idx, data ) {
			    			
			    			var _td = _self.scCalendarTbl.find("#" + data.SOLAR_DATE);
			    			_td.find('.mull').text( data.MOOL );
			    			_td.data('mull',data.MOOL);
			    			
			    			var _tr = _self.$calendarListContainer.find("#" + data.SOLAR_DATE);
			    			_tr.find('.mull').text( data.MOOL );
			    			
							if (isHoliday(data.SOLAR_DATE))
							{
								_tr.find('td.date,td.day').addClass('sun');
								_tr.css('background-color', '#FFF2F2');
							}
			    		});
				    }
				});
			},
			'makeRow' : function(data, reserveMap1, reserveMap2){
				var _self = this;
				var tmp1 = _self.$template1.clone();

	  			var scTimeType = data.SCHD_TIME_TYPE;
    			var scTime = data.SCHD_TIME;
    			
    			var availCnt = data.PSGR_CNT - data.RESERVE_CONFIRM_CNT;
    			if($("#waitReserveYn").val() == "Y"){
    			 availCnt = data.PSGR_CNT - data.RESERVE_CONFIRM_CNT - data.RESERVE_WAIT_CNT - data.WAIT_CNT;
    			}
    			
    			var statusNm;
    			
    			if(scTime != '' && scTime != undefined){
    				tmp1.find(".time_member").html(scTime.substr(0,2) + ':' + scTime.substr(2,2) + '&nbsp;' + availCnt + "명");
    			}
    			
    			tmp1.find(".info_title").text(data.SUB_TITLE);
    			if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined)
    				tmp1.find(".info_title").text("("+ data.SUB_SHIPNM+ ")"+ data.SUB_TITLE);
    			else
    				tmp1.find(".info_title").text(data.SUB_TITLE);
    			
    			var choiceGenre = data.CHOICE_GENRE;
    			choiceGenre = ( choiceGenre == undefined )? '' : choiceGenre;
    				    			
    			var psgrHtml = "";
    			if(scTimeType == '0' && choiceGenre == ''){
    				var genreCnt = 0;
    				var subtitle = "";
    				if(data.GENRE_USEYN1 == 'Y' && data.GENRE1_OPENYN == 'Y'){
    					genreCnt++;
    					subtitle = data.SUB_TITLE1;
    				}
    				if(data.GENRE_USEYN2 == 'Y' && data.GENRE2_OPENYN == 'Y'){
    					genreCnt++;
    					subtitle = data.SUB_TITLE2;
    				}
    				if(data.GENRE_USEYN3 == 'Y' && data.GENRE3_OPENYN == 'Y'){
    					genreCnt++;
    					subtitle = data.SUB_TITLE3;
    				}
    				
    				var title = "출조합니다.";
    				if(genreCnt == 1){
    					title = subtitle;
    				}
    				if(data.SUB_SHIPNM != '' && data.SUB_SHIPNM != undefined)
    					tmp1.find(".info_title").text("("+ data.SUB_SHIPNM+ ") "+title);
    				else
    					tmp1.find(".info_title").text(title);
				
    				data.GENRE_MINCNT =  data.PSGR_CNT;
    				tmp1.find(".time_member").html("시간 미정 - "+ (data.PSGR_CNT == undefined ? "": data.PSGR_CNT + "명~ "));
    			}
    			
    			
    			tmp1.find(".info_title").data('schdId', data.SCHD_ID);

    			data.AVAIL_CNT = availCnt;
    			
    			var lstString = reserveMap1[data.SCHD_ID];
    			
    			if (lstString == null)
    			{
    				lstString = "";
    			}
    			else
    			{
    				lstString += "<br>";
    			}

    			tmp1.find(".info_con").append(lstString);
    			
    			data.RSV_STRING = reserveMap2[data.SCHD_ID];
    			
    			var $td = _self.scCalendarTbl.find("#" + data.SCHD_DATE);
    			var $div = $td.find("div").eq(0);
    			
    			
    			$td.find('.sc_con').append(tmp1);
    			    			
    			// 상태가 정상이 아니거나, 정상이어도 인원이 마감되거나 기한이 지난 것은 예약불가 상태로 처리			    			
    			if (data.STATUS_CD != "113_110" || availCnt <= 0 )
    			{	
    				if (data.STATUS_CD == "113_180")
    				{
    					statusNm = "만료"; //예약가능한 날짜가 지남
    				}
    				else if (availCnt <= 0 )
    				{
    					statusNm = "마감"; //예약인원이 마감
    				}
    				else
    				{
    					statusNm = data.STATUS_NAME;
    				}

    			}
    			else
    			{
    				$div.attr('class', 'possible');
    				statusNm = "예약가";
    				tmp1.find(".poss_icon").data('schd_id', data.SCHD_ID);
    			}
    			
    			
    			data.STATUS_NM = statusNm; 
    			tmp1.data('scdata',data);
			},			
			'blinkEffect' : function()
			{
				  var _self = this;
				  
				  _interval_index ++;		

				  var comp = _self._interval_objs;  
				  var status = _self._interval_index;				  
				  
				  if (status == 1 || status == 3)
				  {
				  	comp.text("");
				  }
				  else if (status == 2)
				  {
				  	comp.text("기상악화");
				  	comp.css("color", "#FF9B00");
				  }
				  else if (status == 4)
				  {
				  	comp.text("출조취소");
				  	comp.css("color", "#FF4B4B");
				  	_self._interval_index = 0;
				  }					
			},

			
			// 공지사항 목록 조회
			'getPostList' : function( bbsType, page ) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer;
				_paging = $('#postListPaging');
				
				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: bbsType
				};
				$.ajax({
					 url : _self.postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('postList') ) {
				    		// 초기화
				    		_contatiner.empty();
				    		var list = data.postList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$postNoDataTemplate.clone();
				    			_self.$listContainer.append( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $row = _self.$postListTemplate.clone();
					    			
					    			if (idx % 2 == 1)
					    			{
					    				$row.addClass("even");
					    			}
					    			
					    			$row.attr( 'rowKey', data.POST_ID );
					    			
					    			var titleLink = $row.find('a');
					    			
					    			titleLink.attr( 'postId', data.POST_ID );
					    			titleLink.attr( 'bbsType', bbsType );					    			
					    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;

					    			// 제목
					    			$row.find('[data-key=TITLE]').text( data.TITLE );

					    			// 등록일
					    			if( data.UPDATED_AT ) {	// 업데이트 시간이 있을경우
					    				data.UPDATED_AT = data.UPDATED_AT.substr(0, 10);
					    				$row.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
					    			}else{	// 없을경우
					    				data.CREATED_AT = data.CREATED_AT.substr(0, 10);
					    				$row.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			}
					    			
					    			_contatiner.append( $row );
					    		});					    		
					    	}
				    		
					    	var numOfPages = Math.ceil(data.total / itemCnt);
					    	
				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: numOfPages
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
									_self.getPostList( bbsType, page );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		
				    		if (numOfPages > 5)
					    		_paging.find('.paging_next').text(">");				    		
				    	}
				    }
				});
			},			

			
			'getMyReserveList' : function(page) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer2;
				_contatiner.empty();
				
				if (isLogin() == false) 
				{
					_contatiner.append( '<td colspan=5> 예약 내역이 없습니다.</td>');
					return;
				}
								
				_paging = $('#resvListPaging');

				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
						 'PAGE' : page
						,'PERPAGE' : '5'
				};
				$.ajax({
					 url : _self._myReserveListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	$.each(data.memReserveList, function(idx,data) {
				    		
			    		 $row = _self.$resvListTemplate.clone();		
			    		 
			    			if (idx % 2 == 1)
			    			{
			    				$row.addClass("even");
			    			}
				    		 
				    		 $row.attr('id', null);
				    		 
				    		 if (data.STATUS_CD == '104_300')
			    			 {
				    			 data.STATUS_NAME = '<span class="finish">입금완료</span>';
			    			 }				    		 
				    		 
				    		 setFiledByDataFilter($row, 'SCHD_DATE', data, 'date');
				    		 setFiledByData($row, 'SUB_TITLE', data);
				    		 setFiledByData($row, 'MAN_CNT', data);				    		 
				    		 setFiledByData($row, 'STATUS_NAME', data);
				    		 setFiledByDataFilter($row, 'TOT_COST', data, 'money');
				    		 
			    			 var titleLink = $row.find('a');
			    			
			    			 titleLink.attr( 'rsvId', data.RSV_ID );
				    		 
				    		 _contatiner.append( $row );		    			
				    	 });
				    	
				    	var numOfPages = Math.ceil(data.total / itemCnt);
				    	
			    		// 페이징 초기화
			    		$(_paging).paging({
							 current: page
							,max: numOfPages
							,itemClass: ''
							,prevClass: 'paging_prev'
							,nextClass: 'paging_next'
							,firstClass: ''
							,lastClass: ''
							,length: 5
							,itemCurrent: 'on'
							,onclick:function(e,page){
								_self.getMyReserveList(page );
							}
						});	
			    		
			    		if (page <= 5)
			    		{
			    			_paging.css("margin-left","40px");
			    		}
			    		else
			    		{
			    			_paging.css("margin-left","");
			    		}
			    		
			    		_paging.find('.paging_prev').text("<");
			    		
			    		if (numOfPages > 5)
			    		_paging.find('.paging_next').text(">");	
				    }
				});				
			},	
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				//캘린더 <,> 버튼 마우스포인트 처리
				_self.$calendarMoveBtn.css('cursor','pointer');
				
				_self.getMyReserveList('1');				
				_self.getPostList('108_110', '1' );
				
		        var date = new Date();
		        var month = date.getMonth() + 1;
		        
		        date.setDate(1);
		        
		        _self.selectDate = date;
		        _self.yearMonth = date.getFullYear() +  ((month < 10)? "0" + month: "" + month);
		        _self.renderScheduleList();
		        
		        var today = jdg.util.today();				
				$('#textDatePicker').val(today);
				
				// 파일리스트
				_self.fileList  = new component.FileList({
					 'id' : this.$smsPopWrap.attr('id')
					,'container' : this.$smsPopWrap.find('[data-type=IMAGE_LIST]')
					,'selection' : "N"
					,'max_file' : 3
				});
				// 파일리스트 초기화
				_self.fileList.init();
		        
			},
			
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
