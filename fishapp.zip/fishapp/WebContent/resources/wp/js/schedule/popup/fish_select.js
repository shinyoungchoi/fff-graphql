$(function() {
	
		"use strict";
		var $preferenceFish = $('.preference-fish'),
			$preferenceFishItem = $preferenceFish.find('.popularity-listitem, .general-listitem'),
			$preferenceFishChoice = $preferenceFish.find('.choice-fish-listbox'),
			$preferenceFishChoiceList = null,
			$preferenceFishChoiceListitem = null,
			preferenceFishChoiceListName = 'choice-fish-list',
			preferenceFishMax = 3;
		$preferenceFishItem.on('click', function(e) {
				var _this = $(this),
					_state = _this.hasClass('is-selected');
				if(_state === true) { // 삭제
					$preferenceFishChoiceList = $preferenceFishChoice.find('.'+preferenceFishChoiceListName);
					$preferenceFishChoiceListitem = $preferenceFishChoiceList.find('li');
					$preferenceFishChoiceListitem.filter(':contains('+_this.text().trim()+')').remove();
					if($preferenceFishChoiceListitem.length - 1 == 0) {
						$preferenceFishChoice.addClass('is-nothing');
						$preferenceFishChoiceList.remove();
					}
					_this.removeClass('is-selected');
				} else if(_state === false && $preferenceFishItem.filter('.is-selected').length < preferenceFishMax) { // 추가
					if($preferenceFishChoice.find('.'+preferenceFishChoiceListName).length == 0) {
						$preferenceFishChoice.removeClass('is-nothing').prepend('<ul class="'+preferenceFishChoiceListName+'"></ul>');
					}
					$preferenceFishChoiceList = $preferenceFishChoice.find('.'+preferenceFishChoiceListName);
					$preferenceFishChoiceList.append('<li class="choice-fish-listitem">'+_this.text()+'</li>');
					_this.addClass('is-selected');
				}
		});
		
		function load(){
			var _param = shared.pt.fish.param;
			
			if (_param && _param.fish)
			{
				var _arry = _param.fish;
				$(_arry).each(
					
						function(i,e)
							{ 
								$( "li:contains('" + e + "')" ).trigger('click');
							});		
			}
		}
		
		$('#fishSubmit').click(function(){
			var fishes = tbQ.util.listToArray('ul.choice-fish-list li');
			shared.pt.fish.param = { fish : fishes};
			$("#fish_kind").val(fishes);
			$('#myModal').modal('hide');
		});
		
		loadFishModal();
	tbQ.loader.hide();
}());