defClass({
	name : 'BplatBody',
	pkg : 'Bplat.viewPkg',
	implement : Bplat.viewPkg.ViewInterface,
	construct : function() {
	},
	methods : {
		'setElement' : function() {

			// url
			this._myReserveListURL = $('#myReserveListURL').val();
			this._memReserveDetailURL = $('#memReserveDetailURL').val();

			this._scheduleListURL = $('#scheduleListURL').val();
			this._scheduleDetailURL = $('#scheduleDetailURL').val();

			this._scheduleWeatherURL = $('#scheduleWeatherURL').val();
			this._scheduleWeatherDateURL = $('#scheduleWeatherDateURL').val();

			this._reserveInsertURL = $('#reserveInsertURL').val();
			this._myReserveListURL = $('#myReserveListURL').val();
			this._memReserveDetailURL = $('#memReserveDetailURL').val();

			this.postListURL = $('#postListURL').val();
			this.postDetailURL = $('#postDetailURL').val();

			this.$listContainer = $('#noticeTbl');
			this.$listContainer2 = $('#rsvInfoTbl');

			this.$postListTemplate = $('#postListTemplate .postListRow');
			this.$resvListTemplate = $('#resvListTemplate .resvListRow');
			this.$postNoDataTemplate = $('#postListTemplate .nodata');

			this.$shipId = $('#shipId').val();
			this.$weatherDiv = $('.weather_popup_wrap');
			this.$weatherInfoTbl = $('.weather_tb');

			// 달력스케쥴
			this.$calendarContainer = $('#tbodyCalendar');

			// 일자별 스케쥴
			this.$calendarListContainer = $('.schd_tb2');

			this.scCalendarTbl = $(".schd_tb");
			this.$template1 = $('#template1');
			this.$template2 = $('#template2 tr');

			this.$reserveList = $('#listContainer');

			this.$calendarMoveBtn = $("span.prev,span.next");

			this.$calendarTdTemplate = $("#tbodyCalendar td:first").html();

			this._schdInfo;

			this.$popupTitleKr = $('.title_kr');
			this.$popupTitleEn = $('.title_en');

			this.$popSubject = $('#popSubject');
			this.$popupContent = $('#popContents');
			this.$popupDate = $('#popDate');

			this.vrBankingYn = true;
			this.detailListForReserve = [];
			this.$checkWhole = $('.wholeYnCheck:checkbox');

			this._feeWhole = 0;
			this._psgrCnt = 0;
			this._nickName = "nickname";

			this._interval_id = null;
			this._interval_objs = null;
			this._interval_index = 0;

			this.$reserv_status_popup_wrap = $('.reserv_status_popup_wrap');

			this.$telOnly = $("input#telOnly").val().replaceAll(" ","");

			this._schdId;

			this._agreeMsg = $('#agreeMsg').val();
			this._roomType;

		},
		'setEvent' : function() {
			var _self = this;

			// 선택된 장르 옵션 상세 정보만 보여주기
			$("table[name=detail_subTable]").find("[data-type=GENRE]").on(
					"change", function() {
						var value = $(this).val();
						$("#detail_div div").hide();
						$("#" + value).show();
					});

			$('select[data-key=MAN_CNT]').change(
					function() {
						var cnt = (_self._roomType == 'P') ? 1 : toNumber($(this).val());
						var fee = $(this).data('fee');
						_self.totalCost(cnt, fee);
					});

			// 날씨보기 버튼 클릭
			_self.$calendarContainer.delegate('.weather_btn', 'click',
					function() {

						stopEvent(event);

						$('.weather_popup_wrap').fadeIn(200);
						$('.weather_popup_con').css({
							top : '60%'
						});
						$('.weather_popup_con').animate({
							top : '50%'
						}, 200);
						isScroll = false;
						lockScroll();

						var wDate = $(this).attr('data-date');

						_self.getWeatherDetail(wDate);
					});

			_self.$weatherDiv.delegate('.weather_close_btn', 'click',
					function() {
						stopEvent(event);
						$('.weather_popup_wrap').fadeOut(200);
						$('.weather_popup_con').animate({
							top : '60%'
						}, 200);
						isScroll = true;
						unlockScroll();
					});

			_self.$checkWhole.click(function() {

						var $insertForm = $("#reserveForm");

						var $checkWhole = this;
						var $manCnt = $insertForm.find('select[data-key=MAN_CNT]');
						var $totCost = $insertForm.find('td[data-key=TOT_COST]');

						if ($checkWhole.checked) {
							$manCnt.attr("disabled", true);
							$manCnt.val(_self._psgrCnt);
							$totCost.html("<span style='color:red;font-weight: bolder;'>독선금액 협의 </span> (계약금:" + stringFilter(_self._feeWhole,'money') + "원)");
						} else {
							$manCnt.attr("disabled", false);
							$manCnt.val(null);
							$totCost.text("0 원");
						}
					});

			_self.$calendarMoveBtn.click(function() {

				var clsname = this.className;

				var date = _self.selectDate;

				if (clsname == "prev") {
					date.setMonth(date.getMonth() - 1);
				} else {
					date.setMonth(date.getMonth() + 1);
				}

				var month = date.getMonth() + 1;

				_self.yearMonth = date.getFullYear()
						+ ((month < 10) ? "0" + month : "" + month);

				_self.renderScheduleList();
			});

			_self.$calendarContainer.delegate('.poss_icon', 'click',
					function() {

						if (_self._agreeMsg) {
							if (confirm(_self._agreeMsg)) {
								location.href = '../auth/agree_form';
							}
							return false;
						}

						stopEvent(event);
						var schdId = $(this).data('schd_id');
						_self.showReserveForm(schdId);
					});

			_self.$calendarListContainer.delegate('.possible', 'click',
					function() {

						if (_self._agreeMsg) {
							if (confirm(_self._agreeMsg)) {
								location.href = 'auth/agree_form';
							}
							return false;
						}

						stopEvent(event);
						var schdId = $(this).data('schd_id');
						_self.showReserveForm(schdId);
					});

			// 예약하기에서 장르 변경시
			$("#reserveForm")
					.on(
							"change",
							"#genreSelect",
							function() {
								var $insertForm = $("#reserveForm");
								var pCnt = $(this).find("option:selected").attr("pcnt");
								var fee = $(this).find("option:selected").attr("pfee");
								var feehol = $(this).find("option:selected").attr("phol");
								var genreId = $(this).val();

								for (var i = 0; i < _self.detailListForReserve.length; i++) {
									var items = _self.detailListForReserve[i];
									if (items.GENRE == genreId) {
										_self._schdInfo = items;
									}
								}

								_self._feeWhole = feehol;
								_self._psgrCnt = pCnt;

								$insertForm.find('#wholeYnCheck').attr('checked', false);

								var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');

								select_manCnt.data('fee', fee);

								select_manCnt.empty().append('<option value="">인원 선택</option>');

								for (var i = 1; i <= pCnt; i++) {
									select_manCnt.append("<option value='" + i + "'>" + i + " 명</option>");
								}

								var select_eqpCnt = $insertForm.find('[data-key=EQP_CNT]');
								select_eqpCnt.html("");

								for (var i = 0; i <= pCnt; i++) {
									select_eqpCnt.append("<option value='" + i + "'>" + i + " 대</option>");
								}

								select_manCnt.attr("disabled", false);
								$insertForm.find('[data-key=TOT_COST]').text('0 원');

							});

			// 예약 버튼 클릭 핸들러
			$('.reservation_btn').on('click', function() {

				stopEvent(event);

				var param = _self.insertCheck();

				if (param == false) {
					return false;
				}

				_self.showReservationConfirmPop();
			});

			// 예약하시겠습니까? 확인 버튼 클릭 핸들러
			$('.reserv_confirm_popup_wrap .reservation_confirm_btn').on(
					'click', function() {

						stopEvent(event);

						$('.reserv_confirm_popup_wrap').hide();
						$('#loadingbar').show();

						var param = _self.insertCheck();
						_self.insertReserve(param);
					});

			// 상세보기
			$("td").delegate(".info_title", "click", function() {
				showPop('.detail_popup_wrap', '.popup_common_con');

				var schdId = $(this).data('schdId');

				_self.showScheduleDetail(schdId);
			});

			$(document.body).on('click', 'a.title', function() {
				showPop('.detail_popup_wrap', '.popup_common_con');
				var schdId = $(this).data('schdId');

				_self._schdId = schdId;
				_self.showScheduleDetail(schdId);
			});

			$(".detail_popup_wrap").delegate("#close_btn,.close_btn", "click",
					function() {
						$('.scDetail').show();
						$('.scUpdate').hide();
						hidePop('.detail_popup_wrap', '.popup_common_con');
					});

			$(".detail_popup_wrap").delegate("#reserve_btn", "click",
					function() {

						$('.scDetail').show();
						$('.scUpdate').hide();
						hidePop('.detail_popup_wrap', '.popup_common_con');

						stopEvent(event);
						var schdId = _self._schdId;
						_self.showReserveForm(schdId);

					});

			$(".contents_wrap")
					.delegate(
							".clickEvent",
							"click",
							function() {

								var me = $(this);
								var bbsType = me.attr("bbsType");
								var postId = me.attr("postId");
								var titleKr;
								var titleEn;

								if (bbsType == null) {
									window.location.href = _self._memReserveDetailURL + "?ID=" + me.attr("rsvId");
									return;
								}
								if (bbsType == '108_110') {
									titleKr = "공지";
									titleEn = "Notice";
								} else {
									titleKr = "예약안내";
									titleEn = "Reservation";
								}

								_self.$popupTitleKr.text(titleKr);
								_self.$popupTitleEn.text(titleEn);

								_self.$popSubject.text("");
								_self.$popupContent.html("");
								_self.$popupDate.text("");

								showPop('.notice_pop_wrap', '.popup_common_con');

								var defaultParam = {
									'POST_ID' : postId
								};

								$.ajax({
											url : _self.postDetailURL,
											type : 'POST',
											data : defaultParam,
											dataType : 'json',
											success : function(data) {
												var dtl = data.detailPost;
												var content = dtl.CONTENT;

												_self.$popSubject.text(dtl.TITLE);

												_self.$popupDate.text(dtl.CREATED_AT);

												var imglist = data.imageList;
												var imgtag;

												if (imglist != null
														&& imglist.length > 0) {
													var leng = imglist.length;

													for (var i = 0; i < leng; i++) {
														imgtag = "<p style='height:50px'></p><p><img src='"
																+ _self.$imageURL
																+ imglist[i].IMG_ID
																+ "/520'></p>";

														if (imglist[i].CONTENT != null) {
															imgtag = imglist[i].CONTENT;
														}

													}

													content += imgtag;
												}

												_self.$popupContent.html(content);
											}
										});
							});

		},
		/** 갱신 */
		'renderScheduleList' : function() {

			var _self = this;
			var yearMonth = _self.yearMonth;

			var tdtemp = _self.$calendarTdTemplate;
			$("#tbodyCalendar td").html(tdtemp);
			makeCalendar(yearMonth);

			_self.getWeatherList(yearMonth);
		},

		/**
		 * 예약확인 팝업 show
		 */
		'showReservationConfirmPop' : function() {
			$('.reserv_confirm_popup_wrap').fadeIn(200);
			$('.reserv_confirm_popup_con').css({
				top : '60%'
			});
			$('.reserv_confirm_popup_con').animate({
				top : '50%'
			}, 200);

			// isScroll = false;
			// lockScroll();
		},

		'showScheduleDetail' : function(schdId) {
			var _self = this;

			var param = {
				SCHD_ID : schdId
			};

			$.ajax({
						url : _self._scheduleDetailURL,
						type : 'POST',
						data : param,
						dataType : 'json',
						success : function(data) {
							$("#detail_div").html("");
							$("table[name=mainTable]").hide();
							$("table[name=detail_subTable]").hide();

							var comps = $('.detail_popup_wrap').find('[data-key]');

							var item = data.detail;
							$.extend(item, data.roomInfo);

							item.SCHD_DATE = strToDateString(item.SCHD_DATE);

							item.FEE_TEXT = jdg.util.addComma(item.FEE) + ' 원';

							if (item.DESCR)
								item.DESCR_HTML = item.DESCR.replaceAll("\n","<br>");
							if (item.NOTICE_TEXT)
								item.NOTICE_HTML = item.NOTICE_TEXT.replaceAll("\n", "<br>");

							if (item.STATUS_CD == "113_180") {
								item.STATUS_NAME = "만료"; // 예약가능한 날짜가 지남
							} else if (item.STATUS_CD == "113_210") {
								item.STATUS_NAME = "출조 취소";
							} else {
								item.STATUS_NAME = "정상";
							}

							if (item.ROOM_TYPE == 'P') {
								item.PSGR_CNT_TEXT = "기준:" + item.STD_MAN + '명 (최대:' + item.PSGR_CNT + "명)";
								item.ADD_FEE_DESC = "기준인원 초과시 " + item.ADD_FEE_DESC + " (추가요금은 입실할때 지불합니다)";

								if (item.STATUS_NAME == "정상" && data.count * 1 != 0) {
									item.STATUS_CD = '113_170';
									item.STATUS_NAME = '마감';
								}
							} else {
								item.PSGR_CNT_TEXT = "정원: " + item.PSGR_CNT + "명";
								item.ADD_FEE_DESC = "다인실입니다. 요금은 1인당 요금입니다."

								if (item.STATUS_NAME == "정상"
										&& data.count * 1 >= item.PSGR_CNT * 1) {
									item.STATUS_CD = '113_170';
									item.STATUS_NAME = '마감';
								}
							}

							for (var i = 0; i < comps.length; i++) {
								var comp = $(comps[i]);
								var value = data.detail[comp.data('key')];

								if (value != undefined) {
									if (comp.is('input') || comp.is('select') || comp.is('textarea')) {
										comp.val(value);
									} else {
										comp.html(value);
									}
								} else {
									comp.html("");
								}
							}

							// 출조취소시 숨김.
							if (item.STATUS_CD != '113_110') {
								$("#reserve_btn").hide();
							} else {
								$("#reserve_btn").show();
							}

							$("table[name=mainTable]").show();

						}
					});

		},

		'showReserveForm' : function(schdId) {
			var _self = this;

			if (_self.$telOnly != "") {
				alert(_self.$telOnly);
				return;
			}

			if (isLogin() == false) {
				showLoginBox();
				return;
			}

			var insertParam = {
				SCHD_ID : schdId
			};

			$.ajax({
				url : _self._scheduleDetailURL,
				type : 'POST',
				data : insertParam,
				dataType : 'json',
				success : function(data) {

					var $insertForm = $("#reserveForm");

					var item = data.detail;

					$.extend(item, data.roomInfo);

					var availCnt;

					_self._roomType = item.ROOM_TYPE;

					if (item.ROOM_TYPE == 'P') {
						availCnt = (data.count > 0) ? 0 : item.PSGR_CNT;
						item.ADD_FEE_DESC = "기준인원 초과시 " + item.ADD_FEE_DESC + " (추가요금은 입실할때 지불합니다)";
						item.PSGR_CNT_TEXT = "기준:" + item.STD_MAN + '명 (최대:' + item.PSGR_CNT + "명)";
					} else {
						availCnt = item.PSGR_CNT - data.count;
						item.ADD_FEE_DESC = "다인실입니다. 요금은 1인당 요금입니다.";
						item.PSGR_CNT_TEXT = "정원: " + item.PSGR_CNT + "명";
					}

					_self._psgrCnt = item.PSGR_CNT;
					_self._nickName = data.nickName;

					$insertForm.find('#wholeYnCheck').attr('checked', false);

					if_showhide(availCnt == item.PSGR_CNT, $insertForm.find('.wholeYnCheck'));

					_self._schdInfo = item;

					var select_manCnt = $insertForm.find('[data-key=MAN_CNT]');

					select_manCnt.data('fee', item.FEE);

					select_manCnt.empty().append(
							'<option value="">인원 선택</option>');

					for (var i = 1; i <= availCnt; i++) {
						select_manCnt.append("<option value='" + i + "'>" + i + " 명</option>");
					}

					var bankAccnHolder;

					_self.vrBankingYn = (item.VR_BANKING_YN == "Y");

					if (_self.vrBankingYn) {
						$insertForm.find('[data-key=BANK_CD]').val("");
						$insertForm.find('[data-key=BANK_CD]').show();
						bankAccnHolder = "* 입급할 은행선택(가상계좌입금)";
					} else {
						bankAccnHolder = item.BANK_NM + " " + item.BANK_ACCN + " " + item.BANK_HOLDER;
						$insertForm.find('[data-key=BANK_CD]').hide();
					}

					$insertForm.find('[data-key=BANK_ACCN_HOLDER]').text(bankAccnHolder);

					var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
					var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val().trim();
					var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
					var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();

					$insertForm.find('[data-key=TOT_COST]').text('0 원');
					$insertForm.find('[data-key=DEPOSIT_NAME]').val(rsvName);

					$insertForm.find('[data-key=NOTICE_HTML]').html(item.NOTICE_HTML);
					$insertForm.find('[data-key=DESCR_HTML]').html(item.DESCR_HTML);
					$insertForm.find('[data-key=ROOM_NM]').html(item.ROOM_NM + '(' + item.ROOM_SIZE + ") : " + item.ROOM_STYLE);
					$insertForm.find('[data-key=ADD_FEE_DESC]').html(item.ADD_FEE_DESC);
					$insertForm.find('[data-key=ROOM_DESC]').html(item.ROOM_DESC);
					$insertForm.find('[data-key=PSGR_CNT_TEXT]').html(item.PSGR_CNT_TEXT);

					showReservationPop();
				}
			});
		},

		'getWeatherDetail' : function(wDate) {

			var _self = this;

			var insertParam = {
				'WEATHER_DATE' : wDate,
				'SHIP_ID' : _self.$shipId
			};

			$.ajax({
				url : _self._scheduleWeatherURL,
				type : 'POST',
				data : insertParam,
				dataType : 'json',
				success : function(data) {
					if (data.hasOwnProperty('marineWeather')) {

						var wDate = data.marineWeather.WEATHER_DATE;
						var $td = _self.$calendarContainer.find('td#' + wDate);

						var ymd = $td.data('date') + ' ' + $td.data('day')
								+ '요일';
						var mull = $td.data('mull');

						_self.$weatherDiv.find("[data-key='ymd']").text(ymd);
						_self.$weatherDiv.find("[data-key='mull']").text(mull);

						var weatherCond = data.marineWeather.WEATHER_COND;
						var windDirect = data.marineWeather.WIND_DIRECT;
						var waveHeight = data.marineWeather.WAVE_HEIGHT;
						var windSpeed = data.marineWeather.WIND_SPEED;

						if (windDirect == " ") {
							windDirect = ",";
							windSpeed = ",";
						}

						var arrWeatherCond = weatherCond.split(",");
						var arrWindDirect = windDirect.split(",");
						var arrWaveHeight = waveHeight.split(",");
						var arrWindSpeed = windSpeed.split(",");

						var tds = _self.$weatherInfoTbl.find('td');

						var img0 = arrWeatherCond[0] == '' ? ''
								: 'https://www.kma.go.kr/' + arrWeatherCond[0];
						var img1 = 'https://www.kma.go.kr/' + arrWeatherCond[1];

						tds.eq(0).find('img').attr('src', img0);
						tds.eq(1).find('img').attr('src', img1);

						if_showhide(img0 != "", tds.eq(0).find('img'));

						tds.eq(2).text(arrWaveHeight[0]);
						tds.eq(3).text(arrWaveHeight[1]);

						tds.eq(4).text(arrWindDirect[0]);
						tds.eq(5).text(arrWindDirect[1]);

						var winsp0 = arrWindSpeed[0] == '' ? ''
								: arrWindSpeed[0] + " m/s";
						var winsp1 = arrWindSpeed[1] == '' ? ''
								: arrWindSpeed[1] + " m/s";

						tds.eq(6).text(winsp0);
						tds.eq(7).text(winsp1);
					}

				}
			});
		},

		'getWeatherList' : function(yearMonth) {

			var _self = this;

			$.ajax({
						url : _self._scheduleWeatherDateURL,
						type : 'POST',
						data : null,
						dataType : 'json',
						success : function(data) {
							if (data.hasOwnProperty('weatherDateList')) {
								var weatherDateList = data.weatherDateList;
								var wDate;

								var td;
								var weatherBtn = '<p class="weather"><a><img class="weather_btn" src="https://img.fishapp.co.kr/legacy/wp/weather_btn.png" alt="날씨" data-date="$wDate"/></a></p>';

								for (var j = 0; j < weatherDateList.length; j++) {

									wDate = weatherDateList[j].WEATHER_DATE;
									td = _self.scCalendarTbl.find("#" + wDate + ">div");

									if (td) {
										td.append(weatherBtn.replace("$wDate", wDate));
									}
								}
							}
							_self.getScheduleList({
								'SCHD_MONTH' : yearMonth
							});
						}
					});
		},

		// 예약금액 자동 셋팅
		'totalCost' : function(man, fee) {
			var _self = this;
			var $insertForm = $("#reserveForm");

			var sum = man * fee;
			if (!sum) sum = 0;
			$insertForm.find('[data-key=TOT_COST]').text(stringFilter(sum, 'money') + ' 원');

		},

		// 데이터 체크
		'insertCheck' : function() {
			var _self = this;

			var schdInfo = _self._schdInfo;

			var $insertForm = $("#reserveForm");
			// validation
			var today = jdg.util.today().replaceAll('-', '');

			var totCost = $insertForm.find('[data-key=TOT_COST]').val();
			totCost = totCost.replaceAll(',', '');
			$insertForm.find('[data-key=TOT_COST]').val(totCost);

			if (!jdg.util.validator($insertForm, true))
				return false;

			var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();

			if (manCnt == "") {
				alert("예약인원을 선택하십시오.");
				return false;
			}

			var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
			var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
			var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
			var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val();
			var dispCd = $insertForm.find('[data-key=DISP_CD]').val();
			var seatTxt = $insertForm.find('[data-key=SEAT_TXT]').val();

			var nickName = _self._nickName;

			var dispTxt = "예약자표시";

			if (dispCd == '1') {
				dispTxt = rsvDepositName;
			} else if (dispCd == '2') {
				dispTxt = rsvName;
			} else if (dispCd == '3') {
				dispTxt = nickName;
			}

			var $bankCd = $insertForm.find('[data-key=BANK_CD]');
			var bankCd = $bankCd.val();
			var vrBankingYn;

			if (rsvTel == "") {
				alert("전화번호를 입력해주십시오.(비정상적인 전화번호를 넣으면 예약이 되지 않습니다.)");
				return false;
			}

			if (_self.vrBankingYn) {
				if (bankCd == '') {
					alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
					return false;
				}

				vrBankingYn = "Y";
			} else {
				vrBankingYn = "N";
				bankCd = null;
			}

			if (rsvName == '' && rsvTel == '' && rsvEmail == '') {
				alert('예약자 정보를 입력해 주세요');
				return false;
			}

			var insertParam = {
				'SCHD_ID' : schdInfo.SCHD_ID,
				'RSV_NAME' : rsvName,
				'RSV_TEL' : rsvTel,
				'RSV_EMAIL' : rsvEmail,
				'DEPOSIT_NAME' : rsvDepositName,
				'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val(),
				'EQP_CNT' : "0",
				'SITE_CD' : 'L',
				'BANK_CD' : bankCd,
				'VR_BANKING_YN' : vrBankingYn,
				'WHOLE_YN' : "N",
				'DISP_CD' : dispCd,
				'DISP_TXT' : dispTxt,
				'SEAT_TXT' : "",
				'GENRE_ID' : ""
			};

			return insertParam;
		},

		// 예약등록
		'insertReserve' : function(insertParam) {

			var _self = this;

			$.ajax({
				url : _self._reserveInsertURL,
				type : 'POST',
				data : insertParam,
				dataType : 'json',
				success : function(data) {

					// 로더 제거
					$('#loadingbar').hide();
					hideReservationConfirmPop();
					hideReservationPop();

					if (data.error == undefined) {
						var rsv_Id = data.rsv_Id;
						if (rsv_Id != null && rsv_Id != undefined) {

							showPop('.reserv_com_pop');
							_self.renderScheduleList();
						}
					} else {
						if (data.error.userMessage) {
							alert(data.error.userMessage);
						}
					}

					isScroll = true;
					unlockScroll();
				}
			});
		},

		// 출조스케쥴 목록 조회
		'getScheduleList' : function(param) {
			var _self = this;
			var tmpDay = new Date();
			$
					.ajax({
						url : _self._scheduleListURL,
						type : 'POST',
						data : param,
						dataType : 'json',
						success : function(data) {

							var scheduleList = data.scheduleList;
							_self.currentScheduleList = scheduleList;

							var reserveMap1 = {};
							var reserveMap2 = {};
							var mapData1;
							var mapData2;
							var rsvStatus;

							var str1;
							var str2;
							var seatText;
							var isBlink = false;

							$.each(data.reserveList,
									function(idx, data) {

										mapData1 = reserveMap1[data.SCHD_ID];
										mapData2 = reserveMap2[data.SCHD_ID];
										rsvStatus = data.STATUS_CD;

											if (mapData1 == null) {
												mapData1 = "";
												mapData2 = "";
											}

												str1 = '<li>' + data.RSV_INFO.replace('(',' 님(');
												str2 = '<p class="p2" rsv_id="' + data.RSV_ID + '" >' + data.DISP_TXT + " 님(" + data.MAN_CNT + "명)";

												if (rsvStatus == "104_300" || rsvStatus == "104_340") {
													str1 += ' <span class="finish">확정</span></li>';
													str2 += ' <span class="fin">확정</span></p>';

												} else if (rsvStatus == "104_310") {
													str1 += ' <span class="yet">미입금</span></li>';
													str2 += ' <span class="yet">미입금</span></p>';
												} else if (rsvStatus == "104_320") {
													str1 += ' <span class="finish">부분입금</span></li>';
													str2 += ' <span class="finish">부분입금</span></p>';
												} else {
													str1 += ' <span class="' + rsvStatus + '">**</span></li>';
													str2 += ' <span class="' + rsvStatus + '">**</span></p>';
												}

												reserveMap1[data.SCHD_ID] = mapData1 + str1;
												reserveMap2[data.SCHD_ID] = mapData2 + str2;
											});

							_self.$calendarListContainer.find("tbody>tr").remove();

							$.each(
											scheduleList,
											function(idx, data) {
												var tmp1 = _self.$template1.clone();

												var scTime = data.SCHD_TIME;
												//var availCnt = data.PSGR_CNT - data.RESERVE_CONFIRM_CNT - data.RESERVE_WAIT_CNT - data.WAIT_CNT;
												
												var availCnt = data.PSGR_CNT - data.RESERVE_CONFIRM_CNT;
												
												var statusNm;

												tmp1.find(".info_title").text(data.ROOM_NM);
												tmp1.find(".info_title").data('schdId', data.SCHD_ID);

												//  펜션은 예약자가 한명이라도 있으면 예약불가(예약가능 0명으로 처리)
												if (data.ROOM_TYPE == 'P' && availCnt < data.PSGR_CNT * 1) 
												{
													availCnt = 0;
												}

												data.AVAIL_CNT = availCnt;

												var lstString = reserveMap1[data.SCHD_ID];

												if (lstString == null) {
													lstString = "";
												} else {
													lstString += "<br>";
												}

												tmp1.find(".info_con").append(lstString);

												data.RSV_STRING = reserveMap2[data.SCHD_ID];

												var $td = _self.scCalendarTbl.find("#" + data.SCHD_DATE);
												var $div = $td.find("div").eq(0);
												$td.find('.sc_con').append(tmp1);

												// 상태가 정상이 아니거나, 정상이어도 인원이 마감되거나
												// 기한이 지난 것은 예약불가 상태로 처리
												// 독선 미입금은 예약 마감처리
												if (data.STATUS_CD != "113_110"
														|| availCnt <= 0) {
													if (data.STATUS_CD == "113_180") {
														statusNm = "만료"; // 예약가능한 날짜 지남
													} else if (availCnt <= 0) {
														statusNm = "마감"; // 예약인원이 마감
													} else {
														statusNm = data.STATUS_NAME;
													}

												} else {
													$div.attr('class','possible');
													statusNm = "예약가";
													tmp1.find(".poss_icon").data('schd_id',data.SCHD_ID);
												}

												data.STATUS_NM = statusNm;
												tmp1.data('scdata', data);
											});

							var calendarTdList = $("#tbodyCalendar>tr>td[id!='']");
							var $listCon = _self.$calendarListContainer;

							// ie7,8 버그대응
							for (var i = calendarTdList.length - 1; i >= 0; i--) {
								if (calendarTdList[i].id == "") {
									calendarTdList.splice(i, 1);
								}
							}

							$.each(calendarTdList,
											function(idx, tdObj) {

												if (_self._interval_id) {
													clearInterval(_self._interval_id);
													_self._interval_id = null;
												}

												var $td = $(tdObj);

												var $listRow = _self.$template2.clone(); // 세로캘린더용
																	// 템플릿
												$listRow.attr('id', tdObj.id);

												var day = idx + 1;

												var dayNum = (day + firstRangeIndex - 1) % 7;

												var dateTd = $listRow.find('.date');
												var dayTd = $listRow.find('.day');

												if (dayNum == 0) {
													dateTd.addClass('sun');
													dayTd.addClass('sun');
													$listRow.css('background-color','#FFF2F2');
												} else if (dayNum == 6) {
													dateTd.addClass('sat');
													dayTd.addClass('sat');
													$listRow.css('background-color','#E0F1FB');
												} else {
													dateTd.removeClass('sat');
													dayTd.removeClass('sat');
													dateTd.removeClass('sun');
													dayTd.removeClass('sun');
												}

												var dayNm = dayList[dayNum];
												dayTd.text(dayNm);

												$listRow.find(".date").html(day);

												var tdTemp1List = $td.find('div#template1');

												if (tdTemp1List.length > 0) {
													var rowspan = tdTemp1List.length;

													if (rowspan > 1) {
														$listRow.find('.spanrow').attr('rowSpan',rowspan);
													}

													$.each(tdTemp1List,
																	function(idx,templateObj) {

																		if (idx > 0) {
																			var color = $listRow.css('background-color');

																			$listRow = _self.$template2.clone();
																			$listRow.find('.spanrow').remove();

																			if (color != '') {
																				$listRow.css('background-color',color);
																			}
																		}

																		var scdata = $(templateObj).data('scdata');

																		var notice_text = "";

																		if (scdata.NOTICE_TEXT != null) {
																			notice_text = '<p class="p1">'+ scdata.NOTICE_TEXT.replaceAll("\n","<br>")	+'</p>';
																		}

																		var rsv_text = "";

																		if (scdata.RSV_STRING != null) {
																			rsv_text = scdata.RSV_STRING;
																		}

																		$listRow.find('a.title').data('schdId',scdata.SCHD_ID);
																		$listRow.find('a.title').html(scdata.ROOM_NM + " (" + scdata.ROOM_SIZE + ")");

																		$listRow.find('div.reservers').html(notice_text	+ rsv_text);

																		if (scdata.STATUS_NM == "예약가") {
																			
																			$listRow.find('td.yes_no').html('<span class="yes">' + scdata.AVAIL_CNT +' 명</span>');

																			if (_self.$telOnly != "") {
																				$listRow.find('td.status')
																						.html('<span class="possible" style="cursor:pointer;color:white;background:blue;padding:3px">전화예약</span>');
																			} else {
																				$listRow.find('td.status')
																						.html('<span class="possible" style="cursor:pointer">예약하기</span>');
																				$listRow.find('td.status>span').data('schd_id',scdata.SCHD_ID);
																			}
																		} else {
																			if (scdata.STATUS_CD == '113_210') {
																				$listRow.find('td.status').html('<span class="cancel blink">예약불가</span>');
																			} else {
																				$listRow.find('td.status').html(scdata.STATUS_NM);
																			}

																			$listRow.find('td.yes_no').html('');
																		}

																		if (scdata.AVAIL_CNT < 0 && scdata.STATUS_NM == "마감") {
																			var exceed = scdata.AVAIL_CNT * -1;

																			$listRow.find('td.yes_no')
																					.html('<span style="color:yellow;background-color:red;padding:10px">'  + exceed + '명 초과</span>');
																		}

																		$listCon.append($listRow);
																	});
												} else {
													$listCon.append($listRow);
												}

											});

							var seatimeList = data.seatimeList;

							$.each(seatimeList, function(idx, data) {

								var _td = _self.scCalendarTbl.find("#"+ data.SOLAR_DATE);
								_td.find('.mull').text(data.MOOL);
								_td.data('mull', data.MOOL);

								var _tr = _self.$calendarListContainer.find("#"	+ data.SOLAR_DATE);
								_tr.find('.mull').text(data.MOOL);
								
								makeHoliday(_tr, data.SOLAR_DATE);
							});

							if (_self.$reserv_status_popup_wrap.length > 0) {
								$('.schd_tb2 .p2').css("cursor", "pointer");
							}

						}
					});
		},


		// 공지사항 목록 조회
		'getPostList' : function(bbsType, page) {

			var _self = this;
			var _contatiner;
			var _paging;

			_contatiner = _self.$listContainer;
			_paging = $('#postListPaging');

			// defaultParam 세팅
			var itemCnt = 5;
			var defaultParam = {
				'PAGE' : page,
				'PERPAGE' : itemCnt,
				'TYPE_CD' : bbsType
			};
			$.ajax({
				url : _self.postListURL,
				type : 'POST',
				data : defaultParam,
				dataType : 'json',
				success : function(data) {
					if (data.hasOwnProperty('postList')) {
						// 초기화
						_contatiner.empty();
						var list = data.postList;
						if (list.length <= 0) {
							// nodata
							var $nodata = _self.$postNoDataTemplate.clone();
							_self.$listContainer.append($nodata);
						} else {
							$('.jdg-ui-nodata').hide();
							// 번호
							var rowCount = data.total;
							var selectPage = itemCnt;
							if (page > 1) {
								rowCount = rowCount - (page * selectPage)
										+ selectPage;
							}

							$.each(list, function(idx, data) {
								var $row = _self.$postListTemplate.clone();

								if (idx % 2 == 1) {
									$row.addClass("even");
								}

								$row.attr('rowKey', data.POST_ID);

								var titleLink = $row.find('a');

								titleLink.attr('postId', data.POST_ID);
								titleLink.attr('bbsType', bbsType);

								// 번호
								data.rowNum = rowCount;
								rowCount--;

								// 제목
								$row.find('[data-key=TITLE]').text(data.TITLE);

								// 등록일
								if (data.UPDATED_AT) { // 업데이트 시간이 있을경우
									data.UPDATED_AT = data.UPDATED_AT.substr(0,10);
									$row.find('[data-key=CREATED_AT]').text(data.UPDATED_AT);
								} else { // 없을경우
									data.CREATED_AT = data.CREATED_AT.substr(0,10);
									$row.find('[data-key=CREATED_AT]').text(data.CREATED_AT);
								}

								_contatiner.append($row);
							});
						}

						var numOfPages = Math.ceil(data.total / itemCnt);

						// 페이징 초기화
						$(_paging).paging({
							current : page,
							max : numOfPages,
							itemClass : '',
							prevClass : 'paging_prev',
							nextClass : 'paging_next',
							firstClass : '',
							lastClass : '',
							length : 5,
							itemCurrent : 'on',
							onclick : function(e, page) {
								_self.getPostList(bbsType, page);
							}
						});

						if (page <= 5) {
							_paging.css("margin-left", "40px");
						} else {
							_paging.css("margin-left", "");
						}

						_paging.find('.paging_prev').text("<");

						if (numOfPages > 5)
							_paging.find('.paging_next').text(">");
					}
				}
			});
		},

		'getMyReserveList' : function(page) {

			var _self = this;
			var _contatiner;
			var _paging;

			_contatiner = _self.$listContainer2;
			_contatiner.empty();

			if (isLogin() == false) {
				_contatiner.append('<td colspan=5> 예약 내역이 없습니다.</td>');
				return;
			}

			_paging = $('#resvListPaging');

			// defaultParam 세팅
			var itemCnt = 5;
			var defaultParam = {
				'PAGE' : page,
				'PERPAGE' : '5'
			};
			$.ajax({
						url : _self._myReserveListURL,
						type : 'POST',
						data : defaultParam,
						dataType : 'json',
						success : function(data) {

							$.each(data.memReserveList,
									function(idx, data) {

										$row = _self.$resvListTemplate.clone();

										if (idx % 2 == 1) {
											$row.addClass("even");
										}

										$row.attr('id', null);

										if (data.STATUS_CD == '104_300') {
											data.STATUS_NAME = '<span class="finish">입금완료</span>';
										}

										setFiledByDataFilter($row,'SCHD_DATE', data,'date');
										setFiledByData($row,'SUB_TITLE', data);
										setFiledByData($row, 'MAN_CNT',data);
										setFiledByData($row,'STATUS_NAME', data);
										setFiledByDataFilter($row,'TOT_COST', data,'money');

										var titleLink = $row.find('a');

										titleLink.attr('rsvId',data.RSV_ID);

										_contatiner.append($row);
									});

							var numOfPages = Math.ceil(data.total / itemCnt);

							// 페이징 초기화
							$(_paging).paging({
								current : page,
								max : numOfPages,
								itemClass : '',
								prevClass : 'paging_prev',
								nextClass : 'paging_next',
								firstClass : '',
								lastClass : '',
								length : 5,
								itemCurrent : 'on',
								onclick : function(e, page) {
									_self.getMyReserveList(page);
								}
							});

							if (page <= 5) {
								_paging.css("margin-left", "40px");
							} else {
								_paging.css("margin-left", "");
							}

							_paging.find('.paging_prev').text("<");

							if (numOfPages > 5)
								_paging.find('.paging_next').text(">");
						}
					});
		},

		'onCreate' : function(p_param, _viewClass) {
			Bplat.log.debug('[schedule_main] onCreate Method');
			var _self = this;
			// 초기화
			_self.setElement();
			_self.setEvent();

			// 캘린더 <,> 버튼 마우스포인트 처리
			_self.$calendarMoveBtn.css('cursor', 'pointer');

			_self.getMyReserveList('1');

			_self.getPostList('108_120', '1');

			var date = new Date();
			var month = date.getMonth() + 1;

			date.setDate(1);

			_self.selectDate = date;
			_self.yearMonth = date.getFullYear() + ((month < 10) ? "0" + month : "" + month);
			_self.renderScheduleList();

		},

		'onRestart' : function(p_param) {
			Bplat.log.debug('[schedule_main] onRestart Method');
		},
		'onStart' : function(p_param) {
			Bplat.log.debug('[schedule_main] onStart Method');
		},
		'onHidePopup' : function(p_param) {
			Bplat.log.debug('[schedule_main] onHidePopup Method', JSON
					.stringify(p_param));
		},
		'onShowPopup' : function(p_param) {
			Bplat.log.debug('[schedule_main] onShowPopup Method');
		},
		'onStop' : function() {
			Bplat.log.debug('[schedule_main] onStop Method');
		},
		'onDestroy' : function() {
			Bplat.log.debug('[schedule_main] onDestroy Method');
		}
	}
});
