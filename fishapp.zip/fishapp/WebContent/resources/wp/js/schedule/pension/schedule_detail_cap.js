defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._myReserveListURL = $('#myReserveListURL').val();				
				this._memReserveDetailURL = $('#memReserveDetailURL').val();				
				
				this._scheduleListURL = $('#scheduleListURL').val();
				this._scheduleDetailURL = $('#scheduleDetailURL').val();
				
				this._scheduleWeatherURL = $('#scheduleWeatherURL').val();
				this._scheduleWeatherDateURL = $('#scheduleWeatherDateURL').val();				
				
				this._reserveInsertURL = $('#reserveInsertURL').val();
				this._myReserveListURL = $('#myReserveListURL').val();
				this._memReserveDetailURL = $('#memReserveDetailURL').val();

				this.postListURL 		= $('#postListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();

				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$postListTemplate 			= $('#postListTemplate .postListRow');
				this.$resvListTemplate 			= $('#resvListTemplate .resvListRow');			
				this.$postNoDataTemplate       = $('#postListTemplate .nodata');
				
				this.$shipId = $('#shipId').val();
				this.$weatherDiv = $('.weather_popup_wrap');
				this.$weatherInfoTbl = $('.weather_tb');
				
				// 달력스케쥴
				this.$calendarContainer = $('#tbodyCalendar');
				
				// 일자별 스케쥴
				this.$calendarListContainer = $('.schd_tb2');

				
				this.scCalendarTbl = $(".schd_tb");
				this.$template1 = $('#template1');
				this.$template2 = $('#template2 tr');			

				this.$reserveList = $('#listContainer');
				
				this.$calendarMoveBtn = $("span.prev,span.next");
				
				this.$calendarTdTemplate = $("#tbodyCalendar td:first").html();		
				
				this._schdInfo;
				
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				
				this.vrBankingYn = true;
				
				this.$checkWhole = $('.wholeYnCheck:checkbox');
				
				this._feeWhole = 0;
				this._psgrCnt = 0;
				this._nickName = "nickname";
				
				this._interval_id = null;
				this._interval_objs = null;
				this._interval_index = 0;
				
				this._clickable = true;	

			},
			'setEvent'		: function() {
				var _self = this;
		    	
		    	$("a.close_fix_btn").bind("click", function(){
		    		window.close();
		    	});
		    	
		    	$("a.close_btn").bind("click", function(){
		    		window.close();
		    	});
		    	
		        $("span.close_btn").bind("click", function(){
		        	window.close();
		        });
		        
		        //수정 취소
		        $("a.sc_cancel_btn").bind("click", function(){
		        	$('#multiple_div').show();		
					$('#scUpdate_detail').hide();
		        });
		        
		        //수정버튼 클릭 시
		        $("a.update_fix_btn").bind("click", function(){
		        	$('#one_div').hide();		
					$('#scUpdate_fix_detail').show();
		        });
		        
	        	//수정 취소
		        $("a.sc_fix_cancel_btn").bind("click", function(){
		        	$('#one_div').show();		
					$('#scUpdate_fix_detail').hide();
		        });
		        
		        //수정하기
		        $("a.sc_fix_save_btn").bind("click", function(){
		        	if (_self._clickable = false) return;		
		        	_self._clickable = false;
					
					if (confirm('변경된 내용을 저장하시겠습니까?'))
					{
						_self.updateSchdeule();
					}					        
		        });
		        
		        //생활낚시 혹은 장르선택된 일반낚시 상태 변경시
		    	$('#one_div table.reserve_tb').delegate('[data-key="STATUS_CD"]','change',function() {
		    		var value = $(this).val();
		    		if($(this).val() == '113_210')
		    			$("#one_div .schd_cancel_desc_row").show();
		    		else{
		    			$("#one_div .schd_cancel_desc_row").hide();
		    			if(confirm("수정하시겠습니까?")){
		    				_self.updateStatus("one_div", { STATUS_CD : value});
		    			}
		    		}
		    	});
		    	
		    	//장르 선택전 일반낚시 상태 변경시
		    	$("#multiple_div table.reserve_tb").delegate('[data-key="STATUS_CD"]','change',function() {
		    		var value = $(this).val();
		    		if($(this).val() == '113_210')
		    			$("#multiple_div .schd_cancel_desc_row").show();
		    		else{
		    			$("#multiple_div .schd_cancel_desc_row").hide();
		    			if(confirm("수정하시겠습니까?")){
		    				_self.updateStatus("multiple_div", { STATUS_CD : value});
		    			}
		    		}
		    	});
		    	
		    	//장르 선택전 수정화면에서 일반낚시 상태 변경시
		    	$("#scUpdate_detail table.reserve_tb").delegate('[data-key="STATUS_CD"]','change',function() {
		    		var value = $(this).val();
		    		if($(this).val() == '113_210')
		    			$("#scUpdate_detail .schd_cancel_desc_row").show();
		    		else{
		    			$("#scUpdate_detail .schd_cancel_desc_row").hide();
		    			if(confirm("수정하시겠습니까?")){
		    				_self.updateStatus("scUpdate_detail", { STATUS_CD : value});
		    			}
		    		}
		    	});
		   
		    	//예약상태 출조취소일경우 반영 (저장버튼 클릭 시)
		    	$('#one_div table.reserve_tb').delegate(".confirm_cancle", "click", function(){
		    		var cancle = $("#one_div").find("[data-key=CANCEL_DESC] option:selected").val();
		    		if(confirm("수정하시겠습니까?")){
		    			_self.updateStatus("one_div", { CANCEL_DESC : cancle, STATUS_CD : '113_210' });
		    		}
		    	});
		    	
		    	//예약상태 출조취소일경우 반영 (저장버튼 클릭 시)
		    	$('#multiple_div table.reserve_tb').delegate(".confirm_cancle", "click", function(){
		    		var cancle = $("#multiple_div").find("[data-key=CANCEL_DESC]:selected").val();
		    		if(confirm("수정하시겠습니까?")){
		    			_self.updateStatus("multiple_div", { CANCEL_DESC : cancle, STATUS_CD : '113_210' });
		    		}
		    	});
		    	
		    	//노출여부 수정시
		      	$('#one_div table.reserve_tb').delegate('[data-key="DEL_FLAG"]','change',function() {
		      		if(confirm("수정하시겠습니까?")){
		      			var value = $(this).val();
		      			_self.updateStatus("one_div", { DEL_FLAG : value});
		      		}		    		
		    	});
		      	
		      	//노출여부 수정시
		      	$('#multiple_div table.reserve_tb').delegate('[data-key="DEL_FLAG"]','change',function() {
		      		if(confirm("수정하시겠습니까?")){
		      			var value = $(this).val();
		      			_self.updateStatus("multiple_div", { DEL_FLAG : value});
		      		}		    		
		    	});
		      	
		      	//장르별 사용여부 체크.(상세)
		      	$("#detail_div table").on("change", "[data-key=GENRE_USEYN]", function(){
		      		var value = $(this).val();
		      		if(value == '')
		      			return;
		      		
		      		var allNotFalse = false;
		      		$("#detail_div select[data-key=GENRE_USEYN]").each(function(){
		      			var useYn = $(this).val();
		      			if(useYn == 'Y'){
		      				allNotFalse = true;
		      			}
		      		});
		      		
		      		if(!allNotFalse){
		      			$(this).val("Y");
		      			alert("모든 장르를 '사용안함'으로 바꿀수 없습니다.");
		      			return;
		      		}
		      		
		      		var type = $(this).attr("ptype");
		      		var param = null;
		      		if(type == 1){
		      			param = { GENRE_USEYN1 : value}
		      		}else if(type == 2){
		      			param = { GENRE_USEYN2 : value}
		      		}else{
		      			param = { GENRE_USEYN3 : value}
		      		}
		      		_self.updateStatus("multiple_div", param);
		      	});
		    	
		    	//일반낚시 장르 선택전 수정하기 화면
		    	$("a.update_btn").bind("click", function(){
		    		$('#multiple_div').hide();		
					$('#scUpdate_detail').show();
		    	});

		    	
		    	//출조 수정(장르 여러개 일반 낚시)
		    	$("a.sc_save_btn").bind("click", function(){
		    		if (_self._clickable = false) return;		
		        	_self._clickable = false;
					
					if (confirm('변경된 내용을 저장하시겠습니까?'))
					{
						_self.updateGenreSchdeule();
					}	
		    	});
		    	
			},
			'updateStatus' : function(formId, param){
				
				var $form = $("#"+ formId);
				
				param.SCHD_ID = $form.find("[data-key=SCHD_ID]").val();
				
				$.ajax({
					 url : '../updateStatus'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if (data.msg == 'ok')
				    	{
				    		alert('변경되었습니다');
				    		window.opener.changeScheduleBy();
				    		window.close();
				    	}
				    	else
				    	{
							alert("변경하는 도중 오류가 발생하였습니다.");
				    	}
				    }
				});
				
			},
		
			'updateSchdeule' : function(){
				//스케쥴 업데이트하기
					var $form = $('#scUpdate_fix_detail');
					
					// validation
					if( !jdg.util.validator( $form, true ) ) return false;
					
					var param = autoDataGetter($form);

					if(param.ROOM_TYPE == 'P'){
						if(param.FEE_WHOLE < 10000){
							alert('숙박비용을 만원이하로 입력할수 없습니다.');
							return;
						}
					}else{
						if (param.FEE < 10000)
						{
							alert('1인 숙박비용을 만원이하로 입력할수 없습니다.');
							return;
						}
					}
					
					if (param.STATUS_CD == '113_210')
					{
						param.CANCEL_DESC = param.CANCEL_DESC + ' 취소합니다.';
					}
					else
					{
						param.CANCEL_DESC = null;
					}
				
					var schdDate = $form.find("[data-key=SCHD_DATE]").text().replace(/-/gi,"");
					param.COMPARE_SCHD_DATE = schdDate;
					console.log(param);
					$.ajax({
						 url : '../update_schedule'
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	if (data.error)
					    	{
					    		alert(data.error);
					    	}
					    	else
					    	{
					    		alert('변경되었습니다');
					    		window.opener.changeScheduleBy();
								window.close();
					    	}
					    }
					});
			},
			
			'showScheduleDetail' : function (schdId)
			{
				var _self = this;
				
				var param = {SCHD_ID: schdId};
				
				$.ajax({
					url : _self._scheduleDetailURL
					,type : 'POST'
					,data : param
					,dataType : 'json'
					,success : function( data ) {
						$("#detail_div").html("");
						$("#detailUpdate_div").html("");
						$(".scUpdate_detail").hide();
						$("#genre_detail_div").hide();
						$("table[name=mainTable]").hide();
						
						var type = data.detail.SCHD_TIME_TYPE;
					
							
						$(".detail_popup_wrap .update_btn").attr("ptype", "single");
						$("#mainTable_div").show();
						
						if (data.detail.DESCR)
							data.detail.DESCR_HTML = data.detail.DESCR.replaceAll("\n","<br>");
						
						var item = data.detail;
						item.RSV_SUMMARY = '확정 '+ item.RESERVE_CONFIRM_CNT +'명, 미입금 ' + item.RESERVE_WAIT_CNT  + '명 , 취소 ' + item.CANCEL_CNT  +'명';
						item.FEE_TEXT = stringFilter(item.FEE, 'money') + ' 원';
						item.FEE_WHOLE_TEXT = stringFilter(item.FEE_WHOLE, 'money');

						//var availCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT  - item.RESERVE_WAIT_CNT - item.WAIT_CNT;
						var availCnt = item.PSGR_CNT - item.RESERVE_CONFIRM_CNT;
						
						if (availCnt <= 0 )
						{
							$("div#reserve_btn").hide();							
						}
						else
						{
							$("div#reserve_btn").show();
						}
						
						item.PSGR_CNT_TEXT = item.PSGR_CNT + " 명";

						if (item.STATUS_CD == "113_180")
						{
							item.STATUS_NAME = "만료"; //예약가능한 날짜가 지남
						}
						else if (availCnt <= 0 )
						{
							item.STATUS_NAME = "마감"; //예약인원이 마감
						}
						
						item.SCHD_DATE = stringFilter(item.SCHD_DATE , 'date');
						item.SCHD_TIME = stringFilter(item.SCHD_TIME , 'time');
						
						item.SCHD_DATE_TIME = item.SCHD_DATE + ' ' +  item.SCHD_TIME;
						
						var cancelDescRow = $('.scUpdate #schd_cancel_desc_row');
						
				    	if (item.STATUS_CD == '113_210')
				    	{
				    		if (item.CANCEL_DESC != null)
				    		{
				    			item.CANCEL_DESC = item.CANCEL_DESC.replace(' 출조를 취소합니다.','');					    						    			
				    		}
				    		cancelDescRow.show();
				    	}
				    	else
				    	{
				    		cancelDescRow.hide();
				    	}
				    							
						autoDataSetter( $('.detail_popup_wrap'), item);
						
						/*수정폼에서 예약한 사람이 있는 경우 비용 수정 불가.
						if(item.RESERVE_CONFIRM_CNT > 0 || item.RESERVE_WAIT_CNT > 0){
							$("#feeSpan").show();
							$("#feeInputSpan").hide();
						}*/
						
						
						$('.scUpdate').hide();
						$('#mainTable_div').hide();
					}
				});				
				
			},		
			// 예약금액 자동 셋팅
			'totalCost' : function(man, fee) {
				var _self = this;
				var $insertForm = $("#reserveForm");

				var sum = man * fee;
				if( !sum ) sum = 0;
				$insertForm.find('[data-key=TOT_COST]').text( stringFilter(sum, 'money') + ' 원');

			},
			
			
			
			//데이터 체크
			'insertCheck': function()
			{
				var _self = this;
				
				var schdInfo = _self._schdInfo;
				
				var $insertForm = $("#reserveForm");
				// validation
				var today = jdg.util.today().replaceAll('-','');
				
				 var totCost = $insertForm.find('[data-key=TOT_COST]').val();
				 totCost = totCost.replaceAll( ',', '' );
				 $insertForm.find('[data-key=TOT_COST]').val( totCost );
				 
				if( !jdg.util.validator( $insertForm, true ) ) return false;
				
				var manCnt = $insertForm.find('[data-key=MAN_CNT]').val();
				var wholeYnCheck = $insertForm.find('#wholeYnCheck').is(':checked') ? "Y" : "N";
				
				if (manCnt == "")
				{
					alert("예약인원을 선택하십시오.");
					return false;
				}
				
				var eqpCnt = $insertForm.find('[data-key=EQP_CNT]').val();
				
				if (eqpCnt == "")
				{
					alert("장비대여 대수를 선택하십시오.");
					return false;
				}				
				
				var rsvName = $insertForm.find('[data-key=RSV_NAME]').text().trim();
				var rsvTel = $insertForm.find('[data-key=RSV_TEL]').val();
				var rsvEmail = $insertForm.find('[data-key=RSV_EMAIL]').text().trim();
				var rsvDepositName = $insertForm.find('[data-key=DEPOSIT_NAME]').val().trim();
				var dispCd = $insertForm.find('[data-key=DISP_CD]').val();
				var seatTxt = $insertForm.find('[data-key=SEAT_TXT]').val();
				
				var nickName = _self._nickName;
				
				var dispTxt = "예약자표시";
				
				if (dispCd == '1') {dispTxt = rsvDepositName;  }
				else if (dispCd == '2') {dispTxt = rsvName;  }
				else if (dispCd == '3') {dispTxt = nickName;  }
				
				
				var $bankCd = $insertForm.find('[data-key=BANK_CD]');
				var bankCd = $bankCd.val();
				var vrBankingYn;
				
				if (rsvTel == "")
				{
					alert("전화번호를 입력해주십시오.(비정상적인 전화번호를 넣으면 예약이 되지 않습니다.)");
					return false;
				}
				
				if (_self.vrBankingYn)
				{
						if( bankCd == '') {
						alert('입금할 은행을 선택해주십시오. \n(선택한 은행으로 가상계좌가 생성됩니다)');
						return false;
					}
					
					vrBankingYn = "Y";
				}
				else
				{
					vrBankingYn = "N";
					bankCd = null;
				}
				
				if( rsvName == '' && rsvTel == '' &&  rsvEmail == '' ) {
					alert('예약자 정보를 입력해 주세요');
					return false;
				}
				
				if( rsvDepositName == '') {
					alert('입금자명을 입력해 주세요');
					return false;
				}
				
				var insertParam = {
						  'SCHD_ID' : schdInfo.SCHD_ID
						, 'RSV_NAME' : rsvName
						, 'RSV_TEL' : rsvTel
						, 'RSV_EMAIL' : rsvEmail
						, 'DEPOSIT_NAME' : rsvDepositName
						, 'MAN_CNT' : $insertForm.find('[data-key=MAN_CNT] option:selected').val()
						, 'EQP_CNT' : $insertForm.find('[data-key=EQP_CNT] option:selected').val()
						, 'WHOLE_YN' : 'N'
						, 'BANK_CD' : bankCd
					    , 'VR_BANKING_YN' : vrBankingYn
					    , 'WHOLE_YN' : wholeYnCheck
					    , 'DISP_CD' : dispCd
					    , 'DISP_TXT' : dispTxt
					    , 'SEAT_TXT' : seatTxt
					    , 'GENRE_ID' : genreId
					};
				
				return insertParam;
			},
			
			
			
			
			'blinkEffect' : function()
			{
				  var _self = this;
				  
				  _interval_index ++;		

				  var comp = _self._interval_objs;  
				  var status = _self._interval_index;				  
				  
				  if (status == 1 || status == 3)
				  {
				  	comp.text("");
				  }
				  else if (status == 2)
				  {
				  	comp.text("기상악화");
				  	comp.css("color", "#FF9B00");
				  }
				  else if (status == 4)
				  {
				  	comp.text("출조취소");
				  	comp.css("color", "#FF4B4B");
				  	_self._interval_index = 0;
				  }					
			},

			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				//캘린더 <,> 버튼 마우스포인트 처리
				_self.$calendarMoveBtn.css('cursor','pointer');
				
		        
			},
			
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
