$(function() {
	
	var _clickable = true;	
	
	var $modRsvForm = $(".reserv_status_popup_wrap");
	
	var _feeMan;
	var _feeWhole;
	var _rsvId;
	var _selectboxInit = false;
	
	var $listContainer  = $('#rsvBBSList'); //예약게시판용
	
	var _rsvDetailUrl = "reserve/detail_manager";
	var _rsvUpdateUrl = 'schedule/update_reserve_manager';

	$listContainer.on('click', 'tr' ,function(){
		
		if (_rsvDetailUrl == "reserve/detail_manager")
		{
			var _path = location.pathname;
			_path = _path.replace('schedule/schedule_rsv','');
			
			_rsvDetailUrl = _path + _rsvDetailUrl;
			_rsvUpdateUrl = _path + _rsvUpdateUrl;			
		}
		
		$("tr#" + Bplat.viewPkg.BplatBody._updated_rsvId).css('background','');
		Bplat.viewPkg.BplatBody._updated_rsvId = null;
		
		//_rsvRow = $(this);		
		//_rsvRow.css('background','#F7D6D6');

		showRsvForm(this.id);
	});
	
	
	$('table.scUpdate').delegate('[data-key="STATUS_CD"]','change',function() {
		
		showCancelDesc();
	});
	
	$('#scUpdate_detail_table').delegate('[data-key="STATUS_CD"]','change',function() {
		
		showCancelDescForUpdateDetail();
	});
	

	
	$modRsvForm.delegate( ".close_btn, .status_cancel_btn", "click", function() {
		close_rsvform();
	});	

	
	$modRsvForm.delegate( ".status_confirm_btn", "click", function() {
		
		if (_clickable = false) return;		
		_clickable = false;
		
		if (confirm('변경된 내용을 저장하시겠습니까?'))
		{
			updateReserve();
		}			
	});	

	
	// 인원수 변경
	$modRsvForm.delegate('[data-key=MAN_CNT]','change',function() {	
		totalCost();
	});						
	
	
	// 독선여부 체크
	$modRsvForm.delegate('#wholeYnCheck','change',function() {				
		
		var $manCntSel = $modRsvForm.find('[data-key=MAN_CNT]');		
		
		if( $(this).is(':checked') ) {
			if( undefined != _feeWhole && '' != _feeWhole ) {
				$modRsvForm.find('[data-key=TOT_COST]').text( stringFilter(_feeWhole, 'money')  );
			} else {
				totalCost();
			}
			$manCntSel.val( $manCntSel.find('option:last').val() );
			$manCntSel.attr('disabled', true);
		} else {
			$manCntSel.attr('disabled', false);
		}
	});	

	$('.schd_tb2 ').delegate( ".btnModifyRsv", "click", function() {
		
		var rsvId = $(this).attr('rsv_id');
		
		showRsvForm(rsvId);
		
	});	
	
	
	function showRsvForm(rsv_id)
	{
		isScroll = false;
	    lockScroll();

		
		var $rsvView = $('.reserv_status_popup_wrap');
		
		$.ajax({
			 url : _rsvDetailUrl
			,type : 'POST'
			,data : {rsvId: rsv_id}
		    ,dataType : 'json'
		    ,success : function( data ) { 
		    	
		    	if (data.error)
		    	{
		    		alert(data.error);
		            isScroll = true;
		            unlockScroll();
		    	}
		    	else
		    	{
		    		var dataObj = data.memReserveDetail;
		    		var refundObj = data.refundInfo;
			        var selectMan = $rsvView.find('[data-key="MAN_CNT"]');
			        var selectEqp = $rsvView.find('[data-key="EQP_CNT"]');
			        
					var warn_text;
					
					
			    	if (dataObj.SITE_CD == 'P')
			    	{
			    		warn_text = '** 포털에서 예약하신 고객입니다. 포털예약은 수정하실 수 없습니다.';
			    		$rsvView.find('.status_confirm_btn').hide(); 
			    		$rsvView.find('input,textarea,select').prop('disabled', true);
			    		
//			    		var tomo = jdg.util.todayAdd(1).replaceAll('-','');
//			    		
//			    		if (tomo < dataObj.SCHD_DATE)
//			    		{
//			    			dataObj.RSV_TEL = '***-***-****';
//			    			dataObj.RSV_EMAIL = '***************';
//			    			warn_text += '<br>※ 연락처는 출조일 하루전부터 조회가능합니다.';
//			    		}
			    		
			    	}
			    	else if (dataObj.SITE_CD == 'S')
			    	{
			    		warn_text = '** 선단에서 예약하신 고객입니다. 선단예약은 수정하실 수 없습니다.';
			    		$rsvView.find('.status_confirm_btn').hide(); 
			    		$rsvView.find('input,textarea,select').prop('disabled', true);
			    	}
			    	else if (dataObj.SITE_CD == 'C') //쿠팡
			    	{
			    		warn_text = '쿠팡을 통해서 예약하신 고객입니다. <br/>쿠팡을 통한 예약은 수정하실 수 없습니다.';
			    		$rsvView.find('.status_confirm_btn').hide(); 
			    		$rsvView.find('input,textarea,select').prop('disabled', true).attr("disabled",true);
			    	}
			    	else
			    	{
			    		warn_text = '※ 예약자명, 예약일, 예약상태를 확인하시고 변경해주시기 바랍니다. <br>※ 메모는 관리자만 조회됩니다. 예약에 대한 정보를 메모하시면 됩니다.';
			    		$rsvView.find('.status_confirm_btn').show(); 
			    		$rsvView.find('input,textarea,select').prop('disabled', false);
			    	}
			    	
			    	$rsvView.find('.warning').html(warn_text);
			        
			        if (_selectboxInit == false)
			        {
				        var cnt = dataObj.PSGR_CNT;
				        
				        selectEqp.append('<option value="0">0대</option>');
				    	
				        for (var i=1; i <= cnt; i++)
				        {
				        	selectMan.append('<option value="' + i + '">' + i + '명</option>');
				        	selectEqp.append('<option value="' + i + '">' + i + '대</option>');
				        }		
				        
				        _selectboxInit = true;
			        }
			   				    		
		    		_feeMan = dataObj.FEE;
		    		_feeWhole = dataObj.FEE_WHOLE;
		    		_rsvId = dataObj.RSV_ID;
		    		
		    		console.log(dataObj);
		    		
		    		if(dataObj.EQP1 != null && dataObj.EQP1 != ''){
		    			$rsvView.find("tr.tool1_tr").css("display","");
		    			 for (var i=0; i <= cnt; i++)
					        {
		    				 	$rsvView.find("[data-key='EQP1']").append('<option value="' + i + '">' + i + '대</option>');
					        }	
		    		}
		    		

		    		if(dataObj.EQP2 != null && dataObj.EQP2 != ''){
		    			$rsvView.find("tr.tool2_tr").css("display","");
		    			 for (var i=0; i <= cnt; i++)
					        {
		    				 	$rsvView.find("[data-key='EQP2']").append('<option value="' + i + '">' + i + '대</option>');
					        }	
		    		}
		    		

		    		if(dataObj.EQP3 != null && dataObj.EQP3 != ''){
		    			$rsvView.find("tr.tool3_tr").css("display","");
		    			 for (var i=0; i <= cnt; i++)
					        {
		    				 	$rsvView.find("[data-key='EQP3']").append('<option value="' + i + '">' + i + '대</option>');
					        }	
		    		}
		    		
		    		dataObj.TOT_COST = stringFilter(dataObj.TOT_COST, 'money');
		    		
		    		autoDataSetter( $rsvView, dataObj);
		    		
		    		var checked = dataObj.WHOLE_YN == "Y";		    		
		    		
		    		$rsvView.find("#wholeYnCheck").attr('checked', checked);		    		
		    		
		    		if (dataObj.SITE_CD != 'P') 
		    		{
						var $manCntSel = $rsvView.find('[data-key=MAN_CNT]');
						$manCntSel.attr('disabled', checked);		    			
		    		}
		    		
		    			
		    		if(refundObj != null){
		    			$rsvView.find(".refundAccountInfo").html("예금주명:"+refundObj.REFUND_RSV_NAME +", 은행명: "+ refundObj.REFUND_BANK+"[계좌정보: "+refundObj.REFUND_ACCOUNT_NUM+"]");
		    			$rsvView.find(".refundAccountDiv").css("display","contents");
		    		}else{
		    			$rsvView.find(".refundAccountInfo").html("");
		    			$rsvView.find(".refundAccountDiv").css("display","none");
		    		}
		    				    		
		    		$('table.rsvUpdate').attr("genre", dataObj.CHOICE_GENRE);
		    		$rsvView.find('.popup_common_con').css({top: '40%'});		    		
		    		$rsvView.show();	
		    		
		    		if($("#siteType").val() == '4'){
		    			$rsvView.find('[data-key=MAN_CNT]').css("display","none");
		    		}else{
		    			$rsvView.find('[data-key=MAN_CNT]').css("display","");
		    		}
		    	}
		    }
		});
		
		
		
	}
	
	
	function showCancelDesc()
	{
		var cd = $('table.scUpdate [data-key="STATUS_CD"]').val();
		
		var cancelDescRow = $('.scUpdate #schd_cancel_desc_row');
		
		if (cd == "113_210")
		{
			cancelDescRow.show();
		}
		else
		{
			cancelDescRow.hide();
		}
	}
	
	function showCancelDescForUpdateDetail()
	{
		var cd = $('#scUpdate_detail_table [data-key="STATUS_CD"]').val();
		
		var cancelDescRow = $('#scUpdate_detail_table #schd_cancel_desc_row');
		
		if (cd == "113_210")
		{
			cancelDescRow.show();
		}
		else
		{
			cancelDescRow.hide();
		}
	}
	
	function close_rsvform()
	{
        isScroll = true;
        unlockScroll();
        $modRsvForm.hide();
	}

	// 예약 수정
	function updateReserve() 
	{
		var $form = $modRsvForm;
		
		// validation
		if( !jdg.util.validator( $form, true ) ) return false;
		
		var param = autoDataGetter($form);
		
		param.TOT_COST = param.TOT_COST.replace(/,/g,'');
		param.RSV_ID = _rsvId;
		param.CHOICE_GENRE = $form.find("table.rsvUpdate").attr("genre");
				
		$.ajax({
			 url : _rsvUpdateUrl
			,type : 'POST'
			,data : param
		    ,dataType : 'json'
		    ,success : function( data ) {
		    	
		    	if (data.error)
		    	{
		    		alert(data.error);
		    	}
		    	else
		    	{
		    	
					close_rsvform();
					alert('변경되었습니다');
		    		
		    		if ($listContainer.attr('id') == 'rsvBBSList') // 예약현황판(최신예약상황) 인경우
		    		{
		    			Bplat.viewPkg.BplatBody._updated_rsvId = _rsvId;
		    			Bplat.viewPkg.BplatBody.getReserveList();	
		    		}
		    		else 
		    		{
		    			Bplat.viewPkg.BplatBody.renderScheduleList();		    		
		    		}
		    	}
		    }
		});
	};	
	
	
	
	// 예약금액 자동 셋팅
	function totalCost() {
		
		var man = $modRsvForm.find('[data-key=MAN_CNT]').val();
		var sum = man * _feeMan;
		if( !sum ) sum = 0;
		$modRsvForm.find('[data-key=TOT_COST]').text( stringFilter(sum, 'money') );
		$(".jdg-page-schedule").css("width","+=1");
		$(".jdg-page-schedule").removeAttr("style");
	};
	
	function stringFilter(str, format){
		switch (format) {
		case 'date':
			if(str.length >= 8){
				//yyyy-mm-dd	
				str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
			}else if(str.length == 6){
				//yyyy-mm
				str = str.substr(0,4) + "-" + str.substr(4,2);
			}else if(str.length == 4){
				//yyyy
				str = str.substr(0,4);
			}
			break;
		case 'money':
			//comma
			var pattern = /(^[+-]?\d+)(\d{3})/;
			str += '';
			
			while(pattern.test(str)) {
				str = str.replace(pattern,'$1,$2');
			}
			break;	
		case 'removeHyphen':
			//remove hyphen date
			str = str.replaceAll('-', '');
			break;	
		default:
			break;
		}
		return str;
	}
	
});


function changeScheduleBy(){
	Bplat.viewPkg.BplatBody.renderScheduleList();	
}