defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._msgInsertURL = $('#msgInsertURL').val();
				this._msgDetailURL = $('#msgDetailURL').val();
				this._msgUpdateURL = $("#msgUpdateURL").val();
				this._msgListURL = $("#msgListURL").val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$insertForm = $('#frm');
				this.$insertBtn = $('#insertBbsBtn');
				this.$type;
				
				this.fileList = null;
				this.type = $("#type").val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				
								
				$("#ir1").on("keyup", function(){
					var content = $(this).val();
					var value = _self.checkBytes(content);
					$("span.count_txt").html(value);
					if(value > 130){
						$("span.msg_type").html("LMS");
					}else{
						$("span.msg_type").html("SMS");
					}
					if(value > 1499){ // 최대 1500자
						var content_ = content.substr(0,1499);
						$("#ir1").val(content_);
						return false;
					}
				});
				
				$("#tempType").on("change", function(){
					var value= $(this).val();
					var html = "";
					$("#temp_title").val("");
					$("#temp_title").hide();
					
					if(value == 1){ //승선안내
						html = "출조안내 \n"
							+ "[예약자명] 님  [출조날짜],  [출조인원] 명 예약감사드립니다.\n"
							+ "선박명:[선박명] \n출조점명:[출조점명]\n"
							+ "출조점주소:[출조점주소] \n출조시간:[출조시간]\n배타는곳:[배타는곳]\n"
							+ "선장연락처:[선장연락처]\n준비물:[준비물]\n출조안내:[출조안내]\n"
							+ "선박제공서비스:[선박제공서비스]\n장비임대비:[장비임대비]\n채비:[채비]\n"
							+ "감사합니다."; 
					}else if(value == 2){ //출조취소(기상악화)
						html += "[선박명] [출조날짜]\n기상악화로 출조취소.\n입금자명의 환불계좌를 부탁드립니다."; 
					}else if(value == 3){ //출조취소(선박정비)
						html += "[선박명] [출조날짜]\n선박정비로 출조취소.\n입금자명의 환불계좌를 부탁드립니다.";
					}else if(value == 4){ //출조취소(개인사정) 
						html += "[선박명] [출조날짜]\n개인사정으로 출조취소.\n입금자명의 환불계좌를 부탁드립니다.";
					}else if(value == 5){ //예약시계좌안내
						html += "[선박명] [선박계좌번호]\n예금주:[예금주] 예약금액: [예약금액] \n입금바랍니다.";
					}else if(value == 6){ //기타
						$("#temp_title").show();
					}
					
					var cnt = _self.checkBytes(html);
					$("spna.count_txt").html(cnt);
					$("#ir1").val(html);
					$("#ir1").trigger("keyup");
					
				});
				// 템플릿 등록/수정
				_self.$insertBtn.click( function() {
					if(_self.type == "update"){
						_self.updateTemplate();
					}else
						_self.insertTemplate();
				});
				
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
						}
				);
				
				
			},
			'detailTemplate' : function(){
				var _self = this;
				var seq = $("#seq").val();
				$.ajax({
					 url : _self._msgDetailURL
					,type : 'POST'
					,data : {SEQ : seq}
				    ,dataType : 'json'
				    ,success : function( data ) {				    	
				    	console.log(data);
				    	var result = data.result;
				    	$("#title").val(result.TITLE);
				    	if(result.TEMP_TYPE == '직접작성'){
				    		$("#temp_title").show();
				    	}
				    	$("#tempType option").each(function(){
				    		if($(this).html() == result.TEMP_TYPE){
				    			$(this).attr("selected","selected");
				    		}
				    	});
				      	$("#temp_title").val(result.TEMP_SUBTITLE);
				      	$("#ir1").val(result.CONTENT);
				      	$("#ir1").trigger("keyup");
				      	if(result.MAIN_IMG_ID != null && result.MAIN_IMG_ID != ''){
				      		_self.fileList.init(result);
				      	}else{
				      		_self.fileList.init();
				      	}
				      	
				      	$("#useYn").val(data.USE_YN);
				    }
				}); 
			},
			 //byte 체크
			'checkBytes' : function(s){
				for (b = i = 0; c = s.charCodeAt(i++); b += c >> 11 ? 3 : c >> 7 ? 2 : 1);
			    return b;
			},
			// 템플릿 등록
			'insertTemplate' : function() {
				var _self = this;
				var param = {};
				
				var tempType = $("#tempType").val();
				if(tempType != 6){
					param.TEMP_TYPE = $("#tempType option:selected").html();
				}else{
					param.TEMP_TYPE = $("#tempType option:selected").html();
					var tempTitle = $("#temp_title").val();
					if(tempTitle == ''){
						alert("문구종류를 입력해주세요.");
						return;
					}
					param.TEMP_SUBTITLE = tempTitle;
				}
					
				param.TITLE = $('#title').val();
				
				if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(param.TITLE))){
					alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
					return;
				}
				param.CONTENT =$('#ir1').val();			
				param.CONTENT_LENGTH = _self.checkBytes(param.CONTENT);
				if(param.CONTENT_LENGTH > 130){
					param.SMS_TYPE = "LMS";
				}else{
					param.SMS_TYPE = "SMS";
				}
				
				$("div.fileList").find("div.fileListRow").each(function(){
					param.MAIN_IMG_ID = $(this).attr("img_id");
					param.SMS_TYPE = "MMS";
				});
				
				if (param.TITLE == '')
				{
					alert('제목을 입력해주십시오.');
					return false;
				}
				
				if (param.CONTENT == '')
				{
					alert('내용을 입력해주십시오.');
					return false;
				}
				
				$.ajax({
					 url : _self._msgInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {				    	
				    	if( data.hasOwnProperty('msg') ) {
				    		if(data.msg == "success"){
					    		alert('등록되었습니다.');
					    		location.href=_self._msgListURL;
					    		return;
				    		}
				    		
				    		alert("등록 도중 오류가 발생하였습니다.");
				    		return;
				    	} else {
				    		alert('로그인이 필요 합니다.');
				    		showLoginBox(null, false);
				    	}
				    }
				}); 
			},
			// 템플릿 수정
			'updateTemplate' : function() {
				var _self = this;
				var param = { SEQ : $("#seq").val() };
				
				var tempType = $("#tempType").val();
				if(tempType != 6){
					param.TEMP_TYPE = $("#tempType option:selected").html();
				}else{
					param.TEMP_TYPE = $("#tempType option:selected").html();
					var tempTitle = $("#temp_title").val();
					if(tempTitle == ''){
						alert("문구종류를 입력해주세요.");
						return;
					}
					param.TEMP_SUBTITLE = tempTitle;
				}
					
				param.TITLE = $('#title').val();
				
				if(!(/^[0-9ㄱ-ㅎ가-힣a-zA-z\s\(\)\[\]]*$/.test(param.TITLE))){
					alert("영문자,숫자,한글, (,),[,]만 입력가능합니다.");
					return;
				}
				param.CONTENT =$('#ir1').val();			
				param.CONTENT_LENGTH = _self.checkBytes(param.CONTENT);
				if(param.CONTENT_LENGTH > 130){
					param.SMS_TYPE = "LMS";
				}else{
					param.SMS_TYPE = "SMS";
				}
				
				$("div.fileList").find("div.fileListRow").each(function(){
					param.MAIN_IMG_ID = $(this).attr("img_id");
					param.SMS_TYPE = "MMS";
				});
				
				if (param.TITLE == '')
				{
					alert('제목을 입력해주십시오.');
					return false;
				}
				
				if (param.CONTENT == '')
				{
					alert('내용을 입력해주십시오.');
					return false;
				}
				
				//사용여부
				param.USE_YN = $("#useYn").val();
				
				$.ajax({
					 url : _self._msgUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {				    	
				    	if( data.hasOwnProperty('msg') ) {
				    		if(data.msg == "success"){
					    		alert('수정되었습니다.');
					    		location.href=_self._msgListURL;
					    		return;
				    		}
				    		
				    		alert("수정 도중 오류가 발생하였습니다.");
				    		return;
				    	} else {
				    		alert('로그인이 필요 합니다.');
				    		showLoginBox(null, false);
				    	}
				    }
				}); 
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				// 파일리스트
				_self.fileList  = new component.FileList({
					 'id' : this.$insertForm.attr('id')
					,'container' : this.$insertForm.find('[data-type=IMAGE_LIST]')
					,'selection' : "N"
						,'max_file' : 1
				});
				
				if(_self.type == "update"){
					_self.detailTemplate();
				}else{
					// 파일리스트 초기화
					_self.fileList.init();
				}
				$("#tempType").trigger("change");
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});