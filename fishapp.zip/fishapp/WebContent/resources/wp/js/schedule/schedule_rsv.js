defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {

				this.postListURL 		= $('#postListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();

				this.$listContainer 			= $('#rsvBBSList');

				this.$resvListTemplate 			= $('#resvListTemplate .resvListRow');			
				this.$postNoDataTemplate       = $('#postListTemplate .nodata');
				
				this._srch_cond = null;
				this._sort_cond = null;
				this._srch_text = null;
				this._page = 1;
				
				this._updated_rsvId = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				$('select.sort').change(function() {
					_self._sort_cond = $(this).val();
					_self._page = 1;
					_self.getReserveList();
				});	

				$(':reset').on('click',function() {
					
					_self._srch_cond = null;
					_self._sort_cond = null;
					_self._srch_text = null;
					_self._page = 1;
				});

				$(':submit').click(function() {
					
					_self._srch_cond = $("select.srch").val();					
					_self._srch_text = $("#srch_text").val();	
					
					if (_self._srch_cond == "DISP_TXT")
					{
						_self._srch_text = _self._srch_text.trim(); 
						
						if (_self._srch_text == "")
						{
							_self._srch_cond = null;
							_self._srch_text = null;
						}
						else if (_self._srch_text.length == 1)
						{
							alert('검색하실 이름을 두글자이상 입력하십시오.');return false;
						}
						else
						{
							_self._srch_text = '%' + _self._srch_text + '%';
						}
					}
					else
					{
						if (_self._srch_text == "")
						{
							alert('검색하실 날짜를 입력하십시오.');return false;
						}

						if (_self._srch_text < "20140101" || _self._srch_text > "29991231")
						{
							alert('날짜형식이 맞지 않습니다.(예: 20151022 )');return false;
						}
						
					}					

					_self._page = 1;
					_self.getReserveList();
					
					return false;
				});				
				
			},
			
			'getReserveList' : function(page) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				var _total = 0;
				var page = _self._page;
				
				_contatiner = _self.$listContainer;
				_contatiner.empty();				
								
				_paging = $('#resvListPaging');				

				// defaultParam 세팅
				var itemCnt     = 5;
				var param = {
						 'PAGE' : page
						,'PERPAGE' : '10'
				};
				
				if (_self._sort_cond)
				{
					param.SORT = _self._sort_cond;
				}				

				if (_self._srch_cond)
				{
					param[_self._srch_cond] = _self._srch_text;
				}
				
				
				$.ajax({
					 url : "rsv_list"
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
			    		if (data.error)
			    		{
			    			alert(data.error);
			    			return;
			    		}
				    	
			    		var d = new Date();
			    		var curr_time = d.getTime();
			    		var new_std = curr_time - 24 * 60 * 60 * 1000; //새 예약건의 기준은 24시간
			    	
				    	$.each(data.reserveList, function(idx,data) {
				    		
				    	    if (_total == 0)
				    	    {
				    	    	_total = data.TOTAL * 1;
				    	    }
				    		
				    	    $row = _self.$resvListTemplate.clone();		
				    		 
				    		 $row.attr('id', data.RSV_ID );
				    		 
				    		 if (data.STATUS_CD == '104_300')
			    			 {
				    			 data.STATUS_NAME = '<span class="finish">확정</span>';
			    			 }		
				    		 else if (data.STATUS_CD == '104_340')
			    			 {
				    			 data.STATUS_NAME = '<span class="finish">확정(미입금)</span>';
			    			 }				    		 
				    		 
				    		 if (_self._sort_cond == null || _self._sort_cond.indexOf("_UP") > 1)
				    		 {
				    			 data.ROW_NUMBER = _total - data.ROW_NUMBER + 1;
				    		 }
				    		 
				    		 var rsv_time = Date.parse(data.RSV_DATE);
				    		 
				    		 if (rsv_time > new_std)
				    		 {
				    			 data.ROW_NUMBER = '<img src="https://img.fishapp.co.kr/legacy/wp/icon_new.png" style="margin: 0px 0 4px 3px;">' + data.ROW_NUMBER;
				    		 }
				    		 
				    		 
				    		 data.DISP_TXT = data.DISP_TXT + " (" + data.MAN_CNT + ")";
				    		 
				    		 setFiledByData($row, 'ROW_NUMBER', data);
				    		 //setFiledByData($row, 'RSV_DATE', data);
				    		 setFiledByData($row, 'RSV_DATE', data, 'date');
				    		 setFiledByDataFilter($row, 'SCHD_DATE', data, 'date');
				    		 setFiledByData($row, 'SUB_TITLE', data);
				    		 setFiledByData($row, 'DISP_TXT', data);
				    		 //setFiledByData($row, 'MAN_CNT', data);				    		 
				    		 setFiledByData($row, 'STATUS_NM', data);
				    		 
				    		 _contatiner.append( $row );		    			
				    	 });
				    	
				    	if (_self._updated_rsvId)
				    	{
				    		$("tr#" + _self._updated_rsvId).css('background','#F7D6D6');
				    	}
				    	
				    	var numOfPages = Math.ceil(_total / 10);
				    	
			    		// 페이징 초기화
			    		$(_paging).paging({
							 current: page
							,max: numOfPages
							,itemClass: ''
							,prevClass: 'paging_prev'
							,nextClass: 'paging_next'
							,firstClass: ''
							,lastClass: ''
							,length: 5
							,itemCurrent: 'on'
							,onclick:function(e,page){
								_self._page = page;								
								_self.getReserveList();
							}
						});	
			    		
			    		if (page <= 5)
			    		{
			    			_paging.css("margin-left","40px");
			    		}
			    		else
			    		{
			    			_paging.css("margin-left","");
			    		}
			    		
			    		_paging.find('.paging_prev').text("<");
			    		
			    		if (numOfPages > 5)
			    		_paging.find('.paging_next').text(">");	
				    }
				});				
			},	
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[schedule_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self._page = 1;				
				_self.getReserveList();
		        
			},
			
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[schedule_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[schedule_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[schedule_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[schedule_main] onDestroy Method' );
			}		
	  }
});
