defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishListURL = $('#fishListURL').val();
				this.fishDetailURL = $('#fishDetailURL').val();
				this.imageURL = $('#imageURL').val();
				this.noImageURL = $('#noImageURL').val();
				this.fishInsertURL = $('#fishInsertURL').val();
				// element
				this.$fishContainer = $('#fishContainer');
				this.$fishListContainer = $('#fishListContainer');
				this.$searchRow = $('#fishTemplate').find('.searchRow');
				this.$imageRow = $('#fishTemplate').find('.imageRow');
				this.$insertBtn = $('#insertBtn');
				this.$editHbBtn = $('#editHbBtn');
				// static variable
				this.fishMonth = $('#fishMonth').val();
				this.$typeCd = '106_110';
				
				this.tabList = $('.cdt_tab_menu li');
				this.$condList = $('.cdt_list_con');
				this.$template = this.$condList.find('li');
				
				this.$prevPage = $('.cdt_list_prev');
				this.$nextPage = $('.cdt_list_next');				
				
			    this.tabIndex = 0;
			    this.page = 1;
			    this.maxpage = 1;
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$insertBtn.click(function (){
					
					if (isLogin() == false)
					{
						showLoginBox("insert_form");
						return;
					}
					else
					{
						location.href = "insert_form";
					}

				});
				
				_self.$editHbBtn.click(function (){
					
					if (isLogin() == false)
					{
						showLoginBox("edit_hongbo_form");
						return;
					}
					else
					{
						location.href = "edit_hongbo_form";
					}
				});
				
				_self.tabList.on('click', function() {
	                var index = _self.tabList.index(this);

	                if (_self.tabIndex == index) return;
	                
	                _self.$typeCd = $(this).data("cd");
	               
	                // 이전 탭
	                $(_self.tabList[_self.tabIndex]).removeClass('on');
	                // 클릭 탭
	                $(_self.tabList[index]).addClass('on');
	                $(_self.tabList[index]).removeClass('over');
	                
	                _self.page = 1;
	                
	                location.hash = _self.$typeCd == "106_110" ? "#c1" : "#m1";

	                _self.tabIndex = index;
	                
	                _self.getFishList();
	            });

	            _self.tabList.on('mouseenter', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).addClass('over');
	            });

	            _self.tabList.on('mouseleave', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).removeClass('over');
	            });
	            
	            
				_self.$prevPage.click(function (){
					
					stopEvent(event);
					
					if (_self.page > 1)
					{
						_self.page --;						
						arrowMoveTop = $(window).scrollTop();
						
						_self.getFishList();
						
				    	// 스크롤을 아래로 내린다				    	
						initScrollDown();
					}
				});
				
				_self.$nextPage.click(function (){
					
					stopEvent(event);
					
					if (_self.page < _self.maxpage)
					{
						_self.page ++;
						arrowMoveTop = $(window).scrollTop();
						
						_self.getFishList();
						
				    	// 스크롤을 아래로 내린다
						initScrollDown();
					}
				});	
				
				$('.fishImg').error(function (){
					
					$(this).unbind("error").attr("src", "https://img.fishapp.co.kr/legacy/wp/nopic.jpg");
					
				});
			},
			'getFishList' : function() {
				var _self = this;
				var page = _self.page;
				
				this.$condList.empty();
				
				if (_self.page == 1)
				{
					_self.$prevPage.hide();
				}
				else
				{
					_self.$prevPage.show();
				}

				// 조회 데이터
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '8'
				};
				$.ajax({
					 url : _self.fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	_self.maxpage = Math.ceil(data.total / 8);
					    	
							if (_self.page == _self.maxpage || _self.maxpage == 0)
							{
								_self.$nextPage.hide();
							}
							else
							{
								_self.$nextPage.show();
							}
					    	
					    	var roomList = data.roomList;

				    		$.each( roomList, function(idx,data) {					    			
				    			console.log(data);
				    			var tmp = _self.$template.clone();					    			
				    			
				    			tmp.find('a.detail_link').attr('href', "detail_form?ROOM_ID=" + data.ROOM_ID);
				    			tmp.find('.title').text(data.ROOM_NM);	
				    			tmp.find('.text').text(data.ROOM_DESC);
				    			tmp.find('.info').html('숙박 기준인원 : '+data.STD_MAN + "명 ( 최대 인원 : "+ data.PSGR_CNT + "명 )");
				    			
				    			var imgList = data.IMAGE_LIST;
				    			var imgUrl;
				    			
				    			if(imgList != null && imgList.length > 0){
				    				var img = imgList[0];
				    				imgUrl = img.HOSTING_URL;
				    			}
				    			else
				    			{
				    				imgUrl = "https://img.fishapp.co.kr/img/common/not_found_280.png";
				    			}
				    			
				    			var imgTag = '<img class="fishImg" src="' + imgUrl + '" alt="객실" onerror="this.src=\'https://img.fishapp.co.kr/img/common/not_found_280.png\'">';	
				    			tmp.find('.img').html(imgTag);
				    			
				    			
				    			_self.$condList.append(tmp);
				    		}
					   );

				    	if (data.roomList)
				    	{
				    		var remain = 4 - data.roomList.length % 4;
				    		
				    		if (remain != 4)
				    			{
						    		for (var i = 0; i < remain; i++)
						    		{
						    			_self.$condList.append("<li style='height: 374px;cursor: initial'><div style='height: 238px;width: 280px;background: #f7fbff;'></div><div class='cdt_list_info_con'></div></li>");
						    		}				    			
				    			}
				    	}


				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				
				var _self = this;				

				// 초기화
				_self.setElement();
				_self.setEvent();
				var hash = location.hash;
												
				if( '' != hash ) {
					location.hash = '#c1';
				} else {
					_self.page = Number(hash.substr(2));
				}
				
				_self.getFishList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
				

				
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
