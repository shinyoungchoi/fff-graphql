defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				//url
				this._updateFishURL = $('#updateFishURL').val();
				this._listFishURL = $('#listFishURL').val();
				// element

				this.$updateBtn = $('#updateBtn');
				this.$listBtn = $('#listBtn');
				// static variable

				this.roomId = $('#roomId').val();				

			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$listBtn.click( function() {
					alert("chrlghk??");
					Bplat.view.loadPage( _self._listFishURL);
				});

				
				$(".divControl>img").click(function(event){
					
					var alt = this.alt;
					
					if (alt == "수정")
					{
						location.href = _self._updateFishURL + '?ROOM_ID=' + _self.roomId;
					}
					
				});
				
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_detail_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_detail_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_detail_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_detail_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_detail_form] onDestroy Method' );
			}		
	  }
});
