defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._scheduleListURL = $('#scheduleListURL').val();
				
			    // 달력 컨트롤
			    this.$calendar = $('#mainTopCal')[0];
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				
			},
			'setEvent'		: function() {
				var _self = this;
				
				var cal = _self.$calendar;
				
			    $('#mainTopCal #calCloseBtn').on( 'click', function(){
			        TweenMax.to ( cal, 0.5, {marginTop:30, opacity:0, ease:Cubic.easeInOut, onComplete : function(){
			            $(cal).hide();
			        } });
			    });
				
				//캘린더 클릭
			    $('.cal').on( 'click', function(){
			    	
			    	_self.getScheduleList();

			    });
			    
				//조황 클릭
			    $('.list_on').on( 'click', function(){
			    	
			    	location.href = "fish/detail_form?GALR_ID=" + $(this).data('id');

			    });
			    

				$('#btnMap').on( 'click', function(e){
					preventEvent(e);
				    				    
				    var link = $(this).data('url');	    
				    popupFullScreen(link);
				});
			    
			    
			    //예약버튼 클릭
			    $('.reserve_btn').on('click', function() {
			    	
			    	var resvDate = $('#reservationDate').val();
			    	
			        if (!resvDate) {
			            alert('예약날짜를 선택해주세요.');
			            return;
			        }
			        
			        var manCnt = $('#personnelNum').val();
			        
			        if (manCnt == 0 ) {
			            alert('예약인원을 선택해주세요.');
			            return;
			        }
			        
			        if (manCnt > availCnt) {			         
			            alert('예약가능한 인원을 초과하였습니다! (최대 ' + availCnt + '명)');
			            return;			        	
			        }
			        
			        
			        var eqpCnt = $('#equipmentNum').val();
			        
			        if (eqpCnt > manCnt) {
			            alert('장비 임대가 예약 인원보다 많습니다!');
			            return;
			        }			        

			        var goUrl = "schedule";
			        
					if (isLogin() == false)
					{
						showLoginBox(goUrl);
						return;
					}
					
					location.href = goUrl;
			        
			    });
			    
			    //공지사항 클릭
				$(".notice_wrap").delegate( ".notice_on", "click", function() {
					
					var me = $(this);
					var postId =me.attr("postId");
					var titleKr;
					var titleEn;
					
					titleKr = "공지";
					titleEn = "Notice";
					
					_self.$popupTitleKr.text(titleKr);
					_self.$popupTitleEn.text(titleEn);					
					
					_self.$popSubject.text("");
					_self.$popupContent.html("");
					_self.$popupDate.text("");					
					
					showPop('.notice_pop_wrap', '.popup_common_con');					
					
					var defaultParam = {
							 'POST_ID' 		: postId
						};
					
					$.ajax({
						 url : 'post/detail'
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data )
						    {
					    		var dtl = data.detailPost;
					    		var content = dtl.CONTENT;
					    	
								_self.$popSubject.text(dtl.TITLE);
								
								_self.$popupDate.text(dtl.CREATED_AT);	
								
								var imglist = data.imageList;
								var imgtag = "";
								
								if (imglist != null && imglist.length > 0)
								{
									var leng = imglist.length;
									
									for (var i=0; i < leng; i++)
									{
										imgtag += "<p style='padding-top:40px; padding-bottom:15px'><img src='/cm/file/image/" + imglist[i].IMG_ID + "/520'></p>";
										
										if (imglist[i].CONTENT != null)
										{
											imgtag += "<p>" + imglist[i].CONTENT + "</p>";
										}										
										
									}		
									
									content += imgtag;
								}
						    	
								
								_self.$popupContent.html(content);
						    	
						    }
					});
					

				});				


			},
			// 출조스케쥴 목록 조회
			'getScheduleList' : function() {
				var _self = this;
				var tmpDay = new Date();
				$.ajax({
					 url : _self._scheduleListURL
					,type : 'POST'
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	_self._scheduleList = data.scheduleList;
			    		
			    		var cal = _self.$calendar;

			    		makeCalendar($('#reservationDate').val());
				        $(cal).css( 'display', 'block').css('opacity', '0');
				        TweenMax.to ( cal, 0.5, {marginTop:0, opacity:1, ease:Cubic.easeInOut });
				    }
				});
			},
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				// 초기화
				this.setElement();
				this.setEvent();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
