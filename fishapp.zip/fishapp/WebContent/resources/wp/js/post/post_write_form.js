defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._postInsertURL = $('#postInsertURL').val();
				this._postUpdateURL = $("#postUpdateURL").val();
				this._postDeleteURL = $("#postDeleteURL").val();
				this._postMainURL = $("#postMainURL").val();
				this._loginURL = $('#loginURL').val();
				this.$insertForm = $("#postInsertForm");
				this.$insertPostBtn = $('#insertPostBtn');
				this.$deletePostBtn = $("#deletePostBtn");
				this._typeCd = $('#typeCd').val();	
				this._postDetailURL = $("#postDetailURL").val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				loadWebEditor("ir1", "");
				
				// 공지사항 등록
				_self.$insertPostBtn.on("click", function() {
					if($("#type").val() == "update"){
						_self.updatePost();
					}else{
						_self.insertPost();
					}					
				});
				
				//공지사항 삭제
				_self.$deletePostBtn.click(function(){
					_self.deletePost();
				});
				
				
				$("[data-type='IMAGE_LIST']").delegate('div.up','click', function() {
					event.preventDefault();
					_self.changeImageIndex(this, -1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});

				$("[data-type='IMAGE_LIST']").delegate('div.down','click', function() {
					event.preventDefault();
					_self.changeImageIndex(this, +1); //업버튼을 눌렀을때는 해당 이미지를 한칸위로 이동
				});
			},
			// 상세 정보
			'getDetail' : function(param ) {
				var _self = this;
				var $insertForm = _self.$insertForm;
				var defaultParam = {
					 'POST_ID' 		: $("#postId").val()
				};
				$.extend( defaultParam, param );
				$.ajax({
					 url : _self._postDetailURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if(data.hasOwnProperty('detailPost')){
				    		var detail = data.detailPost;
				    		// 컨텐츠 내용중 <br> 에 대한 문자열은 \n 으로 변환
							var content = detail.CONTENT;
							if( null != content && content.indexOf('<br>') ){
								content = content.replace(/<br>/gi, '\n');
								detail.CONTENT = content;
								console.log(detail.CONTENT);
							}
							
							$("#ir1").val(detail.CONTENT);
							
							// 수정데이터셋팅
							jdg.util.detailDataSetting( $insertForm, detail );
														
							// 파일리스트 초기화
							_self.fileList = new component.FileList({
								 'id' 				: $insertForm.attr('id')
								,'container' 		: $insertForm.find('[data-type=IMAGE_LIST]')
							});
							_self.fileList.init(data.imageList);
							$("#loading").hide();
				    	}
				    }, error: function(){
				    	$("#loading").hide();
				    }
				});
			},
			//공지사항 삭제
			'deletePost' : function(){
				var _self = this;
				
				if (_self._lock) return; //중복등록방지
				_self._lock = true;
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) 
				{
					_self._lock = false;
					return false;
				}				
				
				var param = autoDataGetter($insertForm);
				
				$.ajax({
					 url : _self._postDeleteURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.result == 'success') {
				    		alert("공지사항이 삭제되었습니다.");
				    		location.href= _self._postMainURL;
				    	} else {
				    		alert('공지사항 삭제 도중 오류가 발생하였습니다.');
				    		return;
				    	}
				    }
				});
			},
			//공지사항 수정
			'updatePost' : function(){
				var _self = this;
				
				if (_self._lock) return; //중복등록방지
				_self._lock = true;
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) 
				{
					_self._lock = false;
					return false;
				}				
				
				var param = autoDataGetter($insertForm);
				
				oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
				
				param.CONTENT =$('#ir1').val().replace(/\u8203/g,'');
				param.TYPE_CD = '108_110';
				//파일 정보 가져가기
				param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
				
				$.ajax({
					 url : _self._postUpdateURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.result == 'success') {
				    		alert("공지사항이 수정되었습니다.");
				    		location.href= _self._postMainURL;
				    	} else {
				    		alert('공지사항 수정 도중 오류가 발생하였습니다.');
				    		return;
				    	}
				    }
				});
			},
			// 공지사항 등록
			'insertPost' : function() {
				var _self = this;
				
				if (_self._lock) return; //중복등록방지
				_self._lock = true;
				
				var $insertForm = _self.$insertForm;
				// validation
				if( !jdg.util.validator( $insertForm, true ) ) 
				{
					_self._lock = false;
					return false;
				}				
				
				var param = autoDataGetter($insertForm);
				
				oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
				
				param.CONTENT =$('#ir1').val().replace(/\u8203/g,'');
				param.TYPE_CD = '108_110';
				
				//파일 정보 가져가기
				param.IMG_ID = JSON.stringify( _self.fileList.getFileList());
				
				$.ajax({
					 url : _self._postInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.result == 'success') {
				    		alert("공지사항이 등록되었습니다.");
				    		location.href= _self._postMainURL;
				    	} else {
				    		alert('공지사항 등록 도중 오류가 발생하였습니다.');
				    		return;
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				if($("#type").val() == "update"){	
					$("#loading").show();
					this.getDetail();					
				}else{	
					
					// 파일리스트
					_self.fileList  = new component.FileList({
						 'id' : _self.$insertForm.attr('id')
						 ,'container' : _self.$insertForm.find('[data-type=IMAGE_LIST]')
					});
					// 파일리스트 초기화
					_self.fileList.init();
				}
	
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});