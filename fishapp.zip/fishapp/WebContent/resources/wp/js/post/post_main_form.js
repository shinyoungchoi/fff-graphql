defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postListURL 		= $('#postListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();
				this.total 		 		= $('#total').val();
				// element
				
				this.$imageURL		 			= $('#imageURL').val();
				
				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$pcListTemplate 			= $('#postListTemplate').find('.postListRow');
				this.$nodataTemplate 			= $('#postListTemplate').find('.nodata');
				
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				

			},
			'setEvent'		: function() {
				var _self = this;
				
				$(".contents_wrap").delegate( ".clickEvent", "click", function() {
					
					var me = $(this);
					var bbsType = me.attr("bbsType");
					var postId =me.attr("postId");
					var titleKr;
					var titleEn;
					
					if (bbsType == '108_110')
					{
						titleKr = "공지";
						titleEn = "Notice";
					}
					else
					{
						titleKr = "예약안내";
						titleEn = "Reservation";						
					}					
					
					_self.$popupTitleKr.text(titleKr);
					_self.$popupTitleEn.text(titleEn);					
					
					_self.$popSubject.text("");
					_self.$popupContent.html("");
					_self.$popupDate.text("");					
					
					showPop('.notice_pop_wrap', '.popup_common_con');					
					
					var defaultParam = {
							 'POST_ID' 		: postId
						};
					
					$.ajax({
						 url : _self.postDetailURL
						,type : 'POST'
						,data : defaultParam
					    ,dataType : 'json'
					    ,success : function( data )
						    {
					    		var dtl = data.detailPost;
					    		var content = dtl.CONTENT;
					    	
								_self.$popSubject.text(dtl.TITLE);
								
								_self.$popupDate.text(dtl.CREATED_AT);	
								
								var imglist = data.imageList;
								var imgtag = "";
								
								if (imglist != null && imglist.length > 0)
								{
									var leng = imglist.length;
									
									for (var i=0; i < leng; i++)
									{
										imgtag += "<p style='padding-top:40px; padding-bottom:15px'><img src='" +  _self.$imageURL + imglist[i].IMG_ID + "/520'></p>";
										
										if (imglist[i].CONTENT != null)
										{
											imgtag += "<p>" + imglist[i].CONTENT + "</p>";
										}										
										
									}		
									
									content += imgtag;
								}
						    	
								
								_self.$popupContent.html(content);
						    	
						    }
					});
					

				});				

			},

			// 공지사항 목록 조회
			'getPostList' : function( bbsType, page ) {
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				if (bbsType == "108_110")
				{
					_contatiner = _self.$listContainer;
					_paging = $('#postListPaging');
				}
				else
				{
					_contatiner = _self.$listContainer2;
					_paging = $('#postListPaging2');					
				}
				
				// defaultParam 세팅
				var itemCnt     = 5;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: bbsType
				};
				$.ajax({
					 url : _self.postListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('postList') ) {
				    		// 초기화
				    		_contatiner.empty();
				    		var list = data.postList;
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$nodataTemplate.clone();
				    			_contatiner.append( $nodata );
				    			_paging.hide();
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $pcRow = _self.$pcListTemplate.clone();
					    			
					    			$pcRow.attr( 'rowKey', data.POST_ID );
					    			
					    			var titleLink = $pcRow.find('a');
					    			
					    			titleLink.attr( 'postId', data.POST_ID );
					    			titleLink.attr( 'bbsType', bbsType );					    			
					    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;

					    			// 제목
					    			$pcRow.find('[data-key=TITLE]').text( data.TITLE );

					    			// 등록일
					    			if( data.UPDATED_AT ) {	// 업데이트 시간이 있을경우
					    				data.UPDATED_AT = data.UPDATED_AT.substr(0, 10);
					    				$pcRow.find('[data-key=CREATED_AT]').text( data.UPDATED_AT );
					    			}else{	// 없을경우
					    				data.CREATED_AT = data.CREATED_AT.substr(0, 10);
					    				$pcRow.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			}
					    			
					    			_contatiner.append( $pcRow );
					    		});
					    		
					    	}
				    		
//				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
//									location.hash = page;
									_self.getPostList( bbsType, page );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		_paging.find('.paging_next').text(">");
				    		
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				_self.getPostList('108_110', '1' );
				_self.getPostList('108_120', '1' );
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
