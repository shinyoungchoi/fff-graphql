defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				

			},
			'setEvent'		: function() {
				
				$('.w_detail_con>li').click(function(event) {
				    event.preventDefault();
				    var win = window.open($(this).attr("link"), "popupWindow", "width=1000,height=600,scrollbars=yes");
				    
				    win.focus();
				});

			},
			'pageInit'		: function() {

			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});




$(function() {

	 $("div.gnb_con #menu_div li").each(function(index){
 		   
        	var html = $(this).find("a").text();
        	var finish = false;
        	if(html.indexOf("날씨") > -1){
        		onActiveMenu(index);
        		finish = true;
        	}
        	
        	if(finish)
        		return false;
        });

            var date = new Date();
            var weatherContainer = $('.w_list_con');
            var weatherList = $('.w_list_con > li');
            var weatherListLen = weatherList.length;
            var weatherIndex = 0;
            var weatherMaxIndex = weatherListLen - 4;
            var dayList = ["일", "월", "화", "수", "목", "금", "토"];
            var weatherDetailList = $('.w_detail_con > li');

            defaultSetting();

            /**
             * 월의 마지막 날짜 구하기
             * @param mm 월 (0: 1월 ~ 11: 12월)
             * @param yyyy 년도
             * @returns {number} 달의 마지막 날짜
             */
            function getLastDate(mm, yyyy) {

                var lastDate = 0;

                if (mm == 3 || mm == 5 || mm == 8 || mm == 10) {
                    lastDate = 30;
                } else {
                    lastDate = 31;

                    if (mm == 1) {
                        if (yyyy % 4 != 0) lastDate = 28;
                        else lastDate = 29;
                    }
                }

                return lastDate;

            }

            /**
             * 기본설정
             */
            function defaultSetting() {

                // 일, 요일 설정
                var lastDate = getLastDate(date.getMonth(), date.getFullYear());

                for (var i = 0; i < weatherListLen; i++) {
                    var weatherItem = $(weatherList[i]);
                    var dateNum = i + date.getDate();
                    var dayNum = (i + date.getDay()) % 7;
                    if (dateNum > lastDate) dateNum -= lastDate;

                    weatherItem.find('.am .date').text(dateNum + "일(" + dayList[dayNum] + ")");
                    weatherItem.find('.pm .date').text(dateNum + "일(" + dayList[dayNum] + ")");
                }

                // 날씨 아이템 설정
                weatherList.css({opacity: 0});
                weatherList.show();
                weatherDetailList.css({opacity: 0});
                weatherDetailList.show();

                for (var i = 0; i < weatherListLen; i++) {
                    var weatherItem = $(weatherList[i]);
                    TweenMax.to(weatherItem, 0.5, {opacity: 1, delay: 0.1 * i});
                }

                for (var i = 0, len = weatherDetailList.length; i < len; i++) {
                    var detailItem = $(weatherDetailList[i]);
                    TweenMax.to(detailItem, 0.5, {opacity: 1, delay: 0.1 * i});
                }

                addEvent();

            }

            /**
             * 이벤트 등록
             */
            function addEvent() {

                $('.w_prev_btn').on('click', function() {
                    if (weatherIndex == 0) return;

                    weatherIndex -= 1;
                    if (weatherIndex < weatherMaxIndex) $('.w_next_btn').stop().fadeIn(500);
                    if (weatherIndex == 0) $('.w_prev_btn').stop().fadeOut(500);
                    moveWeatherContainer();
                });

                $('.w_next_btn').on('click', function() {
                    if (weatherIndex > weatherMaxIndex - 1) return;

                    weatherIndex += 1;
                    if (weatherIndex > 0) $('.w_prev_btn').stop().fadeIn(500);
                    if (weatherIndex == weatherMaxIndex) $('.w_next_btn').stop().fadeOut(500);

                    moveWeatherContainer();
                });

            }

            /**
             * 날씨 컨테이너 이동
             */
            function moveWeatherContainer() {

                var moveLeft = -(weatherIndex * 242);
                TweenMax.to(weatherContainer, 0.5, {marginLeft: moveLeft, ease: Cubic.easeOut});

            }

        });