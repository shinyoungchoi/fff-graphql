
var idx = 0;
var list;

$(function(){

    list = $('.cont_02_01, .cont_02_02, .cont_02_03, .cont_02_04, .cont_02_05');
    TweenMax.staggerTo( list, 0, { opacity:0, ease:Back.easeOut}, 0);

    motionStart();

});

function motionStart(){
    TweenMax.staggerTo( list, 0.6, { opacity:1, ease:Back.easeOut, yoyo:true, repeat:1, repeatDelay:8, onComplete:end}, 0.1 );
}

function end(){
    if( idx == 2 ) motionStart();

    idx++;
    if( idx == 5 ) idx = 0;
}



var scrollTop = 0;
$(function(){


    var o;
    $('[bluestream]').each( function(){
        o = Parsing.parseStrToObj( $(this).attr( 'bluestream' ) );
        o.target = this;
        o.diffValue = {};
        o.destinationValue = {};
        o.ease = o.ease || Cubic.easeOut;
        o.duration = o.duration || 0.5;

        if(o.reverse === 1 ){
            o.originTop -= $(window).height();
        }


        bm.each(o.originValue, function( key, value){
            if(o.reverse === 1 ){
                var tempOrigin, tempMax;
                tempOrigin = o.originValue[key];
                tempMax = o.maxValue[key];

                o.originValue[key] = tempMax;
                o.maxValue[key] = tempOrigin;
            }

            o.diffValue[key] = o.maxValue[key] - o.originValue[key];
            o.destinationValue[key] = o.originValue[key];
        });

        if( o.effect = "parellex" ) parellex.list.push( o );
    });

    $(window).on( 'scroll', parellex.play );
    parellex.play();
});

var parellex = {
    list : [],
    play : function(){
        scrollTop = $(window).scrollTop();
        var per;
//        console.log( scrollTop );  //스크롤 위치표시

        var durationHeight = $(window).height();
        bm.each( parellex.list, function( index, o ){

            if( o.reverse ){
                if( o.originTop+durationHeight+durationHeight > scrollTop && o.originTop < scrollTop ){
                    __move();
                }
            }else{
                if( o.originTop+durationHeight > scrollTop && o.originTop-durationHeight < scrollTop ){
                    __move();
                }
            }

            function __move(){
                bm.each(o.originValue, function( key, value){
                    per = (scrollTop- o.originTop)/durationHeight;

                    if( o.useSmall === 0 && per < 0 ) per = 0;
                    per = Math.min( 1, per );

                    o.destinationValue[key] = o.originValue[key] + o.diffValue[key] * per;
                });

                TweenMax.killTweensOf(o.target);
                TweenMax.to(o.target, o.duration, {css:o.destinationValue, ease:o.ease} );
            };
        });
    }
}