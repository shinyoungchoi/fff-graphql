


	/*
	*	@ary Image 리스트
	*	@container Image를 담을 컨테이너.
	*	@fps 초당 프레임 수.
	*/
	var MovieClip = function( ary, container, fps )
	{
		var totalFrame, delay, currentFrame, isPlay, dicScript, i, len, ctx;
		
		totalFrame = ary.length;
		currentFrame = 1;
		delay = 1000/fps;
		isPlay = false;
		dicScript = {};
		
		//ctx = container.getContext("2d");
		
		
		i=0;
		len=ary.length;
		while( i<len )
		{
			container.appendChild( ary[ i ] );
			ary[ i ].style.position = "absolute";
			ary[ i ].style.visibility = "hidden";
			++i;	
		}
		
		ary[ 0 ].style.visible = "visible";
		
		
		this.getCurrentFrame = function()
		{
			return currentFrame;
		}
		
		this.getTotalFrame = function()
		{
			return totalFrame;	
		}
		
		this.prevFrame = function()
		{
			isPlay = false;	
			moveFrame( currentFrame-1 );
		}
		
		this.nextFrame = function()
		{
			isPlay = false;	
			moveFrame( currentFrame+1 );
		}
		
		this.gotoAndStop = function( frameNum )
		{
			isPlay = false;	
			moveFrame( frameNum );
		}
		
		this.gotoAndPlay = function( frameNum )
		{
			moveFrame( frameNum-1 );
			
			if( isPlay == false )
			{
				isPlay = true;
				playLoop();
			}
		}
		
		this.play = function()
		{
			if( isPlay == false )
			{
				isPlay = true;
				playLoop();
			}
		}
		
		this.stop = function()
		{
			isPlay = false;	
		}
		
		this.addFrameScript = function( frameNum, script )
		{
			dicScript[ frameNum ] = script;
		}
		
		this.setSize = function( width, height )
		{
			container.width = width;
			container.height = height;	
		}
		
		
		
		var playLoop = function()
		{	
			if( isPlay == false ) return;
			if( currentFrame == totalFrame ) moveFrame( 1 );
			else moveFrame( currentFrame+1 );
			
			setTimeout( playLoop, delay );
		}
		
		var moveFrame = function( frameNum )
		{
			
			ary[ currentFrame-1 ].style.visibility = "hidden";
			//container.removeChild( ary[ currentFrame-1 ] );
			
			currentFrame = frameNum;
			if( currentFrame > totalFrame ) currentFrame = totalFrame;
			else if( currentFrame < 1 ) currentFrame = 1;
			
			ary[ currentFrame-1 ].style.visibility = "visible";
			//container.appendChild( ary[ currentFrame-1 ] );
			/*
			var img = ary[ currentFrame-1 ];
			ctx.drawImage(img,0,0);
			*/
			if( typeof dicScript[ frameNum ] !== "undefined" )
			{
				dicScript[ frameNum ]();
			}
		}
	}


    /**
     *
     * @param obj
     * @param duration
     * @param totalFrame
     * @param gapX
     * @param gapY
     * @param repeat
     * @constructor
     */
    var SheetClip = function( obj, duration, totalFrame, gapX, gapY, repeat )
    {
        if( repeat === undefined ) repeat = false;
        var isPlay = true;
        var delay = duration / totalFrame;
        var currentFrame = 1;

        var completeHandler = null;

        this.onComplete = function( fn ){
            completeHandler = fn;
        }

        this.play = function() {
            if( isPlay == false ) {
                isPlay = true;
            }
            playLoop();
        }

        this.stop = function() {
            isPlay = false;
        }

        var playLoop = function()
        {
            if( isPlay == false ) return;

            if( currentFrame == totalFrame && repeat ) moveFrame( 1 );
            else if( currentFrame == totalFrame && !repeat) {
                moveFrame( 1 );
                if( completeHandler ) completeHandler();
                return
            }
            else moveFrame( currentFrame + 1 );

            setTimeout( playLoop, delay );
        }

        var moveFrame = function( frameNum ){
            currentFrame = frameNum;
            var x = -(frameNum-1)*gapX + "px";
            var y = -(frameNum-1)*gapY + "px";
            var bgPos = x + " " + y;

            obj.style.backgroundPosition = bgPos;
        }
    }