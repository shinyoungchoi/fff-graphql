defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {

		        this.arrowBoundTop = 460;
		        this.arrowMoveTop = 549;
		        this.tabList = $('.tab_menu li'); // 탭리스트
		        this.contentList = $('.tab_child'); // 컨텐츠 리스트

		        this.isRequest = false; // 요청여부
		        this.timer; // 인증 타이머
		        this.timerCount = 180; // 인증 요청시간 카운트
		        
		        this.$confirmBtn = $('.confirm_btn');

		        this.tel;
		        this.memberId = null;
		        
		        this.$tel1 = $('#stel1');
		        this.$tel2 = $('#stel2');
		        this.$tel3 = $('#stel3');
		        
				
			},
			'setEvent'		: function() {
				var _self = this;
				

	            // 확인 버튼
				_self.$confirmBtn.on('click', function() {
					
					_self.onValidation(_self.step);

	            });

	            // 인증번호 요청
	            $('.cert_req_btn').on('click', function() {
	            	
	            	var tel = _self.$tel1.val() + "-" + _self.$tel2.val()  + "-" + _self.$tel3.val() ;

	            	$.ajax({
						url : 'sendAuthCode'
						,type : 'POST'
						,data : {TEL: tel}
						,dataType : 'json'
						,success : function( data ) {
					
					    	if( data.ERR != null){
					    		alert( "인증문자발송에 오류가 발생하였습니다.");
					    		return false;
					    	}
					    	
					    	if (data.count == 999)
					    	{
								var str = "이미 가입이 완료된 회원[" + userId +"] 입니다.";
					    		alert(str);
					    		return false;					    		
					    	}
					    	
					    	_self.onCompleteRequest();							
					    	return false;
					    }
					});
	                
	            });

	            // 인증확인 버튼
	            $('.cert_confirm_btn').on('click', function() {
	            	
	                // 인증요청을 하지 않은 경우
	                if (!_self.isRequest) {
	                    alert("인증번호 요청을 해주세요.");
	                    return;
	                }
	                
	                var authcode = $('#authCode').val();

	                // 인증번호를 입력하지 않은 경우
	                if (!authcode) {
	                    alert("인증번호를 입력해주세요.");
	                    return;
	                }
	                
					if (authcode == "" || authcode.length != 6 || isNaN(authcode))
					{
					   alert("인증번호는 6자리 숫자입니다.");	
					   return;
					}

	                
			    	var param = {
					    	AUTH_CODE: authcode
			    	};
					
					$.ajax({
						url : 'confirmAuthCode'
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
					    	if( data.msg == 'ok' ){
			                	_self.initTimer();
			                    _self.onNext();
					    	}
					    	else
					    	{
					    		alert(data.msg);
					    		return false;					    		
					    	}
					    }

					});

	            });
				
				
			},



			
		       /**
	         * 인증번호 요청 완료
	         */
	        onCompleteRequest: function () {
				
				var _self = this;

	            _self.isRequest = true;
	            $('.before_claim').removeClass('on');
	            $('.after_claim').addClass('on');
	            _self.timer = setInterval(_self.onTimer, 1000);

	        },

	        /**
	         * 인증유효시간 타이머 초기화
	         */
	        initTimer: function () {
	        	
	        	var _self = Bplat.viewPkg.BplatBody;

	        	_self.isRequest = false;
	        	_self.timerCount = 180;
	        	clearInterval(_self.timer);
	            $('.time_text').text(_self.timerCount + "초");
	            $('.before_claim').addClass('on');
	            $('.after_claim').removeClass('on');

	        },

	        /**
	         * 인증유효시간 타이머
	         */
	        onTimer : function () {
	        	
	        	var _self = Bplat.viewPkg.BplatBody;

	        	_self.timerCount--;
	            $('.time_text').text(" " + _self.timerCount + "초");

	            if (_self.timerCount == 0) {
	                alert("인증 유효시간이 초과되었습니다.\n인증번호를 재요청 해주세요.");
	                _self.initTimer();
	            }

	        },



	        /**
	         * 다음 스텝 진행
	         */
	        onNext : function (stepNum) {
	        	
	        	var _self = this;

	        	_self.hideStep = _self.step;
	        	_self.step = !stepNum ? _self.step + 1 : stepNum;
	            
	            _self.controlTab();
	            _self.controlContent();

	        },


	        /**
	         * 탭 컨트롤
	         */
	        controlTab : function () {
	        	
	        	var _self = this;

	            var offImgPath = $(_self.tabList[2]).find('img').attr('src').replace('_on', '_off');
	            var onImgPath = $(_self.tabList[3]).find('img').attr('src').replace('_off', '_on');
	            $(_self.tabList[2]).find('img').attr('src', offImgPath);
	            $(_self.tabList[3]).find('img').attr('src', onImgPath);

	        },

	        /**
	         * 컨텐츠 컨트롤
	         */
	        controlContent : function () {
	        	
	        	var _self = this;

	            scroller.moveScroll(_self.arrowMoveTop);
	            targetScrollValue = _self.arrowMoveTop;
	            
	            var contentList = _self.contentList;

	            $(contentList[0]).hide();
	            $(contentList[1]).show();
	            TweenMax.fromTo(contentList[1], 0.5, {marginLeft: 0, marginTop: 100, opacity: 0}, {marginLeft: 0, marginTop: 0, opacity: 1, ease: Cubic.easeInOut, onComplete: function() {

	            }});

	        },
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_step1] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				
				$('.tab_child').show();
				var tel = $('#tel').val();
				var telArr = tel.split("-");
				
				_self.$tel1.val(telArr[0]);
				_self.$tel2.val(telArr[1]);
				_self.$tel3.val(telArr[2]);

				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_step1] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_step1] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_step1] onDestroy Method' );
			}		
	  }
});