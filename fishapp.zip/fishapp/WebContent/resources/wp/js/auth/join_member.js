var joinClass = {
		

	setEvent: function() {
		
			var _self = this;
			
			_self.$join_input_con =  $('.join_input_con');			
			_self.$inputID = _self.$join_input_con.find('input');			
			_self.$okBtn = _self.$join_input_con.find('a');
			
			_self._checkShipMemberURL = $('#checkShipMemberURL').val();
			_self._signupFormURL = $('#signupFormURL').val();
			_self._certFormURL = $('#certFormURL').val();
			
			
			//엔터키 사용
			this.$inputID.keydown(function(e){
				  if (e.which == 13){					  
					  joinClass.validate();
					  return false;
				  }
			});
			
			_self.$okBtn.click(function(){
				joinClass.validate();
			});

		},		
		
		validate :function(){
			var _self = this;
			var idVal = _self.$inputID.val();
	
			
			//빈칸체크
			if(idVal == ""){
				alert("아이디를 입력해주세요.");
				return false;
			}
			
			//아이디 체크
			var regExp = /[^a-z0-9]/;
			if(regExp.test(idVal)){
				alert("아이디는 영어소문자 또는 숫자로 4~12자로 입력해주십시오.");
				return false;
			}
			
			if (idVal.length < 4 || idVal.length > 12)
			{
				alert("최소 4자, 최대 12자 이내로 입력해주십시오.");
				return false;
			}
			
			var result = _self.checkShipMember(idVal);
			
			if (result == 'ERR') 
			{
				alert('시스템오류로 ID확인이 되지 않았습니다.');
				return false;
			}			
			if (result == null) //가입할수 있는 ID
			{
				if (confirm("가입할 수 있는 ID입니다. 회원가입화면으로 이동하시겠습니까?"))
				{
					location.href = _self._signupFormURL; 
					return false;
				}
				return false;	
			}
			if (result.STATUS_CD == '118_130')
			{
				if (confirm("인증 진행중인 아이디입니다. 인증페이지로 이동하시겠습니까?"))
				{
					location.href =  _self._certFormURL; ; //인증페이지 이동
					return false;
				}
				return false;				
			}
			
			alert("이미 등록된 ID입니다.");
			
		},
		
		
		checkShipMember : function(userid){
			var _self = this;
			var result = 'ERR';
			
			$.ajax({
				url : _self._checkShipMemberURL
				,type : 'POST'
				,data : { USER_ID : userid }
				,async: false
			    ,dataType : 'json'
			    ,success : function(data){
			    		result = data.result;
			    }
			});
			return result;
		},
		
		
};


$(function(){
	
	joinClass.setEvent(); 
	
});
