defClass({
	name		: 'BplatBody',
	pkg			: 'Bplat.viewPkg',
	implement	: Bplat.viewPkg.ViewInterface,
	construct : function() {},
	methods :{	
		'setElement'	: function() {
			this._nextStepURL = $('#nextStepURL').val();
			this._loginFormURL = $('#loginFormURL').val();
			this._simpleURL = $('#simpleURL').val();
			this._getUserDetailURL = $('#getUserDetailURL').val();
			this._getShipMemSearchURL = $('#getShipMemSearchURL').val();
			
			this.$idTd = $('#idTd');
			this.$memberInfoForm = $('#memberInfoForm');
			this.$okBtn = $('#okBtn');
			this.$cancelBtn = $('#cancelBtn');
			this.$joinCkeck = $('#joinCkeck');
			
			this.joinCkeckBtnClick = false;
			this.bizShipTitle = $('#bizShipTitle').val();
		},
		'setEvent'		: function() {
			var _self = this;
			
			//엔터키 사용
			_self.$idTd.keydown(function(e){
				  if (e.which == 13){
					  _self.$okBtn.focus();
					  _self.validate();
					  return false;
				  }
			});
			
			_self.$okBtn.click(function(){
				_self.validate();
			});
			
			_self.$cancelBtn.click(function(){
				Bplat.view.loadPage( _self._loginFormURL );
			});
			
		
		},
		'validate' :function(){
			var _self = this;
			var idVal = _self.$idTd.find('[type=text]').val();
			var $entryDetail = _self.$idTd.find('.jdg-entry-detail');
			var simpleCreate = false;
			
			
			//빈칸체크
			if(idVal == ""){
				$entryDetail.empty().append("<span class='jdg-unused'>X 아이디를 입력해주세요.</span>");
				return false;
			}
			
			//아이디 체크
			var regExp = /[^a-z0-9]/;
			if(regExp.test(idVal)){
				$entryDetail.empty().append("<span class='jdg-unused'>아이디는 영어소문자 또는 숫자로 4~12자로 입력해주십시오.</span>");
				return false;
			}
			
			if (idVal.length < 4 || idVal.length > 12)
			{
				$entryDetail.empty().append("<span class='jdg-unused'>최소 4자, 최대 12자 이내로 입력해주십시오.</span>");
				return false;
			}
			
			var userDetail = _self.getUserDetail(idVal);
			var userShipMem =[];
			if(userDetail != null && userDetail != undefined){
					userShipMem = _self.getShipMemSearch(userDetail.MEM_ID);
			}
			
			//가입중 아이디 체크
			if( userDetail != null && userDetail != undefined && userDetail.STATUS_CD == "118_130" ){
				$entryDetail.empty().append("<span class='jdg-unused'>인증 진행중인 아이디입니다. 휴대전화로 발송된 인증링크를 확인해 주세요.</span>");
				return false;
			}
			
			//중복 아이디 체크
			if( userDetail != null && userDetail != undefined 
					&& userShipMem != null && userShipMem != undefined){
				$entryDetail.empty().append("<span class='jdg-unused'>이미 가입되어 있는 ID 입니다. 로그인하여 사용하시면 됩니다.</span>");
				return false;
			}
			
			//존재하는 이메일이나 해당선박에 가입이 안된 이메일 체크
			if( userDetail != null && userDetail != undefined 
					&& userShipMem == null && userShipMem == undefined){
				$entryDetail.empty().append("<span id='simple' class='jdg-used'>선박에 가입되지 않은 사용중인 ID입니다.<br> 위 ID로 가입을 원하시면 확인버튼을 눌러주세요.</span>");
				simpleCreate = true;
				
			}
			if(!simpleCreate){
			$entryDetail.empty().append("<span class='jdg-used'>사용가능한 ID입니다.</span>");
			}
			
			if(simpleCreate){
				if(confirm("[" + _self.bizShipTitle + "] 선박에는 가입 되어 있지 않는 계정입니다.\n간단한 절차로 회원가입이 가능합니다.\n가입하시겠습니까?")){
					Bplat.view.loadPage( _self._simpleURL ,{
						'email' : $('#EMAIL').val()
					});
				}
			}else if(_self.$idTd.find('.jdg-unused').size() > 0){
				alert('정상적인 아이디를 입력해주세요');
				return false;
			}else{
				Bplat.view.loadPage( _self._nextStepURL ,{
					'USER_ID' : $('#USER_ID').val()
				});
			}
		},
		//사용자 정보가져오기
		'getUserDetail' : function(userId) {
			var _self = this;
			
			var userDetail = 	"";
			
			$.ajax({
				url : _self._getUserDetailURL
				,type : 'POST'
					,data : {'USER_ID' : userId}
			,async: false
			,dataType : 'json'
				,success : function( data ) {
					if( data.hasOwnProperty('detail') ) {
						userDetail = data.detail;
					}
				}
			});
			return userDetail;
		},
		'getShipMemSearch' : function(mem_id){
			var _self = this;
			var shipMemberSearch = '';
			
			$.ajax({
				url : _self._getShipMemSearchURL
				,type : 'POST'
				,data : { MEM_ID : mem_id }
				,async: false
			    ,dataType : 'json'
			    ,success : function(data){
			    	if(data.hasOwnProperty('detail')){
			    		shipMemberSearch = data.detail;
			    	}
			    }
			});
			return shipMemberSearch;
		},
		'onCreate' : function( p_param, _viewClass ) {
			Bplat.log.debug( '[signup_simple3] onCreate Method' );
			// 초기화
			this.setElement();
			this.setEvent();
			
		},
		'onRestart' : function( p_param ) {
			Bplat.log.debug( '[signup_simple3] onRestart Method' );
		},
		'onStart' : function( p_param ) {			
			Bplat.log.debug( '[signup_simple3] onStart Method' );
		},
		'onHidePopup' : function( p_param ) {
			Bplat.log.debug( '[signup_simple3] onHidePopup Method', JSON.stringify( p_param ) );
		},
		'onShowPopup' : function( p_param ) {
			Bplat.log.debug( '[signup_simple3] onShowPopup Method' );
		},
		'onStop'	: function() {
			Bplat.log.debug( '[signup_simple3] onStop Method' );			
		},
		'onDestroy' : function() {
			Bplat.log.debug( '[signup_simple3] onDestroy Method' );
		}		
  }
});

