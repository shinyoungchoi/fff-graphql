var findClass = {

	setEvent: function() {
		
		$('.sendAuthBtn').click(function( event ){
			
				event.preventDefault();
				
				var _self = findClass;
				
				var containerID = $(this).data('con');
				
				var container = $('#' + containerID); 
				
				var userName = container.find("#user_name").val();
				var userID = container.find("#user_id").val();
				
				var phoneNum = container.find("#tel1").val() + "-" + container.find("#tel2").val() + '-' + container.find("#tel3").val();	
				var email = container.find("#email").val();
				
				if (phoneNum == undefined) phoneNum = "";
				if (email == undefined) email = "";
				
		    	var param = {
		    			USER_ID : userID
				    	,USER_NAME : userName
				    	,TEL: phoneNum
				    	,EMAIL: email
		    	};
							
				if (containerID == "id_tel_con" && _self.chkName(param) && _self.chkTel(param))
				{
					_self.sendAuthCode('auth/sendAuthCodeForFindUserID',param);
				}
				else if (containerID == "id_email_con" && _self.chkName(param) && _self.chkEMail(param))
				{
					_self.sendAuthCode('auth/sendAuthCodeForFindUserID',param);
				}
				else if (containerID == "pwd_tel_con" && _self.chkID(param) && _self.chkTel(param))
				{
					_self.sendAuthCode('auth/sendAuthCodeForFindUserPwd',param);
				}					
				else if (containerID == "pwd_email_con" && _self.chkID(param) && _self.chkEMail(param))
				{
					_self.sendAuthCode('auth/sendAuthCodeForFindUserPwd',param);
				}			
			});
		
		
		$('.find_cert_confirm_btn').click(function( event ){
			
				var _self = findClass;
				
				event.preventDefault();
				
				var type = $(this).data('type');
				
				_self.authTextInput =  $('.authCodeInput[data-type=' + type + ']');
				
				var authCode = _self.authTextInput.val();
				
				if (authCode == "")
				{
					alert("인증번호를 입력해주십시오.");
					return;
				}
				
				if (isNaN(authCode) || authCode.length != 6)
				{
					alert("인증번호는 6자리 숫자입니다.");
					return;
				}
				
				
				if (type == 'id')
				{
					_self.confirmAuthCodeForID({AUTH_CODE:authCode});
				}
				else
				{
					_self.confirmAuthCodeForPwd({AUTH_CODE:authCode});
				}
			});
		
			$('.change_pwd_btn').click(function( event ){
				
				var _self = findClass;
				
				event.preventDefault();
				_self.changePwd();
			});		
		
		},	
		
		
		
		chkID: function(param) {
			
			var value = param.USER_ID;
			
			if (value == null || value == "" || value.length < 2)
			{
				alert('ID를 입력하십시오.');
				return false;
			}
			
			return true;
		},
		
		chkName: function(param) {
			
			var value = param.USER_NAME;
			
			if (value == null || value == "" || value.length < 2)
			{
				alert('이름을 입력하십시오.');
				return false;
			}			
			
			return true;
		},
		
		chkTel: function(param) {
			
			var value = param.TEL;
			
			if (value == null || value == "")
			{
				alert('전화번호를 입력하십시오.');
				return false;
			}	
			
			//전화번호 형식 체크
			var regExp = /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/;
			if(!regExp.test(value)){
				alert('정상적인 전화번호를 입력해주세요.');
				return false;
			}
			
			return true;
		},
		
		chkEMail: function(param) {
			
			var value = param.EMAIL;
			
			if (value == null || value == "")
			{
				alert('Email을 입력하십시오.');
				return false;
			}
			
			var regExp = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
			if(!regExp.test(value)){
				alert('정상적인 Email을 입력해주세요.');
				return false;
			}
			
			return true;
		},		
		
		sendAuthCode : function(p_url ,param){
			
			var _self = findClass;
			
	    	$('.sendAuthBtn').hide();
	    	$(':radio').prop('disabled', true);	
			
			if (location.pathname.split('/').length > 5)
			{
				p_url = "../" + p_url;
			}
			
			$.ajax({
				url : p_url
				,type : 'POST'
				,data : param
				,dataType : 'json'
				,success : function( data ) {
					
					if(data.ERR != null)
					{
						alert(data.ERR);
				    	$('.sendAuthBtn').show();
				    	$(':radio').prop('disabled', false);	
						
						return false;
					}
					
					if (_self.timer)
					{
						clearInterval(_self.timer);
					}

					_self.timerCount = 180;					
					$('.cert_input').show();
					$('.time_text').text(" " + _self.timerCount + "초");
					$('#id_cert_result').html('');

					_self.timer = setInterval(_self.onTimer, 1000);
					
			    	return false;
			    }

			});
			
			
		},
		
		confirmAuthCodeForID: function(param)
		{
			var _self = findClass;
			
			var p_url = "auth/confirmAuthCodeForFindUserID";
			
			if (location.pathname.split('/').length > 5)
			{
				p_url = "../" + p_url;
			}
			
			$.ajax({
				url : p_url
				,type : 'POST'
				,data : param
				,dataType : 'json'
				,success : function( data ) {
					
					if(data.ERR != null)
					{
						_self.authTextInput.val("");
						_self.authTextInput.focus();
						alert(data.ERR);
						return false;
					}
					
					var htm = '<p class="result" style="color:white">검색된 아이디는 다음과 같습니다.</p><p>&nbsp</p>';
					
					var lst = data.findIDList;
					
					for (var i=0; i < lst.length; i++)
					{
						htm += '<p class="result" style="color:white">' + lst[i].USER_ID  + ' &nbsp;(' + lst[i].JOIN_DATE +' 가입)</p>';
					}
					
					var result = $('#id_cert_result');
					
					result.html(htm);
					result.show();	
					
					$('.cert_input').hide();
					clearInterval(_self.timer);

			    	return false;
			    }

			});			
		},
		
		
		confirmAuthCodeForPwd: function(param)
		{
			var _self = findClass;
			
			var p_url = "auth/confirmAuthCodeForFindUserPwd";
			
			if (location.pathname.split('/').length > 5)
			{
				p_url = "../" + p_url;
			}
			
			$.ajax({
				url : p_url
				,type : 'POST'
				,data : param
				,dataType : 'json'
				,success : function( data ) {
					
					if(data.ERR != null)
					{
						_self.authTextInput.val("");
						_self.authTextInput.focus();
						alert(data.ERR);
						return false;
					}

					var result = $('#pwd_cert_result');
					result.show();	
					
					$('.cert_input').hide();
					clearInterval(_self.timer);

			    	return false;
			    }

			});			
		},

		//문자,숫자,특수기호 중 2가지 이상 조합인지 체크
		'pwCheck' : function(pwVal) {
			var _self = this;
			var count = 0;
			
			//문자 포함
			if(/[a-zA-Z]/.test(pwVal)){
				count++;
			}
			
			//숫자 포함
			if(/[0-9]/.test(pwVal)){
				count++;
			}
			
			//특수기호 포함
			if(/[^0-9a-zA-Zㄱ-ㅎㅏ-ㅣ가-힝]/.test(pwVal)){
				count++;
			}
			
			if( count >= 2){
				return false;
			}else{
				return true;
			}
		},
		
		
		'changePwd': function()
		{
			var _self = findClass;
			
			var pwd = $('#new_pwd').val();
			var pwd2 = $('#new_pwd2').val();
			var pwdRegExp = /(\w)\1\1/;		
			
			
            if (_self.pwCheck(pwd))
            {
            	alert('패스워드는 영문자와 숫자, 기호등을 조합하여 8자 이상이어야 합니다.');
            	return false;
            }			
			
            if (pwdRegExp.test(pwd))
            {
            	alert('패스워드는 같은문자를 3개이상 연속적으로 사용할 수 없습니다.');
                return false;
            }
            
            if (pwd != pwd2)
        	{
            	alert('패스워드와 패스워드 확인이 일치하지 않습니다. 패스워드 확인을 다시 입력해주십시오.');
            	return false;
        	}
			
			
			var p_url = "auth/changeNewPwd";
			
			if (location.pathname.split('/').length > 5)
			{
				p_url = "../" + p_url;
			}
			
			$.ajax({
				url : p_url
				,type : 'POST'
				,data : {PWD: pwd}
				,dataType : 'json'
				,success : function( data ) {
					
					if (data.msg == 'ok')
					{
						$('.id_search_con input').val('');
						alert('패스워드가 성공적으로 변경되었습니다.');		
						hideLoginBox();
					}
					else
					{
						alert(data.msg);
					}
			    }

			});			
		},

		
        onTimer : function () {
        	
        	var _self = findClass;

        	_self.timerCount--;
            $('.time_text').text(" " + _self.timerCount + "초");

            if (_self.timerCount == 0) {
                alert("인증 유효시간이 초과되었습니다.\n인증번호를 재요청 해주세요.");
                clearInterval(_self.timer);
                
		    	$('.sendAuthBtn').show();
		    	$(':radio').prop('disabled', false);
		    	$('.cert_input').hide();		    	
		    	_self.authTextInput.val("");
            }

        }
		
		
		
		
};


$(function(){
	
	findClass.setEvent(); 
	
});
