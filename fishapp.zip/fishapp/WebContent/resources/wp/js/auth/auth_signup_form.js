defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {

		        this.arrowBoundTop = 460;
		        this.arrowMoveTop = 549;

		        this.step = 0; // 스텝
		        this.activeStep = 0; // 활성화된 스텝
		        this.prevStep = 0; // 이전 스텝
		        this.hideStep = -1; // 사라질 스텝
		        this.tabList = $('.tab_menu li'); // 탭리스트
		        this.contentList = $('.tab_child'); // 컨텐츠 리스트
		        this.isRequest = false; // 요청여부
		        this.timer; // 인증 타이머
		        this.timerCount = 180; // 인증 요청시간 카운트
		        this.step1FocusNum = "0";
				
		        
		        this.$confirmBtn = $('.confirm_btn');
		        
		        this.tel;
		        this.memberId = null;
				
			},
			'setEvent'		: function() {
				var _self = this;
				
	            // 탭버튼
				_self.tabList.on('click', function() {
	                var index = _self.tabList.index(this);

	                // 현재 스텝의 탭일 경우
	                if (index == _self.step) return;
	                // 회원가입이 완료된 경우
	                if (_self.activeStep == 3) {
	                    alert("회원 가입이 완료되었습니다.");
	                    return;
	                }
	                

	                // 이전단계를 진행하지 않은 경우
	                if (index > _self.activeStep) {
	                    alert("이전 단계 진행을 해주세요.");
	                    return;
	                }

	                
	                // 인증 요청 중일 경우
	                if (_self.isRequest) {
	                    alert("인증 요청중에는 이동하실 수 없습니다.");
	                    return;
	                }
	                // 이전 단계 클릭한 경우
	                if (index < _self.step) _self.onPrev(index);
	                // 다음 단계 클릭한 경우
	                else {
	                    // 스텝 0일때 1스텝 클릭한 경우
	                    if (_self.step == 0 && index == 1) {
	                        if (_self.onValidation(0)) _self.onNext();
	                    }
	                    // 스텝 0일때 2스텝 클릭한 경우
	                    else if (_self.step == 0 && index == 2) {
	                        if (!_self.onValidation(0)) return;
	                        if (!_self.onValidation(1)) {
	                        	_self.onNext(1);
	                            return;
	                        }
	                        _self.onNext(2);
	                    }
	                    // 스텝 1일때 2스텝 클릭한 경우
	                    else if (_self.step == 1 && index == 2) {
	                        if (_self.onValidation(1)) _self.onNext();
	                    }
	                }
	            });

	            // 확인 버튼
				_self.$confirmBtn.on('click', function() {
					
					_self.onValidation(_self.step);

	            });

	            // 인증번호 요청
	            $('.cert_btn').on('click', function() {

	            	$.ajax({
						url : 'sendAuthCode'
						,type : 'POST'
						,data : {MEM_ID: _self.memberId, TEL: _self.tel}
						,dataType : 'json'
						,success : function( data ) {
					
					    	if( data.count == null || data.count < 1){
					    		alert( "인증문자발송에 오류가 발생하였습니다.");
					    		return false;
					    	}
					    	
					    	if (data.count == 999)
					    	{
								var str = "이미 가입이 완료된 회원[" + userId +"] 입니다.";
					    		alert(str);
					    		return false;					    		
					    	}
					    	
					    	_self.onCompleteRequest();							
					    	return false;
					    }
					});
	                
	            });

	            // 인증확인 버튼
	            $('.cert_confirm_btn').on('click', function() {
	            	
	                // 인증요청을 하지 않은 경우
	                if (!_self.isRequest) {
	                    alert("인증번호 요청을 해주세요.");
	                    return;
	                }
	                
	                var authcode = $('#authCode').val();

	                // 인증번호를 입력하지 않은 경우
	                if (!authcode) {
	                    alert("인증번호를 입력해주세요.");
	                    return;
	                }
	                
					if (authcode == "" || authcode.length != 6 || isNaN(authcode))
					{
					   alert("인증번호는 6자리 숫자입니다.");	
					   return;
					}

	                
			    	var param = {
					    	MEM_ID : _self.memberId
					    	,AUTH_CODE: authcode
					    	,TEL: _self.tel
			    	};
					
					$.ajax({
						url : 'confirmAuthCode'
						,type : 'POST'
						,data : param
						,dataType : 'json'
						,success : function( data ) {
					    	if( data.msg == 'ok' ){
			                	_self.initTimer();
			                    _self.onNext();
					    	}
					    	else
					    	{
					    		alert(data.msg);
					    		return false;					    		
					    	}
					    }

					});

	            });
				
				
			},

			//문자,숫자,특수기호 중 2가지 이상 조합인지 체크
			'pwCheck' : function(pwVal) {
				var _self = this;
				var count = 0;
				
				//문자 포함
				if(/[a-zA-Z]/.test(pwVal)){
					count++;
				}
				
				//숫자 포함
				if(/[0-9]/.test(pwVal)){
					count++;
				}
				
				//특수기호 포함
				if(/[^0-9a-zA-Zㄱ-ㅎㅏ-ㅣ가-힝]/.test(pwVal)){
					count++;
				}
				
				if( count >= 2){
					return false;
				}else{
					return true;
				}
			},

			
		       /**
	         * 인증번호 요청 완료
	         */
	        onCompleteRequest: function () {
				
				var _self = this;

	            _self.isRequest = true;
	            $('.before_claim').removeClass('on');
	            $('.after_claim').addClass('on');
	            _self.timer = setInterval(_self.onTimer, 1000);

	        },

	        /**
	         * 인증유효시간 타이머 초기화
	         */
	        initTimer: function () {
	        	
	        	var _self = Bplat.viewPkg.BplatBody;

	        	_self.isRequest = false;
	        	_self.timerCount = 180;
	        	clearInterval(_self.timer);
	            $('.time_text').text(_self.timerCount + "초");
	            $('.before_claim').addClass('on');
	            $('.after_claim').removeClass('on');

	        },

	        /**
	         * 인증유효시간 타이머
	         */
	        onTimer : function () {
	        	
	        	var _self = Bplat.viewPkg.BplatBody;

	        	_self.timerCount--;
	            $('.time_text').text(" " + _self.timerCount + "초");

	            if (_self.timerCount == 0) {
	                alert("인증 유효시간이 초과되었습니다.\n인증번호를 재요청 해주세요.");
	                _self.initTimer();
	            }

	        },

	        /**
	         * 유효성 확인
	         * @param stepNum 스텝넘버
	         */
	        onValidation : function (stepNum) {
	        	
	        	var _self = this;

	            var i = 0, len = 0;

	            // 스텝0 확인
	            if (stepNum == 0) {
	                var agreeCheckList = $('.check_box').find('input');
	                for (i = 0, len = agreeCheckList.length; i < len; i++) {
	                    if (!$(agreeCheckList[i]).is(':checked')) {
	                        alert("약관에 모두 동의해야합니다.");
	                        return false;
	                    }
	                }
	                _self.onNext();
	            }
	            
	            if (stepNum == 0) {
	            	 return true;
	            }
	            // 스텝1 확인
	            else if (stepNum == 1) {
	            	
	            	var param = {};
	            	var inputValue;
	            	var inputName;
	            	var inputID;
	            	
	            	var emailRegExp = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	            	var nickRegExp = /[0-9]|[a-z]|[A-Z]|[가-힣]/;
	            	var idRegExp = /[0-9]|[a-z]/;
	            	var pwdRegExp = /(\w)\1\1/;
	            	
	                var inputList = $('.sign_in_tb input');
	                for (var i = 0, len = inputList.length; i < len; i++) {
	                    var input = $(inputList[i]);
	                    
	                    inputName = input.attr('name');
	                    inputValue = input.val();
	                    inputID = input.attr('id');

	                    if (!inputValue)  {
	                    	
	                    	inputName = inputName + (inputName == "아이디" || inputName == "비밀번호" || inputName == "전화번호" ? "를" : "을");	                    	
	                    	alert(inputName + ' 입력해주세요.');

	                        input.focus();
	                        _self.step1FocusNum = i;
	                        return false;
	                    }
	                    
	                    if (inputID == "USER_ID" && (inputValue.length < 4 || inputValue.length > 12 || !idRegExp.test(inputValue)))
	                    {
	                    	alert('아이디는 영어 소문자와 숫자만 사용가능하며 4자 이상 12자 이하이어야 합니다.');
	                        input.focus(); _self.step1FocusNum = i;return false;
	                    }
	                    
	                    if (inputID == "PWD" && pwdRegExp.test(inputValue))
	                    {
	                    	alert('패스워드는 같은문자를 3개이상 연속적으로 사용할 수 없습니다.');
	                        input.focus(); _self.step1FocusNum = i;return false;
	                    }
	                    
	                    if (inputID == "PWD" && _self.pwCheck(inputValue))
	                    {
	                    	alert('패스워드는 영문자와 숫자, 기호등을 조합하여 8자 이상이어야 합니다.');
	                        input.focus(); _self.step1FocusNum = i;return false;
	                    }	                    
	                    
	                    if (inputID == "PWD_CHK" && param.PWD != inputValue)
                    	{
	                    	alert('패스워드와 패스워드 확인이 일치하지 않습니다. 패스워드 확인을 다시 입력해주십시오.');
	                    	input.focus(); _self.step1FocusNum = i;return false;
                    	}

	                    if (inputID == "NICK_NAME" && (inputValue.length < 2 || inputValue.length > 12 ))
	                    {
	                    	alert('닉네임은 2글자 이상 12글자 이하로 입력해주십시오.');
	                    	input.focus(); _self.step1FocusNum = i;return false;	                    	
	                    }
	                    
	                    if (inputID == "NICK_NAME" && !nickRegExp.test(inputValue))
	                    {
	                    	alert('닉네임은 영어,한글,숫자만 가능합니다.');
	                    	input.focus(); _self.step1FocusNum = i;return false;	                    	
	                    }
	                    
	                    if (inputID == "MEM_NAME" && (inputValue.length < 2 || inputValue.length > 8 ))
	                    {
	                    	alert('이름은 2글자 이상 8글자 이내로 입력해주십시오.');
	                    	input.focus(); _self.step1FocusNum = i;return false;	                    	
	                    }	 
	                    
						
						if(inputID == "EMAIL" && !emailRegExp.test(inputValue)){
							alert('이메일 주소가 유효하지 않습니다.');
							return false;
						}
	                    	                    
	                    if (inputID == "TEL2" && (isNaN(inputValue) || inputValue * 1 < 100))
                    	{
	                    	alert('전화번호 국번에 오류가 있습니다. (숫자가 아니거나 3~4자리 숫자가 아닙니다.)');
	                    	input.focus(); _self.step1FocusNum = i;return false;
                    	}	                    

	                    if (inputID == "TEL3" && (isNaN(inputValue) || inputValue.length != 4))
                    	{
	                    	alert('전화번호 뒷자리에 오류가 있습니다. (숫자가 아니거나 4자리 숫자가 아닙니다.)');
	                    	input.focus(); _self.step1FocusNum = i;return false;
                    	}
	                    
	                    
	                    param[inputID] = inputValue;
	                }

	                
	                var tel1 = $('#TEL').val();;
	                var tel2 = param.TEL2;
	                var tel3 = param.TEL3;
	                
	                _self.tel = tel1 + '-' + tel2 + '-' + tel3;	                
	                param.TEL = _self.tel;
	                
	                $('#stel1').val(tel1);
	                $('#stel2').val(tel2);
	                $('#stel3').val(tel3);
	                
	                
	                $('#loadingbar').show();
	                
					$.ajax({
						 url : 'insertMember'
						,type : 'POST'
						,data : param
					    ,dataType : 'json'
					    ,success : function( data )
						    {
					    		$('#loadingbar').hide();
					    	
					    		if (data.result == 'FAIL')
					    		{
					    			alert(data.error_message);			
					    			_self.memberId = null;
					    			
					    		}					    		
					    		else if (data.result == 'SUCCESS')
					    		{
					    			_self.memberId = data.MEM_ID;
					    			_self.onNext();
					    		}						    	
						    }
					});	

					
	                return false;
	            }

	        },

	        /**
	         * 다음 스텝 진행
	         */
	        onNext : function (stepNum) {
	        	
	        	var _self = this;

	        	_self.hideStep = _self.step;
	        	_self.step = !stepNum ? _self.step + 1 : stepNum;
	            if (_self.activeStep < _self.step) _self.activeStep = _self.step;
	            
	            if (_self.activeStep == 2)
	            {
	            	var frm = $('#frmUserInfo');
	            	var tel1 = frm.find('#tel1').val();
	            	var tel2 = frm.find('#tel2').val();
	            	var tel3 = frm.find('#tel3').val();
	            	
	            	var certInfo = $('.input_cert_num_con');            	
	            	certInfo.find('#tel1').val(tel1);
	            	certInfo.find('#tel2').val(tel2);
	            	certInfo.find('#tel3').val(tel3);            	
	            }
	            
	            _self.controlTab();
	            _self.controlContent();

	        },

	        /**
	         * 이전 스텝 진행
	         */
	        onPrev : function (stepNum) {
	        	
	        	var _self = this;

	        	_self.hideStep = _self.step;
	        	_self.step = _self.stepNum;
	        	_self.controlTab();
	        	_self.controlContent();

	        },

	        /**
	         * 탭 컨트롤
	         */
	        controlTab : function () {
	        	
	        	var _self = this;

	            var offImgPath = $(_self.tabList[_self.prevStep]).find('img').attr('src').replace('_on', '_off');
	            var onImgPath = $(_self.tabList[_self.step]).find('img').attr('src').replace('_off', '_on');
	            $(_self.tabList[_self.prevStep]).find('img').attr('src', offImgPath);
	            $(_self.tabList[_self.step]).find('img').attr('src', onImgPath);
	            _self.prevStep = _self.step;

	        },

	        /**
	         * 컨텐츠 컨트롤
	         */
	        controlContent : function () {
	        	
	        	var _self = this;

	            scroller.moveScroll(_self.arrowMoveTop);
	            targetScrollValue = _self.arrowMoveTop;
	            
	            var contentList = _self.contentList;

	            $(contentList[_self.hideStep]).hide();
	            $(contentList[_self.step]).show();
	            TweenMax.fromTo(contentList[_self.step], 0.5, {marginLeft: 0, marginTop: 100, opacity: 0}, {marginLeft: 0, marginTop: 0, opacity: 1, ease: Cubic.easeInOut, onComplete: function() {
	                if (_self.step == 1) $($('.sign_in_tb input')[_self.step1FocusNum]).focus();
	            }});

	        },
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[signup_step1] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();
				
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[signup_step1] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[signup_step1] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[signup_step1] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[signup_step1] onDestroy Method' );
			}		
	  }
});