defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();

				this.$fishDate = $('#fishDate');
				this.$insertBtn = $('#insertBbsBtn');
				this.$typeCd;
				
				this.content;
				
				this.postId;
				
				this.hash;
				
				this.$title = $('#title');
				this.titleBold = 'N';
				this.titleColorBoxVisible = false;
				
				this.$titleColorPalette = $('.title_color_pal');


			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조과등록
				_self.$insertBtn.click( function() {
					_self.updateBbs();
				});
				
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
						}
				);
				
				
				// 글자 색상 팔레트 호출
				$('#btnTitleColor').click( function(event) {
					event.preventDefault();

					if (_self.titleColorBoxVisible)
					{
						_self.$titleColorPalette.hide();
					}
					else
					{
						_self.$titleColorPalette.show();
					}					
					
					_self.titleColorBoxVisible = !_self.titleColorBoxVisible;
				});
				
				// 글자 bold
				$('#btnTitleBold').click( function(event) {
					event.preventDefault();
					
					if (_self.titleBold == 'Y')
						{
							_self.$title.css('font-weight','normal');
							_self.titleBold = 'N';
						}
					else
						{
							_self.$title.css('font-weight','bolder');
							_self.titleBold = 'Y';
						}
					
				});
				
				// 글자색 팔레트 선택
				$('.title_color_pal li div').click( function(event) {
					event.preventDefault();
					
					var color = $(this).css('background-color');					
					_self.$title.css('color',color);	
					
					$('#btnTitleColor').find('div').css('background-color', color);	
					
					_self.$titleColorPalette.hide();
					_self.titleColorBoxVisible = false;
				});

			},
			
			'loadBbs' : function()
			{
				var _self = this;
				
				var sPageURL = window.location.search.substring(1);
				
				var postId = sPageURL.replace('POST_ID=','');		
				
				_self.postId = postId;
				
				var defaultParam = {
						 'POST_ID' 		: postId
					};
				
				$.ajax({
					 url : 'detail'
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data )
					    {
				    		var dtl = data.detailBbs;
				    		var content = dtl.CONTENT;
				    		
							$('#title').val(dtl.TITLE);
							
							window._content = content;
							
							var hash = dtl.TYPE_CD == '108_130' ? '#c' : '#q';
							
							if (dtl.SECRET_YN == "Y")
							{
								$('#chkSecret').attr("checked",true);
							}

							if (dtl.NOTICE_YN == "Y")
							{
								$('#chkNotice').attr("checked",true);
							}
							
							if (dtl.TITLE_BOLD == "Y")
							{
								$('#title').css("font-weight", "bold");
							}

							if (dtl.TITLE_COLOR != "")
							{
								$('#title').css("color", "#" + dtl.TITLE_COLOR);
								$('#btnTitleColor div').css("background-color", "#" + dtl.TITLE_COLOR);
							}
							
							
							_self.hash = hash;
							
							if (hash == '#c')
							{
								_self.$typeCd = '108_130';
								$('.captain').parent().addClass('on');
							}
							else
							{
								_self.$typeCd = '108_140';
								$('.member').parent().addClass('on');					
							}
							
							if (dtl.TITLE_BOLD == 'Y')
							{
								_self.$title.css('font-weight','bolder');
								_self.titleBold = 'Y';
							}

							if (dtl.TITLE_COLOR != null)
							{
								var color = dtl.TITLE_COLOR;					
								_self.$title.css('color',color);	
								
								$('#btnTitleColor').find('div').css('background-color', color);	
							}
							
					    }
				});
				
			},
			
			
			
			// 게시글 수정
			'updateBbs' : function() {
				var _self = this;

				oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);	
	
				
				var param = {};
				
				param.TITLE = $('#title').val();
				param.CONTENT =$('#ir1').val();
				param.POST_ID = _self.postId;
				
				param.TITLE_COLOR = rgb2hex(_self.$title.css('color'));
				param.TITLE_BOLD = _self.titleBold;
				
				param.NOTICE_YN = $('#chkNotice').is(':checked') ? "Y" : "N";
				param.SECRET_YN = $('#chkSecret').is(':checked') ? "Y" : "N";	
				
				
				if (param.TITLE == '')
				{
					alert('제목을 입력해주십시오.');
					return false;
				}
				
				if (param.CONTENT == '')
				{
					alert('내용을 입력해주십시오.');
					return false;
				}
				
				$.ajax({
					 url : 'update'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if( data.hasOwnProperty('result') ) {
				    		alert('등록되었습니다.');
				    		
				    		location.href = "main" + _self.hash + '1';
				    	} else {
				    		alert('로그인이 필요 합니다.');
				    		showLoginBox(null, false);
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				_self.loadBbs();


			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});