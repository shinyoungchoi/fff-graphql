defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.postDetailURL 		= $('#postDetailURL').val();
				this.postListURL 		= $('#postListURL').val();
				this.imageURL 			= $('#imageURL').val();
				this.noImageURL 		= $('#noImageURL').val();
				// element
				// 게시 종류 전역 설정
				this.MAIN_TYPE 				= '108_110';
				this.$tbl = $('.jdg-table-notice-view');
				this.$vfrm = $("#vfrm");

			},
			'setEvent'		: function() {
				var _self = this;
				
				
			},
			
			
			'ifrmResize'		: function() {
				
				var _self = this;
				var wid = this.$tbl.width() * 0.9;
				
				_self.$vfrm.width(wid);
				_self.$vfrm.height(wid * 0.625);
				
			},
			
			'pageInit'		: function() {
				var _self = this;
				
				
			},			
			
			
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				_self.ifrmResize();
				
				if (_self.$vfrm != null)
					{
					 	window.onresize = function() {_self.ifrmResize();};
					}

				
//				_self.pageInit();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
