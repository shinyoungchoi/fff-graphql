defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this._fishInsertURL = $('#fishInsertURL').val();
				this._fishDetailURL = $('#fishDetailURL').val();
				this._loginURL = $('#loginURL').val();
				// element
				this.$insertForm = $('#memberFishInsertForm');
				this.$fishDate = $('#fishDate');
				this.$insertBtn = $('#insertBbsBtn');
				this.$typeCd;
				this.hash;
				
				this.$title = $('#title');
				this.titleBold = 'N';
				this.titleColorBoxVisible = false;
				
				this.$titleColorPalette = $('.title_color_pal');

				
			},
			'setEvent'		: function() {
				var _self = this;
				
				// 조과등록
				_self.$insertBtn.click( function() {
					_self.insertBbs();
				});
				
				$("select[data-handle]").change(function(evt)
						{
							var tgt = $(evt.target);							
							var hd = tgt.attr('data-handle');
							
							var hdObj = _self.$insertForm.find('input[data-key=' + hd + ']');
							
							if (tgt.val() == "etc")
							{
								hdObj.show();
							}
							else if (hdObj.attr('disabled') == undefined || hdObj.attr('disabled') == false)
							{
								hdObj.hide();
								hdObj.val('');
							}
						}
				);
				
				// 글자 색상 팔레트 호출
				$('#btnTitleColor').click( function(event) {
					event.preventDefault();

					if (_self.titleColorBoxVisible)
					{
						_self.$titleColorPalette.hide();
					}
					else
					{
						_self.$titleColorPalette.show();
					}					
					
					_self.titleColorBoxVisible = !_self.titleColorBoxVisible;
				});
				
				// 글자 bold
				$('#btnTitleBold').click( function(event) {
					event.preventDefault();
					
					if (_self.titleBold == 'Y')
						{
							_self.$title.css('font-weight','normal');
							_self.titleBold = 'N';
						}
					else
						{
							_self.$title.css('font-weight','bolder');
							_self.titleBold = 'Y';
						}
					
				});
				
				// 글자색 팔레트 선택
				$('.title_color_pal li div').click( function(event) {
					event.preventDefault();
					
					var color = $(this).css('background-color');					
					_self.$title.css('color',color);	
					
					$('#btnTitleColor').find('div').css('background-color', color);	
					
					_self.$titleColorPalette.hide();
					_self.titleColorBoxVisible = false;
				});
				
				
				
			},
			// 조과 등록
			'insertBbs' : function() {
				var _self = this;

				oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);	
	
				
				var param = {};
				
				param.TYPE_CD = _self.$typeCd;	
				param.TITLE = $('#title').val();
				param.CONTENT =$('#ir1').val();
				
				param.TITLE_COLOR = rgb2hex(_self.$title.css('color'));
				param.TITLE_BOLD = _self.titleBold;
				
				param.NOTICE_YN = $('#chkNotice').is(':checked') ? "Y" : "N";
				param.SECRET_YN = $('#chkSecret').is(':checked') ? "Y" : "N";				
				
				
				if (param.TITLE == '')
				{
					alert('제목을 입력해주십시오.');
					return false;
				}
				
				if (param.CONTENT == '')
				{
					alert('내용을 입력해주십시오.');
					return false;
				}
				
				$.ajax({
					 url : _self._fishInsertURL
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	
				    	if( data.hasOwnProperty('BBS_ID') ) {
				    		alert('등록되었습니다.');
				    		
				    		var hash = (_self.$typeCd == '108_130') ? '#c1' : '#q1';
				    		
				    		// 상세로 이동
				    		location.href = "main" + hash;
				    	} else {
				    		alert('로그인이 필요 합니다.');
				    		showLoginBox(null, false);
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_insert_form] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				var hash = (location.hash == null)? "#c" : location.hash;
				
				_self.hash = hash;
				
				if (hash == '#c')
				{
					_self.$typeCd = '108_130';
					$('.captain').parent().addClass('on');
				}
				else
				{
					_self.$typeCd = '108_140';
					$('.member').parent().addClass('on');					
				}

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_insert_form] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_insert_form] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_insert_form] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_insert_form] onDestroy Method' );
			}		
	  }
});