defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.bbsListURL 		= $('#bbsListURL').val();
				this.postDetailURL 	    = $('#postDetailURL').val();
				this.postDeleteURL 	    = $('#postDeleteURL').val();
				this.postUpdateURL 	    = $('#postUpdateURL').val();
				this.total 		 		= $('#total').val();
				// element
				
				this.$imageURL		 			= $('#imageURL').val();
				
				this.$listContainer 			= $('#noticeTbl');
				this.$listContainer2 			= $('#rsvInfoTbl');
				
				this.$pcListTemplate 			= $('#bbsListTemplate').find('.bbsListRow');
				this.$nodataTemplate 			= $('#bbsListTemplate').find('.nodata');
				
				this.$popupTitleKr = $('.title_kr');
				this.$popupTitleEn = $('.title_en');
				
				this.$popSubject = $('#popSubject');
				this.$popupContent = $('#popContents');
				this.$popupDate = $('#popDate');
				this.$nickName = $('#nickName');
				
				this.$divControl = $('.divControl');
				
				
				this.tabList = $('.cdt_tab_menu li');
				
				this.tabIndex = 0;
				this.postId;
				
				this.$insertBtn = $('#insertBtn');
				this.$updateBtn = $('#updateBtn');
				
				this.session = $('#session').val();
				this.auth = $('#auth').val();

			},
			'setEvent'		: function() {
				var _self = this;
				
	            _self.tabList.on('click', function() {
	                var index = _self.tabList.index(this);

	                if (_self.tabIndex == index) return;
	                
	                _self.$typeCd = $(this).data("cd");
	               
	                // 이전 탭
	                $(_self.tabList[_self.tabIndex]).removeClass('on');
	                // 클릭 탭
	                $(_self.tabList[index]).addClass('on');
	                $(_self.tabList[index]).removeClass('over');
	                
	                _self.page = 1;	                
	                _self.tabIndex = index;	                
	                location.hash = _self.tabIndex == 0 ? '#c1' : '#q1';
	                
	                _self.getPostList(location.hash, 'Y');
	            });

	            _self.tabList.on('mouseenter', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).addClass('over');
	            });

	            _self.tabList.on('mouseleave', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).removeClass('over');
	            });
				
	            _self.$insertBtn.on('click', function(e) {
	            	
	            	var type = (_self.tabIndex == 0) ? '#c' : '#q';	            	
	            	
					if (isLogin() == false)
					{
						showLoginBox("insert_form");
						return;
					}
					else
					{
						location.href = "insert_form" +  type;
					}
	            });

	            _self.$updateBtn.on('click', function(e) {

	            	location.href = _self.postUpdateURL + '?POST_ID=' + _self.postId;
	            	
	            });
	            
				
				$(".contents_wrap").delegate( ".clickEvent", "click", function() {
					
					var me = $(this);
					
					var secret= me.attr('secret');
					
					var creator = me.attr('creator');
					
					
					if (secret == 'N' || _self.auth == 'admin' || _self.session == creator)
					{
						var postId =me.attr("postId");					
						location.href = "detail_form?POST_ID=" + postId;
					}
					else
					{
						alert('비밀글은 작성자와 관리자만 볼 수 있습니다!');
					}

				});				

			},

			// 목록 조회
			'getPostList' : function( hash, noticeYn ) {
				
				if (hash == null || hash == '')
				{
					hash = '#c1';
				}
               
                var bbsType = (hash.substr(1,1) == 'c') ? '108_130' : '108_140';
                var page = hash.substr(2);				
				
				var _self = this;
				var _contatiner;
				var _paging;
				
				_contatiner = _self.$listContainer;
				_paging = $('#bbsListPaging');
				
				// defaultParam 세팅
				var itemCnt     = 10;
				var defaultParam = {
					 'PAGE' 		: page
					,'PERPAGE' 		: itemCnt
					,'TYPE_CD' 		: bbsType
				};
				
				if (noticeYn == 'Y')
				{
					defaultParam.NOTICE_YN = "Y";
				}
				
				
				$.ajax({
					 url : _self.bbsListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('bbsList') ) {
				    		
				    		// 초기화
				    		
							if (noticeYn == 'Y')
							{
								_contatiner.empty();								
							}
							else
							{
								_contatiner.find('.bbsrow').remove();
							}

							var today = jdg.util.today();							
							
				    		
				    		var noticeList = data.noticeList;
				    		var list = data.bbsList;
				    		
				    		if (noticeList != null)
				    		{
				    			list = $.merge(noticeList,list);
				    		}
			    		
				    		
				    		if( list.length <= 0 ) {
					    		// nodata
				    			var $nodata = _self.$nodataTemplate.clone();
				    			_self.$listContainer.append( $nodata );
					    	}else{
					    		$('.jdg-ui-nodata').hide();
					    		
					    		// 번호
					    		var rowCount = data.total;
					    		var selectPage = itemCnt;
					    		if ( page > 1 ) {
					    			rowCount = rowCount - (page * selectPage) + selectPage;
								}
					    		
					    		$.each( list, function(idx, data) {
					    			var $pcRow = _self.$pcListTemplate.clone();
					    			
					    			$pcRow.attr( 'rowKey', data.POST_ID );
					    			
					    			var titleLink = $pcRow.find('a');
					    			var titleColor = data.TITLE_COLOR;
					    			var titleBold = data.TITLE_BOLD;
					    			
					    			titleLink.attr( 'postId', data.POST_ID );
					    			titleLink.attr( 'bbsType', bbsType );	
					    			titleLink.attr( 'secret', data.SECRET_YN);
					    			titleLink.attr( 'creator', data.CREATED_BY);
					    		
					    			
					    			// 번호
					    			data.rowNum = rowCount;
					    			rowCount--;

					    			var rownum = (data.NOTICE_YN == 'Y')? '▩' : data.RN;
					    			
					    			if (data.CREATED_AT >= today)
					    			{
					    				$pcRow.find('[data-key=TITLE]').before('<img src="https://img.fishapp.co.kr/legacy/wp/icon_new.png" style="margin: 0px 0 4px 3px;">');	
					    			}
					    			
					    			
					    			if (data.SECRET_YN == "Y")
					    			{
					    				$pcRow.find('[data-key=TITLE]').before('<img src="https://img.fishapp.co.kr/legacy/wp/icon_secret.png" style="margin: 3px 4px 4px 3px;">');					    				
					    			}
					    			
					    			
					    			if (data.NOTICE_YN == 'N')
					    			{
					    				$pcRow.addClass("bbsrow");
					    			}					    
					    			
					    			if (data.REPLY_CNT > 0)
					    			{
					    				$pcRow.find('[data-key=REPLY_CNT]').text( " [" + data.REPLY_CNT + "]" );
					    			}
					    			
					    			// 제목
					    			$pcRow.find('[data-key=RN]').text( rownum );
					    			$pcRow.find('[data-key=TITLE]').text( data.TITLE );
					    			
					    			if (titleColor != null)
				    				{
				    					$pcRow.find('[data-key=TITLE]').css('color', '#' + titleColor);
				    				}
					    			
					    			if (titleBold == "Y")
						    		$pcRow.find('[data-key=TITLE]').css('font-weight', 'bolder');
					    			
					    			
					    			$pcRow.find('[data-key=VIEW_CNT]').text( data.VIEW_CNT );
					    			$pcRow.find('[data-key=NICK_NAME]').text( data.NICK_NAME );

					    			// 등록일
				    				data.CREATED_AT = data.CREATED_AT.substr(0, 10);
				    				$pcRow.find('[data-key=CREATED_AT]').text( data.CREATED_AT );
					    			
					    			_contatiner.append( $pcRow );
					    		});
					    		
					    	}
				    		
//				    		// 페이징 초기화
				    		$(_paging).paging({
								 current: page
								,max: (Math.ceil(data.total / itemCnt))
								,itemClass: ''
								,prevClass: 'paging_prev'
								,nextClass: 'paging_next'
								,firstClass: ''
								,lastClass: ''
								,length: 5
								,itemCurrent: 'on'
								,onclick:function(e,page){
									
									var hash = (location.hash == "")? "#c1" : location.hash;
									location.hash = hash.substr(0,2) + page;

									_self.getPostList( location.hash );
								}
							});	
				    		
				    		if (page <= 5)
				    		{
				    			_paging.css("margin-left","40px");
				    		}
				    		else
				    		{
				    			_paging.css("margin-left","");
				    		}
				    		
				    		_paging.find('.paging_prev').text("<");
				    		_paging.find('.paging_next').text(">");
				    		

				    		
				    	}
				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				var _self = this;
				// 초기화
				_self.setElement();
				_self.setEvent();
				
				var hash = (location.hash == "")? "#c1" : location.hash;

				_self.tabIndex = (hash.substr(1,1) == 'c') ? 0 : 1;
				$(_self.tabList[_self.tabIndex]).addClass('on');		
				
				_self.getPostList(hash, 'Y');

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
