/**
 * Created with JetBrains PhpStorm.
 * User: kjh
 * Date: 15. 1. 6
 * Time: 오후 2:03
 * To change this template use File | Settings | File Templates.
 */
var targetScrollValue = 0;
var isScroll = true;
var scrollMaxHeight;

function setMaxHeight(){
    scrollMaxHeight = $(document).height() - $( window).height();
}

$(function(){

    var gap = 200;
    var duration = 0.8;
    $(window).on('resize', setMaxHeight );
//    function setMaxHeight(){
//        max = $(document).height() - $( window).height();
//    }
    var scrollSenseDelay = 100;
    var scrollSenseReady = true;



    TweenMax.to( document.documentElement, duration, { scrollTop:0, ease:Cubic.easeOut});
    TweenMax.to( document.body, duration, { scrollTop:0, ease:Cubic.easeOut});
});

var scroller = {
    moveScroll : function( scrollTop ){
        TweenMax.killTweensOf( document.body );
        TweenMax.killTweensOf( document.documentElement );
        TweenMax.to( document.body, 0.5, { scrollTop:scrollTop, ease:Cubic.easeOut});
        TweenMax.to( document.documentElement, 0.5, { scrollTop:scrollTop, ease:Cubic.easeOut});

        if( window.isScrollReady == false ){
            setTimeout( function(){
                window.isScrollReady = true;
            }, 500 );
        }
    }
}

