defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
			'setElement'	: function() {
				// url
				this.fishListURL = $('#fishListURL').val();
				this.fishDetailURL = $('#fishDetailURL').val();
				this.imageURL = $('#imageURL').val();
				this.noImageURL = $('#noImageURL').val();
				this.fishInsertURL = $('#fishInsertURL').val();
				this._updateFishURL = $("#updateFishURL").val();
				// element
				this.$fishContainer = $('#fishContainer');
				this.$fishListContainer = $('#fishListContainer');
				this.$searchRow = $('#fishTemplate').find('.searchRow');
				this.$imageRow = $('#fishTemplate').find('.imageRow');
				this.$insertBtn = $('#insertBtn');
				this.$editHbBtn = $('#editHbBtn');
				// static variable
				this.fishMonth = $('#fishMonth').val();
				this.$typeCd = '106_110';
				
				this.tabList = $('.cdt_tab_menu li');
				this.$condList = $('.cdt_list_con');
				this.$template = this.$condList.find('li');
				
				this.$prevPage = $('.cdt_list_prev');
				this.$nextPage = $('.cdt_list_next');				
				
			    this.tabIndex = 0;
			    this.page = 1;
			    this.maxpage = 1;
			    
			    this.$resaveBtn = $('#resaveBtn'); //자동조황
			   this.$fishGalrId = $("#LAST_GALR_ID").val();
			},
			'setEvent'		: function() {
				var _self = this;
				
				_self.$resaveBtn.click(function(){
					Bplat.view.loadPage(_self._updateFishURL + '?GALR_ID=' + _self.$fishGalrId +'&mode=rewrite');
				});
				
				_self.$insertBtn.click(function (){
					
					if (isLogin() == false)
					{
						showLoginBox("insert_form");
						return;
					}
					else
					{
						location.href = "insert_form";
					}

				});
				
				_self.$editHbBtn.click(function (){
					
					if (isLogin() == false)
					{
						showLoginBox("edit_hongbo_form");
						return;
					}
					else
					{
						location.href = "edit_hongbo_form";
					}
				});
				
				_self.tabList.on('click', function() {
	                var index = _self.tabList.index(this);

	                if (_self.tabIndex == index) return;
	                
	                _self.$typeCd = $(this).data("cd");
	               
	                // 이전 탭
	                $(_self.tabList[_self.tabIndex]).removeClass('on');
	                // 클릭 탭
	                $(_self.tabList[index]).addClass('on');
	                $(_self.tabList[index]).removeClass('over');
	                
	                _self.page = 1;
	                
	                location.hash = _self.$typeCd == "106_110" ? "#c1" : "#m1";

	                _self.tabIndex = index;
	                
	                _self.getFishList();
	            });

	            _self.tabList.on('mouseenter', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).addClass('over');
	            });

	            _self.tabList.on('mouseleave', function(e) {
	                var index = _self.tabList.index(this);
	                if (_self.tabIndex == index) return;
	                $(_self.tabList[index]).removeClass('over');
	            });
	            
	            
				_self.$prevPage.click(function (){
					
					stopEvent(event);
					
					if (_self.page > 1)
					{
						_self.page --;						
						arrowMoveTop = $(window).scrollTop();
						
						_self.getFishList();
						
				    	// 스크롤을 아래로 내린다				    	
						initScrollDown();
					}
				});
				
				_self.$nextPage.click(function (){
					
					stopEvent(event);
					
					if (_self.page < _self.maxpage)
					{
						_self.page ++;
						arrowMoveTop = $(window).scrollTop();
						
						_self.getFishList();
						
				    	// 스크롤을 아래로 내린다
						initScrollDown();
					}
				});	
				
				$('.fishImg').error(function (){
					
					$(this).unbind("error").attr("src", "https://img.fishapp.co.kr/legacy/wp/nopic.jpg");
					
				});
			},
			'getFishList' : function() {
				var _self = this;
				var page = _self.page;
				
				this.$condList.empty();
				
				if (_self.page == 1)
				{
					_self.$prevPage.hide();
				}
				else
				{
					_self.$prevPage.show();
				}

				// 조회 데이터
				var defaultParam = {
					 'PAGE' : page
					,'PERPAGE' : '8'
					,'TYPE_CD' : _self.$typeCd
				};
				$.ajax({
					 url : _self.fishListURL
					,type : 'POST'
					,data : defaultParam
				    ,dataType : 'json'
					    ,success : function( data ) {
					    	
					    	_self.maxpage = Math.ceil(data.total / 8);
					    	
							if (_self.page == _self.maxpage || _self.maxpage == 0)
							{
								_self.$nextPage.hide();
							}
							else
							{
								_self.$nextPage.show();
							}
					    	
					    	var fishList = data.fishList;

				    		$.each( fishList, function(idx,data) {					    			
				    			
				    			var tmp = _self.$template.clone();					    			
				    		
				    			tmp.find('a.detail_link').attr('href', "detail_form?GALR_ID=" + data.GALR_ID);
				    			tmp.find('.title').text(data.TITLE);	
				    			tmp.find('.text').text(data.SUMMARY);
				    			tmp.find('.info').html('<img src="https://img.fishapp.co.kr/legacy/wp/writer.jpg" alt="작성자"/> ' + data.CREATED_NICK + ' | <img src="https://img.fishapp.co.kr/legacy/wp/time.jpg" alt="작성일"/>' + jdg.util.replaceDate(data.FISH_DATE,'yymmdd'));
				    			
				    			var imgTag;
				    			imgTag = '<img class="fishImg" src="' + data.IMGHOST_URL + '" alt="'+data.SHIP_NAME +', '+ data.TITLE+'" onerror="this.src=\'https://img.fishapp.co.kr/legacy/wp/broken_pic.jpg\'">';	
//				    			var movImgId = data.MOV_IMG_ID;
//				    			
//				    			if (movImgId == null)
//				    			{
//				    				imgTag = '<img src="https://img.fishapp.co.kr/legacy/wp/nopic.jpg">';
//				    			}
//				    			else
//				    			{
				    					
//				    				if (movImgId.substr(0,5) == 'http:')
//				    				{
//					    							    					
//				    				}						    			
//				    				else if (movImgId.length > 10)
//					    			{
//					    				imgTag = '<p style="position: absolute"><img src="https://img.fishapp.co.kr/legacy/cm/ytube64.png" style="position: absolute;top: 100px;left: 100px;"></p>';
//					    				imgTag += '<img class="fishImg" src="https://i1.ytimg.com/vi/' + movImgId +'/mqdefault.jpg" width="280" height="238"  onerror="this.src=\'https://img.fishapp.co.kr/legacy/wp/broken_pic.jpg\'">';
//					    			}
//					    			else
//					    			{
//					    				imgTag = '<img class="fishImg" src="/cm/file/crop_image/' + movImgId + '/280x238"  alt="'+data.SHIP_NAME +', '+ data.TITLE+'" onerror="this.src=\'https://img.fishapp.co.kr/legacy/wp/broken_pic.jpg\'">';						    				
//					    			}					    				
//				    			}
				    			tmp.find('.img').html(imgTag);
				    			_self.$condList.append(tmp);
				    		}
					   );

				    	if (data.fishList)
				    	{
				    		var remain = 4 - data.fishList.length % 4;
				    		
				    		if (remain != 4)
				    			{
						    		for (var i = 0; i < remain; i++)
						    		{
						    			_self.$condList.append("<li style='height: 374px;cursor: initial'><div style='height: 238px;width: 280px;background: #f7fbff;'></div><div class='cdt_list_info_con'></div></li>");
						    		}				    			
				    			}
				    	}


				    }
				});
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[fish_main] onCreate Method' );
				
				var _self = this;				

				// 초기화
				_self.setElement();
				_self.setEvent();
				var hash = location.hash;
				
				if (hash.indexOf("m") >= 0)
				{
					_self.$typeCd = '106_120';
					_self.tabIndex = 1; //두번째탭
				}
				
				$(_self.tabList[_self.tabIndex]).addClass('on');
								
				if( '' == hash ) {
					location.hash = '#c1';
				} else {
					_self.page = Number(hash.substr(2));
				}
				
				_self.getFishList();
			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[fish_main] onStart Method' );
				

				
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[fish_main] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[fish_main] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[fish_main] onDestroy Method' );
			}		
	  }
});
