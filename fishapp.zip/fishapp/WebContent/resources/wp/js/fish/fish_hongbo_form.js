defClass({
		name		: 'BplatBody',
		pkg			: 'Bplat.viewPkg',
		implement	: Bplat.viewPkg.ViewInterface,
		construct : function() {},
		methods :{	
				'setElement'	: function() {
					this._loginURL = $('#loginURL').val();
					// element
					this.$updateForm = $('#memberFishInsertForm');
					this.$fishDate = $('#fishDate');
					this.$updateBtn = $('#updateFishBtn');
					
				},
				'setEvent'		: function() {
					var _self = this;
				
				_self.$updateBtn.click( function() {
					_self.updateFish();
				});				
		        
				loadbbsEditor("ir1", "");
				loadbbsEditor("ir2", "");	
			},
			

			// 홍보문구 업데이트
			'updateFish' : function() {
				var _self = this;
				
				var param = {};			
				
				addHtmlText(param); //webEditor to param
				
				if (param.HEADER_TEXT == oInitHTML["ir1"] && param.FOOTER_TEXT == oInitHTML["ir2"])
				{
		    		alert('목록으로 이동합니다.');
		    		var url = window.location.href;
					Bplat.view.loadPage('main#c1');
					return;
				}

				$.ajax({
					 url : 'save_hongbo'
					,type : 'POST'
					,data : param
				    ,dataType : 'json'
				    ,success : function( data ) {
				    	if( data.hasOwnProperty('result') ) {
				    		alert('저장 되었습니다');
				    		var url = window.location.href;
							Bplat.view.loadPage('main#c1');
				    	}
				    }
				});
			},
			'pageInit'		: function() {
				var _self = this;				
				
			},
			'onCreate' : function( p_param, _viewClass ) {
				Bplat.log.debug( '[home] onCreate Method' );
				var _self = this;
				// 초기화
				this.setElement();
				this.setEvent();

			},
			'onRestart' : function( p_param ) {
				Bplat.log.debug( '[home] onRestart Method' );
			},
			'onStart' : function( p_param ) {			
				Bplat.log.debug( '[home] onStart Method' );
			},
			'onHidePopup' : function( p_param ) {
				Bplat.log.debug( '[home] onHidePopup Method', JSON.stringify( p_param ) );
			},
			'onShowPopup' : function( p_param ) {
				Bplat.log.debug( '[home] onShowPopup Method' );
			},
			'onStop'	: function() {
				Bplat.log.debug( '[home] onStop Method' );			
			},
			'onDestroy' : function() {
				Bplat.log.debug( '[home] onDestroy Method' );
			}		
	  }
});
