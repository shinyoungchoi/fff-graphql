var cal, arrowBoundTop, arrowMoveTop;
var isLoginSuccess = false;

// 예약인원 업, 다운
function setPersonnelNum(dir) {
    var val = $('#personnelNum').val() || 0;
    var valNum = dir == "up" ? parseInt(val) + 1 : parseInt(val) - 1;
    $('#personnelNum').val(valNum < 0 ? 0 : valNum);
}

// 장비임대 업, 다운
function setEquipmentNum(dir) {
    var val = $('#equipmentNum').val() || 0;
    var valNum = dir == "up" ? parseInt(val) + 1 : parseInt(val) - 1;
    $('#equipmentNum').val(valNum < 0 ? 0 : valNum);
}

var _goUrl = null;
var _loginRefresh = true;

function showLoginBox(goUrl, isRefresh)
{
	$('.login_wrap').show();
	
	if (isRefresh)
	{
		_loginRefresh = isRefresh;
	}
	
	_goUrl = goUrl;
	
    $('.join_con').hide();
    $('.id_search_con').hide();
    $('.login_con').show();
    TweenMax.to ( '.login_wrap', 0.5, {marginRight:'0', ease:Cubic.easeInOut });
}

function hideLoginBox()
{
    TweenMax.to ( '.login_wrap', 0.5, {marginRight:'-50%', ease:Cubic.easeInOut,
	    	onComplete:function () 
	    	{
	    		$('.login_wrap').hide();  
	    	}  
    });    
    $('.login_wrap').css('top', 0);
    
}

function isLogin()
{
	return ($('.after_login').length > 0) ;
}

function stringFilter(str, format){
	switch (format) {
	case 'date':
		if(str.length >= 8){
			//yyyy-mm-dd	
			str = str.substr(0,4) + "-" + str.substr(4,2) + "-" +  str.substr(6,2);
		}else if(str.length == 6){
			//yyyy-mm
			str = str.substr(0,4) + "-" + str.substr(4,2);
		}else if(str.length == 4){
			//yyyy
			str = str.substr(0,4);
		}
		break;
	case 'time':
		if(str.length == 6){
			str = str.substr(0,2) + ":" + str.substr(2,2) + ":" +  str.substr(4,2);
		}else if(str.length == 4){
			str = str.substr(0,2) + ":" + str.substr(2,2);
		}
		break;
	case 'money':
		//comma
		var pattern = /(^[+-]?\d+)(\d{3})/;
		str += '';
		
		while(pattern.test(str)) {
			str = str.replace(pattern,'$1,$2');
		}
		break;	
	case 'removeHyphen':
		//remove hyphen date
		str = str.replaceAll('-', '');
		break;	
	default:
		break;
	}
	return str;
}


function toNumber(value)
{
	if (isNaN(value))
	{
		value = 0;
	}
	else
	{
		value = value * 1;
	}
	
	return value;
}


function if_showhide(condition, visualObj)
{
	if (condition)
	{
		visualObj.show();
	}
	else
	{
		visualObj.hide();
	}
}


function initPageing(pagingContainer, clickFunction, page, totalCnt, rowPerPage, numOfpagee)
{
//	// 페이징 초기화
	$(pagingContainer).paging({
		 current: page
		,max: (Math.ceil(totalCnt / rowPerPage))
		,itemClass: ''
		,prevClass: 'paging_prev'
		,nextClass: 'paging_next'
		,firstClass: ''
		,lastClass: ''
		,length: 5
		,itemCurrent: 'on'
		,onclick:function(e,page){
			_self.getPostList( bbsType, page );
		}
	});	
	
	if (page <= numOfpagee) //numOfpagee 5면 페이지를 5개씩 보여준다.
	{
		_paging.css("margin-left","40px");
	}
	else
	{
		_paging.css("margin-left","");
	}
	
	pagingContainer.find('.paging_prev').text("<");
	pagingContainer.find('.paging_next').text(">");	
}


function setFiledByData(container, fieldName, data)
{
	container.find('[data-key="' + fieldName +'"]').html(data[fieldName]);	
}

function setFiledByString(container, fieldName, str)
{
	container.find('[data-key="' + fieldName + '"]').html(str);	
}

function setFiledByDataFilter(container, fieldName, data, filter)
{
	container.find('[data-key="' + fieldName + '"]').html(stringFilter(data[fieldName], filter));	
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

$(function(){

    arrowBoundTop = 520;
    arrowMoveTop = 680;

    // 메뉴활성화
    onActiveMenu(0);
    
    // 샘플 팝업 닫기
    
    $('#info_alert_close').on('click', function(){
    	
    	var chk = $('#chk_hide_alert').is(":checked");
    	
    	if (chk)
    	{
    		setCookie('hide_alert',1, 1);
    	}
    	
    	$('.info_alert').hide();
    });
    
    var chk_hide_alert = getCookie('hide_alert');
    
    if (!chk_hide_alert)
    {
    	$('.info_alert').show();
    }

    // 상단 스크롤 화살표
    new SheetClip(document.getElementById("arrowDown"), 1000, 8, 89, 0, true).play();
    $('#arrowDown').on('click', function(){
        scroller.moveScroll(arrowMoveTop);
        targetScrollValue = arrowMoveTop;
    });


    // 로그인, 회원가입 아이콘 변경
    $('#loginBtn')
        .on('mouseover', function(){
            bm.image.srcChange( $('#loginBtn span').find('img'), '_off', '_on' );
        }).on('mouseout', function(){
            bm.image.srcChange( $('#loginBtn span').find('img'), '_on', '_off' );
        });
    
    $('#logoutBtn')
    .on('mouseover', function(){
        bm.image.srcChange( $('#logoutBtn span').find('img'), '_off', '_on' );
    }).on('mouseout', function(){
        bm.image.srcChange( $('#logoutBtn span').find('img'), '_on', '_off' );
    });
    
    $('#joinBtn')
        .on('mouseover', function(){
            bm.image.srcChange( $('#joinBtn span').find('img'), '_off', '_on' );
        }).on('mouseout', function(){
            bm.image.srcChange( $('#joinBtn span').find('img'), '_on', '_off' );
        });

    // 로그인 닫기 버튼
    $('.close_btn a').on('click', function(){
        hideLoginBox();
    });
     
    // 로그인 버튼 (로그인 팝업 호출)
    $('#loginBtn').on('click', function(){
    	showLoginBox();
    });
    
    // 로그인, 패스워드 입력필드에서 엔터키처리
    $('#jdg-id,#jdg-pw').on('keypress', function(e){
    	
    	if (e.which == 13) {
    		
    		if (this.id == "jdg-id")
    		{
    			if (this.value != "")    			
    				$('#jdg-pw').focus();
    		}
    		else
    		{
    			if (this.value != "")  
    				loginAction();
    		}
    	}
    });
    
    _loginURL = $('#loginURL').val();
    _logoutURL = $('#logoutURL').val();
    
    $('.after_login').show();

    // 로그인 버튼(아이디,패스워드로 로그인)
    $('#login_button').on('click', function() {    	
    	loginAction();			
    });

    // 로그아웃 버튼
    $('#logoutBtn').on('click', function() {
        if (confirm('로그아웃 하시겠습니까?')) {        	
    		$.ajax({
    			url : _logoutURL
    			,type : 'POST'
    			,async: false
    		    ,dataType : 'json'
    		    ,success : function(data){    		    	
    		    	window.location.reload(true);
    		    }
    		});
        }        
        return false;
    });

    // 회원가입 버튼
    $('#joinBtn').on('click', function(){    	
    	$('.login_wrap').show(); 
        $('.login_con').hide();
        $('.id_search_con').hide();
        $('.join_con').show();
        TweenMax.to ( '.login_wrap', 0.5, {marginRight:'0', ease:Cubic.easeInOut });
    });

    $('#loginConJoinBtn').on('click', function(){
        $('.login_con').hide();
        $('.join_con').fadeIn(500);
    });

    // 아이디 찾기 버튼
    $('#findIdBtn').on('click', function() {
    	
    	$('.id_search_con input').val('');
    	$('.id_search_con input:radio')[0].checked = 'checked'
        $('.login_con').hide();
        $($('.id_search_con .search_info')[0]).addClass('on');
        $($('.id_search_con .search_info')[1]).removeClass('on');
        
        $('#id_search_con .cert_info').hide();
    	$('.sendAuthBtn').show();
    	$(':radio').prop('disabled', false);	
        
        $($('.id_search_con')[0]).fadeIn(500, function() {
            $('#idTelName').focus();
        });
    });

    // 비밀번호 찾기 버튼
    $('#findPwBtn').on('click', function() {
    	
    	$('.id_search_con input').val('');
    	$('.id_search_con input:radio')[2].checked = 'checked'
        $('.login_con').hide();
        $($('.pw_search_con .search_info')[0]).addClass('on');
        $($('.pw_search_con .search_info')[1]).removeClass('on');

        $('#pw_search_con .cert_info').hide();
    	$('.sendAuthBtn').show();
    	$(':radio').prop('disabled', false);	
        
        $('.pw_search_con').fadeIn(500, function() {
            $('#pwTelName').focus();
        });
    });

    // 라디오 버튼 클릭
    $('.id_search_con input:radio').on('change', function() {
        var type = $(this).data('type');

        if (type == "idTel") {
            $($('.id_search_con .search_info')[0]).addClass('on');
            $($('.id_search_con .search_info')[1]).removeClass('on');
            $('#idTelName').focus();
        } else if (type == "idEmail") {
            $($('.id_search_con .search_info')[1]).addClass('on');
            $($('.id_search_con .search_info')[0]).removeClass('on');
            $('#idEmailName').focus();
        } else if (type == "pwTel") {
            $($('.pw_search_con .search_info')[0]).addClass('on');
            $($('.pw_search_con .search_info')[1]).removeClass('on');
            $('#pwTelName').focus();
        } else if (type == "pwEmail") {
            $($('.pw_search_con .search_info')[1]).addClass('on');
            $($('.pw_search_con .search_info')[0]).removeClass('on');
            $('#pwEmailName').focus();
        }
    });

    // 달력 컨트롤
    cal = $('#mainTopCal')[0];

    $('#mainTopCal #calCloseBtn').on( 'click', function(){
        TweenMax.to ( cal, 0.5, {marginTop:30, opacity:0, ease:Cubic.easeInOut, onComplete : function(){
            $(cal).hide();
        } });
    });

    // 조황 마우스 오버 아웃 컨트롤.
    $('.condition_list li').hover(function(){
        $(this).addClass( 'on' );
    },function(){
        $(this).removeClass( 'on' );
    })

    $('.notice_list li').hover(function(){
        $(this).addClass( 'on' );
    },function(){
        $(this).removeClass( 'on' );
    })

    if( $('.main_img_con').length > 0 ){
        var mainImg = new MainImg();
        mainImg.rollStart();
    }

    var isGnb = false;
    var isArrow = true;

    $(window).on('scroll', function() {
        var st = $(window).scrollTop();

        // GNB 컨트롤
        if (st >= 160 && !isGnb) {
            $('.gnb_fixed_wrap').slideDown(150);
            isGnb = true;
        }
        if (st < 160 && isGnb) {
            $('.gnb_fixed_wrap').slideUp(150);
            isGnb = false;
        }

        // 화살표 컨트롤
        if (st > arrowBoundTop && isArrow) {
            $('#arrowDown').fadeOut(500);
            isArrow = false;
        }
        if (st <= arrowBoundTop && !isArrow) {
            $('#arrowDown').fadeIn(500);
            isArrow = true;
        }

    });

	$('#btnBcGo').click(function(event) {
	    event.preventDefault();	    
	    var link = location.href;	    
	    var idx = link.indexOf("/wp/");	    
	    link = "/wp/" + link.substring(idx + 4, idx + 25) +"/ship";
	    window.open(link,'ship','width=950,height=500');
	    //popupFullScreen(link);
	});
	
	$('#btnCcGo').click(function(event) {
	    event.preventDefault();	    
	    var link = location.href;	    
	    var idx = link.indexOf("/ws/");	    
	    link = "/cc/" + link.substring(idx + 4, idx + 14);	    
	    popupFullScreen(link);
	});

});

/**
 * 메뉴 활성화
 * @param menuIndex
 */
function onActiveMenu(menuIndex) {

    var menuList = $('.top_con .gnb_con ul li');
    var fixedMenuList = $('.gnb_fx_con .gnb_con ul li');
    menuList.removeClass('on');
    fixedMenuList.removeClass('on');
    $(menuList[menuIndex]).addClass('on');
    $(fixedMenuList[menuIndex]).addClass('on');
}


function loginAction()
{
	var idv = $("#jdg-id").val();
	var pwv = $("#jdg-pw").val();
	
	if (idv == "")
	{
		alert('아이디를 입력해주십시오.');
		$("#jdg-id").focus();
		return;
	}
	
	if (pwv == "")
	{
		alert('패스워드를 입력해주십시오.');
		$("#jdg-pw").focus();
		return;
	}
	
	var param = {LOGIN_ID: $("#jdg-id").val()	,PWD: $("#jdg-pw").val()};
	
	if ($("#auto_login").is(":checked"))
	{
		param.AUTO_LOGIN = "on";
	}	
	
	$.ajax({
		url : _loginURL
		,type : 'POST'
		,data : param
		,async: false
	    ,dataType : 'json'
	    ,success : function(data){    	

		    	if (data.msg != null)
		    	{
		    		if (data.redirectUrl != null)
		    		{
		    			if (confirm(data.msg))
		    			{
		    				location.href = data.redirectUrl;
		    			}
		    		}
		    		else
		    		{
		    			alert(data.msg);
		    		}
		    		
		    		return false;
		    	}	    		
	    		
		    	if (_goUrl)
		    	{
		    		location.href = _goUrl;
		    	}
		    	else
		    	{
		    		if (_loginRefresh)
		    			{
		    				window.location.reload(true);
		    			}
		    		else
		    			{
			    	        TweenMax.to ( '.login_wrap', 0.5, {marginRight:'-50%', ease:Cubic.easeInOut });		    	        
			    	        $('.login_wrap').css('top', 0);		    			
		    			}
		    	}
	    }
	});	    	
}

/** 스크롤을 아래로 내린다 */
function scrollDown()
{	
	$( "#arrowDown" ).trigger( "click" );
}

/** 스크롤을 0.3초 뒤에 아래로 내린다 */
function initScrollDown()
{
	var timeout = setTimeout('scrollDown();', 300);
}

var MainImg = function(){

    var mainList = $('.main_img_con li');
    var timer;
    var prevIndex = 0;
    var imgIndex = 0;

    this.rollStart = function(){
        clearInterval(timer);
        timer = setInterval( increaseIndex, 2500 );
        setBtns();
    };

    function setBtns(){
        $('.main_next_btn').on( 'click', function(){
            increaseIndex();
        });

        $('.main_prev_btn').on( 'click', function(){
            decreaseIndex();
        });

        clearInterval(timer);
        timer = setInterval( increaseIndex, 2500 );
    };

    function decreaseIndex(){
        prevIndex = imgIndex;
        imgIndex--;

        if( imgIndex < 0 ) imgIndex = mainList.length-1;
        indexControl();
    };

    function increaseIndex(){
        prevIndex = imgIndex;
        imgIndex++;

        if( imgIndex >= mainList.length ) imgIndex = 0;
        indexControl();
    };

    function indexControl(){
        TweenMax.to( mainList[ prevIndex ], 1, {opacity:0} );

        $(mainList[ imgIndex ]).show();
        TweenMax.fromTo( mainList[ imgIndex ], 1, {opacity:0}, {opacity:1} );
    };
}

var oEditors = [];

var oInitHTML = {};

function loadWebEditor(taId, strContent)
{
	loadEditor(taId, strContent,"/rsc/se/SmartEditor2Skin2.html");
}


function loadbbsEditor(taId, strContent)
{
	loadEditor(taId, strContent,"/rsc/se/SmartEditor2Skin.html?v=2");
}

function loadEditor(taId, strContent, skinUrl)
{
	if (strContent == null)
	{
		strContent = "";
	}
	
	nhn.husky.EZCreator.createInIFrame({
		oAppRef: oEditors,
		elPlaceHolder: taId,
		//SmartEditor2Skin.html 파일이 존재하는 경로
		sSkinURI: skinUrl,	
		htParams : {
			// 툴바 사용 여부 (true:사용/ false:사용하지 않음)
			bUseToolbar : true,				
			// 입력창 크기 조절바 사용 여부 (true:사용/ false:사용하지 않음)
			bUseVerticalResizer : true,		
			// 모드 탭(Editor | HTML | TEXT) 사용 여부 (true:사용/ false:사용하지 않음)
			bUseModeChanger : true,			
			fOnBeforeUnload : function(){
				
			}
		}, 
		fOnAppLoad : function(){
			oEditors.getById[taId].exec("PASTE_HTML", [strContent]);
			oInitHTML[taId] = oEditors.getById[taId].getContents();
		},
		fCreator: "createSEditor2"
	});

}

function addHtmlText(param)
{
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
	oEditors.getById["ir2"].exec("UPDATE_CONTENTS_FIELD", []);
	
	param.HEADER_TEXT =$('#ir1').val().replace(/\u8203/g,'');
	param.FOOTER_TEXT =$('#ir2').val().replace(/\u8203/g,'');

}
