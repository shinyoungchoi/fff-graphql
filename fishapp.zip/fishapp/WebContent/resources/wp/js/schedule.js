var tdList, trList;
var makeDate;
var activeIndex, firstRangeIndex, lastRangeIndex;
var year, month, date;
var lastDate, prevLastDate;
var prevMonth, nextMonth;
var nextMonth;
var activeID;
var isRemainingDate = true;
var isMothTypeEvent = false;
var isDayTypeEvent = false;
var reservationDate;

/**
 * 월의 마지막 날짜 구하기
 * @param mm 월 (0: 1월 ~ 11: 12월)
 * @param yyyy 년도
 * @returns {number} 달의 마지막 날짜
 */
function getLastDate(mm, yyyy) {

    var lastDate = 0;

    if (mm == 3 || mm == 5 || mm == 8 || mm == 10) {
        lastDate = 30;
    } else {
        lastDate = 31;

        if (mm == 1) {
            if (yyyy % 4 != 0) lastDate = 28;
            else lastDate = 29;
        }
    }

    return lastDate;

}

/**
 * 달력 만들기
 * @param value 달력을 만들 날짜(ex: 2015-01-01)
 */
function makeCalendar(value) {

    setMonthTypeSchedule(value);

}

var monthListEng = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var monthListKr = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
var dayList = ["일", "월", "화", "수", "목", "금", "토"];

/**
 * 월별 스케쥴 설정
 */
function setMonthTypeSchedule(value) {

    tdList = $('#scheduleContainer tbody td');
    
    var currentDate = new Date();

    if (!value) {
        makeDate = new Date();
    } else {
        var yyyy = value.substr(0,4) * 1;
        var mm = value.substr(4,2) * 1 - 1;
        makeDate = new Date(yyyy, mm);
    }

    year = makeDate.getFullYear();
    month = makeDate.getMonth();
    if (!value) date = makeDate.getDate();
    lastDate = getLastDate(month, year);
    prevMonth = month - 1 < 0 ? 11 : month - 1;
    nextMonth = month + 1 > 11 ? 1 : month + 1;
    prevLastDate = getLastDate(prevMonth, year);
    makeDate.setDate(1);
    firstRangeIndex = makeDate.getDay();
    var currentActiveID = currentDate.getFullYear() + getDigitNum(currentDate.getMonth() + 1) + getDigitNum(currentDate.getDate());
    activeID = !$('#reservationDate').val() ? currentActiveID : $('#reservationDate').val();
    lastRangeIndex = firstRangeIndex + lastDate - 1;

    $('.schd_tb_top .text').text(year + "년 " + (month + 1) + "월");

    var dateId = "";
    var dateClass = "";
    var dateNum = 0;
    var len = tdList.length;
    for (var i = 0; i < len; i++) {
        var td = $(tdList[i]);
        if (i < firstRangeIndex || i > lastRangeIndex) {
            dateNum = "";
            dateId = "";
        } else {
            dateNum = i - firstRangeIndex + 1;
            dateId = year + getDigitNum(month + 1) + getDigitNum(dateNum);
            
            makeDate.setDate(dateNum);
            td.data('date', (month + 1) + "월 " + dateNum + "일"); 
            td.data('day', dayList[makeDate.getDay()]); 
        }
        
        td.attr('class', dateClass);
        td.attr('id', dateId);
        td.find('.number').text(dateNum);
        

        
        if (lastRangeIndex % 7 == 6 && i > lastRangeIndex) td.hide();
        else if (lastRangeIndex <= 34 && i > 34) td.hide();
        else td.show();
    }

}


/**
 * 예약요청
 * @param value 예약날짜
 */
function requestReservation(date) {

    reservationDate = date;
    showReservationPop();

}

/**
 * 예약팝업 show
 */
function showReservationPop() {

    $('.reserv_popup_wrap').fadeIn(200);
    $('.reserv_popup_wrap .popup_common_con').css({top: '60%'});
    $('.reserv_popup_wrap .popup_common_con').animate({top: '40%'}, 200);
    isScroll = false;
    lockScroll();

}
/**
비회원 예약 팝업
**/
function showNoMemberReservationPop() {

    $('.nomem_reserv_popup_wrap').fadeIn(200);
    $('.nomem_reserv_popup_wrap .popup_common_con').css({top: '60%'});
    $('.nomem_reserv_popup_wrap .popup_common_con').animate({top: '40%'}, 200);
    isScroll = false;
    lockScroll();

}


/**
 * 비회원 예약확인 팝업 hide
 */
function hideNoMemberReservationConfirmPop() {
    $('.nomem_reserv_popup_wrap').fadeOut(200);
    $('.nomem_reserv_popup_wrap .reserv_confirm_popup_con').animate({top: '60%'}, 200);
    isScroll = true;
    unlockScroll();
}

/**
 * 예약팝업 hide
 */
function hideReservationPop() {

    $('.reserv_popup_wrap').fadeOut(200);
    $('.reserv_popup_wrap .popup_common_con').animate({top: '60%'}, 200);
    isScroll = true;
    unlockScroll();

}

/**
 * 예약확인 팝업 hide
 */
function hideReservationConfirmPop() {
    $('.reserv_confirm_popup_wrap').fadeOut(200);
    $('.reserv_popup_wrap .reserv_confirm_popup_con').animate({top: '60%'}, 200);
    isScroll = true;
    unlockScroll();
}


/**
 *
 * @param num 디지털 형식으로 변환할 숫자
 * @returns {string} 숫자를 디지털 형식으로 변환
 */
function getDigitNum(num) {

    if (num < 10) return "0" + num;
    return "" + num;

}


function makeHoliday(row,date)
{
	if (isHoliday(date)) {
		row.find('td.date,td.day').addClass('sun');
		row.css('background-color', '#FFF2F2');
		
		var rspan = row.find('td.date').attr('rowspan');
		if (rspan)
		{
			for (var i=1; i < rspan; i++)
			{
				row = row.next();
				row.css('background-color', '#FFF2F2');
			}
		}
	}
}
