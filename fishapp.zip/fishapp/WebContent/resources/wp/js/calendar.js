var tdList;
var makeDate;
var activeIndex, firstRangeIndex, lastRangeIndex;
var year, month, date;
var lastDate, prevLastDate;
var prevMonth, nextMonth;
var nextMonth;
var activeID;
var isRemainingDate = true;
var isEvent = false;

var availCnt = 0;

/**
 * 월의 마지막 날짜 구하기
 * @param mm 월 (0: 1월 ~ 11: 12월)
 * @param yyyy 년도
 * @returns {number} 달의 마지막 날짜
 */
function getLastDate(mm, yyyy) {

    var lastDate = 0;

    if (mm == 3 || mm == 5 || mm == 8 || mm == 10) {
        lastDate = 30;
    } else {
        lastDate = 31;

        if (mm == 1) {
            if (yyyy % 4 != 0) lastDate = 28;
            else lastDate = 29;
        }
    }

    return lastDate;

}

/**
 * 달력 만들기
 * @param reserveDate 달력을 만들 날짜(ex: 2015-01-01)
 */
function makeCalendar(reserveDate) {

    tdList = $('#calendarContainer tbody td');
    var currentDate = new Date();

    if (!reserveDate) {
        makeDate = new Date();
    } else {
        var yyyy = parseInt(reserveDate.split('-')[0]);
        var mm = parseInt(reserveDate.split('-')[1]) - 1;
        var dd = parseInt(reserveDate.split('-')[2]);
        if (!dd) makeDate = new Date(yyyy, mm);
        else makeDate = new Date(yyyy, mm, dd);
    }

    year = makeDate.getFullYear();
    month = makeDate.getMonth();
    if (!reserveDate) date = makeDate.getDate();
    lastDate = getLastDate(month, year);
    prevMonth = month - 1 < 0 ? 11 : month - 1;
    nextMonth = month + 1 > 11 ? 1 : month + 1;
    prevLastDate = getLastDate(prevMonth, year);
    makeDate.setDate(1);
    firstRangeIndex = makeDate.getDay();
    
    var currentDateID = currentDate.getFullYear() + "-" + getDigitNum(currentDate.getMonth() + 1) + "-" + getDigitNum(currentDate.getDate());
    var reservationDate = $('#reservationDate').val() ;
    activeID = reservationDate == null ? "" : reservationDate;
    lastRangeIndex = firstRangeIndex + lastDate - 1;

    var monthListEng = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var monthListKr = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
//    var dayList = ["일", "월", "화", "수", "목", "금", "토"];

    $('.year').text(year);
    $('.month_text').text(monthListEng[month]);
    $('.month_num').text(monthListKr[month]);

    var dateId = "";
    var dateClass;
    var dateNum = "";
    var len = tdList.length;
    for (var i = 0; i < len; i++) {
    	
    	dateClass = "deselect";
    	
        var td = $(tdList[i]);
        if (i < firstRangeIndex || i > lastRangeIndex) {
            dateNum = "";
            dateId = "";
        } else {
            dateNum = i - firstRangeIndex + 1;
            dateId = year + "-" + getDigitNum(month + 1) + "-" + getDigitNum(dateNum);
            
            if (dateId == activeID) 
            {	
            	dateClass = "select";
            }
            
            if (dateId == currentDateID)
            {
            	td.css("font-weight","900");;
            	td.css("text-decoration","underline"); 
            }
            else
            {
            	td.css("font-weight","normal");
            	td.css("text-decoration","none");           	
            }
        }

        td.attr('class', dateClass);
        td.attr('id', dateId);
        td.text(dateNum);

        if (lastRangeIndex % 7 == 6 && i > lastRangeIndex) td.hide();
        else if (lastRangeIndex <= 34 && i > 34) td.hide();
        else td.show();
    }
    
    var scheduleList = Bplat.viewPkg.BplatBody._scheduleList;
    
    var schdDate;
    var schdStr;
    
    $(scheduleList).each(function()
    		{
  
	    	schdDate = this.SCHD_DATE;
	    	schdStr = schdDate.substr(0,4) + "-" + schdDate.substr(4,2) + "-" + schdDate.substr(6,2);
	    	
	    	var $td = $("#calendarContainer tbody td[id=" + schdStr + "]");
	    	
	    	$td.data("availCnt", this.AVAIL_CNT);
	    	
	    	if (schdStr != activeID)
	    		{
	    			$td.attr('class', "");
	    		}   	
    		}

	);
    

    if (!isEvent) addEvent();
}

function addEvent() {

    $(tdList).on('click', function() {
        if ($(this).css('cursor') == 'default') return;

        var currentDate = new Date();
        var resevationDate = new Date($(this).attr('id').split('-')[0], parseInt($(this).attr('id').split('-')[1]) - 1, $(this).attr('id').split('-')[2]);
        
        
        availCnt = $(this).data("availCnt"); //예약가능인원

        if (resevationDate < currentDate) {
            alert("예약하실 수 없습니다.");
            return;
        }

        $(Bplat.viewPkg.BplatBody.$calendar).hide();
        $('#reservationDate').val($(this).attr('id'));
    });

    $(tdList).on('mouseenter', function() {
        if ($(this).css('cursor') == 'default') return;
        if ($(this).attr('id') == activeID) return;

        $(this).addClass("select");
    });

    $(tdList).on('mouseleave', function() {
        if ($(this).css('cursor') == 'default') return;
        if ($(this).attr('id') == activeID) return;

        $(this).removeClass("select");
    });

    isEvent = true;

}

/**
 * 달력 업데이트
 * @param dir 'prev' 이전달 next '다음달'
 */
function updateCalendar(dir) {

    var yyyy = 0;
    var mm = 0;
    var dd = 0;

    if (dir == "next") {
        if (month == 11) {
            month = 0;
            year += 1;
        }
        else month += 1;
    } else {
        if (month == 0) {
            month = 11;
            year -= 1;
        }
        else month -= 1;
    }

    var dateString = year + "-" + getDigitNum(month + 1);

    makeCalendar(dateString);

}

/**
 *
 * @param num 디지털 형식으로 변환할 숫자
 * @returns {string} 숫자를 디지털 형식으로 변환
 */
function getDigitNum(num) {

    if (num < 10) return "0" + num;
    return "" + num;

}