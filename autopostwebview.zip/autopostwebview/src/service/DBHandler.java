package service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bean.GalBean;
import bean.ImageBean;

public class DBHandler {

	private Connection _conn = null;

	public DBHandler() {

	}

	public Connection getConnection() throws Exception
	{
		if (_conn == null)
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 개발DB
			//_conn = DriverManager.getConnection("jdbc:oracle:thin:@52.79.247.119:1521:xe", "pentadev", "Fishapp2014");
			// 아마존 DB
			_conn = DriverManager.getConnection("jdbc:oracle:thin:@fishapp.cvueacsj3te4.ap-northeast-2.rds.amazonaws.com:1521:ORCL", "fishapp", "fishapp2014!");

		}

		return _conn;
	}

	public void closeConnection()
	{
		try
		{
			if (!_conn.isClosed())
			{
				_conn.close();
			}
			_conn = null;
		}
		catch(Exception e){}
	}

	public List<GalBean> getFishGalleryListRenew() throws Exception
	{
		List<GalBean> lst = null;

		//어부지리는 한글도메인안됨. 한글도메인이면 **.ho 또는 **.sd로 안내
		String sql1 =
				" SELECT A.SHIP_ID                                                                                                      " +
				", A.SUNDAN_ID                                                                                                         " +
				", A.GALR_ID                                                                                                           " +
				", A.SHIP_NAME                                                                                                         " +
				", S.SUNDAN_NAME                                                                                                       " +
				", A.PORT_NAME                                                                                                         " +
				", A.FISH_DATE                                                                                                         " +
				", A.TITLE                                                                                                             " +
				", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
				", A.LOC_DESC                                                                                                          " +
				", A.FISH_NAME                                                                                                          " +
				", A.GPS_LAT                                                                                                           " +
				", A.GPS_LONG                                                                                                          " +
				", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
				", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                        " +
				", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                             " +
				", A.PEOPLE_ONBOARD     " +
				", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                              " +
				", C.PSGR_CNT                                                                                                          " +
				", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME" +
				", NVL(CPTN_TITLE,'선장')  CPTN_TITLE       " +
				//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
                //", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
				" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
				" ( select IMGHOST_URL from t_upload_file where file_id = "+
                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
				", NVL(AREA_DESC, ' ') AREA_DESC                                                                                       " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                           " +
				"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                  " +
				"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE         " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           DECODE(LENGTHB(SUBSTR(C.DOM_ADDR,1,1)), 1, C.DOM_ADDR, 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho')  ,             " +
				"           DECODE(LENGTHB(SUBSTR(S.DOM_ADDR,1,1)), 1, S.DOM_ADDR, 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE_URL  " +
				", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2                                    " +
				", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD                                                        " +
				", DECODE(INNAK_STATUS,'S','S',NULL) INNAK_STATUS, DECODE(DINAK_STATUS,'S','S',NULL) DINAK_STATUS, DECODE(AFISH_STATUS,'S','S',NULL) AFISH_STATUS  " +
				", HEADER_HB, FOOTER_HB, PICASA_YN                                                                        " +
				" FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                " +
				" WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - 3 ,'YYYYMMDD')                                                                 " +
				" AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
				" AND A.SHIP_ID = H.SHIP_ID(+)    AND A.TYPE_CD = '106_110'                                                                                         " +
				" AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                                 " +
				" AND (U.AFISH_YN = 'Y' AND U.AFISH_ID  IS NOT NULL AND (AFISH_STATUS IS NULL) AND AFISH_BBS_CD IS NOT NULL) " +
				" AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
				" AND A.PORT_CD =  B.PORT_CD (+)                                                                                        " +
				" AND A.SHIP_ID = C.SHIP_ID (+)                                                                                            " +
				" AND ROWNUM = 1                                                                                           " +
				" ORDER BY A.GALR_ID     ";

		Connection conn = getConnection();
		PreparedStatement psmt;

		psmt = conn.prepareStatement(sql1);

		System.out.println(sql1);

		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<GalBean>();

			while(rs.next())
			{
				GalBean bean = new GalBean();
				bean.SHIP_ID = rs.getString("SHIP_ID");
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.SHIP_NAME = rs.getString("SHIP_NAME");
				bean.SUNDAN_NAME = rs.getString("SUNDAN_NAME");
				bean.CPTN_NAME = rs.getString("CPTN_NAME");
				bean.CPTN_TITLE = rs.getString("CPTN_TITLE");
				bean.PORT_NAME = rs.getString("PORT_NAME");
				bean.FISH_DATE = rs.getString("FISH_DATE");
				bean.TITLE = rs.getString("TITLE");
				bean.LOC_DESC = rs.getString("LOC_DESC");
				bean.HEADER_TEXT = rs.getString("HEADER_TEXT"); //조행기 헤더
				bean.FOOTER_TEXT = rs.getString("FOOTER_TEXT"); //조행기 푸터
				bean.INNAK_AREA_CD = rs.getString("INNAK_AREA_CD");
				bean.PSGR = rs.getString("PSGR_CNT");
				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");
				bean.AREA_DESC = rs.getString("AREA_DESC");
				bean.SITE = rs.getString("SITE");
				bean.SITE_URL = rs.getString("SITE_URL");
				bean.CPTN_IMG_ID = rs.getString("CPTN_IMG_ID");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");
				bean.SHIP_AUTOPOST_NEW = rs.getString("SHIP_AUTOPOST_NEW");
				bean.SUNDAN_AUTOPOST_NEW = rs.getString("SUNDAN_AUTOPOST_NEW");

				bean.FISH_NAME = rs.getString("FISH_NAME");
				bean.SUNDAN_ID = rs.getString("SUNDAN_ID");
				bean.DATE_DY = rs.getString("DATE_DY");

				bean.SUMMARY = rs.getString("SUMMARY"); //조황요약
				bean.HEADER_HB = rs.getString("HEADER_HB"); //홍보내용 헤더
				bean.FOOTER_HB = rs.getString("FOOTER_HB"); //홍보내용 푸터
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");

				bean.AFISH_ID = rs.getString("AFISH_ID");
				bean.AFISH_PWD = rs.getString("AFISH_PWD");
				bean.AFISH_YN= rs.getString("AFISH_YN");
				bean.AFISH_STATUS= rs.getString("AFISH_STATUS");
				bean.AFISH_P1= rs.getString("AFISH_BBS_CD"); //게시판코드

				lst.add(bean);
			}

		}
		catch(Exception e) {

			e.printStackTrace();

		}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}



	public List<GalBean> getFishGalleryList() throws Exception
	{
		List<GalBean> lst = null;

		//어부지리는 한글도메인안됨. 한글도메인이면 **.ho 또는 **.sd로 안내
		String sql1 =
				"SELECT A.SHIP_ID                                                                                                      " +
				", A.SUNDAN_ID                                                                                                         " +
				", A.GALR_ID                                                                                                           " +
				", A.SHIP_NAME                                                                                                         " +
				", S.SUNDAN_NAME                                                                                                       " +
				", A.PORT_NAME                                                                                                         " +
				", A.FISH_DATE                                                                                                         " +
				", A.TITLE                                                                                                             " +
				", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
				", A.FISH_NAME                                                                                                          " +
				", A.LOC_DESC                                                                                                          " +
				", A.GPS_LAT                                                                                                           " +
				", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
				", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                        " +
				", A.GPS_LONG                                                                                                          " +
				", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                             " +
				", A.PEOPLE_ONBOARD                                                                                                    " +
				", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                              " +
				", C.PSGR_CNT                                                                                                          " +
				", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME" +
				", NVL(CPTN_TITLE,'선장')  CPTN_TITLE       " +
				//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
              //  ", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
            	" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
				" ( select IMGHOST_URL from t_upload_file where file_id = "+
                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
				", NVL(AREA_DESC, ' ') AREA_DESC                                                                                       " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                           " +
				"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                  " +
				"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE         " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           DECODE(LENGTHB(SUBSTR(C.DOM_ADDR,1,1)), 1, C.DOM_ADDR, 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho')  ,             " +
				"           DECODE(LENGTHB(SUBSTR(S.DOM_ADDR,1,1)), 1, S.DOM_ADDR, 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE_URL  " +
				", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2                                    " +
				", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD                                                        " +
				", DECODE(INNAK_STATUS,'S','S',NULL) INNAK_STATUS, DECODE(DINAK_STATUS,'S','S',NULL) DINAK_STATUS, DECODE(AFISH_STATUS,'S','S',NULL) AFISH_STATUS  " +
				", HEADER_HB, FOOTER_HB, PICASA_YN                                                                        " +
				"FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                " +
				"WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - 3 ,'YYYYMMDD')                                                                 " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
				"AND A.SHIP_ID = H.SHIP_ID(+)    AND A.TYPE_CD = '106_110'                                                                                         " +
				"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                                 " +
				"AND (U.AFISH_YN = 'Y' AND U.AFISH_ID  IS NOT NULL AND (AFISH_STATUS  IS NULL) AND AFISH_BBS_CD IS NOT NULL) " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
				"AND A.PORT_CD =  B.PORT_CD (+)                                                                                        " +
				"AND A.SHIP_ID = C.SHIP_ID (+)                                                                                            " +
				"AND ROWNUM = 1                                                                                           " +
				"ORDER BY A.GALR_ID                                                                                                    " ;

		String sql2 =
				"SELECT A.SHIP_ID                                                                                                                                    " +
						", A.SUNDAN_ID                                                                                                                                       " +
						", A.GALR_ID                                                                                                                                         " +
						", A.SHIP_NAME                                                                                                                                       " +
						", S.SUNDAN_NAME                                                                                                                                     " +
						", A.PORT_NAME                                                                                                                                       " +
						", A.FISH_DATE                                                                                                                                       " +
						", TITLE                                                                                                                      " +
						", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
						", A.FISH_NAME                                                                                                          " +
						", A.LOC_DESC                                                                                                                                        " +
						", A.GPS_LAT                                                                                                                                         " +
						", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
						", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                        " +
						", A.GPS_LONG                                                                                                                                        " +
						", HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                   " +
						", A.PEOPLE_ONBOARD                                                                                                                                  " +
						", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                                                            " +
						", C.PSGR_CNT                                                                                                                                        " +
						", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME" +
						", NVL(CPTN_TITLE,'선장')  CPTN_TITLE                                                                                                                  " +
						//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
		              //  ", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
		            	" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
		                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
						" ( select IMGHOST_URL from t_upload_file where file_id = "+
		                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
						", NVL(AREA_DESC, ' ') AREA_DESC                                                                                                                     " +
						", DECODE(A.SUNDAN_ID, NULL,                                                                                                                         " +
						"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                                                " +
						"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE                                       " +
						", DECODE(A.SUNDAN_ID, NULL,                                                                                                                         " +
						"           DECODE(LENGTHB(SUBSTR(C.DOM_ADDR,1,1)), 1, C.DOM_ADDR, 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho')  ,                              " +
						"           DECODE(LENGTHB(SUBSTR(S.DOM_ADDR,1,1)), 1, S.DOM_ADDR, 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE_URL                  " +
						", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2                                                                   " +
						", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD                                                                               " +
						", DECODE(INNAK_STATUS,'S','S',NULL) INNAK_STATUS, DECODE(DINAK_STATUS,'S','S',NULL) DINAK_STATUS, DECODE(AFISH_STATUS,'S','S',NULL) AFISH_STATUS    " +
						", HEADER_HB, FOOTER_HB, PICASA_YN                                                                                                                   " +
						"FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                                              " +
						"WHERE GALR_ID= 'G0010310EC'                                                                                                                         " +
						"AND A.SHIP_ID = U.SHIP_ID                                                                                                                           " +
						"AND A.SHIP_ID = H.SHIP_ID(+)                                                                                            " +
						"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                                       " +
						"AND AFISH_BBS_CD IS NOT NULL                                          " +
						"AND A.SHIP_ID = U.SHIP_ID                                                                                                                           " +
						"AND A.PORT_CD =  B.PORT_CD (+)                                                                                                                      " +
						"AND A.SHIP_ID = C.SHIP_ID (+)                                                                                                                       " +
						"AND ROWNUM = 1                                                                                                                                      " +
						"ORDER BY A.GALR_ID                                                                                                                                  " ;

		Connection conn = getConnection();
		PreparedStatement psmt;

		psmt = conn.prepareStatement(sql1);

		System.out.println(sql1);

		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<GalBean>();

			while(rs.next())
			{
				GalBean bean = new GalBean();
				bean.SHIP_ID = rs.getString("SHIP_ID");
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.SHIP_NAME = rs.getString("SHIP_NAME");
				bean.SUNDAN_NAME = rs.getString("SUNDAN_NAME");
				bean.CPTN_NAME = rs.getString("CPTN_NAME");
				bean.CPTN_TITLE = rs.getString("CPTN_TITLE");
				bean.PORT_NAME = rs.getString("PORT_NAME");
				bean.FISH_DATE = rs.getString("FISH_DATE");
				bean.TITLE = rs.getString("TITLE");
				bean.LOC_DESC = rs.getString("LOC_DESC");
				bean.HEADER_TEXT = rs.getString("HEADER_TEXT"); //조행기 헤더
				bean.FOOTER_TEXT = rs.getString("FOOTER_TEXT"); //조행기 푸터
				bean.INNAK_AREA_CD = rs.getString("INNAK_AREA_CD");
				bean.PSGR = rs.getString("PSGR_CNT");
				bean.AREA_DESC = rs.getString("AREA_DESC");
				bean.SITE = rs.getString("SITE");
				bean.SITE_URL = rs.getString("SITE_URL");
				bean.CPTN_IMG_ID = rs.getString("CPTN_IMG_ID");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");

				bean.SUMMARY = rs.getString("SUMMARY"); //조황요약
				bean.HEADER_HB = rs.getString("HEADER_HB"); //홍보내용 헤더
				bean.FOOTER_HB = rs.getString("FOOTER_HB"); //홍보내용 푸터
//				bean.PICASA_YN = rs.getString("PICASA_YN"); //홍보내용에 포함된 이미지가 피카사에 업로드되었는지 여부

//				bean.DINAK_STATUS = rs.getString("DINAK_STATUS");
				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");
//				bean.INNAK_ID = rs.getString("INNAK_ID");
//				bean.INNAK_PWD = rs.getString("INNAK_PWD");
//				bean.INNAK_YN = rs.getString("INNAK_YN");
//				bean.INNAK_STATUS = rs.getString("INNAK_STATUS");
//				bean.INNAK_BBS_CD = rs.getString("INNAK_BBS_CD");
//
//				bean.DINAK_ID = rs.getString("DINAK_ID");
//				bean.DINAK_PWD = rs.getString("DINAK_PWD");
//				bean.DINAK_YN = rs.getString("DINAK_YN");
//				bean.DINAK_P1 = rs.getString("DINAK_P1");
//				bean.DINAK_P2 = rs.getString("DINAK_P2");
//				bean.DINAK_STATUS = rs.getString("DINAK_STATUS");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");

				bean.AFISH_ID = rs.getString("AFISH_ID");
				bean.AFISH_PWD = rs.getString("AFISH_PWD");
				bean.AFISH_YN= rs.getString("AFISH_YN");
				bean.AFISH_STATUS= rs.getString("AFISH_STATUS");
				bean.AFISH_P1= rs.getString("AFISH_BBS_CD"); //게시판코드

				bean.SHIP_AUTOPOST_NEW = rs.getString("SHIP_AUTOPOST_NEW");
				bean.SUNDAN_AUTOPOST_NEW = rs.getString("SUNDAN_AUTOPOST_NEW");
				bean.FISH_NAME = rs.getString("FISH_NAME");
				bean.SUNDAN_ID = rs.getString("SUNDAN_ID");
				bean.DATE_DY = rs.getString("DATE_DY");
				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");

				lst.add(bean);
			}

		}
		catch(Exception e) {

			e.printStackTrace();

		}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}

	public List<GalBean> getDinakListRenew() throws Exception
	{
		List<GalBean> lst = null;

		//어부지리는 한글도메인안됨. 한글도메인이면 **.ho 또는 **.sd로 안내
		String sql1 =
				"SELECT A.SHIP_ID                                                                                                                   " +
				", A.SUNDAN_ID                                                                                                                      " +
				", A.GALR_ID                                                                                                                        " +
				", A.SHIP_NAME                                                                                                                      " +
				", S.SUNDAN_NAME                                                                                                                    " +
				", A.PORT_NAME                                                                                                                      " +
				", A.FISH_DATE                                                                                                                      " +
				", A.TITLE                                                                                                             " +
				", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
				", A.LOC_DESC                                                                                                          " +
				", A.FISH_NAME                                                                                                          " +
				", A.GPS_LAT                                                                                                           " +
				", A.GPS_LONG                                                                                                          " +
				", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
				", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                                           " +
				", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                                          " +
				", A.PEOPLE_ONBOARD                                                                                                                 " +
				", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                                           " +
				", C.PSGR_CNT                                                                                                                       " +
				", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME                                                    " +
				", NVL(CPTN_TITLE,'선장')  CPTN_TITLE                                                                                                " +
				//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
                //", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
            	" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
				" ( select IMGHOST_URL from t_upload_file where file_id = "+
                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
                ", NVL(AREA_DESC, ' ') AREA_DESC                                                                                                    " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                               " +
				"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE                      " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           DECODE(LENGTHB(SUBSTR(C.DOM_ADDR,1,1)), 1, C.DOM_ADDR, 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho')  ,             " +
				"           DECODE(LENGTHB(SUBSTR(S.DOM_ADDR,1,1)), 1, S.DOM_ADDR, 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE_URL " +
				", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2   , DFISH_BBS_CD                                                 " +
				", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD, DINAK_STATUS                                                " +
				", HEADER_HB, FOOTER_HB, PICASA_YN                                                                                                  " +
				"FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                             " +
				"WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - 3 ,'YYYYMMDD')                                                " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                                          " +
				"AND A.SHIP_ID = H.SHIP_ID(+) AND A.TYPE_CD = '106_110'                                                                                                       " +
				"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                            " +
				"AND (U.DINAK_YN = 'Y' AND U.DINAK_ID  IS NOT NULL AND (DINAK_STATUS IS NULL OR DINAK_STATUS = 'N'))                                " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                                          " +
				"AND A.PORT_CD =  B.PORT_CD (+)                                                                                                     " +
				"AND A.SHIP_ID = C.SHIP_ID (+)                                                                                                      " +
				"AND ROWNUM = 1                                                                                                                     " +
				"ORDER BY A.GALR_ID ";

		Connection conn = getConnection();
		PreparedStatement psmt;

		psmt = conn.prepareStatement(sql1);


		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<GalBean>();

			while(rs.next())
			{
				GalBean bean = new GalBean();
				bean.SHIP_ID = rs.getString("SHIP_ID");
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.SHIP_NAME = rs.getString("SHIP_NAME");
				bean.SUNDAN_NAME = rs.getString("SUNDAN_NAME");
				bean.CPTN_NAME = rs.getString("CPTN_NAME");
				bean.CPTN_TITLE = rs.getString("CPTN_TITLE");
				bean.PORT_NAME = rs.getString("PORT_NAME");
				bean.FISH_DATE = rs.getString("FISH_DATE");
				bean.TITLE = rs.getString("TITLE");
				bean.LOC_DESC = rs.getString("LOC_DESC");
				bean.HEADER_TEXT = rs.getString("HEADER_TEXT"); //조행기 헤더
				bean.FOOTER_TEXT = rs.getString("FOOTER_TEXT"); //조행기 푸터
				bean.INNAK_AREA_CD = rs.getString("INNAK_AREA_CD");
				bean.PSGR = rs.getString("PSGR_CNT");
				bean.AREA_DESC = rs.getString("AREA_DESC");
				bean.SITE = rs.getString("SITE");
				bean.SITE_URL = rs.getString("SITE_URL");
				bean.CPTN_IMG_ID = rs.getString("CPTN_IMG_ID");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");
				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");

				bean.SUMMARY = rs.getString("SUMMARY"); //조황요약
				bean.HEADER_HB = rs.getString("HEADER_HB"); //홍보내용 헤더
				bean.FOOTER_HB = rs.getString("FOOTER_HB"); //홍보내용 푸터

				bean.SHIP_AUTOPOST_NEW = rs.getString("SHIP_AUTOPOST_NEW");
				bean.SUNDAN_AUTOPOST_NEW = rs.getString("SUNDAN_AUTOPOST_NEW");

				bean.FISH_NAME = rs.getString("FISH_NAME");
				bean.SUNDAN_ID = rs.getString("SUNDAN_ID");
				bean.DATE_DY = rs.getString("DATE_DY");

				bean.INNAK_BBS_CD = rs.getString("INNAK_BBS_CD");
//
				bean.DINAK_ID = rs.getString("DINAK_ID");
				bean.DINAK_PWD = rs.getString("DINAK_PWD");
				bean.DINAK_YN = rs.getString("DINAK_YN");
				bean.DINAK_P1 = rs.getString("DINAK_P1");
				bean.DINAK_P2 = rs.getString("DINAK_P2");
				bean.DINAK_STATUS = rs.getString("DINAK_STATUS");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");
				bean.DFISH_BBS_CD = rs.getString("DFISH_BBS_CD");

				bean.AFISH_ID = rs.getString("AFISH_ID");
				bean.AFISH_PWD = rs.getString("AFISH_PWD");
				bean.AFISH_YN= rs.getString("AFISH_YN");
//				bean.AFISH_STATUS= rs.getString("AFISH_STATUS");
				bean.AFISH_P1= rs.getString("AFISH_BBS_CD"); //게시판코드
//
//				bean.YBADA_ID = rs.getString("YBADA_ID");
//				bean.YBADA_PWD = rs.getString("YBADA_PWD");
//				bean.YBADA_YN = rs.getString("YBADA_YN");

				lst.add(bean);
			}

		}
		catch(Exception e) {

			e.printStackTrace();

		}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}


	public List<GalBean> getDinakList() throws Exception
	{
		List<GalBean> lst = null;

		//어부지리는 한글도메인안됨. 한글도메인이면 **.ho 또는 **.sd로 안내
		String sql1 =
				"SELECT TTA.* FROM ( SELECT A.SHIP_ID " +
				", A.SUNDAN_ID                                                                                                                      " +
				", A.GALR_ID                                                                                                                        " +
				", A.SHIP_NAME                                                                                                                      " +
				", S.SUNDAN_NAME                                                                                                                    " +
				",  (select count(*)  from t_fish_galr where dinak_status = 'S' and ship_id = A.SHIP_ID and TO_CHAR(DINAK_TIME ,'yyyymmdd hh24:mi:ss')  between "+
				"  to_char(sysdate - 1,'yyyymmdd hh24:mi:ss')  and to_char(sysdate,'yyyymmdd hh24:mi:ss') )  as DINAK_CNT   " +
				", A.PORT_NAME                                                                                                                      " +
				", A.FISH_DATE                                                                                                                      " +
				", A.TITLE                                                                                                             " +
				", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
				", A.LOC_DESC                                                                                                          " +
				", A.FISH_NAME                                                                                                          " +
				", A.GPS_LAT                                                                                                           " +
				", A.GPS_LONG                                                                                                          " +
				", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
				", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                    "+
				", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                                          " +
				", A.PEOPLE_ONBOARD                                                                                                                 " +
				", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                                           " +
				", C.PSGR_CNT                                                                                                                       " +
				", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME                                                    " +
				", NVL(CPTN_TITLE,'선장')  CPTN_TITLE                                                                                                " +
				//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
                //", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
            	" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
				" ( select IMGHOST_URL from t_upload_file where file_id = "+
                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
				", NVL(AREA_DESC, ' ') AREA_DESC                                                                                                    " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                               " +
				"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE                      " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                                        " +
				"           DECODE(LENGTHB(SUBSTR(C.DOM_ADDR,1,1)), 1, C.DOM_ADDR, 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho')  ,             " +
				"           DECODE(LENGTHB(SUBSTR(S.DOM_ADDR,1,1)), 1, S.DOM_ADDR, 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE_URL " +
				", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2 , DFISH_BBS_CD                                                 " +
				", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD, DINAK_STATUS                                                " +
				", HEADER_HB, FOOTER_HB, PICASA_YN                                                                                                  " +
				" FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                             " +
				"WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - 3 ,'YYYYMMDD')                                                " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                                          " +
				"AND A.SHIP_ID = H.SHIP_ID(+) AND A.TYPE_CD = '106_110'                                                                                                  " +
				"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                            " +
				"AND (U.DINAK_YN = 'Y' AND U.DINAK_ID  IS NOT NULL AND (DFISH_BBS_CD != 'N' or DFISH_BBS_CD IS NULL) AND (DINAK_STATUS IS NULL OR DINAK_STATUS = 'W'))                                " +
				"AND A.SHIP_ID = U.SHIP_ID                                                                                                          " +
				"AND A.PORT_CD =  B.PORT_CD (+)                                                                                                     " +
				"AND A.SHIP_ID = C.SHIP_ID (+)   "+
				                                                                                                                   
				"ORDER BY A.GALR_ID DESC " +
				                   " ) TTA WHERE DINAK_CNT < 4 AND ROWNUM = 1";                                                                                                 
        

		                                                                                                                          

		Connection conn = getConnection();
		PreparedStatement psmt;

		psmt = conn.prepareStatement(sql1);

		System.out.println(sql1);

		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<GalBean>();

			while(rs.next())
			{
				GalBean bean = new GalBean();
				bean.SHIP_ID = rs.getString("SHIP_ID");
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.SHIP_NAME = rs.getString("SHIP_NAME");
				bean.SUNDAN_NAME = rs.getString("SUNDAN_NAME");
				bean.CPTN_NAME = rs.getString("CPTN_NAME");
				bean.CPTN_TITLE = rs.getString("CPTN_TITLE");
				bean.PORT_NAME = rs.getString("PORT_NAME");
				bean.FISH_DATE = rs.getString("FISH_DATE");
				bean.TITLE = rs.getString("TITLE");
				bean.LOC_DESC = rs.getString("LOC_DESC");
				bean.HEADER_TEXT = rs.getString("HEADER_TEXT"); //조행기 헤더
				bean.FOOTER_TEXT = rs.getString("FOOTER_TEXT"); //조행기 푸터
				bean.INNAK_AREA_CD = rs.getString("INNAK_AREA_CD");
				bean.PSGR = rs.getString("PSGR_CNT");
				bean.AREA_DESC = rs.getString("AREA_DESC");
				bean.SITE = rs.getString("SITE");
				bean.SITE_URL = rs.getString("SITE_URL");
				bean.CPTN_IMG_ID = rs.getString("CPTN_IMG_ID");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");

				bean.SUMMARY = rs.getString("SUMMARY"); //조황요약
				bean.HEADER_HB = rs.getString("HEADER_HB"); //홍보내용 헤더
				bean.FOOTER_HB = rs.getString("FOOTER_HB"); //홍보내용 푸터
//				bean.PICASA_YN = rs.getString("PICASA_YN"); //홍보내용에 포함된 이미지가 피카사에 업로드되었는지 여부

//				bean.DINAK_STATUS = rs.getString("DINAK_STATUS");
				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");
//				bean.INNAK_ID = rs.getString("INNAK_ID");
//				bean.INNAK_PWD = rs.getString("INNAK_PWD");
//				bean.INNAK_YN = rs.getString("INNAK_YN");
//				bean.INNAK_STATUS = rs.getString("INNAK_STATUS");
				bean.INNAK_BBS_CD = rs.getString("INNAK_BBS_CD");
//
				bean.DINAK_ID = rs.getString("DINAK_ID");
				bean.DINAK_PWD = rs.getString("DINAK_PWD");
				bean.DINAK_YN = rs.getString("DINAK_YN");
				bean.DINAK_P1 = rs.getString("DINAK_P1");
				bean.DINAK_P2 = rs.getString("DINAK_P2");
				bean.DINAK_STATUS = rs.getString("DINAK_STATUS");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");
				bean.DFISH_BBS_CD = rs.getString("DFISH_BBS_CD");

				bean.AFISH_ID = rs.getString("AFISH_ID");
				bean.AFISH_PWD = rs.getString("AFISH_PWD");
				bean.AFISH_YN= rs.getString("AFISH_YN");
//				bean.AFISH_STATUS= rs.getString("AFISH_STATUS");
				bean.AFISH_P1= rs.getString("AFISH_BBS_CD"); //게시판코드
//
//				bean.YBADA_ID = rs.getString("YBADA_ID");
//				bean.YBADA_PWD = rs.getString("YBADA_PWD");
//				bean.YBADA_YN = rs.getString("YBADA_YN");

				bean.SHIP_AUTOPOST_NEW = rs.getString("SHIP_AUTOPOST_NEW");
				bean.SUNDAN_AUTOPOST_NEW = rs.getString("SUNDAN_AUTOPOST_NEW");
				bean.FISH_NAME = rs.getString("FISH_NAME");
				bean.SUNDAN_ID = rs.getString("SUNDAN_ID");
				bean.DATE_DY = rs.getString("DATE_DY");

				lst.add(bean);
			}

		}
		catch(Exception e) {

			e.printStackTrace();

		}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}

	public List<ImageBean> getFishImageList(String galId) throws Exception
	{
		List<ImageBean> lst = null;

		String sql =
				"SELECT                                                                                                                  " +
				"           A.GALR_ID                                                                                                    " +
				"         , A.IMG_ID                                                                                                     " +
				"         , A.CONTENT                                                                                                    " +
				"         , A.SEQ                                                                                                        " +
				"         , A.MOVIE_YN                                                                                                   " +
				"         , 'https://img.fishapp.co.kr/img/' || TO_CHAR(A.CREATED_AT,'YYYY/MM/DD/') || IMG_ID || '.jpg'   AS HOSTING_URL " +
				"FROM T_FISH_GALLERY_IMG A                                                                                               " +
				"WHERE A.GALR_ID = ?                                                                                          " +
				"ORDER BY A.GALR_ID, A.SEQ ASC                                                                                           " ;
		
		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, galId);

		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<ImageBean>();

			while(rs.next())
			{
				ImageBean bean = new ImageBean();
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.IMG_ID = rs.getString("IMG_ID");
				bean.CONTENT = rs.getString("CONTENT");
				bean.SEQ = rs.getString("SEQ");
				bean.MOVIE_YN = rs.getString("MOVIE_YN");
				bean.HOSTING_URL = rs.getString("HOSTING_URL");

				lst.add(bean);
			}
		}
		catch(Exception e) {}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}

	public int updateHostingLink(String hostingUrl, String imageId) throws Exception
	{
		List<HashMap<String,String>> lst = null;

		String sql = "UPDATE T_FISH_GALLERY_IMG SET  HOSTING_URL = ? WHERE IMG_ID = ?";

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, hostingUrl);
		psmt.setString(2, imageId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}

		return cnt;
	}

	public int updateHongbo(String shipId, String header, String footer) throws Exception
	{
		List<HashMap<String,String>> lst = null;

		String sql = "UPDATE T_FISH_HONGBO SET  HEADER_HB = ?, FOOTER_HB = ?,PICASA_YN = 'Y' WHERE SHIP_ID = ?";

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, header);
		psmt.setString(2, footer);
		psmt.setString(3, shipId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}

		return cnt;
	}

	public int updateInnakStatus(String galId, String statusCd) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "INNAK:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET INNAK_STATUS = ?, INNAK_TIME = SYSDATE WHERE GALR_ID = ?";
		return updateStatus(galId, statusCd, sql);
	}
	
	public int updateInnakStatus2(String galId, String statusCd) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "INNAK2:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET INNAK_STATUS_2 = ?, INNAK_TIME_2 = SYSDATE WHERE GALR_ID = ?";
		return updateStatus(galId, statusCd, sql);
	}
	
	public int updateInnakStatusWithError1(String galId, String statusCd, String errorMessage) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "INNAK:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET INNAK_STATUS = ?, INNAK_TIME = SYSDATE, INNAK_ERROR_1 = ? WHERE GALR_ID = ?";
		return updateStatusWithError(galId, statusCd, errorMessage, sql);
	}
	
	public int updateInnakStatusWithError2(String galId, String statusCd, String errorMessage) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "INNAK2:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET INNAK_STATUS_2 = ?, INNAK_TIME_2 = SYSDATE, INNAK_ERROR_2 = ?  WHERE GALR_ID = ?";
		return updateStatusWithError(galId, statusCd, errorMessage, sql);
	}
	
	private int updateStatusWithError(String galId, String statusCd, String errorMessage, String sql)  throws Exception
	{
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, statusCd);
		psmt.setString(2, errorMessage);
		psmt.setString(3, galId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
		return cnt;
	}

	public int updateDinakStatus(String galId, String statusCd) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "DINAK:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET DINAK_STATUS = ?, DINAK_TIME = SYSDATE WHERE GALR_ID = ?";
		return updateStatus(galId, statusCd, sql);
	}
	

	public int updateAfishStatus(String galId, String statusCd) throws Exception
	{
		System.out.println("uploadStatus :" + galId +  "AFISH:" + statusCd);

		String sql = "UPDATE T_FISH_GALR SET AFISH_STATUS = ?, AFISH_TIME = SYSDATE WHERE GALR_ID = ?";
		return updateStatus(galId, statusCd, sql);
	}

	private int updateStatus(String galId, String statusCd, String sql)  throws Exception
	{
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, statusCd);
		psmt.setString(2, galId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
		return cnt;
	}



	public int insertLog(Date startTime, Date endTime, int contents, int photos, int succ_photos, int innak_post, int dinak_post, int afish_post,String innak_yn, String dinnak_yn, double photoUploadTime) throws Exception
	{

		// 사진업로드수, 조황게시물수 모두 0이면 로그기록 안함
		if (photos == 0 && contents == 0)
		{
			return 0;
		}

		String sql =
				"INSERT INTO T_AUTOPOST_LOG " +
						"    (                       " +
						"        START_DATE,         " +
						"        END_DATE,           " +
						"        CONTENTS,           " +
						"        PHOTOS,             " +
						"        SUCC_PHOTOS,        " +
						"        SUCC_INNAK,         " +
						"        SUCC_DINAK,         " +
						"        SUCC_AFISH,         " +
						"        PHTO_UPLOAD_TIME   " +
						"    )                       " +
						"    VALUES                  " +
						"    (                       " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ?,                  " +
						"        ? ) " ;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setTimestamp(1, new java.sql.Timestamp(startTime.getTime()));
		psmt.setTimestamp(2, new java.sql.Timestamp(endTime.getTime()));
		psmt.setInt(3, contents);
		psmt.setInt(4, photos);
		psmt.setInt(5, succ_photos);
		psmt.setInt(6, innak_post);
		psmt.setInt(7, dinak_post);
		psmt.setInt(8, afish_post);
		psmt.setDouble(9, photoUploadTime);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {

			e.printStackTrace();
		}
		finally
		{
			psmt.close();
			psmt = null;
		}
		return cnt;
	}

	private List<HashMap<String,String>> rsToMap(ResultSet rs) throws Exception
	{
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		List<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();

	    while (rs.next()) {
	        HashMap<String,String> row = new HashMap<String, String>(columns);
	        for(int i=1; i<=columns; ++i) {
	            row.put(md.getColumnName(i),rs.getString(i));
	        }
	        list.add(row);
	    }

	    return list;
	}


	public Map getShipInfo(GalBean galItem) throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT TS.SHIP_ID, TS.BIZ_ID, TS.SHIP_NAME, TS.PSGR_CNT, TS.AREA_DESC, TS.NAVIGATION, TB.SHOP_NM , "
				+ "(SELECT VALUE FROM T_CODE WHERE CODE = TB.BANK_CD) AS BANK_CD_NAME, "
				+" TB.BANK_CD, TB.BANK_ACCN, TB.BANK_HOLDER, TB.SHOP_TEL,  TS.BOAT_PLACE, TS.SUB_SHIP_NM, "
				 + " ( SELECT TEL FROM T_MEMBER WHERE MEM_ID = TB.MGR_MEM_ID) AS CPTN_TEL "
				+ " FROM T_SHIP TS , T_BIZ TB "
				 + " WHERE TS.BIZ_ID = TB.BIZ_ID AND TS.SHIP_ID = ? ";

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, galItem.SHIP_ID);

		Map map = new HashMap<String,String>();
		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();

			while(rs.next())
			{
				map.put("SHIP_ID", rs.getString("SHIP_ID"));
				map.put("BIZ_ID", rs.getString("BIZ_ID"));
				map.put("SHIP_NAME", rs.getString("SHIP_NAME"));
				map.put("PSGR_CNT", rs.getString("PSGR_CNT"));
				map.put("AREA_DESC", rs.getString("AREA_DESC"));
				map.put("NAVIGATION", rs.getString("NAVIGATION"));
				map.put("SUB_SHIP_NM", rs.getString("SUB_SHIP_NM"));
				map.put("SHOP_NM", rs.getString("SHOP_NM"));
				map.put("BANK_CD", rs.getString("BANK_CD_NAME"));
				map.put("BANK_ACCN", rs.getString("BANK_ACCN"));
				map.put("BANK_HOLDER", rs.getString("BANK_HOLDER"));
				map.put("SHOP_TEL", rs.getString("SHOP_TEL"));
				map.put("BOAT_PLACE", rs.getString("BOAT_PLACE"));
				map.put("CPTN_TEL", rs.getString("CPTN_TEL"));
			}
		}
		catch(Exception e) {}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return map;
	}

	public Map<String, String> getSundanInfo(GalBean galItem) throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT TS.SUNDAN_ID, TS.BIZ_ID, TS.SUNDAN_NAME,TS.ADDR, TS.NAVIGATION, TB.SHOP_NM , TB.SHOP_IMG_ID, TS.SUB_SUNDAN_NM, "
				 + " (SELECT VALUE FROM T_CODE WHERE CODE = TB.BANK_CD) AS BANK_CD_NAME "
				+ ", TB.BANK_ACCN, TB.BANK_HOLDER, TB.SHOP_TEL "
				 + " FROM T_SUNDAN TS , T_BIZ TB "
				+ " WHERE TS.BIZ_ID = TB.BIZ_ID AND TS.SUNDAN_ID = ?";

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, galItem.SUNDAN_ID);

		Map map = new HashMap<String,String>();
		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();

			while(rs.next())
			{
				map.put("SUNDAN_ID", rs.getString("SUNDAN_ID"));
				map.put("BIZ_ID", rs.getString("BIZ_ID"));
				map.put("SUNDAN_NAME", rs.getString("SUNDAN_NAME"));
				map.put("ADDR", rs.getString("ADDR"));
				map.put("NAVIGATION", rs.getString("NAVIGATION"));
				map.put("SHOP_NM", rs.getString("SHOP_NM"));
				map.put("SHOP_IMG_ID", rs.getString("SHOP_IMG_ID"));
				map.put("BANK_CD", rs.getString("BANK_CD_NAME"));
				map.put("BANK_ACCN", rs.getString("BANK_ACCN"));
				map.put("BANK_HOLDER", rs.getString("BANK_HOLDER"));
				map.put("SHOP_TEL", rs.getString("SHOP_TEL"));
				map.put("SUB_SUNDAN_NM",  rs.getString("SUB_SUNDAN_NM"));
			}
		}
		catch(Exception e) {}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return map;
	}

	public List<GalBean> getInnakFishGalleryList() throws Exception
	{
		List<GalBean> lst = null;

		String sql1 =
				"SELECT * FROM ( 																										" +
				"SELECT A.SHIP_ID                                                                                                      " +
				", A.SUNDAN_ID                                                                                                         " +
				", A.GALR_ID                                                                                                           " +
				", A.SHIP_NAME                                                                                                         " +
				", S.SUNDAN_NAME                                                                                                       " +
				", A.PORT_NAME                                                                                                         " +
				", A.FISH_DATE                                                                                                         " +
				", A.TITLE                                                                                                             " +
				", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
				", A.LOC_DESC                                                                                                          " +
				", A.FISH_NAME                                                                                                          " +
				", A.GPS_LAT                                                                                                           " +
				", A.GPS_LONG                                                                                                          " +
				", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
				", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                        " +
				", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                " +
				", A.PEOPLE_ONBOARD                                                                                                    " +
				", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                              " +
				", B.NEW_INNAK_AREA_CD                                                                              " +
				", C.PSGR_CNT                                                                                                          " +
				", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME" +
				", NVL(CPTN_TITLE,'선장')  CPTN_TITLE       " +
				//", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
                //", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
            	" , ( select IMGHOST_URL from t_upload_file where file_id =  "+ 
                " (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID)) AS CPTN_IMG_ID , " +
				" ( select IMGHOST_URL from t_upload_file where file_id = "+
                " (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID))  AS MAIN_IMG_ID" +     
				", NVL(AREA_DESC, ' ') AREA_DESC                                                                                       " +
				", DECODE(A.SUNDAN_ID, NULL,                                                                                           " +
				"           NVL(REPLACE(C.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                  " +
				"           NVL(REPLACE(S.DOM_ADDR,'https://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE         " +
				", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2                                    " +
				", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD  "
				+ ", INNAK_BBS_CD_2   , INNAK_STATUS_2                                               " +
				", DECODE(DINAK_STATUS,'S','S',NULL) DINAK_STATUS, DECODE(AFISH_STATUS,'S','S',NULL) AFISH_STATUS  " +
				", HEADER_HB, FOOTER_HB, PICASA_YN, INNAK_STATUS   , INNAK_TRY_CNT_1, INNAK_TRY_CNT_2                                                                    " +
				", A.CREATED_AT " +
				"FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                " +
				"WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - 3, 'YYYYMMDD')       "+
				" AND (TO_DATE(TO_CHAR(A.CREATED_AT,'YYYYMMDD'),'YYYYMMDD') - TO_DATE(FISH_DATE,'YYYYMMDD')) < 2 "     +                                     
				"AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
				"AND A.SHIP_ID = H.SHIP_ID(+) AND A.TYPE_CD = '106_110'                                                                                          " +
				"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                                      " +
				"AND U.INNAK_YN = 'Y' AND U.INNAK_ID IS NOT NULL AND INNAK_BBS_CD != 'N' AND" +
				" (      ( (INNAK_STATUS IS NULL OR INNAK_STATUS = 'W') AND INNAK_TRY_CNT_1 < 2) OR "+
				"		           (  ( INNAK_STATUS_2 IS NULL OR INNAK_STATUS_2 = 'W') AND (INNAK_BBS_CD_2 IS NOT NULL AND INNAK_BBS_CD_2 != 'N') AND INNAK_TRY_CNT_2 < 2))      " +
				"  AND A.PORT_CD =  B.PORT_CD (+)    "+         
				"AND A.SHIP_ID = U.SHIP_ID                                                           " +
				"AND A.PORT_CD =  B.PORT_CD (+)                                                                                        " +
				"AND A.SHIP_ID = C.SHIP_ID (+)       " +
				"ORDER BY  CASE WHEN SHIP_ID = 'H0000945P3' OR SHIP_ID = 'H0001747WL' OR SHIP_ID = 'H0001650D7' THEN 0   END,FISH_DATE DESC, A.CREATED_AT ASC                                                                                           " +
				") Z WHERE ROWNUM = 1";

		// 조황아이디를 지정하는 쿼리(주의: 잘못하면 같은 조황이 여러번 계속 올라갈수 있음. 주의!주의!주의!)
//
//		"SELECT * FROM ( 																										" +
//		"SELECT A.SHIP_ID                                                                                                      " +
//		", A.SUNDAN_ID                                                                                                         " +
//		", A.GALR_ID                                                                                                           " +
//		", A.SHIP_NAME                                                                                                         " +
//		", S.SUNDAN_NAME                                                                                                       " +
//		", A.PORT_NAME                                                                                                         " +
//		", A.FISH_DATE                                                                                                         " +
//		", A.TITLE                                                                                                             " +
//		", (SELECT TO_CHAR(TO_DATE(A.FISH_DATE , 'YYYYMMDD'), 'd') from dual) as DATE_DY                                     " +
//		", A.LOC_DESC                                                                                                          " +
//		", A.FISH_NAME                                                                                                          " +
//		", A.GPS_LAT                                                                                                           " +
//		", A.GPS_LONG                                                                                                          " +
//		", C.AUTOPOST_NEW AS SHIP_AUTOPOST_NEW                                                                                                        " +
//		", S.AUTOPOST_NEW AS SUNDAN_AUTOPOST_NEW                                                                                                        " +
//		", A.HEADER_TEXT, A.FOOTER_TEXT, A.SUMMARY                                                                " +
//		", A.PEOPLE_ONBOARD                                                                                                    " +
//		", NVL(INNAK_AREA_CD, '27') INNAK_AREA_CD                                                                              " +
//		", B.NEW_INNAK_AREA_CD                                                                              " +
//		", C.PSGR_CNT                                                                                                          " +
//		", NVL((SELECT MEM_NAME FROM T_MEMBER WHERE MEM_ID = CPTN_MEM_ID),' ') CPTN_NAME" +
//		", NVL(CPTN_TITLE,'선장')  CPTN_TITLE       " +
//		", (SELECT CPTN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS CPTN_IMG_ID "+
//        ", (SELECT MAIN_IMG_ID FROM T_SHIP TS WHERE TS.SHIP_ID = A.SHIP_ID) AS MAIN_IMG_ID "+
//		", NVL(AREA_DESC, ' ') AREA_DESC                                                                                       " +
//		", DECODE(A.SUNDAN_ID, NULL,                                                                                           " +
//		"           NVL(REPLACE(C.DOM_ADDR,'http://',''), 'www.fishapp.co.kr/' || C.REDIRECT_NAME || '.ho') ,                  " +
//		"           NVL(REPLACE(S.DOM_ADDR,'http://',''), 'www.fishapp.co.kr/' || S.REDIRECT_NAME || '.sd'))   AS SITE         " +
//		", INNAK_ID, INNAK_PWD, DINAK_ID, DINAK_PWD, INNAK_YN, DINAK_YN, DINAK_P1,DINAK_P2                                    " +
//		", AFISH_ID, AFISH_PWD, AFISH_YN, AFISH_P1, AFISH_BBS_CD, INNAK_BBS_CD                                                        " +
//		", DECODE(INNAK_STATUS,'S','S',NULL) INNAK_STATUS, DECODE(DINAK_STATUS,'S','S',NULL) DINAK_STATUS, DECODE(AFISH_STATUS,'S','S',NULL) AFISH_STATUS  " +
//		", HEADER_HB, FOOTER_HB, PICASA_YN                                                                        " +
//		"FROM T_FISH_GALR A, T_PORT B, T_SHIP C, T_AUTOPOST_USER U, T_FISH_HONGBO H, T_SUNDAN S                                " +
//		"WHERE A.FISH_DATE >= TO_CHAR(SYSDATE - ? ,'YYYYMMDD')                                                         " +
//		"AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
//		"AND A.SHIP_ID = H.SHIP_ID(+) AND A.TYPE_CD = '106_110'                                                                                          " +
//		"AND A.SUNDAN_ID = S.SUNDAN_ID(+)                                                                                      " +
//		"AND ( " +
//		"	(U.INNAK_YN = 'Y' AND U.INNAK_ID IS NOT NULL AND (INNAK_STATUS IS NULL OR INNAK_STATUS = 'F'))      " +
//		"          OR  (U.DINAK_YN = 'Y' AND U.DINAK_ID  IS NOT NULL AND (DINAK_STATUS IS NULL OR DINAK_STATUS = 'F'))  " +
//		" )  " +
//		"AND A.SHIP_ID = U.SHIP_ID                                                                                             " +
//		"AND A.PORT_CD =  B.PORT_CD (+)                                                                                        " +
//		"AND A.SHIP_ID = C.SHIP_ID (+)                                                                                            " +
//		"AND A.GALR_ID = '조황 ID'                                                                                            " +
//		"ORDER BY A.CREATED_AT DESC                                                                                               " +
//		") Z WHERE ROWNUM = 1";administrator

		Connection conn = getConnection();
		PreparedStatement psmt;

		psmt = conn.prepareStatement(sql1);
		//psmt.setString(1, "0");		// 오늘 동록한 조황만 처리
		
		System.out.println(sql1);

		ResultSet rs = null;
		try
		{
			rs = psmt.executeQuery();
			lst = new ArrayList<GalBean>();

			while(rs.next())
			{
				GalBean bean = new GalBean();
				bean.SHIP_ID = rs.getString("SHIP_ID");
				bean.GALR_ID = rs.getString("GALR_ID");
				bean.SHIP_NAME = rs.getString("SHIP_NAME");
				bean.SUNDAN_NAME = rs.getString("SUNDAN_NAME");
				bean.CPTN_NAME = rs.getString("CPTN_NAME");
				bean.CPTN_TITLE = rs.getString("CPTN_TITLE");
				bean.PORT_NAME = rs.getString("PORT_NAME");
				bean.FISH_DATE = rs.getString("FISH_DATE");
				bean.TITLE = rs.getString("TITLE");
				bean.LOC_DESC = rs.getString("LOC_DESC");
				bean.GPS_LAT = rs.getString("GPS_LAT");
				bean.GPS_LONG = rs.getString("GPS_LONG");
				bean.HEADER_TEXT = rs.getString("HEADER_TEXT"); //조행기 헤더
				bean.FOOTER_TEXT = rs.getString("FOOTER_TEXT"); //조행기 푸터
				bean.INNAK_AREA_CD = rs.getString("INNAK_AREA_CD");
				bean.NEW_INNAK_AREA_CD = rs.getString("NEW_INNAK_AREA_CD"); //변경된 인낚 AREA_CD
				bean.PSGR = rs.getString("PSGR_CNT");
				bean.AREA_DESC = rs.getString("AREA_DESC");
				bean.SITE = rs.getString("SITE");
				bean.CPTN_IMG_ID = rs.getString("CPTN_IMG_ID");
				bean.SHIP_IMG_ID = rs.getString("MAIN_IMG_ID");
				bean.FISH_NAME = rs.getString("FISH_NAME");
				bean.SUNDAN_ID = rs.getString("SUNDAN_ID");
				bean.DATE_DY = rs.getString("DATE_DY");

				bean.SHIP_AUTOPOST_NEW = rs.getString("SHIP_AUTOPOST_NEW");
				bean.SUNDAN_AUTOPOST_NEW = rs.getString("SUNDAN_AUTOPOST_NEW");

				bean.SUMMARY = rs.getString("SUMMARY"); //조황요약
				bean.HEADER_HB = rs.getString("HEADER_HB"); //홍보내용 헤더
				bean.FOOTER_HB = rs.getString("FOOTER_HB"); //홍보내용 푸터
				bean.PICASA_YN = rs.getString("PICASA_YN"); //홍보내용에 포함된 이미지가 피카사에 업로드되었는지 여부

				bean.PEOPLE_ONBOARD = rs.getString("PEOPLE_ONBOARD");

				bean.INNAK_ID = rs.getString("INNAK_ID");
				bean.INNAK_PWD = rs.getString("INNAK_PWD");
				bean.INNAK_YN = rs.getString("INNAK_YN");
				bean.INNAK_STATUS = rs.getString("INNAK_STATUS");
				bean.INNAK_BBS_CD = rs.getString("INNAK_BBS_CD");
				bean.INNAK_STATUS_2 = rs.getString("INNAK_STATUS_2");
				bean.INNAK_BBS_CD_2 = rs.getString("INNAK_BBS_CD_2");
				bean.INNAK_TRY_CNT_2 = rs.getInt("INNAK_TRY_CNT_2");
				bean.INNAK_TRY_CNT_1 = rs.getInt("INNAK_TRY_CNT_1");
				lst.add(bean);
			}

		}
		catch(Exception e) {
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
			e.printStackTrace();

		}
		finally
		{
			rs.close();
			rs = null;
			psmt.close();
			psmt = null;
		}

		return lst;
	}

	public int updateInnakErrorStatus(String gALR_ID, String errorPage) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("uploadStatus :" + gALR_ID +  "INNAK:" + errorPage);

		String sql = "UPDATE T_FISH_GALR SET INNAK_ERROR_1 = ? WHERE GALR_ID = ?";
		return updateErrorPage(gALR_ID, errorPage, sql);
	}

	public int updateInnakErrorStatus2(String gALR_ID, String errorPage) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("uploadStatus :" + gALR_ID +  "INNAK:" + errorPage);

		String sql = "UPDATE T_FISH_GALR SET INNAK_ERROR_2 = ? WHERE GALR_ID = ?";
		return updateErrorPage(gALR_ID, errorPage, sql);
	}
	
	public int updateAfishErrorStatus(String gALR_ID, String errorPage) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("uploadStatus :" + gALR_ID +  "AFISH:" + errorPage);

		String sql = "UPDATE T_FISH_GALR SET AFITH_ERROR = ? WHERE GALR_ID = ?";
		return updateErrorPage(gALR_ID, errorPage, sql);
	}
	
	public int updateDinakErrorStatus(String gALR_ID, String errorPage) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("uploadStatus :" + gALR_ID +  "Dinak:" + errorPage);

		String sql = "UPDATE T_FISH_GALR SET DINAK_ERROR = ? WHERE GALR_ID = ?";
		return updateErrorPage(gALR_ID, errorPage, sql);
	}
	
	private int updateErrorPage(String galId, String errorMessage, String sql)  throws Exception
	{
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement(sql);
		psmt.setString(1, errorMessage);
		psmt.setString(2, galId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
		return cnt;
	}

	public void updateInnakCnt1(String galId) throws Exception {
		// TODO Auto-generated method stub
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement("UPDATE T_FISH_GALR SET INNAK_TRY_CNT_1 = (INNAK_TRY_CNT_1 + 1) WHERE GALR_ID = ?");
		psmt.setString(1, galId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
		
	}

	public void updateInnakCnt2(String galId) throws Exception {
		// TODO Auto-generated method stub
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement("UPDATE T_FISH_GALR SET INNAK_TRY_CNT_2 = (INNAK_TRY_CNT_2 + 1) WHERE GALR_ID = ?");
		psmt.setString(1, galId);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
		
	}

	public void updateInnakStatusSuccess2(String gALR_ID, String string) throws Exception {
		// TODO Auto-generated method stub
		List<HashMap<String,String>> lst = null;

		Connection conn = getConnection();
		PreparedStatement psmt = conn.prepareStatement("UPDATE T_FISH_GALR SET INNAK_BBS_CD_2 = null,INNAK_ERROR_2 = null, INNAK_TRY_CNT_2 = null, INNAK_STATUS_2= null  WHERE GALR_ID = ?");
		psmt.setString(1, gALR_ID);

		int cnt = 0;
		try
		{
			cnt = psmt.executeUpdate();
		}
		catch(Exception e) {}
		finally
		{
			psmt.close();
			psmt = null;
		}
	}



}
