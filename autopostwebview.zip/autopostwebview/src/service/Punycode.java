package service;

public class Punycode
{
  /* Punycode parameters */
  final static int TMIN = 1;
  final static int TMAX = 26;
  final static int BASE = 36;
  final static int INITIAL_N = 128;
  final static int INITIAL_BIAS = 72;
  final static int DAMP = 700;
  final static int SKEW = 38;
  final static char DELIMITER = '-';
  
  /** 길성호.com -> xn--wk0bv37aolp.com */
  public static String convertPunyCode(String korUrl)
  {
		char chr = korUrl.charAt(0);
		if (chr>='가' && chr<='힣')
		{
			int dot = korUrl.indexOf('.');
			try
			{
			return "xn--" + encode(korUrl.substring(0, dot)) + korUrl.substring(dot);
			}catch(Exception e){}
		}
		return korUrl;
  }
  
  public static String encode(String input)
		    throws Exception
		  {
		    int n = INITIAL_N;
		    int delta = 0;
		    int bias = INITIAL_BIAS;
		    StringBuffer output = new StringBuffer();

		    // Copy all basic code points to the output
		    int b = 0;
		    for (int i = 0; i < input.length(); i++) {
		      char c = input.charAt(i);
		      if (isBasic(c)) {
			output.append(c);
			b++;
		      }
		    }

		    // Append delimiter
		    if (b > 0) {
		      output.append(DELIMITER);
		    }

		    int h = b;
		    while (h < input.length()) {
		      int m = Integer.MAX_VALUE;

		      // Find the minimum code point >= n
		      for (int i = 0; i < input.length(); i++) {
			int c = input.charAt(i);
			if (c >= n && c < m) {
			  m = c;
			}
		      }

		      if (m - n > (Integer.MAX_VALUE - delta) / (h + 1)) {
			throw new Exception("OVERFLOW");
		      }
		      delta = delta + (m - n) * (h + 1);
		      n = m;

		      for (int j = 0; j < input.length(); j++) {
			int c = input.charAt(j);
			if (c < n) {
			  delta++;
			  if (0 == delta) {
				  throw new Exception("OVERFLOW");
			  }
			}
			if (c == n) {
			  int q = delta;

			  for (int k = BASE;; k += BASE) {
			    int t;
			    if (k <= bias) {
			      t = TMIN;
			    } else if (k >= bias + TMAX) {
			      t = TMAX;
			    } else {
			      t = k - bias;
			    }
			    if (q < t) {
			      break;
			    }
			    output.append((char) digit2codepoint(t + (q - t) % (BASE - t)));
			    q = (q - t) / (BASE - t);
			  }

			  output.append((char) digit2codepoint(q));
			  bias = adapt(delta, h + 1, h == b);
			  delta = 0;
			  h++;
			}
		      }

		      delta++;
		      n++;
		    }

		    return output.toString();
		  }

  /**
   * Decode a punycoded string.
   *
   * @param input Punycode string
   * @return Unicode string.
   */
  public static String decode(String input) throws Exception
  {
    int n = INITIAL_N;
    int i = 0;
    int bias = INITIAL_BIAS;
    StringBuffer output = new StringBuffer();

    int d = input.lastIndexOf(DELIMITER);
    if (d > 0) {
      for (int j = 0; j < d; j++) {
	char c = input.charAt(j);
	if (!isBasic(c)) {
	  return null; // decode 실패 (잘못된 퓨니코드)
	}
	output.append(c);
      }
      d++;
    } else {
      d = 0;
    }

    while (d < input.length()) {
      int oldi = i;
      int w = 1;

      for (int k = BASE; ; k += BASE) {
	if (d == input.length()) {
		return ""; // decode 실패 (잘못된 퓨니코드)
	}
	int c = input.charAt(d++);

	int digit = codepoint2digit(c);
	
	if (digit > (Integer.MAX_VALUE - i) / w) {
		return ""; // decode 실패 (overflow)
	}

	i = i + digit * w;

	int t;
	if (k <= bias) {
	  t = TMIN;
	} else if (k >= bias + TMAX) {
	  t = TMAX;
	} else {
	  t = k - bias;
	}
	if (digit < t) {
	  break;
	}
	w = w * (BASE - t);	
      }

      bias = adapt(i - oldi, output.length()+1, oldi == 0);

      if (i / (output.length() + 1) > Integer.MAX_VALUE - n) {
    	  return ""; // decode 실패 (overflow)
      }

      n = n + i / (output.length() + 1);
      i = i % (output.length() + 1);
      output.insert(i, (char) n);
      i++;
    }

    return output.toString();
  }

  private final static int adapt(int delta, int numpoints, boolean first)
  {
    if (first) {
      delta = delta / DAMP;
    } else {
      delta = delta / 2;
    }

    delta = delta + (delta / numpoints);

    int k = 0;
    while (delta > ((BASE - TMIN) * TMAX) / 2) {
      delta = delta / (BASE - TMIN);
      k = k + BASE;
    }

    return k + ((BASE - TMIN + 1) * delta) / (delta + SKEW);
  }

  private final static boolean isBasic(char c)
  {
    return c < 0x80;
  }
  
  public final static int digit2codepoint(int d) throws Exception
  {
    if (d < 26) {
      // 0..25 : 'a'..'z'
      return d + 'a';
    } else if (d < 36) {
      // 26..35 : '0'..'9';
      return d - 26 + '0';
    } else {
    	throw new Exception("Punycode.digit2codepoint: bad Input");
    }
  }

  private final static int codepoint2digit(int c) throws Exception
  {
    if (c - '0' < 10) {
      // '0'..'9' : 26..35
      return c - '0' + 26;
    } else if (c - 'a' < 26) {
      // 'a'..'z' : 0..25
      return c - 'a';
    } else {
    	throw new Exception("Punycode.codepoint2digit: bad Input");
    }
  }
}

