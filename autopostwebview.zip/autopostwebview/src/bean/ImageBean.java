package bean;

public class ImageBean {
	
  public String GALR_ID;
  public String IMG_ID;
  public String CONTENT;
  public String SEQ;
  public String MOVIE_YN;
  public String SAVE_NAME;
  public int IMG_WIDTH;
  public int IMG_HEIGHT;
  public String HOSTING_URL;
  public String FILE_PATH;

}
