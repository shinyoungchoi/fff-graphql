package bean;

public class GalBean {	
	public String SHIP_ID;
	public String GALR_ID;
	public String SHIP_NAME;
	public String SUNDAN_NAME;
	public String CPTN_NAME;
	public String CPTN_TITLE;
	public String PORT_NAME;
	public String FISH_DATE;
	public String TITLE;
	public String LOC_DESC;
	public String HEADER_TEXT; //본문내용
	public String FOOTER_TEXT; //본문내용
	public String AREA_DESC;
	public String SITE;
	public String SITE_URL;
	public String PSGR;
	public String INNAK_AREA_CD;
	public String NEW_INNAK_AREA_CD;
	public String SHIP_IMG_ID;
	public String CPTN_IMG_ID;
	public String GPS_LAT;
	public String GPS_LONG;
	
	// 인낚 아이디,패스워드,등록여부, 상태값
	public String INNAK_ID;
	public String INNAK_PWD;
	public String INNAK_YN;
	public String INNAK_STATUS;
	public String INNAK_BBS_CD;
	public String INNAK_STATUS_2;
	public String INNAK_BBS_CD_2;
	public String INNAK_TYPE;
	
	// 디낚 아이디,패스워드,등록여부, 상태값
	public String DINAK_ID;
	public String DINAK_PWD;
	public String DINAK_YN;
	public String DINAK_P1;
	public String DINAK_P2;
	public String DINAK_STATUS;
	
	// 어부지리 아이디,패스워드,등록여부, 상태값
	public String AFISH_ID;
	public String AFISH_PWD;
	public String AFISH_YN;
	public String AFISH_P1;
	public String AFISH_STATUS;
	
	// 부낚 아이디,패스워드,등록여부, 상태값
	public String YBADA_ID;
	public String YBADA_PWD;
	public String YBADA_YN;
	public String YBADA_STATUS;
	
	public String PEOPLE_ONBOARD;
	public String HEADER_HB;
	public String FOOTER_HB;
	public String PICASA_YN;
	public String SUMMARY;
	
	public String FISH_NAME;
	public String SUNDAN_ID;
	public String DATE_DY;
	
	/* 디낚 지역명(코드없이 지명으로 되어 있음. ex: 제주|서귀포  */
	public String DINAK_AREA_NM;
	public String SHIP_AUTOPOST_NEW;
	public String SUNDAN_AUTOPOST_NEW;
	//디낚 등록안함
	public String DFISH_BBS_CD;
	public int INNAK_TRY_CNT_2;
	public int INNAK_TRY_CNT_1; 

}
