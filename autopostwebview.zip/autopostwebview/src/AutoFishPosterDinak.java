import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.vdurmont.emoji.EmojiParser;

import bean.GalBean;
import bean.ImageBean;
import component.ApBrowser;
import javafx.application.Application;
import javafx.concurrent.Worker.State;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.stage.Stage;
import service.ApTimer;
import service.DBHandler;
import service.Punycode;

public class AutoFishPosterDinak extends Application {
    private Scene scene;

    private String _runState;
	private static Logger logger = Logger.getLogger(AutoFishPosterDinak.class);
	//private static final String _mapUrl = "http://map.naver.com/?dlevel=12&pinType=site&pinId=21713882&x=#x#&y=#y#&enc=b64";
	//private static final String _mapImageUrl = "http://openapi.naver.com/map/getStaticMap?version=1.0&crs=EPSG:4326&center=#pos#&level=5&w=580&h=375&maptype=default&markers=#pos#&key=68ae0cd498350c9fba07d0ab8f7600b8&uri=www.fishapp.co.kr";

	private static final String Footer =

			"<div style='width: 99%;overflow:auto;'>" +
					"<div style='width:260px;float:left;background-color:#fff;margin: 5px 0px 10px 30px;'> " +
					"<ul style='margin: 0px; padding: 0px;><li style='list-style-type:none;'>" +
					"<div class='ship_info_list'><img src='#ship_image#' width='250px' style='max-height: 170;pxborder-radius: 10px;border: gray solid 1px;'></div> " +
					"</li> " +
					"</ul></div> " +
					"<div style='float:left;font-size:10pt;width: 320px;background: #ececec;padding: 10px 10px;margin: 5px 0px;'> " +
					"<div> " +
					"<table style='float:left;'>" +
					"<tr style='height: 25px;'><td>항구명</td><td style='font-weight: bold;padding: 0px 10px;'>#port_name#</td></tr> " +
					"<tr style='height: 25px;'><td>선박명</td><td style='font-weight: bold;padding: 0px 10px;width:110px'>#ship_name#</td></tr> " +
					"<tr style='height: 25px;'><td>승객</td><td style='font-weight: bold;padding: 0px 10px;'>#psgr#</td></tr>  " +
					"<tr style='height: 25px;'><td>출조해역</td><td style='font-weight: bold;padding: 0px 10px;width:110px' width='120'>#area_desc#</td></tr>  " +
					"</table> " +
					"<table  style='float:right;'><tr><td width='100' style='padding-bottom: 10px;text-align:center'>" +
					"<div style='border-radius: 50px; width:100px;overflow: hidden;margin-bottom:10px'><img id='cptn_img' src='#cptn_image#' width='100' height='100'></div> " +
					"<span style='font-weight:bold;'>#cptn_name#</span> #cptn_title# " +
					"</td></tr> </table>" +
					"<div style='font-size:11pt;width: 95%;font-weight:bolder;color:#1AA5A5;float:left;background:yellow;padding: 2px 2px 2px 10px;overflow: hidden;margin-bottom: 5px;'>☞<a href='http://#site#' style='margin:10px;color:blue' target='_blank'>#site#</a> " +
					"</div>" +
					"</div>" +
					"</div>" +
					"</div>" ;
	
	
    @Override public void start(Stage stage) {
    	
    	ApBrowser br = new ApBrowser();
    	
        stage.setTitle("Dinak 자동조황");
        scene = new Scene(br,1000,700, Color.web("#666970"));
        stage.setScene(scene);
        stage.show();
        
        ApTimer timer = new ApTimer();
        timer.startAutoKill(); //20초가 넘도록 종료되지 않으면 강제종료시킴
        
        postDinak(br);
        
    }
    
    private void postDinak(ApBrowser br)
    {
    	WebEngine we = br.webEngine;   
        we.getLoadWorker().stateProperty().addListener((ov,oldState,newState)->{
        	String nickName = "";
        	 System.out.println("now  "+oldState);
             System.out.println("now   "+ newState);
         	System.out.println("now state: succeeded -" + _runState);  
         	
         	if(newState==State.SUCCEEDED){        		
        		System.out.println("state: succeeded -" + _runState);        		
        		if (_runState == "login")
        		{
        			_runState = "login_end";                    
                    br.setFormField("id", galBean.DINAK_ID);
                    br.setFormField("password", galBean.DINAK_PWD);                    
                    System.out.println("####"+ galBean.DINAK_ID);
                    System.out.println("####"+ galBean.DINAK_PWD);
                    br.runScript("$('form:eq(0)').attr('action','exec/member-login.dnak')"); 
                    br.runScript("document.forms[0].submit();");
                    
        		}
        		else if (_runState == "login_end")
        		{
        			
        	        _runState = "write_before";        	        
        			String logoutResultPage = br.getString("document.documentElement.outerHTML"); 
        			
        			if (logoutResultPage.indexOf("btn_login.gif')") > 0 ) // 로그인버튼이미지가 있으면 로그인 실패
        			{
        				try{
        				dbh.updateDinakStatus(galBean.GALR_ID, "X"); //
        				}
        				catch(Exception e){
        					e.getStackTrace();
        				}        				
        				System.exit(777);
        			}
        			else
        			{

        			}    
        			
        			int startIndex = logoutResultPage.indexOf("<div class=\"name\">");
        			String nickNamePage = logoutResultPage.substring(startIndex+30);
        			int endIndex = nickNamePage.indexOf("</a>");
        			nickNamePage = nickNamePage.substring(0,endIndex);
        			startIndex = nickNamePage.indexOf(">")+1;
        			nickNamePage = nickNamePage.substring(startIndex);
        			System.out.println(nickNamePage);
        			nickName = nickNamePage;
        			String title = galBean.TITLE;
        			
        			System.out.println("http://jowhang.dinak.co.kr/%EC%A0%90%EC%A3%BC%EC%84%A0%EC%9E%A5%EC%A1%B0%ED%99%A9/list?sNatural=1&sKeyword="+title+"&sRegion=&sType=&sYear=2023&sMonth=&sDay=&sNick="+nickName);
        			br.loadPage("http://jowhang.dinak.co.kr/%EC%A0%90%EC%A3%BC%EC%84%A0%EC%9E%A5%EC%A1%B0%ED%99%A9/list?sNatural=1&sKeyword="+title+"&sRegion=&sType=&sYear=2023&sMonth=&sDay=&sNick="+nickName);
        			
        			
        			
        		}
        		else if (_runState == "write_before")
        		{
        			  _runState = "write";  
        			  
        			  //인낚게시판이 null인 경우.
        			  if(galBean.INNAK_BBS_CD == null || galBean.INNAK_BBS_CD.equals("") || galBean.INNAK_BBS_CD.equals("N")) {
        				  try {
							dbh.updateDinakStatus(galBean.GALR_ID, "F");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
        			  }
        				String searchPage = br.getString("document.documentElement.outerHTML"); 
        				//System.out.println("####"+searchPage);
        				int searchTableIndex = searchPage.indexOf("<tr class=\"new\">");
        				//오늘작성된 글ㄹ이 있는 경우.
        				if(searchTableIndex > -1) {
	        				searchPage = searchPage.substring(searchTableIndex);
	        				int searchTableLastIndex = searchPage.indexOf("</table>");
	        				searchPage = searchPage.substring(0,searchTableLastIndex);
	        				String title = galBean.TITLE;
	        				title = title.trim();
	        				title = title.replaceAll("&","&amp;");
	        				title = title.replaceAll("lt;", "<");
	        				title = title.replaceAll("gt;", ">");
	        				System.out.println(title);
	        				//System.out.println(searchPage);
	        				int startIndex = searchPage.indexOf(title);
	        				System.out.println(startIndex);
	        			  if(startIndex > -1) {
	        				  //검색된 정보가 있는 경우.
		        			  String searchPage__ = searchPage.substring(startIndex);
		        			  int lastIndex = searchPage__.indexOf("</div>");
		        			  String page = searchPage.substring(startIndex, startIndex+lastIndex);
		        			  //해당 row 정보 가져옴.
		        			  int nickNameIndex =  page.indexOf(nickName);
		        				Date today = new Date();
		        				SimpleDateFormat format = new SimpleDateFormat("YY.MM.dd");
		        				String todayStr = format.format(today);
		        				System.out.println(todayStr);
		        				int todayStrIndex = page.indexOf(todayStr);
		        				System.out.println(todayStrIndex);
		        			if(nickNameIndex > -1 && todayStrIndex > -1) {
		        				//동일한 글 존재.
		        				try {
									dbh.updateDinakStatus(galBean.GALR_ID, "S");
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}finally {
									 System.exit(777);
								}
		        			}
	        			  }
        				}
        			
        			 String board_id = ("lure".equals(galBean.INNAK_BBS_CD)) ? "dnk2_2_2": "dnk1_2_2";
        			 br.loadPage("http://jowhang.dinak.co.kr/%EC%A0%90%EC%A3%BC%EC%84%A0%EC%9E%A5%EC%A1%B0%ED%99%A9/write");
          			
        		}
        		else if (_runState == "write")
        		{
        			
        	        _runState = "write_end";  
        	        
        	        try
        	        {
        				dbh.updateDinakStatus(galBean.GALR_ID, "W");	//작성페이지까지 오면 성공으로 간주
        	        	

        			  //인낚게시판 구분을 이용해서 디낚 장르를 선택
        			  //인낚게시판은 5가지 게시판으로 구분한다.(좌대fam,갯바위rock,방파제break,선상boat,류어lure)
        			  //디낚은 루어게시판이 별도로 있고 ( dnk2_2_2) 나머지 4개장르는 점주선장조황게시판(dnk1_2_2)에 장르로 구분한다.
        			  String genre = null;
        	      	  if (galBean.INNAK_BBS_CD.equals("fam")) // 좌대
        	      	  {
        	      		  genre = "유료/좌대";
        	      	  }
        	      	  else if (galBean.INNAK_BBS_CD.equals("rock")) //갯바위
        	      	  {
        	      		  genre = "갯바위";
        	      	  }
        	      	 else if (galBean.INNAK_BBS_CD.equals("break")) //방파제
        	      	  {
        	      		  genre = "방파제";
        	      	  }	
        	      	 else //boat 또는 lure 또는 값이 없을때는 선상
        	      	 {
        	      		genre = "선상";
        	      	 }
        	      	  
        	      	Boolean testYn = false;

        	      	br.runScript("$('input:radio[name=editType]:radio[value=\"editor\"]').prop('checked',true);");
        	      	br.runScript("$('[id=jw-edit-type1]').trigger('change')"); //����
        	                	        
        	        String content = htmlContent.replaceAll("", "").replaceAll("<br />", "").replaceAll("'", "\"").replaceAll("(\r\n|\n)", "").replaceAll("\\\\", "");
        	        content = EmojiParser.removeAllEmojis(content);  
        	        //br.setFormField("wr_subject", galBean.TITLE); //����
        	        br.runScript("$('select[name=region1]').val('"+galBean.DINAK_P1+"')");
        	        br.runScript("$('select[name=region1]').trigger('change')");
        	        br.runScript("$('select[name=region2]').val('"+galBean.DINAK_P2+"')");
        	        br.runScript("$('select[name=region2]').trigger('change')");
        	        
        	        br.runScript("$('input:radio[name=type]:radio[value=\""+genre+"\"]').prop('checked',true);");
        	        
        	        //어종별 선상 조황등록처리
        	        if(genre == "선상") {
        	        	br.runScript("$('.usingextend').css('display','block')");
            	        br.runScript("$('input:checkbox[name=usingextend]').prop('checked',true)");
            	        br.runScript("$('input:checkbox[name=usingextend]').trigger('change')");
        	        	//fishes
            	        br.runScript("$('.fishes').css('display','block')");
        	        	String fishes = "";
        	        	String option = "0";
        	        	if (galBean.FISH_NAME == null) {
        	        		fishes = "갈치선상/갈치지깅";
        	        		option = "1";
        	        	} else if (galBean.FISH_NAME.equals("갈치")) {
        	        		fishes = "갈치선상/갈치지깅";
        	        		option = "1";
        	        	} else if(galBean.FISH_NAME.indexOf("오징어") != -1 || galBean.FISH_NAME.indexOf("문어") != -1 || galBean.FISH_NAME.equals("쭈꾸미")) {
        	        		fishes = "오징어/문어/주꾸미";
        	        		option = "2";
        	        	} else if(galBean.FISH_NAME.equals("삼치") || galBean.FISH_NAME.equals("부시리") || galBean.FISH_NAME.equals("방어") || galBean.FISH_NAME.equals("대구") || galBean.FISH_NAME.equals("고등어") || galBean.FISH_NAME.equals("명태") ) {
        	        		fishes = "(지깅)삼치/부시리/방어/대구";
        	        		option = "3";
        	        	} else if(galBean.FISH_NAME.equals("참돔") || galBean.FISH_NAME.equals("광어") || galBean.FISH_NAME.equals("농어") || galBean.FISH_NAME.equals("민어") || galBean.FISH_NAME.equals("도다리") || galBean.FISH_NAME.equals("양태") ) {
        	        		fishes = "참돔/농어/광어";
        	        		option = "4";
        	        	} else if(galBean.FISH_NAME.equals("열기") || galBean.FISH_NAME.equals("볼락") || galBean.FISH_NAME.equals("우럭") || galBean.FISH_NAME.equals("백조기") || galBean.FISH_NAME.equals("쥐노래미") ) {
        	        		fishes = "열기/볼락/우럭/백조기/도다리";
        	        		option = "5";
        	        	} else {
        	        		fishes = "감/참/부/방 선상찌낚시";
        	        		option = "6";
        	        	}
        	        	br.runScript("$('select[name=fishes]').val('"+fishes+"')");
        	        	//br.runScript("$('select[name=fishes] option:eq(" + option + ")').attr('selected', 'selected')");
        	        	//br.runScript("$('select[name=fishes]').trigger('change')");
        	        }


        	        String title = galBean.TITLE;
        	        title = galBean.TITLE.replaceAll("\'", "\"");
        	        title = EmojiParser.removeAllEmojis(title);  
        	       //br.runScript("document.getElementById('jw-subject').value="+ title);
        	       br.runScript("$('#jw-subject').val('" + title + "')"); //����

        	        br.runScript("$('#jw-contents').html('" + content + "')");


        	        if(!testYn) {
        	        	br.runScript("document.getElementById('jw-write').submit()");
        	        }

        	       // br.runScript("$('.btn-primary:eq(3)').click()"); //mobile

        	        }
        	        catch(Exception e)
        	        {
        	        	e.printStackTrace();
        	        	String errMessge = e.getMessage();
        	        	 String errorPage = br.getString("document.documentElement.outerHTML");
                         int startError = errorPage.indexOf("alert")+ 7;
                         if(startError > 0) {
	                         errorPage = errorPage.substring(startError);
	                         startError = errorPage.indexOf(")")-1;
	                         errorPage = errorPage.substring(0,startError);
	                         //오류 메시지 처리.
	                         //System.out.println("에러메시지:"+ errorPage+","+ errMessge);
	                         try {
	                        	  dbh.updateDinakErrorStatus(galBean.GALR_ID, errorPage);    
	                          }catch (Exception e1) {
	                              // TODO Auto-generated catch block
	                              e1.printStackTrace();
	                          }
                         }
        	        	System.exit(8888);
        	        }
        		}
        		else if (_runState == "write_end")
        		{
        			_runState = "logout";
        			
        			String writeEndResultPage = br.getString("document.documentElement.outerHTML");
        			int startIndex = writeEndResultPage.indexOf("<div class=\"subject\">");
        			int endIndex = writeEndResultPage.indexOf("<div title=\"작성일\" class=\"date\">");
        			
        			String title = galBean.TITLE;
        			title = title.replaceAll(" ","");
        			title = title.replaceAll("\"", "");
        			title = title.replaceAll("\'", "");
        			title = title.replaceAll("&", "");
        			System.out.println(title);
        			String compareContent = writeEndResultPage.substring(startIndex, endIndex);
        			compareContent = compareContent.replaceAll(" ", "");
        			compareContent = compareContent.replaceAll("&amp;", "");
        			compareContent = compareContent.replaceAll("\"", "");
        			compareContent = compareContent.replaceAll("&quot;", "");
        			compareContent = compareContent.replaceAll("&", "");
        			compareContent = compareContent.replaceAll("lt;", "<");
        			compareContent = compareContent.replaceAll("gt;", ">");
        			//System.out.println(compareContent);
        			boolean containYn = compareContent.contains(title);
        			System.out.println(containYn);
        			if(containYn)
        			{
        				try{
        					System.out.println("글 등록 완료");
        					dbh.updateDinakStatus(galBean.GALR_ID, "S");  
        				}
        				catch(Exception e){}
        				finally {
        					System.exit(999);
        				}

        			}else {
        				try{
        					System.out.println("글 등록 안됨.");
        					dbh.updateDinakStatus(galBean.GALR_ID, "E");  
        				}
        				catch(Exception e){}
        				finally {
        					System.exit(999);
        				}
        			}
        			
        			br.loadPage("http://mypage.dnak.sfg.kr/exec/member-logout.dnak"); //
        		}
        		else if (_runState == "logout")
        		{
        			_runState = "logout_check";
        			System.exit(999);
        		}
            }
        });
        _runState = "login";
  
        br.loadPage("https://ssl.dinak.co.kr/proxy/mypage/member-login.dnak?loc=http%3a%2f%2fjowhang%2edinak%2eco%2ekr%2f점주선장조황");
    }

    public static void main(String[] args){
    		start();
    }

	private static DBHandler dbh = new DBHandler();

	private static Date date;

	private static Date startTime;
	private static Date endTime;
	private static int contents = 0;

	private static GalBean galBean;
	private static String htmlContent = null;

    public static void start()
    {
		startTime = new Date();

		try
		{
			List<GalBean>  lst = getFishGalList();
			System.out.println("test NO " + lst.size());

			if (lst == null || lst.size()  ==0)
			{
				System.out.println("Nothing");
				return ;
			}

			contents = lst.size();

			if (contents > 0)
			{
				galBean = lst.get(0);
				List<ImageBean>  galImgageList = getImageList( galBean.GALR_ID );
				//신버전일 경우 패스
				if(StringUtils.equals("Y", galBean.SHIP_AUTOPOST_NEW) || StringUtils.equals("Y", galBean.SUNDAN_AUTOPOST_NEW)){
					htmlContent = makeNewContent(galBean, galImgageList);
				}else{
					htmlContent = makeContent(galBean, galImgageList);
				}
//				System.out.println(htmlContent);
			    launch();
			}
		}
		catch(Exception e) {

			e.printStackTrace();

		}
		finally
		{
			System.out.println();
			System.out.println("@   AutoPosting Start :" + startTime);

			endTime = new Date();

			System.out.println("@   AutoPosting End :" + endTime);

			dbh.closeConnection();
			System.exit(-1);
		}

    }

	private static List<GalBean> getFishGalList() throws Exception
	{
		try
		{
			return dbh.getDinakList();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception("1. getFishGalList failed!!!");
		}
	}
	
	private static List<ImageBean> getImageList(String galId)  throws Exception
	{
		List<ImageBean> lst = null;
		try
		{
			lst = dbh.getFishImageList(galId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception("2. getImageist [" + galId  + "] failed!!!");
		}	
		
		return lst;
	}
	
	private static String makeContent(GalBean galItem,   List<ImageBean>  imgList ) 
	{
		//String title = galItem.SHIP_NAME + ", " + galItem.TITLE;
		String title =galItem.TITLE;
		File file = null;
		
		StringBuilder sb = new StringBuilder("<div class='cdt_view_cts' style='text-align:center;'>");
		//자동조황으로 올라갔다는 내용 표시함.
		sb.append("<span style='color:#fff;font-size:3px;'>낚시뚜에서 디낚으로 보내는 자동조황</span>");
		if (galItem.SUMMARY != null && galItem.SUMMARY.length() > 1)
		{
			sb.append("<p style='background-color: #698794;padding: 10px;font-size: 11pt;color: white;font-weight: 800;margin: 20px;text-align: left;border-radius: 10px;border-color: white; border-width: 3px;border-style: dotted;'>" +
							galItem.SUMMARY.trim().replaceAll("\n", "").replaceAll("\r", "")   + "</p>");
		}
		
		if (galItem.HEADER_HB != null) // ����ȫ�� ���
		{
			// (1) �ּ��±� ����� (2) 0823 ĳ���� �����
			sb.append("<p>" + galItem.HEADER_HB.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</p>");
		}
		
		if (galItem.HEADER_TEXT != null) //��Ȳ ���
		{
			// (1) �ּ��±� ����� (2) 0823 ĳ���� �����
			sb.append("<p>" + galItem.HEADER_TEXT.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</p>");
		}
		
		// ��Ȳ�̹�����
		for (ImageBean imgItem : imgList) {			
			
			if ("Y".equals(imgItem.MOVIE_YN))
			{
				sb.append("<iframe frameborder='0' style='width:100%;height:300px' webkitallowfullscreen mozallowfullscreen allowfullscreen src='//www.youtube.com/embed/"+ imgItem.IMG_ID + "'></iframe>");
			}
			else
			{
				
				//��ī�� ��η�			
				sb.append("<img width='600' style='border-radius:7px;' src='" +  imgItem.HOSTING_URL  +"'>");
			}
			
			if (imgItem.CONTENT != null)
			{
				sb.append("<p style='padding-bottom: 20px'>" + imgItem.CONTENT.replaceAll("\n", "<br>")  + "<br></p>");
			}
			else
			{
				sb.append("<p style='padding-bottom: 20px'></p>");
			}
		}	

		// ��Ȳ Ǫ��
		if (galItem.FOOTER_TEXT != null)
		{
			// (1) �ּ��±� ����� (2) 0823 ĳ���� �����
			sb.append("<p>" + galItem.FOOTER_TEXT.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</p>");
		}
		
		// ���� ȫ�� Ǫ��
		if (galItem.FOOTER_HB != null)
		{
			// (1) �ּ��±� ����� (2) 0823 ĳ���� �����
			sb.append("<p>" + galItem.FOOTER_HB.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</p>");
		}
		
		//네이버 이미지 지도 안됨
//		// ����(���̹��� - �̹�����)
//		if (galItem.GPS_LAT != null && galItem.GPS_LONG != null)
//		{
//			//String naverMapUrl = _mapUrl.replaceAll("#x#", galItem.GPS_LONG).replaceAll("#y#", galItem.GPS_LAT);
//			String naverMapImage = _mapImageUrl.replaceAll("#pos#", galItem.GPS_LONG + ","  + galItem.GPS_LAT);
//					
//			//sb.append("<a href='" + naverMapUrl +"' target='_blank'><img width='580' height='375' style='border: #e8e8e8 10px double;' src='" + naverMapImage +"'></a><br>");
//			sb.append("<img width='580' height='375' style='border: #e8e8e8 10px double;' src='" + naverMapImage +"'><br>");
//		}
		
		sb.append("</div><br>");
		
		// ����,����, ���� �ּ� �Ұ�
		String shipImage = galItem.SHIP_IMG_ID;
		
		if (shipImage != null)
		{
			String capImage = galItem.CPTN_IMG_ID;
			
			capImage = (capImage == null) ? "https://lh3.googleusercontent.com/-YG2GBea2yF0/VZUfv0Wd3TI/AAAAAAAANG0/NxhrQeXZfCY/s120/nopic_cptn.jpg"
					: capImage;
			
			String footer = 
					Footer.replaceAll("#port_name#", galItem.PORT_NAME)
					.replaceAll("#ship_image#", shipImage)
					.replaceAll("#cptn_image#", capImage)
					.replaceAll("#cptn_name#", galItem.CPTN_NAME)
					.replaceAll("#cptn_title#", galItem.CPTN_TITLE)
					.replaceAll("#ship_name#", galItem.SHIP_NAME)
					.replaceAll("#site#", galItem.SITE)
					.replaceAll("#psgr#", galItem.PSGR + "명")
					.replaceAll("#area_desc#", galItem.AREA_DESC);
			
			sb.append(footer);
		}
		else
		{
			sb.append("<div style='width:99%;border:4px solid #e8e8e8;height:30px;text-align:center;'>" );
			sb.append("<div style='font-size:11pt;width:100%;font-weight:bolder;color:blue'>"+ galItem.SHIP_NAME + " (" + galItem.PORT_NAME + ") 예약☞ <a href='http://" + galItem.SITE_URL +"' style='margin:10px;'>" + galItem.SITE +"</a>");
			sb.append("</div>" );
		}
		
		return sb.toString();
	}
	
	

	private static String makeNewContent(GalBean galItem,   List<ImageBean>  imgList ) throws Exception 
	{
		String title =galItem.TITLE;
		
		String siteType = "H";
		Map<String,String> info = null;
		
		if(StringUtils.isNotEmpty(galItem.SUNDAN_NAME)){
			siteType = "S";
		}
		
		//선박인 경우
		if(StringUtils.equals("H",  siteType)){
			info = dbh.getShipInfo(galItem);
			//구버전일 경우 패스
			if(StringUtils.equals("N", galItem.SHIP_AUTOPOST_NEW)){
				return null;
			}
		}else{
			info = dbh.getSundanInfo(galItem);
			if(StringUtils.equals("N", galItem.SUNDAN_AUTOPOST_NEW)){
				return null;
			}
		}
		
		String date = galItem.FISH_DATE;			
		String schdDate = date.substring(0, 4) +"-"+ date.substring(4,6) +"-"+ date.substring(6, 8);
		if("1".equals(galItem.DATE_DY)){
			schdDate += "(일)";
		}else if("2".equals(galItem.DATE_DY)){
			schdDate += "(월)";
		}else if("3".equals(galItem.DATE_DY)){
			schdDate += "(화)";
		}else if("4".equals(galItem.DATE_DY)){
			schdDate += "(수)";
		}else if("5".equals(galItem.DATE_DY)){
			schdDate += "(목)";				
		}else if("6".equals(galItem.DATE_DY)){
			schdDate += "(금)";
		}else if("7".equals(galItem.DATE_DY)){
			schdDate += "(토)";
		}
		
		StringBuilder sb = new StringBuilder("<div class='cdt_view_cts'	style='max-width: 620px; margin: 0; padding: 0; text-align: center; vertical-align: top;'>");
		//자동조황으로 올라갔다는 내용 표시함.
		sb.append("<span style='color:#fff;font-size:3px;'>낚시뚜에서 디낚으로 보내는 자동조황</span>");
		sb.append("<table border='0' cellspacing='0' cellpadding='0' style='max-width: 620px; margin: 0 auto; border-collapse: collapse;'>");			
		sb.append("<tr><td>");			
		sb.append("<table border='0' width='100%' cellspacing='0' cellpadding='0' style='vertical-align: top; background-color: #21d6e9'>");			
		sb.append("<tr><td style='text-align: left;'><img src='https://img.fishapp.co.kr/img/shipb/top01.png' width='100%'></td></tr>");
		sb.append("<tr><td style='padding: 35px 0;'>");
		if(StringUtils.equals("H",  siteType)){
			sb.append("<p style='font-size: 20px; color: #fff; margin: 0; padding-left: 18px; text-align: left; letter-spacing: -1px;'>"+ (info.get("SUB_SHIP_NM") == null ? "" : info.get("SUB_SHIP_NM"))+"</p>");
			sb.append("<p style='font-size: 40px; color: #fff; margin: 0; padding-left: 18px; text-align: left; letter-spacing: -1px; font-weight: 600; line-height: normal;'>"+info.get("SHIP_NAME")+"</p></td>");
			
		}else{
			sb.append("<p style='font-size: 20px; color: #fff; margin: 0; padding-left: 18px; text-align: left; letter-spacing: -1px;'>"+(info.get("SUB_SUNDAN_NM") == null ? "" : info.get("SUB_SUNDAN_NM"))+"</p>");
			sb.append("<p style='font-size: 40px; color: #fff; margin: 0; padding-left: 18px; text-align: left; letter-spacing: -1px; font-weight: 600; line-height: normal;'>"+info.get("SUNDAN_NAME")+"</p></td>");
			
		}
		sb.append("</tr>");
		
		sb.append("<tr>");
		sb.append("<td style='text-align: left;'><img src='https://img.fishapp.co.kr/img/shipb/top02.png' width='100%'></td></tr>");			
		sb.append("</table>");
		
		if (galItem.SUMMARY != null && galItem.SUMMARY.length() > 1)
		{
			sb.append("<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #004ea2'>");
			sb.append("<tr>");
			sb.append("<td style='background-color: #004ea2; padding: 25px 10px; color: #fff; font-size: 13px; text-align: left; line-height: 24px;'>");
			sb.append(galItem.SUMMARY.trim().replaceAll("\n", "<br/>").replaceAll("\r", "")  );
			sb.append("</td></tr></table>");
		}
		
		String cnt = galItem.PSGR;
		if(galItem.PEOPLE_ONBOARD != null){
			cnt = galItem.PEOPLE_ONBOARD;
		}
		
		sb.append("<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #fff; vertical-align: top;'>");
		sb.append("<tr style='height: 85px;'>");
		sb.append("<td rowspan='2' style='background-color: #efefef; padding: 25px 10px; vertical-align: top;'>");
		sb.append("<table>");
		sb.append("<tr>");
		sb.append("<td style='width: 100px; font-weight: 600; color: #001c48; font-size: 17px; letter-spacing: -1.5px; text-align: left; line-height: 24px; vertical-align: top;'>");
		sb.append("&middot;&nbsp;출조일시</td>");
		sb.append("<td style='text-align: left; font-size: 17px; line-height: 24px; color: #4d585f; vertical-align: top;'>"+schdDate+"</td>");
		sb.append("</tr><tr>");
		sb.append("<td style='width: 100px; font-weight: 600; color: #001c48; font-size: 17px; letter-spacing: -1.5px; text-align: left; line-height: 24px; vertical-align: top;'>&middot;&nbsp;출조인원</td>");
		sb.append("<td style='text-align: left; font-size: 17px; line-height: 24px; color: #4d585f; vertical-align: top;'>"+cnt+"명</td>");
		sb.append("</tr><tr>");
		sb.append("<td style='width: 100px; font-weight: 600; color: #001c48; font-size: 17px; letter-spacing: -1.5px; text-align: left; line-height: 24px; vertical-align: top;'>&middot;&nbsp;어종</td>");
		sb.append("<td style='text-align: left; font-size: 17px; line-height: 24px; color: #4d585f; vertical-align: top;'>"+galItem.FISH_NAME+"</td>");
		sb.append("</tr></table></td></tr></table>");
			
		//컨텐츠 넣기
		sb.append("</td></tr>");
		
		
		if (galItem.HEADER_HB != null) // 선박홍보 헤더
		{
			// (1) 주석태그 지우기 (2) 0823 캐릭터 지우기
			sb.append("<tr><td  style='padding-bottom:20px;padding-top:20px;'><div>" + galItem.HEADER_HB.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</div></td></tr>");
		}
		
		if (galItem.HEADER_TEXT != null) 
		{
			sb.append("<tr><td  style='padding-bottom:20px;padding-top:20px;'><div  style='font-size: 17px;'>" + galItem.HEADER_TEXT.replaceAll("\n", "<br/>").replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</div></td></tr>");
		}
		
		sb.append("<tr><td style='padding:20px 0;text-align:center;'>");
		
		// 조황이미지들
		for (ImageBean imgItem : imgList) {			
			
			if ("Y".equals(imgItem.MOVIE_YN))
			{
				sb.append("<iframe frameborder='0' style='width:100%;height:300px' webkitallowfullscreen mozallowfullscreen allowfullscreen src='//www.youtube.com/embed/"+ imgItem.IMG_ID + "'></iframe>");
			}
			else
			{
				sb.append("<img width='600' style='border-radius:7px;' src='" +  imgItem.HOSTING_URL  +"'>");
			}
			
			if (imgItem.CONTENT != null)
			{
				sb.append("<p  style='font-size: 17px;'>" + imgItem.CONTENT.replaceAll("\n", "<br>")  + "<br></p>");
			}
			else
			{
				sb.append("<p style='padding-bottom: 20px'></p>");
			}
		}			
		sb.append("</td></tr>");
		
		//선박 푸터글
		if (galItem.FOOTER_TEXT != null)
		{
			sb.append("<tr><td style='padding-bottom:20px;'><div  style='font-size: 17px;'>" + galItem.FOOTER_TEXT.replaceAll("(?s)<!--.*?-->", "").replaceAll("\n", "<br/>").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</div></td></tr>");
		}
		
		// 선박 홍보 푸터
		if (galItem.FOOTER_HB != null)
		{
			// (1) 주석태그 지우기 (2) 0823 캐릭터 지우기
			sb.append("<tr><td style='padding-bottom:20px;'><div>" + galItem.FOOTER_HB.replaceAll("(?s)<!--.*?-->", "").replaceAll("\u8203","").replaceAll("\"/cm/file/","\"https://www.fishapp.co.kr/cm/file/") + "</div></td></tr>");
		}
		
		
		//footer 
		sb.append("<tr><td>");

		String shipImage = galItem.SHIP_IMG_ID;		
		
		// 어부지리에서 한글도메인을 지워버리는 문제점 발생: 한글도메인인 경우 퓨니코드로 변환한다.(영문도메인은 변환시켜도 원래값이 나오므로 그냥 다 변환시킴)
		String siteUrl = galItem.SITE;
		try
		{
			siteUrl = Punycode.convertPunyCode(galItem.SITE);
		}
		catch(Exception e){};
		
		
		//선박인 경우
		if(StringUtils.equals("H",  siteType)){
			// 선박,선장, 접속 주소 소개		
			if (shipImage != null)
			{
				String capImage = galItem.CPTN_IMG_ID;
				
				capImage = (capImage == null) ? "https://lh3.googleusercontent.com/-YG2GBea2yF0/VZUfv0Wd3TI/AAAAAAAANG0/NxhrQeXZfCY/s120/nopic_cptn.jpg" 
						:  capImage;
				
				String footer = 
						Footer_.replaceAll("#port_name#", galItem.PORT_NAME)
						.replaceAll("#ship_image#", shipImage)
						.replaceAll("#navigation#",   (info.get("NAVIGATION") == null) ? "" : info.get("NAVIGATION"))
						.replaceAll("#shopnm#", (info.get("SHOP_NM") == null) ? galItem.SHIP_NAME : info.get("SHOP_NM"))
						.replaceAll("#tel#", info.get("CPTN_TEL"))
						.replaceAll("#sub_ship_nm#", (info.get("SUB_SHIP_NM") == null) ? "" : info.get("SUB_SHIP_NM"))
						.replaceAll("#bankcd#", (info.get("BANK_CD") == null)? "" : info.get("BANK_CD"))
						.replaceAll("#bankaccn#", (info.get("BANK_ACCN") == null)? "" : info.get("BANK_ACCN"))
						.replaceAll("#bankholder#", (info.get("BANK_HOLDER") == null ) ? "" : info.get("BANK_HOLDER"))
						.replaceAll("#cptn_image#", capImage)
						.replaceAll("#cptn_name#", galItem.CPTN_NAME +" 선장")
						.replaceAll("#cptn_title#", galItem.CPTN_TITLE)
						.replaceAll("#ship_name#", galItem.SHIP_NAME)
						.replaceAll("#site#", siteUrl)
						.replaceAll("#psgr#", (galItem.PSGR == null ? "-" : galItem.PSGR) + "명")
						.replaceAll("#boatplace#", (info.get("BOAT_PLACE") == null) ? "" : info.get("BOAT_PLACE"))
						.replaceAll("#area_desc#", galItem.AREA_DESC);
				
				sb.append(footer);
			
			}
			else
			{
				String footer = 
								FooterWithoutImage.replaceAll("#port_name#", galItem.PORT_NAME)
						.replaceAll("#ship_image#", shipImage)
						.replaceAll("#navigation#",   (info.get("NAVIGATION") == null) ? "" : info.get("NAVIGATION"))
						.replaceAll("#shopnm#", (info.get("SHOP_NM") == null) ? galItem.SHIP_NAME : info.get("SHOP_NM"))
						.replaceAll("#tel#", info.get("CPTN_TEL"))
						.replaceAll("#sub_ship_nm#", (info.get("SUB_SHIP_NM") == null) ? "" : info.get("SUB_SHIP_NM"))
						.replaceAll("#bankcd#", (info.get("BANK_CD") == null)? "" : info.get("BANK_CD"))
						.replaceAll("#bankaccn#", (info.get("BANK_ACCN") == null)? "" : info.get("BANK_ACCN"))
						.replaceAll("#bankholder#", (info.get("BANK_HOLDER") == null ) ? "" : info.get("BANK_HOLDER"))
						.replaceAll("#cptn_name#", galItem.CPTN_NAME +" 선장")
						.replaceAll("#cptn_title#", galItem.CPTN_TITLE)
						.replaceAll("#ship_name#", galItem.SHIP_NAME)
						.replaceAll("#site#", siteUrl)
						.replaceAll("#psgr#", (galItem.PSGR == null ? "-" : galItem.PSGR) + "명")
						.replaceAll("#boatplace#", (info.get("BOAT_PLACE") == null) ? "" : info.get("BOAT_PLACE"))
						.replaceAll("#area_desc#", galItem.AREA_DESC);
				
				sb.append(footer);
			}
		}else{
			//선단의 경우
			String shopImgId = info.get("SHOP_IMG_ID");
			if(shopImgId != null){
				String footer = 
						sundanFooter.replaceAll("#port_name#", galItem.PORT_NAME)
						.replaceAll("#ship_image#", shopImgId)
						.replaceAll("#tel#", info.get("SHOP_TEL"))
						.replaceAll("#navigation#",   (info.get("NAVIGATION") == null) ? "" : info.get("NAVIGATION"))
						.replaceAll("#shopnm#", info.get("SHOP_NM"))
						.replaceAll("#shoptel#", info.get("SHOP_TEL"))
						.replaceAll("#sub_sundan_nm#", (info.get("SUB_SUNDAN_NM") == null) ? "" : info.get("SUB_SUNDAN_NM"))
						.replaceAll("#bankcd#", (info.get("BANK_CD") == null)? "" : info.get("BANK_CD"))
						.replaceAll("#bankaccn#", (info.get("BANK_ACCN") == null)? "" : info.get("BANK_ACCN"))
						.replaceAll("#bankholder#", (info.get("BANK_HOLDER") == null ) ? "" : info.get("BANK_HOLDER"))
						.replaceAll("#cptn_name#", galItem.CPTN_NAME)
						.replaceAll("#cptn_title#", galItem.CPTN_TITLE)
						.replaceAll("#sundan_name#", galItem.SUNDAN_NAME)
						.replaceAll("#site#", siteUrl)
						.replaceAll("#psgr#", (galItem.PSGR == null ? "-" : galItem.PSGR) + "명")
						.replaceAll("#shopaddr#", info.get("ADDR"));				
				sb.append(footer);
			}else{
				String footer = 
						sundanFooterWithout.replaceAll("#port_name#", galItem.PORT_NAME)
						.replaceAll("#navigation#",   (info.get("NAVIGATION") == null) ? "" : info.get("NAVIGATION"))
						.replaceAll("#tel#", info.get("SHOP_TEL"))
						.replaceAll("#shopnm#", info.get("SHOP_NM"))
						.replaceAll("#shoptel#", info.get("SHOP_TEL"))
						.replaceAll("#sub_sundan_nm#", (info.get("SUB_SUNDAN_NM") == null) ? "" : info.get("SUB_SUNDAN_NM"))
						.replaceAll("#bankcd#", (info.get("BANK_CD") == null)? "" : info.get("BANK_CD"))
						.replaceAll("#bankaccn#", (info.get("BANK_ACCN") == null)? "" : info.get("BANK_ACCN"))
						.replaceAll("#bankholder#", (info.get("BANK_HOLDER") == null ) ? "" : info.get("BANK_HOLDER"))
						.replaceAll("#cptn_name#", galItem.CPTN_NAME)
						.replaceAll("#cptn_title#", galItem.CPTN_TITLE)
						.replaceAll("#sundan_name#", galItem.SUNDAN_NAME)
						.replaceAll("#site#", siteUrl)
						.replaceAll("#psgr#", (galItem.PSGR == null ? "-" : galItem.PSGR) + "명")
						.replaceAll("#shopaddr#", info.get("ADDR"));
				
				sb.append(footer);
			}
							
		}	
		sb.append("</td></tr>");
		
		
		sb.append("<tr><td style='text-align: center;'>");
		sb.append("<img	src='https://img.fishapp.co.kr/img/shipb/logo2.png' alt='낚시뚜'	width='100%'/></td></tr>");
		sb.append("</table>");
		sb.append("</div>");
		
		String content = sb.toString();
		
		//System.out.println("###"+content);		
		
		return content;
	}
	
	private static final String FooterWithoutImage = 
			"<table border='0' width='100%' cellspacing='0'	cellpadding='0'	style='background-color: #41b7f4; vertical-align: middle;'>"
			+ "<tr><td style='padding: 10px 0px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0'>"
			+ "<tr>"
			+ "<td style='padding-left: 30px; width: 80px; color: #fff; font-size: 15px; font-weight: 600; letter-spacing: -1.2px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "네비주소 :</td>"
			+ "<td style='color: #fff; font-size: 15px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "#navigation#</td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='padding: 0px 30px 20px;'>"
			+ "<table border='0' width='100%' cellspacing='0' cellpadding='0' style='padding: 17px 20px 15px; background-color: #67c5f6; text-align: left;'>"
			+ "<tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>"
			+ "예약문의</p>"
			+ "<p style='margin: 0; padding: 0 0 25px; color: #ffff00; font-size: 24px; font-weight: 600; line-height: 24px;'>#tel#</p></td>"
			+ "</tr><tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>#bankcd#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 24px; font-weight: 600; line-height: 24px;'>#bankaccn#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600; line-height: 38px;'>#bankholder#</p></td>"
			+ "</tr></table></td>"
			+ "	</tr>"
			+ " </table> "
			+ "	<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #eaf7ff;'>"
			+ "<tr>"
			+ " <td style='padding: 20px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0' style='text-align: left;'>"
			+ "	<tr><td	style='width: 100px; text-align: left; vertical-align: top'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>항구명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#port_name#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>승선인원</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#psgr#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shopnm#</span></td>"
			+ "</tr><tr>"
			+ "<td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>배 타는 곳</span></td>"
			+ "<td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>"
			+ "#boatplace#</span></td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='text-align: center; padding-bottom: 24px;'>"
			+ "<a href='http://#site#' target='_blank'>"
			+ "<img	src='https://img.fishapp.co.kr/img/shipb/btn_go3.png' alt='홈페이지 바로가기 Click' style='width: 100%;'/></a></td>"
			+ "</tr></table>";
	
	private static final String Footer_ = 
			"<table border='0' width='100%' cellspacing='0'	cellpadding='0'	style='background-color: #41b7f4; vertical-align: middle;'>"
			+ "<tr><td style='padding: 10px 0px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0'>"
			+ "<tr>"
			+ "<td style='padding-left: 30px; width: 80px; color: #fff; font-size: 15px; font-weight: 600; letter-spacing: -1.2px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "네비주소 :</td>"
			+ "<td style='color: #fff; font-size: 15px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "#navigation#</td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='padding: 0px 30px 20px;'>"
			+ "<table border='0' width='100%' cellspacing='0' cellpadding='0' style='padding: 17px 20px 15px; background-color: #67c5f6; text-align: left;'>"
			+ "<tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>"
			+ "예약문의</p>"
			+ "<p style='margin: 0; padding: 0 0 25px; color: #ffff00; font-size: 24px; font-weight: 600; line-height: 24px;'>#tel#</p></td>"
			+ "</tr><tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>#bankcd#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 24px; font-weight: 600; line-height: 24px;'>#bankaccn#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600; line-height: 38px;'>#bankholder#</p></td>"
			+ "</tr></table></td>"
			+ "	</tr>"
			+ " </table> "
			+ "	<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #eaf7ff;'>"
			+ " <tr>"
			+ " <td style='text-align: center'> <p style='display: inline-block; padding: 40px 0px 5px; margin: 0 auto;'>"
			+ " <img src='#cptn_image#'  width='115px' height='115px'>"
			+ "</p></td>"
			+ "	</tr><tr>"
			+ " <td style='text-align: center; padding-bottom: 20px;'>"
			+ " <p style='margin: 0; padding: 0; font-size: 14px; letter-spacing: -1.5px; font-weight: 400; color: #001c48;'>#sub_ship_nm#</p>"
			+ "	<p style='margin: 0; padding: 0; font-size: 45px; letter-spacing: -2px; font-weight: 900; color: #113898; line-height: 52px;'>#ship_name#</p>"
			+ " <p style='margin: 0; padding: 10px 0 0; font-size: 14px; letter-spacing: -1.5px; font-weight: 900; color: #001c48;'>#cptn_name#</p></td>"
			+ "	</tr><tr>"
			+ "	<td style='width: 100%;'>"
			+ " <img src='#ship_image#' style='width: 590px;'></td>"
			+ " </tr><tr>"
			+ " <td style='padding: 20px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0' style='text-align: left;'>"
			+ "	<tr><td	style='width: 100px; text-align: left; vertical-align: top'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>항구명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#port_name#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>승선인원</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#psgr#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shopnm#</span></td>"
			+ "</tr><tr>"
			+ "<td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>배 타는 곳</span></td>"
			+ "<td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>"
			+ "#boatplace#</span></td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='text-align: center; padding-bottom: 24px;'>"
			+ "<a href='http://#site#' target='_blank'>"
			+ "<img	src='https://img.fishapp.co.kr/img/shipb/btn_go3.png' alt='홈페이지 바로가기 Click' style='width: 100%;' /></a></td>"
			+ "</tr></table>";
	
	
	private static final String sundanFooter = 
			"<table border='0' width='100%' cellspacing='0'	cellpadding='0'	style='background-color: #41b7f4; vertical-align: middle;'>"
			+ "<tr><td style='padding: 10px 0px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0'>"
			+ "<tr>"
			+ "<td style='padding-left: 30px; width: 80px; color: #fff; font-size: 15px; font-weight: 600; letter-spacing: -1.2px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "네비주소 :</td>"
			+ "<td style='color: #fff; font-size: 15px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "#navigation#</td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='padding: 0px 30px 20px;'>"
			+ "<table border='0' width='100%' cellspacing='0' cellpadding='0' style='padding: 17px 20px 15px; background-color: #67c5f6; text-align: left;'>"
			+ "<tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>"
			+ "예약문의</p>"
			+ "<p style='margin: 0; padding: 0 0 25px; color: #ffff00; font-size: 24px; font-weight: 600; line-height: 24px;'>#tel#</p></td>"
			+ "</tr><tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>#bankcd#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 24px; font-weight: 600; line-height: 24px;'>#bankaccn#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600; line-height: 38px;'>#bankholder#</p></td>"
			+ "</tr></table></td>"
			+ "	</tr>"
			+ " </table> "
			+ "	<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #eaf7ff;'>"
			+ " <tr>"
			+ " <td style='text-align: center; padding-bottom: 20px;'>"
			+ " <p style='margin: 0; padding: 0; font-size: 14px; letter-spacing: -1.5px; font-weight: 400; color: #001c48;'>#sub_sundan_nm#</p>"
			+ "	<p style='margin: 0; padding: 0; font-size: 45px; letter-spacing: -2px; font-weight: 900; color: #113898; line-height: 52px;'>#sundan_name#</p>"
			+ "	</tr><tr>"
			+ "	<td style='width: 100%;'>"
			+ " <img src='#ship_image#' style='width: 590px;'></td>"
			+ " </tr><tr>"
			+ " <td style='padding: 20px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0' style='text-align: left;'>"
			+ "	<tr><td	style='width: 100px; text-align: left; vertical-align: top'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>항구명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#port_name#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shopnm#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점연락처</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shoptel#</span></td>"
			+ "</tr><tr>"
			+ "<td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점 주소</span></td>"
			+ "<td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>"
			+ "#shopaddr#</span></td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='text-align: center; padding-bottom: 24px;'>"
			+ "<a href='http://#site#' target='_blank'>"
			+ "<img	src='https://img.fishapp.co.kr/img/shipb/btn_go3.png' alt='홈페이지 바로가기 Click' style='width: 100%;' /></a></td>"
			+ "</tr></table>";
			
	
	private static final String sundanFooterWithout = 
			"<table border='0' width='100%' cellspacing='0'	cellpadding='0'	style='background-color: #41b7f4; vertical-align: middle;'>"
			+ "<tr><td style='padding: 10px 0px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0'>"
			+ "<tr>"
			+ "<td style='padding-left: 30px; width: 80px; color: #fff; font-size: 15px; font-weight: 600; letter-spacing: -1.2px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "네비주소 :</td>"
			+ "<td style='color: #fff; font-size: 15px; line-height: 25px; text-align: left; vertical-align: top;'>"
			+ "#navigation#</td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='padding: 0px 30px 20px;'>"
			+ "<table border='0' width='100%' cellspacing='0' cellpadding='0' style='padding: 17px 20px 15px; background-color: #67c5f6; text-align: left;'>"
			+ "<tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>"
			+ "예약문의</p>"
			+ "<p style='margin: 0; padding: 0 0 25px; color: #ffff00; font-size: 24px; font-weight: 600; line-height: 24px;'>#tel#</p></td>"
			+ "</tr><tr style='line-height: normal;'>"
			+ "<td style='color: #fff; text-align: center;'>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600;'>#bankcd#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 24px; font-weight: 600; line-height: 24px;'>#bankaccn#</p>"
			+ "<p style='margin: 0; padding: 0; font-size: 18px; font-weight: 600; line-height: 38px;'>#bankholder#</p></td>"
			+ "</tr></table></td>"
			+ "	</tr>"
			+ " </table> "
			+ "	<table border='0' width='100%' cellspacing='0' cellpadding='0' style='background-color: #eaf7ff;'>"
			+ " <tr>"
			+ " <td style='text-align: center; padding-bottom: 20px;'>"
			+ " <p style='margin: 0; padding: 0; font-size: 14px; letter-spacing: -1.5px; font-weight: 400; color: #001c48;'>#sub_sundan_nm#</p>"
			+ "	<p style='margin: 0; padding: 0; font-size: 45px; letter-spacing: -2px; font-weight: 900; color: #113898; line-height: 52px;'>#sundan_name#</p>"
			+ "	</tr><tr>"
			+ " <td style='padding: 20px 10px;'><table border='0' width='100%' cellspacing='0' cellpadding='0' style='text-align: left;'>"
			+ "	<tr><td	style='width: 100px; text-align: left; vertical-align: top'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>항구명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#port_name#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점명</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shopnm#</span></td>"
			+ " </tr><tr>"
			+ " <td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ " <span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점연락처</span></td>"
			+ " <td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>#shoptel#</span></td>"
			+ "</tr><tr>"
			+ "<td style='width: 100px; text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: bold; line-height: 30px; color: #001c48; letter-spacing: -1.5px;'>출조점 주소</span></td>"
			+ "<td style='text-align: left; vertical-align: top;'>"
			+ "<span style='font-size: 14px; font-weight: normal; line-height: 30px; color: #4d585f; letter-spacing: -1.5px;'>"
			+ "#shopaddr#</span></td>"
			+ "</tr></table></td>"
			+ "</tr><tr>"
			+ "<td style='text-align: center; padding-bottom: 24px;'>"
			+ "<a href='http://#site#' target='_blank'>"
			+ "<img	src='https://img.fishapp.co.kr/img/shipb/btn_go3.png' alt='홈페이지 바로가기 Click' style='width: 100%;' /></a></td>"
			+ "</tr></table>";
	
    
    
}