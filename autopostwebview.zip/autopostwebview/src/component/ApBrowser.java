package component;

import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import org.w3c.dom.Document;
import org.w3c.dom.html.HTMLIFrameElement;

public class ApBrowser extends Region {
 
	public WebView browser = new WebView();
    public WebEngine webEngine = browser.getEngine();
    
    public static final String DEFAULT_JQUERY_MIN_VERSION = "1.7.2";
    public static final String JQUERY_LOCATION = "http://code.jquery.com/jquery-1.7.2.min.js";
    
    private Object executejQuery(final WebEngine engine, String minVersion, String jQueryLocation, String script) {
        return engine.executeScript(
          "(function(window, document, version, callback) { "
            + "var j, d;"
            + "var loaded = false;"
            + "if (!(j = window.jQuery) || version > j.fn.jquery || callback(j, loaded)) {"
            + "  var script = document.createElement(\"script\");"
            + "  script.type = \"text/javascript\";"
            + "  script.src = \"" + jQueryLocation + "\";"
            + "  script.onload = script.onreadystatechange = function() {"
            + "    if (!loaded && (!(d = this.readyState) || d == \"loaded\" || d == \"complete\")) {"
            + "      callback((j = window.jQuery).noConflict(1), loaded = true);"
            + "      j(script).remove();"
            + "    }"
            + "  };"
            + "  document.documentElement.childNodes[0].appendChild(script) "
            + "} "
          + "})(window, document, \"" + minVersion + "\", function($, jquery_loaded) {" + script + "});"
        );
      }
      
    public Object executejQuery(String script) {
        return executejQuery(webEngine, DEFAULT_JQUERY_MIN_VERSION, JQUERY_LOCATION, script);
    }
      
    
    public void setFormField(String name, String value)
    {
    	String str1 = "document.getElementsByName('" + name + "')[0].value='" + value.replace("'",  "\\'") + "'";
    	webEngine.executeScript(str1);
    }
        
    public void runScript(String str1)
    {
    	webEngine.executeScript(str1);
    }   

    public void test()
    {
    	Document doc = webEngine.getDocument();
    	HTMLIFrameElement iframeElement = (HTMLIFrameElement) doc.getElementsByTagName("iframe").item(0);
    	Document iframeContentDoc = iframeElement.getContentDocument();
    	System.out.println(iframeContentDoc.getTextContent());
    }
    
    public void setHTMLbyClassName(String className, String text)
    {
    	String str1 = "document.getElementsByClassName('" + className + "')[0].innerHTML = '" + text.replace("'",  "\\'") + "'";
    	//String str1 = "document.getElementsByTagName('body')[0].innerHTML = 'jjj'";
    	
    	webEngine.executeScript(str1);
    }
    
    public String getString(String str) 
    {
    	return (String) webEngine.executeScript(str);
    }
    
        
    public void submit(String str1)
    {
    	webEngine.executeScript(str1 + ".submit()");
    }

    public void loadPage(String url)
    {
        webEngine.load(url);
    }
     
    public ApBrowser() {
        getStyleClass().add("browser");
        getChildren().add(browser);
        
        String[] browserString = {
                "Mozilla/5.0 (Windows; U; Windows NT 6.3; ko; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8 IPMS/A640400A-14D460801A1-000000426571"
        		/*
        		,
                "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; IPMS/A640400A-14D460801A1-000000426571; TCO_20110131100426; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; Tablet PC 2.0)",
                "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.7 (KHTML, like Gecko) Chrome/7.0.517.44 Safari/534.7",
                "Mozilla/5.0 (Windows; U; Windows NT 6.1; ko-KR) AppleWebKit/533.18.1 (KHTML, like Gecko) Version/5.0.2 Safari/533.18.5",
                "Opera/9.80 (Windows NT 6.1; U; ko) Presto/2.6.30 Version/10.62",
                "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; GTB7.5; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
                "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
                "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
                "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
                "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; IPMS/2403160A-157B256A4A4-00000055034A; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; Tablet PC 2.0)",
                "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; InfoPath.2; Tablet PC 2.0)"
                */
};
        
        //int i = (int) Math.round(Math.random() * 12);
        
        webEngine.setUserAgent(browserString[0]);
    }
    
    private Node createSpacer() {
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        return spacer;
    }
 
    @Override protected void layoutChildren() {
        double w = getWidth();
        double h = getHeight();
        layoutInArea(browser,0,0,w,h,0, HPos.CENTER, VPos.CENTER);
    }
 
    @Override protected double computePrefWidth(double height) {
        return 750;
    }
 
    @Override protected double computePrefHeight(double width) {
        return 500;
    }
}