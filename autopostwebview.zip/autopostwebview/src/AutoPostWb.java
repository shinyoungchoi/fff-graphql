import component.ApBrowser;
import javafx.application.Application;
import javafx.concurrent.Worker.State;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
 
 
public class AutoPostWb extends Application {
    private Scene scene;
    
    private String _runState;
    
    @Override public void start(Stage stage) {
    	ApBrowser br = new ApBrowser();
    	
        stage.setTitle("Web View");
        scene = new Scene(br,1280,900, Color.web("#666970"));
        stage.setScene(scene);
        stage.show();
        
        WebEngine we = br.webEngine;
        
        we.getLoadWorker().stateProperty().addListener((ov,oldState,newState)->{
        	
        	if(newState==State.SUCCEEDED){
        		
        		System.out.println("state: succeeded -" + _runState);
        		
        		if (_runState == "Alogin")
        		{
        			_runState = "Alogin_end";                    
                    br.setFormField("user_id", "ksmlovekdk");
                    br.setFormField("password", "kdi101022");
                    br.submit("document.forms[2]");       			
        		}
        		else if (_runState == "Alogin_end")
        		{
        	        _runState = "Awrite";
        	        System.out.println(_runState);
        	        br.runScript("document.getElementById('view_width').value='768';");
        	        //br.setFormField("inputWeb", "https://img.fishapp.co.kr/coupang/H0001777GC.html");
        	       
        		}
        		else if (_runState == "Awrite")
        		{
        	        _runState = "Awrite_end";
        	        
        	        br.setFormField("title", "����");
        	        
        	        br.runScript("document.getElementsByTagName('iframe')[0].contentDocument.body.innerHTML = '" + "<font color=red>����</font><b>���</b>" + "'");

        	        br.runScript("document.getElementsByClassName('uploader__btn active')[0].click()");
        	        
        		}
        		else if (_runState == "Awrite_end")
        		{
        			_runState = "Awrite_exit";
        		}
            }
        });
        
        _runState = "Alogin";
        br.loadPage("https://www.iloveimg.com/html-to-image");
    }
 
    public static void main(String[] args){
        launch(args);
    }
}